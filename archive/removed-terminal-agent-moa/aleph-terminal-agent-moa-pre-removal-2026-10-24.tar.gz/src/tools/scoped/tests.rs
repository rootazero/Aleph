use super::*;
// HookExecutor + make_command_hook are only exercised by the cfg(unix) hook tests below.
#[cfg(unix)]
use crate::extension::hooks::HookExecutor;
#[cfg(unix)]
use crate::extension::{HookAction, HookConfig, HookEvent, HookKind, HookPriority};
use crate::sync_primitives::Arc as StdArc;
use crate::tools::runtime::{LoopTool, LoopToolRegistry, ToolResult as LoopToolResult};
use serde_json::{json, Value};
#[cfg(unix)]
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex as StdMutex;

// -------------------------------------------------------------------------
// Stubs
// -------------------------------------------------------------------------

/// A `LoopTool` whose name is set at construction time (owned `String`).
/// Used by deferred-tier tests that need two tools with distinct names.
struct NamedStub(String);
impl NamedStub {
    fn new(n: &str) -> Self {
        Self(n.to_string())
    }
}
#[async_trait::async_trait]
impl LoopTool for NamedStub {
    fn name(&self) -> &str {
        &self.0
    }
    fn description(&self) -> &str {
        "stub"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    // Declared parallel-safe so the tier tests keep their contrast: a GATE
    // (permission Ask / tier argument filter) forcing `Global` must be
    // distinguishable from the inner claim, which requires the ungated inner
    // claim to be `Shared`. (The trait default is fail-closed `false`.)
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        true
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success { output: json!({}) }
    }
}

/// Noop tool service stub used as `parent_tools` for SubagentTool in tests.
struct NoopParentTools;

#[async_trait::async_trait]
impl ToolService for NoopParentTools {
    async fn execute(&self, _name: &str, _input: Value) -> Result<ToolOutput, ToolError> {
        Err(ToolError::NotFound {
            name: "test".into(),
        })
    }
    async fn list(&self) -> Vec<ToolDefinition> {
        vec![]
    }
    async fn describe(&self, _: &str) -> Option<ToolDefinition> {
        None
    }
    fn metadata_schema(&self) -> Arc<[crate::tool_metadata::ToolDefinition]> {
        Arc::from([])
    }
}

fn in_mem_session() -> Arc<dyn crate::session::service::SessionService> {
    use crate::session::in_process::InProcessActorSessionService;
    use crate::session::store::{migrate_add_session_events, SessionEventStore, SqliteEventStore};
    let conn = rusqlite::Connection::open_in_memory().unwrap();
    migrate_add_session_events(&conn).unwrap();
    let store: Arc<dyn SessionEventStore> = Arc::new(SqliteEventStore::new(conn));
    Arc::new(InProcessActorSessionService::new(store))
}

struct StubTool {
    tool_name: &'static str,
}

#[async_trait::async_trait]
impl LoopTool for StubTool {
    fn name(&self) -> &str {
        self.tool_name
    }
    fn description(&self) -> &str {
        "stub"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    // Models a declared parallel-safe (read-only) tool; the trait default is
    // now fail-closed `false`, so safety must be explicit (`UnsafeStubTool`
    // below models the default/mutating side).
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        true
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success {
            output: json!({ "tool": self.tool_name }),
        }
    }
}

fn make_registry(names: &[&'static str]) -> Arc<LoopToolRegistry> {
    let mut r = LoopToolRegistry::new();
    for &name in names {
        r.register(Box::new(StubTool { tool_name: name }));
    }
    Arc::new(r)
}

// -------------------------------------------------------------------------
// Test 1: list filters by allowed set
// -------------------------------------------------------------------------
#[tokio::test]
async fn list_filters_by_allowed_set() {
    let registry = make_registry(&["read_file", "write_file"]);
    let allowed = ["read_file".to_string()].into_iter().collect();
    let svc = ScopedToolService::new(registry, allowed);

    let defs = svc.list().await;
    assert_eq!(defs.len(), 1);
    assert_eq!(defs[0].name, "read_file");
}

// -------------------------------------------------------------------------
// Test 1b: definition rewriter mutates description and schema
// -------------------------------------------------------------------------

/// Rewriter that prepends an "[AGENT-A]" marker and stamps a custom
/// `x-agent` field into the schema. Lets us assert the rewriter's
/// output reaches the LLM-facing path (both `list()` and the
/// `metadata_schema()` cache).
struct StampingRewriter;
impl ToolDefinitionRewriter for StampingRewriter {
    fn rewrite(&self, def: &mut ToolDefinition) {
        def.description = format!("[AGENT-A] {}", def.description);
        if let Some(obj) = def.input_schema.as_object_mut() {
            obj.insert("x-agent".into(), json!("agent-a"));
        }
    }
}

#[tokio::test]
async fn list_applies_definition_rewriter() {
    let registry = make_registry(&["read_file"]);
    let svc = ScopedToolService::new(registry, std::collections::BTreeSet::new())
        .with_definition_rewriter(Arc::new(StampingRewriter));

    let defs = svc.list().await;
    assert_eq!(defs.len(), 1);
    assert_eq!(defs[0].description, "[AGENT-A] stub");
    assert_eq!(defs[0].input_schema.get("x-agent"), Some(&json!("agent-a")));
}

#[tokio::test]
async fn describe_applies_definition_rewriter() {
    let registry = make_registry(&["read_file"]);
    let svc = ScopedToolService::new(registry, std::collections::BTreeSet::new())
        .with_definition_rewriter(Arc::new(StampingRewriter));

    let def = svc.describe("read_file").await.expect("present");
    assert_eq!(def.description, "[AGENT-A] stub");
}

#[test]
fn metadata_schema_reflects_rewriter_after_cache_bump() {
    // metadata_schema() caches its output; assert the bump-generation
    // helper actually re-runs the rewriter chain so callers can opt-in
    // to a fresh pass without rebuilding the whole service.
    let registry = make_registry(&["read_file"]);
    let svc = ScopedToolService::new(registry, std::collections::BTreeSet::new())
        .with_definition_rewriter(Arc::new(StampingRewriter));

    let first = svc.metadata_schema();
    assert_eq!(first[0].description, "[AGENT-A] stub");

    // A second call without bumping → cache hit, same Arc.
    let second = svc.metadata_schema();
    assert!(Arc::ptr_eq(&first, &second), "expected cached identity");

    // After an explicit bump the schema is recomputed (rewriter runs
    // again). Identity differs from the first; content stays correct.
    svc.bump_cache_generation();
    let third = svc.metadata_schema();
    assert!(!Arc::ptr_eq(&first, &third), "cache must invalidate");
    assert_eq!(third[0].description, "[AGENT-A] stub");
}

// -------------------------------------------------------------------------
// Test 2: list includes subagent tool when set
// -------------------------------------------------------------------------
#[tokio::test]
async fn list_includes_subagent_tool_when_set() {
    use crate::agents::background_tracker::BackgroundAgentTracker;
    use crate::agents::AgentRegistry;
    use crate::harness::chain_context::ChainContext;
    use crate::providers::adapter::{ProviderResponse, RequestPayload};
    use crate::providers::AiProvider;
    use std::future::Future;
    use std::pin::Pin;

    struct MockProvider;
    impl AiProvider for MockProvider {
        fn process<'a>(
            &'a self,
            _p: RequestPayload<'a>,
        ) -> Pin<Box<dyn Future<Output = crate::error::Result<ProviderResponse>> + Send + 'a>>
        {
            Box::pin(async { Ok(ProviderResponse::text_only("ok".into())) })
        }
        fn name(&self) -> &str {
            "mock"
        }
        fn color(&self) -> &str {
            "#000"
        }
    }

    let provider: Arc<dyn AiProvider> = Arc::new(MockProvider);
    let chain = ChainContext::new();
    let registry_arc = Arc::new(AgentRegistry::with_builtins());
    let tracker = Arc::new(BackgroundAgentTracker::new());
    let st = Arc::new(crate::agents::subagent_tool::SubagentTool::new(
        provider,
        chain,
        registry_arc,
        tracker,
        in_mem_session(),
        Arc::new(NoopParentTools),
    ));

    let registry = make_registry(&["read_file"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_subagent_tool(st);

    let defs = svc.list().await;
    let names: Vec<&str> = defs.iter().map(|d| d.name.as_str()).collect();
    assert!(
        names.contains(&"subagent"),
        "subagent must be in list; got: {:?}",
        names
    );

    // The subagent tool is attached beside the registry, so it never passed
    // through the metadata builder and shipped a hardcoded default: no
    // wall-clock budget → any delegation slower than the harness fallback
    // aborted the PARENT run. Both definition paths must carry the budget.
    let expected = crate::tools::budget::builtin_tool_budget_ms("subagent");
    assert!(expected.is_some(), "subagent must be in the budget table");
    let listed = defs.iter().find(|d| d.name == "subagent").expect("listed");
    assert_eq!(listed.metadata.max_duration_ms, expected);
    let described = svc.describe("subagent").await.expect("subagent described");
    assert_eq!(described.metadata.max_duration_ms, expected);
}

// -------------------------------------------------------------------------
// Test 2b: subagent survives a non-empty allow set (production path).
//
// Regression for the gateway run_loop wiring: `allowed_names` is built
// from the builtin tool registry's tool definitions, which never contains
// "subagent" (SubagentTool is attached on top of the registry). Before
// the is_allowed exemption, list / describe / execute / metadata_schema
// all silently dropped subagent whenever the allow set was non-empty —
// i.e. every real LLM-facing call.
// -------------------------------------------------------------------------
#[tokio::test]
async fn subagent_survives_non_empty_allow_set() {
    use crate::agents::background_tracker::BackgroundAgentTracker;
    use crate::agents::AgentRegistry;
    use crate::harness::chain_context::ChainContext;
    use crate::providers::adapter::{ProviderResponse, RequestPayload};
    use crate::providers::AiProvider;
    use std::future::Future;
    use std::pin::Pin;

    struct MockProvider;
    impl AiProvider for MockProvider {
        fn process<'a>(
            &'a self,
            _p: RequestPayload<'a>,
        ) -> Pin<Box<dyn Future<Output = crate::error::Result<ProviderResponse>> + Send + 'a>>
        {
            Box::pin(async { Ok(ProviderResponse::text_only("ok".into())) })
        }
        fn name(&self) -> &str {
            "mock"
        }
        fn color(&self) -> &str {
            "#000"
        }
    }

    let provider: Arc<dyn AiProvider> = Arc::new(MockProvider);
    let st = Arc::new(crate::agents::subagent_tool::SubagentTool::new(
        provider,
        ChainContext::new(),
        Arc::new(AgentRegistry::with_builtins()),
        Arc::new(BackgroundAgentTracker::new()),
        in_mem_session(),
        Arc::new(NoopParentTools),
    ));

    // Production-shaped allow set: only registry-known tool names, no
    // "subagent" entry — exactly what gateway run_loop produces.
    let registry = make_registry(&["read_file", "write_file"]);
    let allowed: BTreeSet<String> = ["read_file".into(), "write_file".into()].into();
    let svc = ScopedToolService::new(registry, allowed).with_subagent_tool(st);

    // (1) list() exposes subagent
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert!(
        names.iter().any(|n| n == "subagent"),
        "list() must expose subagent under non-empty allow set; got {:?}",
        names
    );

    // (2) describe() returns subagent (used when LLM probes the schema)
    assert!(
        svc.describe("subagent").await.is_some(),
        "describe(subagent) must return Some under non-empty allow set"
    );

    // (3) metadata_schema (LLM-facing) includes subagent
    let schema_names: Vec<String> = svc
        .metadata_schema()
        .iter()
        .map(|t| t.name.clone())
        .collect();
    assert!(
        schema_names.iter().any(|n| n == "subagent"),
        "metadata_schema must include subagent; got {:?}",
        schema_names
    );

    // (4) execute("subagent", …) is not rejected as NotFound by the
    //     allow-filter (mock provider lets the call complete).
    let result = svc.execute("subagent", json!({ "task": "ping" })).await;
    assert!(
        !matches!(&result, Err(ToolError::NotFound { name }) if name == "subagent"),
        "execute(subagent) must not be NotFound under non-empty allow set; got {:?}",
        result
    );
}

// -------------------------------------------------------------------------
// Test 4: execute routes to subagent tool by name
// -------------------------------------------------------------------------
#[tokio::test]
async fn execute_routes_to_subagent_tool_by_name() {
    use crate::agents::background_tracker::BackgroundAgentTracker;
    use crate::agents::AgentRegistry;
    use crate::harness::chain_context::ChainContext;
    use crate::providers::adapter::{ProviderResponse, RequestPayload};
    use crate::providers::AiProvider;
    use std::future::Future;
    use std::pin::Pin;

    struct MockProvider;
    impl AiProvider for MockProvider {
        fn process<'a>(
            &'a self,
            _p: RequestPayload<'a>,
        ) -> Pin<Box<dyn Future<Output = crate::error::Result<ProviderResponse>> + Send + 'a>>
        {
            Box::pin(async { Ok(ProviderResponse::text_only("subagent result".into())) })
        }
        fn name(&self) -> &str {
            "mock"
        }
        fn color(&self) -> &str {
            "#000"
        }
    }

    let provider: Arc<dyn AiProvider> = Arc::new(MockProvider);
    let chain = ChainContext::new();
    let registry_arc = Arc::new(AgentRegistry::with_builtins());
    let tracker = Arc::new(BackgroundAgentTracker::new());
    let st = Arc::new(crate::agents::subagent_tool::SubagentTool::new(
        provider,
        chain,
        registry_arc,
        tracker,
        in_mem_session(),
        Arc::new(NoopParentTools),
    ));

    // Registry has NO "subagent" tool — proves routing goes to st, not inner
    let registry = make_registry(&["read_file"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_subagent_tool(st);

    // A valid subagent call; the mock provider returns "subagent result"
    let result = svc
        .execute("subagent", json!({ "task": "do something" }))
        .await;
    assert!(
        result.is_ok(),
        "subagent execute should succeed; got: {:?}",
        result.err()
    );
}

// -------------------------------------------------------------------------
// Test 5 (was: execute applies hook decorator) was removed with the
// legacy `ToolHookDecorator` trait (see the audit at
// review-results/agents-batch-6/tools/summary.json finding #3).
// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
// Test 6: describe returns from filtered set (allowed / not-allowed)
// -------------------------------------------------------------------------
#[tokio::test]
async fn describe_returns_from_filtered_set() {
    let registry = make_registry(&["read_file", "write_file"]);
    let allowed = ["read_file".to_string()].into_iter().collect();
    let svc = ScopedToolService::new(registry, allowed);

    // Allowed tool: should return Some
    let def = svc.describe("read_file").await;
    assert!(def.is_some(), "read_file is allowed, must be found");
    assert_eq!(def.unwrap().name, "read_file");

    // Not-in-allowed tool: must return None
    let def = svc.describe("write_file").await;
    assert!(def.is_none(), "write_file is not in allowed set");

    // Totally unknown tool: must return None
    let def = svc.describe("nonexistent").await;
    assert!(def.is_none(), "unknown tool must return None");
}

// -------------------------------------------------------------------------
// Test 7: metadata_schema caches when no refresh signal
// -------------------------------------------------------------------------

#[test]
fn scoped_metadata_schema_caches_when_no_refresh_signal() {
    let registry = make_registry(&["a", "b"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    let s1 = svc.metadata_schema();
    let s2 = svc.metadata_schema();
    assert!(
        Arc::ptr_eq(&s1, &s2),
        "without refresh signal cache should hold across calls"
    );
    assert_eq!(s1.len(), 2);
}

// -------------------------------------------------------------------------
// Test 8: metadata_schema respects allowed filter
// -------------------------------------------------------------------------

#[test]
fn scoped_metadata_schema_respects_allowed_filter() {
    let registry = make_registry(&["a", "b"]);
    let mut allowed = BTreeSet::new();
    allowed.insert("a".to_string());
    let svc = ScopedToolService::new(registry, allowed);
    let s = svc.metadata_schema();
    assert_eq!(s.len(), 1);
    assert_eq!(s[0].name, "a");
}

// Health gate tests
// -------------------------------------------------------------------------

use crate::tool_metadata::{HealthReason, ProbeResult, ToolHealthProbe};
use std::borrow::Cow;

struct AlwaysDead;

#[async_trait::async_trait]
impl ToolHealthProbe for AlwaysDead {
    async fn probe(&self) -> ProbeResult {
        ProbeResult::Unhealthy {
            reason: HealthReason::DependencyDown(Cow::Borrowed("test fixture")),
            retry_after: None,
        }
    }
}

// -------------------------------------------------------------------------
// Extension HookExecutor wiring
// -------------------------------------------------------------------------

/// Capturing tool that echoes the input value it actually receives, so
/// tests can assert on hook-rewritten input flowing into the underlying
/// tool implementation.
struct EchoTool;

#[async_trait::async_trait]
impl LoopTool for EchoTool {
    fn name(&self) -> &str {
        "echo"
    }
    fn description(&self) -> &str {
        "echoes input"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success { output: input }
    }
}

fn echo_registry() -> Arc<LoopToolRegistry> {
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(EchoTool));
    Arc::new(r)
}

#[cfg(unix)]
fn make_command_hook(event: HookEvent, kind: HookKind, command: &str) -> HookConfig {
    HookConfig {
        event,
        kind,
        priority: HookPriority::Normal,
        matcher: None,
        actions: vec![HookAction::Command {
            command: command.to_string(),
        }],
        plugin_name: "test".to_string(),
        plugin_root: PathBuf::from("/tmp"),
        handler: None,
        timeout_secs: None,
        declared_event: None,
        scope_key: crate::extension::visibility::ScopeKey::Global,
    }
}

/// `apply_layer_two` always stringifies tool output (`Value::String`).
/// Tests that care about the structured shape parse it back here.
fn parse_tool_output(value: &Value) -> Value {
    match value {
        Value::String(s) => serde_json::from_str(s).unwrap_or_else(|_| value.clone()),
        other => other.clone(),
    }
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting / printf / '/tmp')
async fn before_tool_hook_block_returns_refused_by_hook() {
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        "echo 'block: blocked by policy'",
    )]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    match svc.execute("echo", json!({})).await {
        Err(ToolError::Refused {
            name,
            by: crate::tools::service::RefusedBy::Hook,
            reason,
        }) => {
            assert_eq!(name, "echo");
            assert!(
                reason.contains("blocked by policy"),
                "unexpected reason: {reason}"
            );
        }
        other => panic!("expected Refused by a hook, got: {other:?}"), // rust-doctor-disable-line panic-in-library
    }
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting / printf / '/tmp')
async fn before_tool_hook_deny_returns_permission_denied() {
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        "echo 'deny: hard policy stop'",
    )]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    match svc.execute("echo", json!({})).await {
        Err(ToolError::PermissionDenied { name, reason }) => {
            assert_eq!(name, "echo");
            assert!(
                reason.contains("hard policy stop"),
                "unexpected reason: {reason}"
            );
        }
        other => panic!("expected PermissionDenied from deny hook, got: {other:?}"), // rust-doctor-disable-line panic-in-library
    }
}

/// Names `.1` as the transcript of session `.0` and of nothing else.
#[cfg(unix)]
struct OneTranscript(&'static str, PathBuf);

#[cfg(unix)]
impl crate::extension::hooks::TranscriptSource for OneTranscript {
    fn transcript_path(&self, session_id: &str) -> Option<PathBuf> {
        (session_id == self.0).then(|| self.1.clone())
    }
}

/// A real tool call through the chokepoint hands its hooks the Claude Code
/// envelope on both faces: `permission_mode` from the tier the gate enforces
/// (the one fact this seam supplies), `cwd` / `$CLAUDE_PROJECT_DIR` /
/// `transcript_path` from what the run published (the executor derives
/// them), and — after the result budget has flattened the output to text —
/// the tool's own answer as a `tool_response` OBJECT.
#[cfg(unix)]
#[tokio::test]
async fn a_real_tool_call_hands_its_hooks_the_claude_code_envelope() {
    use crate::config::types::policies::ExecTier;
    let dir = tempfile::tempdir().unwrap();
    let project = tempfile::tempdir().unwrap();
    let transcript = dir.path().join("transcript.jsonl");
    let pre = dir.path().join("pre.json");
    let post = dir.path().join("post.json");
    let post_env = dir.path().join("post.env");
    let executor = Arc::new(HookExecutor::new(vec![
        make_command_hook(
            HookEvent::BeforeToolCall,
            HookKind::Interceptor,
            &format!("cat > '{}'", pre.display()),
        ),
        make_command_hook(
            HookEvent::AfterToolCall,
            HookKind::Observer,
            &format!("cat > '{}'; env > '{}'", post.display(), post_env.display()),
        ),
    ]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Full)
        .with_hook_executor(executor, "agent:main:main");
    crate::projects::with_project_root(
        Some(project.path().to_path_buf()),
        crate::extension::hooks::with_transcript_source(
            Some(Arc::new(OneTranscript(
                "agent:main:main",
                transcript.clone(),
            ))),
            svc.execute("echo", json!({"k": "v"})),
        ),
    )
    .await
    .expect("echo runs under Full");

    let project_dir = project.path().to_string_lossy().to_string();
    let read = |file: &PathBuf| -> Value {
        serde_json::from_str(&std::fs::read_to_string(file).expect("the hook ran")).unwrap()
    };
    for (face, seen) in [("PreToolUse", read(&pre)), ("PostToolUse", read(&post))] {
        assert_eq!(
            seen["permission_mode"],
            ExecTier::Full.cc_permission_mode(),
            "{face}"
        );
        assert_eq!(seen["cwd"], project_dir.as_str(), "{face}");
        assert_eq!(
            seen["transcript_path"],
            transcript.to_string_lossy().as_ref(),
            "{face}"
        );
        assert_eq!(seen["tool_input"], json!({"k": "v"}), "{face}");
    }
    assert_eq!(read(&post)["tool_response"], json!({"k": "v"}));
    let env = std::fs::read_to_string(&post_env).unwrap();
    assert!(
        env.lines()
            .any(|l| l == format!("CLAUDE_PROJECT_DIR={project_dir}")),
        "{env}"
    );
}

// -------------------------------------------------------------------------
// `HookEvent::PermissionDenied`: every `ToolError::PermissionDenied` leaving
// the chokepoint fires the observer. One test per deny arm, so a fire-site
// moved into a single arm goes red on the others.
// -------------------------------------------------------------------------

/// A `PermissionDenied` observer on `tool` that writes its stdin payload to a
/// file, and that file's path.
#[cfg(unix)]
fn permission_denied_probe(dir: &std::path::Path, tool: &str) -> (HookConfig, PathBuf) {
    let marker = dir.join(format!("{tool}.denied.json"));
    let mut hook = make_command_hook(
        HookEvent::PermissionDenied,
        HookKind::Observer,
        &format!("cat > '{}'", marker.display()),
    );
    hook.matcher = Some(tool.to_string());
    (hook, marker)
}

/// The observer saw THIS refusal: its tool name and the exact reason the
/// model was handed.
#[cfg(unix)]
fn assert_denial_observed(marker: &std::path::Path, err: &ToolError) {
    let ToolError::PermissionDenied { name, reason } = err else {
        panic!("expected PermissionDenied, got {err:?}"); // rust-doctor-disable-line panic-in-library
    };
    let seen: Value = serde_json::from_str(
        &std::fs::read_to_string(marker).expect("the PermissionDenied observer ran"),
    )
    .unwrap();
    assert_eq!(seen["hook_event_name"], "permission_denied");
    assert_eq!(seen["tool_name"], name.as_str());
    assert_eq!(seen["env"]["DENY_REASON"], reason.as_str());
}

#[cfg(unix)]
fn guest_turn(session: &str) -> crate::tools::turn_context::TurnContext {
    crate::tools::turn_context::TurnContext {
        session_key: crate::routing::session_key::SessionKey::main(session),
        run_id: String::new(),
        channel_id: String::new(),
        conversation_id: String::new(),
        caller_role: Some("guest".to_string()),
        channel_tool_permissions: None,
        unattended: false,
        plan_gate: None,
        side_question: false,
        telecom_authority: None,
    }
}

/// Arm 1: the `deny_rule` gate (here an explicit `[policies.tool_permissions]`
/// entry) — the refusal no hook could witness before this event existed.
#[cfg(unix)]
#[tokio::test]
async fn a_policy_denial_fires_the_permission_denied_observer() {
    let dir = tempfile::tempdir().unwrap();
    let (probe, marker) = permission_denied_probe(dir.path(), "echo");
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_tool_permissions(crate::config::types::policies::ToolPermissionsConfig {
            default: crate::extension::PermissionAction::Allow,
            overrides: std::collections::HashMap::from([(
                "echo".to_string(),
                crate::extension::PermissionAction::Deny,
            )]),
        })
        .with_hook_executor(Arc::new(HookExecutor::new(vec![probe])), "test-session");
    let err = svc.execute("echo", json!({})).await.unwrap_err();
    assert_denial_observed(&marker, &err);
}

/// Arm 2: the operator gate, where the operator answered no.
#[cfg(unix)]
#[tokio::test]
async fn an_operator_refusal_fires_the_permission_denied_observer() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let dir = tempfile::tempdir().unwrap();
    let (probe, marker) = permission_denied_probe(dir.path(), "cron_manage");
    let svc = ScopedToolService::new(make_registry(&["cron_manage"]), BTreeSet::new())
        .with_turn_context(guest_turn("p44-operator-refused"))
        .with_config_approval(Arc::new(StubApprover(ApprovalOutcome::Denied)))
        .with_hook_executor(Arc::new(HookExecutor::new(vec![probe])), "test-session");
    let err = svc.execute("cron_manage", json!({})).await.unwrap_err();
    assert_denial_observed(&marker, &err);
}

/// Arm 3: the operator gate with no approval channel (refused unasked).
#[cfg(unix)]
#[tokio::test]
async fn an_unaskable_operator_gate_fires_the_permission_denied_observer() {
    let dir = tempfile::tempdir().unwrap();
    let (probe, marker) = permission_denied_probe(dir.path(), "cron_manage");
    let svc = ScopedToolService::new(make_registry(&["cron_manage"]), BTreeSet::new())
        .with_turn_context(guest_turn("p44-operator-unaskable"))
        .with_hook_executor(Arc::new(HookExecutor::new(vec![probe])), "test-session");
    let err = svc.execute("cron_manage", json!({})).await.unwrap_err();
    assert_denial_observed(&marker, &err);
}

/// Arm 4: a BeforeToolCall hook's `deny:` — one hook's verdict, witnessed by
/// another.
#[cfg(unix)]
#[tokio::test]
async fn a_hook_deny_fires_the_permission_denied_observer() {
    let dir = tempfile::tempdir().unwrap();
    let (probe, marker) = permission_denied_probe(dir.path(), "echo");
    let deny = make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        "echo 'deny: hard policy stop'",
    );
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new()).with_hook_executor(
        Arc::new(HookExecutor::new(vec![deny, probe])),
        "test-session",
    );
    let err = svc.execute("echo", json!({})).await.unwrap_err();
    assert_denial_observed(&marker, &err);
}

/// The other direction of the gate (判据 §14): a call that succeeds, and one
/// refused as something other than `PermissionDenied`, never fire it. A hook
/// `block:` is such a refusal: the model reads it as a policy refusal (kind
/// `permission`), but it is not a `PermissionDenied` — a hook's verdict does
/// not re-fire hooks.
#[cfg(unix)]
#[tokio::test]
async fn only_a_permission_denied_fires_the_permission_denied_observer() {
    let dir = tempfile::tempdir().unwrap();
    let (probe, marker) = permission_denied_probe(dir.path(), "echo");
    let allowed = ScopedToolService::new(echo_registry(), BTreeSet::new()).with_hook_executor(
        Arc::new(HookExecutor::new(vec![probe.clone()])),
        "test-session",
    );
    allowed
        .execute("echo", json!({}))
        .await
        .expect("an allowed call succeeds");
    let block = make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        "echo 'block: not now'",
    );
    let blocked = ScopedToolService::new(echo_registry(), BTreeSet::new()).with_hook_executor(
        Arc::new(HookExecutor::new(vec![block, probe])),
        "test-session",
    );
    let err = blocked.execute("echo", json!({})).await.unwrap_err();
    assert!(
        matches!(
            err,
            ToolError::Refused {
                by: crate::tools::service::RefusedBy::Hook,
                ..
            }
        ),
        "{err:?}"
    );
    assert_eq!(
        err.kind(),
        crate::tools::error_kind::ToolErrorKind::Permission,
        "{err:?}"
    );
    assert!(
        !marker.exists(),
        "neither a success nor a hook block is a permission denial"
    );
}

/// This seam hands a REFUSED call's raw arguments to hooks, together with a
/// reason that quotes the policy table in backticks. A `PermissionDenied`
/// hook using both the natural way (`"$DENY_REASON"`, `"$ARGUMENTS"`) must
/// receive them as data: the refused call's `$(…)` does not run there.
#[cfg(unix)]
#[tokio::test]
async fn a_refused_calls_arguments_and_reason_reach_the_hook_as_data() {
    let dir = tempfile::tempdir().unwrap();
    let marker = dir.path().join("M");
    let (reason_out, args_out) = (dir.path().join("reason"), dir.path().join("args"));
    let hook = make_command_hook(
        HookEvent::PermissionDenied,
        HookKind::Observer,
        &format!(
            r#"printf '%s\n' "$DENY_REASON" > '{}'; printf '%s' "$ARGUMENTS" > '{}'"#,
            reason_out.display(),
            args_out.display()
        ),
    );
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_tool_permissions(crate::config::types::policies::ToolPermissionsConfig {
            default: crate::extension::PermissionAction::Allow,
            overrides: std::collections::HashMap::from([(
                "echo".to_string(),
                crate::extension::PermissionAction::Deny,
            )]),
        })
        .with_hook_executor(Arc::new(HookExecutor::new(vec![hook])), "test-session");
    let input = json!({ "x": format!("$(touch {})", marker.display()) });
    let err = svc.execute("echo", input.clone()).await.unwrap_err();
    let ToolError::PermissionDenied { reason, .. } = &err else {
        panic!("expected PermissionDenied, got {err:?}"); // rust-doctor-disable-line panic-in-library
    };
    assert!(
        reason.contains('`'),
        "premise: the policy reason quotes in backticks: {reason}"
    );
    assert!(
        !marker.exists(),
        "the refused call's `$(…)` ran in the hook"
    );
    let read = |p: &PathBuf| std::fs::read_to_string(p).expect("the hook ran");
    assert_eq!(read(&reason_out), format!("{reason}\n"));
    assert_eq!(read(&args_out), input.to_string());
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting / printf / '/tmp')
async fn before_tool_hook_update_input_rewrites_args() {
    // Hook rewrites the tool input to a fixed JSON value. The EchoTool
    // returns whatever input it receives, so we can assert by reading the
    // tool output.
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        r#"echo 'update_input: {"path":"/etc/hosts","force":true}'"#,
    )]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    let output = svc
        .execute("echo", json!({ "path": "/tmp/original" }))
        .await
        .expect("execute should succeed when hook only rewrites input");
    // Layer 2 stringifies tool output; parse it back to inspect fields.
    let parsed = parse_tool_output(&output.value);
    assert_eq!(parsed["path"], json!("/etc/hosts"));
    assert_eq!(parsed["force"], json!(true));
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting)
async fn execute_with_cancel_effective_returns_rewritten_input() {
    // The narrow capture contract (task #4): `execute_with_cancel_effective`
    // must surface the POST-hook input the handler actually ran with — not the
    // pre-hook dispatch input. A BeforeToolCall `update_input:` rewrite is the
    // canonical case: the call crosses the dispatch line with the rewritten
    // value, so the marker must be `Some(rewritten)`.
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        r#"echo 'update_input: {"path":"/etc/hosts","force":true}'"#,
    )]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    let (result, effective) = svc
        .execute_with_cancel_effective(
            "echo",
            json!({ "path": "/tmp/original" }),
            CancellationToken::new(),
        )
        .await;

    assert!(result.is_ok(), "rewritten call should succeed: {result:?}");
    assert_eq!(
        effective,
        Some(json!({ "path": "/etc/hosts", "force": true })),
        "the marker must carry the value the handler actually ran with"
    );
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting)
async fn execute_with_cancel_effective_is_none_when_hook_denies() {
    // fail-closed: a blocked/guardrailed call never reaches the dispatch line,
    // so it must not produce a replay-eligible marker.
    let deny = make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        "echo 'deny: hard policy stop'",
    );
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(Arc::new(HookExecutor::new(vec![deny])), "test-session");

    let (result, effective) = svc
        .execute_with_cancel_effective(
            "echo",
            json!({ "path": "/tmp/x" }),
            CancellationToken::new(),
        )
        .await;

    assert!(result.is_err(), "denied call must refuse: {result:?}");
    assert_eq!(
        effective, None,
        "a denied call must not produce a replay-eligible marker"
    );
}

#[tokio::test]
async fn execute_with_cancel_effective_is_some_of_input_without_hooks() {
    // Without hooks the effective input is exactly the dispatched input, so a
    // marker is still producible — but only because the call crossed the
    // dispatch line.
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new());

    let (result, effective) = svc
        .execute_with_cancel_effective(
            "echo",
            json!({ "path": "/tmp/x" }),
            CancellationToken::new(),
        )
        .await;

    assert!(result.is_ok(), "plain call should succeed: {result:?}");
    assert_eq!(
        effective,
        Some(json!({ "path": "/tmp/x" })),
        "without hooks the effective input is exactly the dispatched input"
    );
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting / printf / '/tmp')
async fn before_tool_hook_context_wraps_tool_output_for_llm() {
    // BeforeToolCall hook emits `context:` lines. Historically these
    // landed in `HookResult.additional_contexts` but nothing consumed
    // them — the LLM never saw them. This test guards the wiring fix
    // (scoped.rs wraps them as `<system-reminder>` blocks on the tool
    // output value so they reach the model next turn).
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        "echo 'context: file auto-formatted'\necho 'context: lint passed'",
    )]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    let output = svc
        .execute("echo", json!({ "path": "/tmp/x" }))
        .await
        .expect("execute should succeed");
    let s = output
        .value
        .as_str()
        .expect("hook contexts wrap result as a string");
    assert!(
        s.contains("<system-reminder>"),
        "missing reminder wrapper: {s}"
    );
    assert!(
        s.contains("file auto-formatted"),
        "missing context line: {s}"
    );
    assert!(s.contains("lint passed"), "missing context line: {s}");
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting / printf / '/tmp')
async fn after_tool_hook_observer_fires_on_success() {
    // Observer writes the tool name to a tempfile so we can prove it
    // fired with the right context. Run inside a per-test tempdir to
    // avoid interference when tests run in parallel.
    let dir = tempfile::tempdir().expect("create tempdir");
    let marker = dir.path().join("after.flag");
    let marker_str = marker.to_string_lossy().to_string();
    let cmd = format!(r#"printf '%s' "$TOOL_NAME" > '{marker_str}'"#);
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::AfterToolCall,
        HookKind::Observer,
        &cmd,
    )]));
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    let _ = svc
        .execute("echo", json!({}))
        .await
        .expect("execute should succeed");

    let contents = tokio::fs::read_to_string(&marker)
        .await
        .expect("observer must have written marker");
    assert_eq!(contents.trim(), "echo");
}

#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh (echo quoting / printf / '/tmp')
async fn after_tool_failure_hook_fires_when_tool_errors() {
    // Construct a registry with a tool that always errors.
    struct ErrTool;
    #[async_trait::async_trait]
    impl LoopTool for ErrTool {
        fn name(&self) -> &str {
            "boom"
        }
        fn description(&self) -> &str {
            "always errors"
        }
        fn schema(&self) -> Value {
            json!({ "type": "object" })
        }
        async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
            LoopToolResult::Error {
                error: "kaboom".to_string(),
                retryable: false,
            }
        }
    }
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(ErrTool));
    let registry = Arc::new(r);

    let dir = tempfile::tempdir().expect("create tempdir");
    let marker = dir.path().join("fail.flag");
    let marker_str = marker.to_string_lossy().to_string();
    let cmd = format!(r#"printf '%s' "$TOOL_NAME" > '{marker_str}'"#);
    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::AfterToolCallFailure,
        HookKind::Observer,
        &cmd,
    )]));
    let svc = ScopedToolService::new(registry, BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    let err = svc
        .execute("boom", json!({}))
        .await
        .expect_err("tool returns error");
    assert!(matches!(err, ToolError::Execution { .. }));

    let contents = tokio::fs::read_to_string(&marker)
        .await
        .expect("failure observer must have written marker");
    assert_eq!(contents.trim(), "boom");
}

#[tokio::test]
async fn no_hooks_means_no_change_in_behaviour() {
    // Sanity: without `.with_hook_executor`, ScopedToolService behaves
    // identically to before (regression guard).
    let svc = ScopedToolService::new(echo_registry(), BTreeSet::new());
    let out = svc
        .execute("echo", json!({ "k": "v" }))
        .await
        .expect("execute succeeds");
    // Layer 2 stringifies tool output; parse it back to compare structurally.
    assert_eq!(parse_tool_output(&out.value), json!({ "k": "v" }));
}

#[tokio::test]
async fn list_strips_unhealthy_tools() {
    let registry = make_registry(&["alive", "dead"]);
    let health = Arc::new(ToolHealthCache::new());
    health.register_probe("dead", Arc::new(AlwaysDead));
    health.refresh("dead").await;
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_health(health);
    let defs = svc.list().await;
    let names: Vec<&str> = defs.iter().map(|d| d.name.as_str()).collect();
    assert!(names.contains(&"alive"));
    assert!(!names.contains(&"dead"), "got: {names:?}");
}

#[test]
fn metadata_schema_strips_unhealthy_tools_and_invalidates_on_flip() {
    // Driven sync from outside an async runtime — populate the cache via
    // a small block_on island.
    let registry = make_registry(&["alive", "dead"]);
    let health = Arc::new(ToolHealthCache::new());
    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    rt.block_on(async {
        health.register_probe("dead", Arc::new(AlwaysDead));
        health.refresh("dead").await;
    });
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_health(Arc::clone(&health));

    let s1 = svc.metadata_schema();
    let names: Vec<&str> = s1.iter().map(|d| d.name.as_str()).collect();
    assert!(names.contains(&"alive"));
    assert!(!names.contains(&"dead"), "first call should strip dead");

    // Flip "dead" healthy via invalidation; the schema cache must
    // invalidate so the next call surfaces "dead" again.
    health.invalidate_all();
    let s2 = svc.metadata_schema();
    assert!(
        !Arc::ptr_eq(&s1, &s2),
        "cache must rotate when health generation flips"
    );
    let names2: Vec<&str> = s2.iter().map(|d| d.name.as_str()).collect();
    assert!(
        names2.contains(&"dead"),
        "after invalidation, dead reappears; got: {names2:?}"
    );
}

// -------------------------------------------------------------------------
// CRITICAL-1 — describe() populates per-tool budget + idempotency metadata
// from the static tables, so the harness's per-tool wall-clock budget can
// actually fire (it was always `None` while metadata was hardcoded default).
// -------------------------------------------------------------------------
#[tokio::test]
async fn describe_populates_builtin_budget_metadata() {
    // `memory_search` is in BUILTIN_TOOL_BUDGETS_MS (5_000ms) and is a
    // declared pure read (`is_idempotent_builtin_name`).
    let registry = make_registry(&["memory_search"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    let def = svc.describe("memory_search").await.expect("tool present");
    assert_eq!(def.metadata.max_duration_ms, Some(5_000));
    assert!(def.metadata.idempotent);
}

#[tokio::test]
async fn describe_falls_back_to_the_default_budget_for_untabled_tool() {
    // A tool absent from the table used to advertise `None`, which the harness
    // read as "no per-tool budget" and escalated into a run-level StalledTurn
    // abort. Every definition now carries a budget, so a slow call is a
    // recoverable tool error instead.
    let registry = make_registry(&["some_custom_tool"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    let def = svc
        .describe("some_custom_tool")
        .await
        .expect("tool present");
    assert_eq!(
        def.metadata.max_duration_ms,
        Some(crate::tools::budget::DEFAULT_TOOL_BUDGET_MS)
    );
    assert!(!def.metadata.idempotent);
}

/// A `LoopTool` that declares its own wall-clock budget — the seam MCP tools
/// use to surface their owning server's configured request timeout.
struct SelfBudgetedTool;

#[async_trait::async_trait]
impl LoopTool for SelfBudgetedTool {
    fn name(&self) -> &str {
        "self_budgeted"
    }
    fn description(&self) -> &str {
        "declares its own budget"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success { output: json!({}) }
    }
    fn max_duration_ms(&self) -> Option<u64> {
        Some(777_000)
    }
}

#[tokio::test]
async fn declared_budget_wins_over_the_table_and_the_default() {
    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(SelfBudgetedTool));
    let svc = ScopedToolService::new(Arc::new(registry), BTreeSet::new());
    let def = svc.describe("self_budgeted").await.expect("tool present");
    assert_eq!(def.metadata.max_duration_ms, Some(777_000));
    // list() and metadata_schema() rebuild definitions separately from
    // describe(); a budget that only reaches one of them is a budget the
    // harness may still miss.
    let listed = svc.list().await;
    let listed = listed
        .iter()
        .find(|d| d.name == "self_budgeted")
        .expect("listed");
    assert_eq!(listed.metadata.max_duration_ms, Some(777_000));
}

#[tokio::test]
async fn every_listed_definition_carries_a_budget() {
    // The invariant the harness depends on: no definition leaving the
    // registry may be unbudgeted, whatever its provenance.
    let registry = make_registry(&["memory_search", "bash", "ask_user", "some_custom_tool"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    for def in svc.list().await {
        assert!(
            def.metadata.max_duration_ms.is_some(),
            "tool {} left the registry without a wall-clock budget",
            def.name
        );
    }
}

// -------------------------------------------------------------------------
// call_concurrency_claim — dispatch parallelism query
// -------------------------------------------------------------------------

/// A LoopTool that always reports false for parallel safety, for tests
/// that need to see the harness route around the fast path.
struct UnsafeStubTool;

#[async_trait::async_trait]
impl LoopTool for UnsafeStubTool {
    fn name(&self) -> &str {
        "unsafe_tool"
    }
    fn description(&self) -> &str {
        "stub that mutates shared state"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success {
            output: json!({"ok": true}),
        }
    }
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        false
    }
}

#[tokio::test]
async fn call_concurrency_claim_shared_for_safe_stub_tool() {
    // `StubTool` explicitly declares `is_concurrent_safe -> true` (the trait
    // default is now fail-closed `false`), so its declared safety flows
    // through the registry → ScopedToolService chain as a Shared claim.
    let registry = make_registry(&["safe_tool"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    assert!(matches!(
        svc.call_concurrency_claim("safe_tool", &json!({})).await,
        crate::tools::concurrency::ConcurrencyClaim::Shared
    ));
}

#[tokio::test]
async fn call_concurrency_claim_exclusive_for_unsafe_tool_override() {
    // Hand-rolled unsafe tool — propagates non-Shared claim through the
    // same chain.
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(UnsafeStubTool));
    let registry = Arc::new(r);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    assert!(!matches!(
        svc.call_concurrency_claim("unsafe_tool", &json!({})).await,
        crate::tools::concurrency::ConcurrencyClaim::Shared
    ));
}

#[tokio::test]
async fn call_concurrency_claim_exclusive_for_unknown_tool() {
    // Conservative default — the harness must not parallel-dispatch a
    // tool it cannot find a definition for.
    let registry = make_registry(&[]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    assert!(!matches!(
        svc.call_concurrency_claim("nope", &json!({})).await,
        crate::tools::concurrency::ConcurrencyClaim::Shared
    ));
}

#[tokio::test]
async fn call_concurrency_claim_exclusive_for_disallowed_tool() {
    // Tools outside the allow list are conservatively unsafe — the
    // harness's parallel fast-path scan should never see them as
    // candidates.
    let registry = make_registry(&["safe_tool", "other"]);
    let mut allowed = BTreeSet::new();
    allowed.insert("other".to_string());
    let svc = ScopedToolService::new(registry, allowed);
    assert!(!matches!(
        svc.call_concurrency_claim("safe_tool", &json!({})).await,
        crate::tools::concurrency::ConcurrencyClaim::Shared
    ));
    assert!(matches!(
        svc.call_concurrency_claim("other", &json!({})).await,
        crate::tools::concurrency::ConcurrencyClaim::Shared
    ));
}

#[tokio::test]
async fn list_propagates_concurrent_safe_flag_from_inner_tool() {
    // The metadata view served to gateway / inspection APIs should
    // surface the inner LoopTool's static parallel-safety hint.
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(StubTool {
        tool_name: "safe_tool",
    }));
    r.register(Box::new(UnsafeStubTool));
    let registry = Arc::new(r);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    let defs = svc.list().await;
    let safe = defs
        .iter()
        .find(|d| d.name == "safe_tool")
        .expect("safe_tool listed");
    let unsafe_def = defs
        .iter()
        .find(|d| d.name == "unsafe_tool")
        .expect("unsafe_tool listed");
    assert!(safe.metadata.concurrent_safe);
    assert!(!unsafe_def.metadata.concurrent_safe);
}

// -------------------------------------------------------------------------
// execute_with_cancel — opencode-parity AbortSignal end-to-end
// -------------------------------------------------------------------------

/// LoopTool that sleeps 5s on every call. Used to prove the cancel token
/// propagates from `ScopedToolService::execute_with_cancel` → `LoopToolRegistry`
/// → the resolved `LoopTool::execute` without ever firing the inner sleep.
struct SlowLoopTool;

#[async_trait::async_trait]
impl LoopTool for SlowLoopTool {
    fn name(&self) -> &str {
        "slow_tool"
    }
    fn description(&self) -> &str {
        "sleeps forever"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, cancel: CancellationToken) -> LoopToolResult {
        tokio::select! {
            biased;
            _ = cancel.cancelled() => LoopToolResult::Error {
                error: "cancelled cooperatively".into(),
                retryable: false,
            },
            _ = tokio::time::sleep(std::time::Duration::from_secs(5)) => LoopToolResult::Success {
                output: json!({"slept": true}),
            },
        }
    }
}

#[tokio::test]
async fn execute_with_cancel_short_circuits_inner_loop_tool() {
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(SlowLoopTool));
    let registry = Arc::new(r);
    let svc = ScopedToolService::new(registry, BTreeSet::new());

    let cancel = CancellationToken::new();
    let cancel_for_spawn = cancel.clone();
    tokio::spawn(async move {
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;
        cancel_for_spawn.cancel();
    });

    let started = std::time::Instant::now();
    let result = svc
        .execute_with_cancel("slow_tool", json!({}), cancel)
        .await;
    let elapsed = started.elapsed();

    // Must short-circuit well below the 5s inner sleep — cooperatively
    // via the tool's own `select!`, not via wrapper drop.
    assert!(
        elapsed < std::time::Duration::from_millis(500),
        "expected cancel to abort fast; took {elapsed:?}"
    );
    let err = result.expect_err("cancelled call should surface a ToolError");
    let msg = err.to_string();
    assert!(
        msg.contains("cancelled"),
        "expected cancellation error, got: {msg}"
    );
}

#[tokio::test]
async fn execute_with_cancel_runs_to_completion_when_token_never_fires() {
    // Sanity check: when the caller passes a never-fired token, the
    // tool's own `select!` lets it complete normally — i.e. the cancel
    // arm is biased but does not preempt a fresh token.
    struct InstantTool;
    #[async_trait::async_trait]
    impl LoopTool for InstantTool {
        fn name(&self) -> &str {
            "instant"
        }
        fn description(&self) -> &str {
            "returns immediately"
        }
        fn schema(&self) -> Value {
            json!({ "type": "object" })
        }
        async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
            LoopToolResult::Success {
                output: json!({"ok": true}),
            }
        }
    }

    let mut r = LoopToolRegistry::new();
    r.register(Box::new(InstantTool));
    let registry = Arc::new(r);
    let svc = ScopedToolService::new(registry, BTreeSet::new());

    let out = svc
        .execute_with_cancel("instant", json!({}), CancellationToken::new())
        .await
        .expect("never-fired token should let the tool complete");
    // ScopedToolService routes the inner JSON through `apply_layer_two`,
    // which can re-render the value as a JSON-encoded string for token
    // accounting. Accept either representation — what we care about
    // here is that the call ran to completion rather than being cancelled.
    let matches = match &out.value {
        serde_json::Value::Object(_) => out.value == json!({"ok": true}),
        serde_json::Value::String(s) => {
            serde_json::from_str::<Value>(s).ok() == Some(json!({"ok": true}))
        }
        _ => false,
    };
    assert!(matches, "unexpected output shape: {:?}", out.value);
}

// -------------------------------------------------------------------------
// Panic containment — a panicking tool body costs one call, not the batch.
// -------------------------------------------------------------------------

/// Panics on every call, with a message distinctive enough to prove the
/// payload survived the catch rather than being replaced by a placeholder.
struct PanickingTool;

#[async_trait::async_trait]
impl LoopTool for PanickingTool {
    fn name(&self) -> &str {
        "panicker"
    }
    fn description(&self) -> &str {
        "panics"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        true
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        panic!("tool body exploded: {}", 42);
    }
}

/// Sleeps before succeeding, so a batch sibling is genuinely in flight (not
/// merely queued) at the moment the panicking call unwinds, and flips a flag
/// on completion — a dropped future never reaches it.
struct SlowSiblingTool(StdArc<std::sync::atomic::AtomicBool>);

#[async_trait::async_trait]
impl LoopTool for SlowSiblingTool {
    fn name(&self) -> &str {
        "sibling"
    }
    fn description(&self) -> &str {
        "completes after a yield"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        true
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;
        self.0.store(true, Ordering::SeqCst);
        LoopToolResult::Success {
            output: json!({ "sibling": "done" }),
        }
    }
}

#[tokio::test]
async fn a_panicking_tool_body_becomes_an_attributed_per_call_error() {
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(PanickingTool));
    let svc = ScopedToolService::new(Arc::new(r), BTreeSet::new());

    let err = svc
        .execute("panicker", json!({}))
        .await
        .expect_err("a panicking tool body must resolve to an error, not unwind the caller");

    match &err {
        ToolError::Execution { name, cause } => {
            assert_eq!(
                name, "panicker",
                "the error must name the tool that panicked"
            );
            assert!(
                cause.contains("tool panicked"),
                "cause must say a panic happened, got: {cause}"
            );
            assert!(
                cause.contains("tool body exploded: 42"),
                "cause must carry the panic payload, got: {cause}"
            );
            // The synthesized error is built above `execute_inner`, so it has
            // to reach back into the same sanitizer; both fence halves prove
            // it did (a panic body is untrusted, unbounded text).
            assert!(
                cause.contains(crate::security::content_sanitizer::FENCE_OPEN_PREFIX)
                    && cause.contains(crate::security::content_sanitizer::FENCE_CLOSE_PREFIX),
                "panic body must be fenced like every other tool error, got: {cause}"
            );
        }
        other => panic!("expected ToolError::Execution, got: {other:?}"),
    }
    // Deterministic panics must not be respun into a second panic.
    assert!(!err.is_retryable(), "a panic is not a transient failure");
}

/// The documented PRICE of catching at the outermost seam.
///
/// `execute_with_cancel`'s `catch_unwind` sits above `execute_inner`, so the
/// unwind jumps over this call's post-hooks, ledger entry and artifact harvest.
/// That is a deliberate trade — a catch inside every gate stage would be the
/// alternative — and until now it was stated in one comment and nowhere else.
///
/// A cost recorded only in prose is one refactor away from being quietly paid
/// twice or quietly repaid: someone moves the seam, and nothing goes red either
/// way. So pin it, from both sides, because the absence half alone would stay
/// green against a hook that was simply never wired: the SAME service, the SAME
/// hooks, one tool that returns and one that panics.
///
/// Both post-hook events are registered, because the panic is above the fork
/// between them: `AfterToolCallFailure` is the arm a reader would expect to
/// still fire, and it does not either.
#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh
async fn a_panicking_call_skips_its_post_hooks_and_a_returning_one_does_not() {
    let dir = tempfile::tempdir().expect("create tempdir");
    let marker = dir.path().join("after.log");
    let marker_str = marker.to_string_lossy().to_string();
    let cmd = format!(r#"printf '%s\n' "$TOOL_NAME" >> '{marker_str}'"#);
    let executor = Arc::new(HookExecutor::new(vec![
        make_command_hook(HookEvent::AfterToolCall, HookKind::Observer, &cmd),
        make_command_hook(HookEvent::AfterToolCallFailure, HookKind::Observer, &cmd),
    ]));
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(EchoTool));
    r.register(Box::new(PanickingTool));
    let svc = ScopedToolService::new(Arc::new(r), BTreeSet::new())
        .with_hook_executor(executor, "test-session");

    // Presence: an ordinary call reaches its post-hook.
    svc.execute("echo", json!({}))
        .await
        .expect("the echo tool succeeds");
    let after_ok = tokio::fs::read_to_string(&marker).await.unwrap_or_default();
    assert_eq!(
        after_ok.split_whitespace().collect::<Vec<_>>(),
        vec!["echo"],
        "a returning call must reach its post-hook, or the absence below proves nothing"
    );

    // The ruled-out side: a panicking call reaches neither post-hook event.
    svc.execute("panicker", json!({}))
        .await
        .expect_err("a panicking tool body resolves to an error");
    let after_panic = tokio::fs::read_to_string(&marker).await.unwrap_or_default();
    assert_eq!(
        after_panic.split_whitespace().collect::<Vec<_>>(),
        vec!["echo"],
        "a panicking call added a post-hook line: the unwind no longer jumps over \
         this call's post-hooks (and with them its ledger entry and artifact \
         harvest). If that is intended, the comment at `execute_with_cancel`'s \
         catch_unwind is the only place this cost is written down — update it too."
    );
}

#[tokio::test]
async fn a_panicking_call_does_not_take_its_batch_siblings_down() {
    use futures::StreamExt;

    // Mirrors the Act phase: several tool futures polled by ONE task via
    // `stream::iter(..).buffer_unordered(n)`. Without containment the unwind
    // escapes that task and drop-cancels every sibling with it.
    let sibling_finished = StdArc::new(std::sync::atomic::AtomicBool::new(false));
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(SlowSiblingTool(sibling_finished.clone())));
    r.register(Box::new(PanickingTool));
    let svc = ScopedToolService::new(Arc::new(r), BTreeSet::new());

    // Sibling first so it is parked on its sleep when the panic fires.
    let calls = vec![
        svc.execute_with_cancel("sibling", json!({}), CancellationToken::new()),
        svc.execute_with_cancel("panicker", json!({}), CancellationToken::new()),
    ];
    let results: Vec<_> = futures::stream::iter(calls)
        .buffer_unordered(2)
        .collect()
        .await;

    assert_eq!(results.len(), 2, "both calls must report an outcome");
    assert!(
        sibling_finished.load(Ordering::SeqCst),
        "the sibling was dropped mid-flight instead of running to completion"
    );
    assert!(
        results.iter().any(|r| r.is_ok()),
        "the sibling's success must survive the panicking call"
    );
    assert!(
        results.iter().any(|r| matches!(
            r, Err(ToolError::Execution { name, .. }) if name == "panicker"
        )),
        "the panicking call must surface as its own attributed failure"
    );
}

// -------------------------------------------------------------------------
// Per-tool confirmation gate — `LoopTool::requires_confirmation()` honored
// by the dispatch gate.
// -------------------------------------------------------------------------

/// A tool that declares itself confirmation-required without being in any
/// hard-coded gateway list — the MCP / extension / skill opt-in path.
struct ConfirmTool;

#[async_trait::async_trait]
impl LoopTool for ConfirmTool {
    fn name(&self) -> &str {
        "danger"
    }
    fn description(&self) -> &str {
        "irreversible stub"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success {
            output: json!({ "ran": true }),
        }
    }
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        false
    }
    fn requires_confirmation(&self) -> bool {
        true
    }
}

/// Records every approval request (count + the actions the human was shown)
/// and returns a fixed outcome.
struct FakeRequester {
    outcome: crate::sandbox::exec_approval::gate::ApprovalOutcome,
    calls: AtomicUsize,
    seen: StdMutex<Vec<crate::sandbox::exec_approval::ApprovalAction>>,
}

impl FakeRequester {
    fn new(outcome: crate::sandbox::exec_approval::gate::ApprovalOutcome) -> Self {
        Self {
            outcome,
            calls: AtomicUsize::new(0),
            seen: StdMutex::new(Vec::new()),
        }
    }

    /// The summaries put in front of the human, in order.
    fn summaries(&self) -> Vec<String> {
        self.seen
            .lock()
            .unwrap()
            .iter()
            .map(|a| a.summary.clone())
            .collect()
    }

    /// The chain rule each card named, in order.
    fn rule_ids(&self) -> Vec<Option<&'static str>> {
        self.seen
            .lock()
            .unwrap()
            .iter()
            .map(|a| a.rule_id)
            .collect()
    }
}

#[async_trait::async_trait]
impl crate::sandbox::exec_approval::gate::ApprovalRequester for FakeRequester {
    async fn request_approval(
        &self,
        action: &crate::sandbox::exec_approval::ApprovalAction,
    ) -> crate::sandbox::exec_approval::gate::ApprovalResponse {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.seen.lock().unwrap().push(action.clone());
        self.outcome.into()
    }
}

fn confirm_registry() -> Arc<LoopToolRegistry> {
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(ConfirmTool));
    r.register(Box::new(StubTool { tool_name: "plain" }));
    Arc::new(r)
}

#[test]
fn registry_reports_per_tool_requires_confirmation() {
    let reg = confirm_registry();
    assert!(reg.requires_confirmation("danger"));
    assert!(!reg.requires_confirmation("plain"));
    // Unknown tool is conservatively not gated here (allowed-filter rejects it).
    assert!(!reg.requires_confirmation("nope"));
    // Alias resolution: dotted spelling still resolves to the same tool.
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(ConfirmTool));
    assert!(r.requires_confirmation("danger"));
}

#[tokio::test]
async fn declared_confirmation_tool_runs_when_approved() {
    let requester = StdArc::new(FakeRequester::new(
        crate::sandbox::exec_approval::gate::ApprovalOutcome::Approved,
    ));
    // Gating comes solely from the tool's own `requires_confirmation()`
    // declaration.
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_confirmation(StdArc::clone(&requester) as _);

    let out = svc
        .execute("danger", json!({}))
        .await
        .expect("approved → runs");
    let ran = match &out.value {
        Value::Object(_) => out.value == json!({"ran": true}),
        Value::String(s) => serde_json::from_str::<Value>(s).ok() == Some(json!({"ran": true})),
        _ => false,
    };
    assert!(ran, "unexpected output: {:?}", out.value);
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "gate must prompt once"
    );
}

#[tokio::test]
async fn an_expired_approval_card_is_not_a_refusal() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Timeout));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_confirmation(StdArc::clone(&requester) as _);

    let err = svc
        .execute("danger", json!({}))
        .await
        .expect_err("an unanswered card cannot run the tool");

    // The distinction is the whole point. A card nobody answered used to arrive
    // as a non-retryable `Execution` error reading "The user did not approve …
    // Do not retry" — which (a) told the model a lie about what the human did,
    // and (b) let the harness's cross-batch memo ban the call permanently,
    // contradicting `DenialLedger`, which deliberately drops a Timeout because
    // "an expired card is not a decision".
    assert!(
        matches!(err, ToolError::ApprovalExpired { .. }),
        "expected ApprovalExpired, got {err:?}"
    );
    assert!(
        err.is_retryable(),
        "an expired card must not be banned by the cross-batch failure memo"
    );
    let text = err.to_string();
    assert!(
        !text.contains("did not approve"),
        "must not speak an expiry as a refusal: {text}"
    );
}

/// Build a `TurnContext` with a unique `SessionKey` so each test isolates its
/// entry in the process-wide session approval memory.
/// `agent` MUST be unique per test.
///
/// `SessionKey::main` is deterministic, and the stores this key addresses — the
/// session approval memory and the denial ledger — are process-wide, with a
/// sticky session-pause flag. Two tests reusing one agent name therefore share a
/// bucket: a grant remembered by one satisfies the other's prompt, a denial
/// recorded by one auto-refuses the other, and three denials between them pause
/// both. The failures are order-dependent, so they surface as flakes, not as a
/// clean red test.
///
/// (The sandbox workspace tests get this for free — see `sid()` there, which
/// mints an ephemeral uuid. Here it rests on naming discipline.)
fn turn_ctx(agent: &str) -> crate::tools::turn_context::TurnContext {
    crate::tools::turn_context::TurnContext {
        session_key: crate::routing::session_key::SessionKey::main(agent),
        run_id: String::new(),
        channel_id: "test".to_string(),
        conversation_id: "conv".to_string(),
        caller_role: None,
        channel_tool_permissions: None,
        unattended: false,
        plan_gate: None,
        side_question: false,
        telecom_authority: None,
    }
}

#[tokio::test]
async fn session_grant_skips_reprompt_within_session() {
    // An "approve for session" must be remembered for the SAME call: the first
    // prompts, the second (identical arguments) is satisfied by the memory.
    let requester = StdArc::new(FakeRequester::new(
        crate::sandbox::exec_approval::gate::ApprovalOutcome::ApprovedForSession,
    ));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-session-grant"))
        .with_confirmation(StdArc::clone(&requester) as _);

    svc.execute("danger", json!({})).await.expect("first runs");
    svc.execute("danger", json!({})).await.expect("second runs");

    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "session grant must suppress the second prompt"
    );
}

/// The invariant the action-keyed grant exists for: "allow session" grants the
/// ACTION the user read, never the tool. Fails on a name-keyed store (1 call).
#[tokio::test]
async fn session_grant_does_not_carry_to_different_arguments() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::ApprovedForSession));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-grant-per-action"))
        .with_confirmation(StdArc::clone(&requester) as _);

    // The operator approves deleting a scratch file for the session…
    svc.execute(
        "file_ops",
        json!({"operation": "delete", "path": "/tmp/junk"}),
    )
    .await
    .expect("approved");
    // …which must NOT authorize deleting their home directory.
    svc.execute(
        "file_ops",
        json!({"operation": "delete", "path": "/home/u/Documents"}),
    )
    .await
    .expect("approved");

    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        2,
        "a session grant on one action must not authorize a different action of \
         the same tool — that is what threw away the tier's argument filter"
    );
}

/// The card must show WHAT will run. A `reason` that only names the tool is an
/// operator clicking "allow" on a string they cannot evaluate.
#[tokio::test]
async fn approval_card_carries_the_action_not_just_the_tool_name() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-card-content"))
        .with_confirmation(StdArc::clone(&requester) as _);

    svc.execute(
        "file_ops",
        json!({"operation": "delete", "path": "/home/u/Documents"}),
    )
    .await
    .expect("approved");

    let summaries = requester.summaries();
    assert_eq!(summaries.len(), 1);
    assert!(
        summaries[0].contains("delete") && summaries[0].contains("/home/u/Documents"),
        "the human must see the operation and the path: {}",
        summaries[0]
    );
}

/// Arguments reach a human-visible card and a log line — a credential in them
/// must not.
#[tokio::test]
async fn secrets_in_arguments_are_redacted_before_the_human_sees_them() {
    use crate::extension::PermissionAction;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    const KEY: &str = "sk-ant-api03-BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB";
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(make_registry(&["alpha"]), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-redact"))
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("alpha", PermissionAction::Ask)],
        ))
        .with_confirmation(StdArc::clone(&requester) as _);

    svc.execute("alpha", json!({ "token": KEY }))
        .await
        .expect("approved");

    let summaries = requester.summaries();
    assert_eq!(summaries.len(), 1);
    assert!(
        !summaries[0].contains(KEY),
        "a credential must never reach the approval card: {}",
        summaries[0]
    );
}

#[tokio::test]
async fn one_shot_approval_reprompts_each_call() {
    // A plain one-shot `Approved` is NOT remembered — every call re-prompts.
    let requester = StdArc::new(FakeRequester::new(
        crate::sandbox::exec_approval::gate::ApprovalOutcome::Approved,
    ));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-one-shot"))
        .with_confirmation(StdArc::clone(&requester) as _);

    svc.execute("danger", json!({})).await.expect("first runs");
    svc.execute("danger", json!({})).await.expect("second runs");

    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        2,
        "one-shot approval must re-prompt each call"
    );
}

#[tokio::test]
async fn declared_confirmation_tool_blocked_when_denied() {
    let requester = StdArc::new(FakeRequester::new(
        crate::sandbox::exec_approval::gate::ApprovalOutcome::Denied,
    ));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_confirmation(StdArc::clone(&requester) as _);

    match svc.execute("danger", json!({})).await {
        Err(ToolError::Refused {
            name,
            by: crate::tools::service::RefusedBy::Person,
            ..
        }) => assert_eq!(name, "danger"),
        other => panic!("denied confirmation must block, got: {other:?}"), // rust-doctor-disable-line panic-in-library
    }
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn declared_confirmation_tool_fails_closed_without_requester() {
    // No approval transport wired → confirm-required tool must fail closed,
    // never silently auto-run.
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new());
    match svc.execute("danger", json!({})).await {
        Err(ToolError::Refused {
            name,
            by: crate::tools::service::RefusedBy::NobodyAsked,
            reason: cause,
        }) => {
            assert_eq!(name, "danger");
            assert!(
                cause.contains("approval channel is available"),
                "unexpected cause: {cause}"
            );
            // The fail-closed message names the rule too, so a run that dies
            // here says which gate it died on rather than just "no channel".
            assert!(
                cause.contains("declares its own confirmation gate"),
                "unexpected cause: {cause}"
            );
        }
        other => panic!("expected a fail-closed refusal, got: {other:?}"), // rust-doctor-disable-line panic-in-library
    }
}

#[tokio::test]
async fn plain_tool_unaffected_by_confirmation_gate() {
    // A tool that does not declare requires_confirmation runs normally even
    // with no requester wired — the change is byte-identical for it.
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new());
    let out = svc
        .execute("plain", json!({}))
        .await
        .expect("plain tool runs");
    let ok = matches!(&out.value, Value::Object(_) | Value::String(_));
    assert!(ok, "plain tool should produce output");
}

#[tokio::test]
async fn declared_confirmation_tool_never_parallel() {
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new());
    assert!(
        !matches!(
            svc.call_concurrency_claim("danger", &json!({})).await,
            crate::tools::concurrency::ConcurrencyClaim::Shared
        ),
        "confirm-required tool must be forced onto the serial path"
    );
    assert!(
        matches!(
            svc.call_concurrency_claim("plain", &json!({})).await,
            crate::tools::concurrency::ConcurrencyClaim::Shared
        ),
        "plain concurrent-safe tool stays parallelizable"
    );
}

#[tokio::test]
async fn describe_surfaces_requires_approval_metadata() {
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new());
    let danger = svc.describe("danger").await.expect("danger described");
    assert!(
        danger.metadata.requires_approval,
        "describe() metadata must reflect the tool's requires_confirmation()"
    );
    let plain = svc.describe("plain").await.expect("plain described");
    assert!(!plain.metadata.requires_approval);
}

// -------------------------------------------------------------------------
// SESSION_ID scoping at the dispatch chokepoint.
//
// Regression: `code_exec` / `bash` / `code_check` refuse to run with
// "no active session context" because `current_session()` reads the
// `SESSION_ID` task-local, which the gateway path never scoped — only
// `TURN_CONTEXT` was scoped here. The dispatch chokepoint must scope BOTH
// from the turn's `session_key` so exec-class tools target the right
// per-session workspace instead of looping on a deterministic refusal.
// -------------------------------------------------------------------------

/// Tool that captures `current_session()` observed during `execute`.
struct SessionProbeTool {
    seen: StdArc<crate::sync_primitives::Mutex<Option<crate::session::service::SessionId>>>,
}

#[async_trait::async_trait]
impl LoopTool for SessionProbeTool {
    fn name(&self) -> &str {
        "session_probe"
    }
    fn description(&self) -> &str {
        "captures current_session() during execute"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        *self.seen.lock().unwrap_or_else(|e| e.into_inner()) =
            crate::sandbox::context::current_session();
        LoopToolResult::Success { output: json!({}) }
    }
}

#[tokio::test]
async fn execute_scopes_session_id_from_turn_context() {
    let seen = StdArc::new(crate::sync_primitives::Mutex::new(None));
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(SessionProbeTool { seen: seen.clone() }));
    let registry = Arc::new(reg);

    let sid = crate::routing::session_key::SessionKey::ephemeral("scoped-sess");
    let turn = crate::tools::turn_context::TurnContext {
        session_key: sid.clone(),
        run_id: String::new(),
        channel_id: String::new(),
        conversation_id: String::new(),
        caller_role: None,
        channel_tool_permissions: None,
        unattended: false,
        plan_gate: None,
        side_question: false,
        telecom_authority: None,
    };
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_turn_context(turn);

    svc.execute("session_probe", json!({}))
        .await
        .expect("probe executes");

    let captured = seen.lock().unwrap_or_else(|e| e.into_inner()).clone();
    assert_eq!(
        captured.as_ref(),
        Some(&sid),
        "execute must scope SESSION_ID from turn_context so exec-class tools see the session"
    );
}

/// Without a turn context there is no session to scope — exec-class tools
/// still fall back to the no-session policy. Locks in that the new scoping
/// is gated on `turn_context` being present and never invents a session.
#[tokio::test]
async fn execute_without_turn_context_leaves_session_unset() {
    let seen = StdArc::new(crate::sync_primitives::Mutex::new(Some(
        crate::routing::session_key::SessionKey::ephemeral("stale"),
    )));
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(SessionProbeTool { seen: seen.clone() }));
    let registry = Arc::new(reg);

    let svc = ScopedToolService::new(registry, BTreeSet::new());
    svc.execute("session_probe", json!({}))
        .await
        .expect("probe executes");

    let captured = seen.lock().unwrap_or_else(|e| e.into_inner()).clone();
    assert!(
        captured.is_none(),
        "no turn_context ⇒ no SESSION_ID scope; current_session() must be None"
    );
}

// -------------------------------------------------------------------------
// Config-tier authorization gate — chat-tier connections must be denied
// when they call operator-only (config-mutating) tools. Operator-tier and
// no-turn-context (internal/cron) runs must pass through unobstructed.
// -------------------------------------------------------------------------

#[tokio::test]
async fn chat_tier_blocked_from_config_tool() {
    use crate::routing::session_key::SessionKey;
    let registry = make_registry(&["cron_manage"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_turn_context(
        crate::tools::turn_context::TurnContext {
            // Distinct from every other test's key on purpose: `main()` is
            // deterministic, and the approval stores it keys (session memory +
            // denial ledger) are process-global with a sticky session-pause
            // flag. Two tests on one key share a bucket and go order-dependent.
            session_key: SessionKey::main("agent-cfg-chat-tier"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("guest".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        },
    );
    let err = svc.execute("cron_manage", json!({})).await.unwrap_err();
    assert!(
        matches!(err, ToolError::PermissionDenied { .. }),
        "chat tier must be denied config tool, got {err:?}"
    );
}

#[tokio::test]
async fn operator_tier_allowed_config_tool() {
    use crate::routing::session_key::SessionKey;
    let registry = make_registry(&["cron_manage"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new()).with_turn_context(
        crate::tools::turn_context::TurnContext {
            session_key: SessionKey::main("agent-cfg-operator-tier"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("operator".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        },
    );
    assert!(svc.execute("cron_manage", json!({})).await.is_ok());
}

#[tokio::test]
async fn no_turn_context_allows_config_tool() {
    let registry = make_registry(&["cron_manage"]);
    let svc = ScopedToolService::new(registry, BTreeSet::new());
    assert!(
        svc.execute("cron_manage", json!({})).await.is_ok(),
        "internal/non-gateway run (no turn context) must pass"
    );
}

// -------------------------------------------------------------------------
// Phase 2b: live operator sudo approval for chat-tier config tools.
//
// When `config_approval_requester` is wired, a chat-tier connection's
// attempt to run a config tool suspends for operator approval via
// `confirm_with_memory`. Approval → falls through to normal execution.
// Denial → `PermissionDenied`. No requester (None) → hard-reject (fail
// closed) — `chat_tier_blocked_from_config_tool` above already covers this.
// -------------------------------------------------------------------------

struct StubApprover(crate::sandbox::exec_approval::gate::ApprovalOutcome);

#[async_trait::async_trait]
impl crate::sandbox::exec_approval::gate::ApprovalRequester for StubApprover {
    async fn request_approval(
        &self,
        _action: &crate::sandbox::exec_approval::ApprovalAction,
    ) -> crate::sandbox::exec_approval::gate::ApprovalResponse {
        self.0.into()
    }
}

#[tokio::test]
async fn chat_tier_config_tool_approved_executes() {
    use crate::routing::session_key::SessionKey;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(StubTool {
        tool_name: "cron_manage",
    }));
    let svc = ScopedToolService::new(Arc::new(reg), BTreeSet::new())
        .with_turn_context(crate::tools::turn_context::TurnContext {
            // Distinct session key per test: confirm_with_memory writes to the
            // process-global denial_ledger / session_memory keyed by session, so
            // sharing a key across tests would let the `denied` test's ledger
            // entry auto-reject this one (order-dependent flake).
            session_key: SessionKey::main("cfg-approve-test"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("guest".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        })
        .with_config_approval(Arc::new(StubApprover(ApprovalOutcome::Approved)));
    assert!(
        svc.execute("cron_manage", json!({})).await.is_ok(),
        "operator-approved config tool must execute"
    );
}

#[tokio::test]
async fn chat_tier_config_tool_denied_rejected() {
    use crate::routing::session_key::SessionKey;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(StubTool {
        tool_name: "cron_manage",
    }));
    let svc = ScopedToolService::new(Arc::new(reg), BTreeSet::new())
        .with_turn_context(crate::tools::turn_context::TurnContext {
            session_key: SessionKey::main("cfg-deny-test"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("guest".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        })
        .with_config_approval(Arc::new(StubApprover(ApprovalOutcome::Denied)));
    let err = svc.execute("cron_manage", json!({})).await.unwrap_err();
    assert!(
        matches!(err, ToolError::PermissionDenied { .. }),
        "operator-denied config tool must be PermissionDenied, got {err:?}"
    );
}

/// A requester that denies WITH the human's stated reason attached, as the
/// channel bridge does for `/deny <reason>`.
struct ReasonedDenier(&'static str);

#[async_trait::async_trait]
impl crate::sandbox::exec_approval::gate::ApprovalRequester for ReasonedDenier {
    async fn request_approval(
        &self,
        _action: &crate::sandbox::exec_approval::ApprovalAction,
    ) -> crate::sandbox::exec_approval::gate::ApprovalResponse {
        crate::sandbox::exec_approval::gate::ApprovalResponse {
            outcome: crate::sandbox::exec_approval::gate::ApprovalOutcome::Denied,
            deny_reason: Some(self.0.to_string()),
        }
    }
}

/// `/deny <reason>` must reach the model verbatim: the human's own words are
/// the difference between a re-plan and a blind retry (hermes parity).
#[tokio::test]
async fn deny_reason_reaches_the_model_facing_error() {
    let requester = StdArc::new(ReasonedDenier("use the staging DB instead"));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_confirmation(StdArc::clone(&requester) as _);

    let err = svc
        .execute("danger", json!({}))
        .await
        .expect_err("denied → error");
    let text = err.to_string();
    assert!(
        text.contains("use the staging DB instead"),
        "the user's stated reason must be relayed verbatim, got: {text}"
    );
}

/// A tool that is BOTH operator-gated and confirm-gated, like the real
/// `vault_store` / `agent_delete` (in `OPERATOR_TOOLS` ∩
/// `CONFIRMATION_REQUIRED_TOOLS`).
struct OperatorConfirmTool;

#[async_trait::async_trait]
impl LoopTool for OperatorConfirmTool {
    fn name(&self) -> &str {
        "vault_store"
    }
    fn description(&self) -> &str {
        "operator + confirm gated stub"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success {
            output: json!({ "ran": true }),
        }
    }
    fn requires_confirmation(&self) -> bool {
        true
    }
}

/// One decision per call: when the operator gate has just approved this exact
/// call (`AllowOnce`, which writes nothing into session memory), the
/// confirmation gate must NOT re-prompt it. `vault_store` sits in both gate
/// sets, so without the skip the requester's own channel would be asked to
/// confirm the action the operator already read and authorized.
#[tokio::test]
async fn operator_approval_is_not_double_prompted_by_the_confirm_gate() {
    use crate::routing::session_key::SessionKey;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(OperatorConfirmTool));

    let operator = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    // If the confirm gate were consulted it would DENY — so a successful run
    // proves it was skipped, and the call counter proves it was never asked.
    let own_channel = StdArc::new(FakeRequester::new(ApprovalOutcome::Denied));

    let svc = ScopedToolService::new(Arc::new(reg), BTreeSet::new())
        .with_turn_context(crate::tools::turn_context::TurnContext {
            session_key: SessionKey::main("cfg-no-double-prompt"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("guest".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        })
        .with_config_approval(StdArc::clone(&operator) as _)
        .with_confirmation(StdArc::clone(&own_channel) as _);

    svc.execute("vault_store", json!({"key": "k", "value": "v"}))
        .await
        .expect("operator-approved call must run without a second prompt");
    assert_eq!(
        operator.calls.load(Ordering::SeqCst),
        1,
        "the operator gate must prompt exactly once"
    );
    assert_eq!(
        own_channel.calls.load(Ordering::SeqCst),
        0,
        "the confirm gate must not re-prompt a call the operator just approved"
    );
}

/// The skip is scoped to the operator-approved call path only: an
/// operator-tier caller passes the config gate WITHOUT an approval, so the
/// confirmation gate must still fire for it.
#[tokio::test]
async fn operator_tier_caller_still_hits_the_confirm_gate() {
    use crate::routing::session_key::SessionKey;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(OperatorConfirmTool));

    let own_channel = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(Arc::new(reg), BTreeSet::new())
        .with_turn_context(crate::tools::turn_context::TurnContext {
            session_key: SessionKey::main("cfg-operator-still-confirms"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("operator".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        })
        .with_confirmation(StdArc::clone(&own_channel) as _);

    svc.execute("vault_store", json!({"key": "k", "value": "v"}))
        .await
        .expect("approved confirm-gated call runs");
    assert_eq!(
        own_channel.calls.load(Ordering::SeqCst),
        1,
        "an operator-tier caller skipped the config gate, so the confirm gate must still ask"
    );
}

// =============================================================================
// Tool permission policy (`[policies.tool_permissions]`) gating
// =============================================================================

fn perms(
    default: crate::extension::PermissionAction,
    overrides: &[(&str, crate::extension::PermissionAction)],
) -> crate::config::types::policies::ToolPermissionsConfig {
    crate::config::types::policies::ToolPermissionsConfig {
        default,
        overrides: overrides
            .iter()
            .map(|(n, a)| ((*n).to_string(), *a))
            .collect(),
    }
}

#[tokio::test]
async fn deny_tool_hidden_from_list_and_describe() {
    use crate::extension::PermissionAction;
    let svc = ScopedToolService::new(make_registry(&["alpha", "beta"]), BTreeSet::new())
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("beta", PermissionAction::Deny)],
        ));
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert!(names.contains(&"alpha".to_string()));
    assert!(
        !names.contains(&"beta".to_string()),
        "Deny tool must be invisible to the LLM"
    );
    assert!(svc.describe("beta").await.is_none());
    // metadata_schema mirrors list().
    let schema = svc.metadata_schema();
    let schema_names: Vec<&str> = schema.iter().map(|d| d.name.as_str()).collect();
    assert!(!schema_names.contains(&"beta"));
}

#[tokio::test]
async fn deny_tool_execute_rejected_with_permission_denied() {
    use crate::extension::PermissionAction;
    let svc = ScopedToolService::new(make_registry(&["alpha", "beta"]), BTreeSet::new())
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("beta", PermissionAction::Deny)],
        ));
    let err = svc.execute("beta", json!({})).await.unwrap_err();
    assert!(
        matches!(err, ToolError::PermissionDenied { .. }),
        "policy-denied tool must be PermissionDenied, got {err:?}"
    );
    // Non-denied sibling still runs.
    assert!(svc.execute("alpha", json!({})).await.is_ok());
}

#[tokio::test]
async fn ask_tool_routes_through_confirmation_gate() {
    use crate::extension::PermissionAction;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(make_registry(&["alpha"]), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-perm-ask"))
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("alpha", PermissionAction::Ask)],
        ))
        .with_confirmation(StdArc::clone(&requester) as _);
    svc.execute("alpha", json!({}))
        .await
        .expect("approved Ask tool runs");
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "Ask policy must prompt exactly once"
    );
}

#[tokio::test]
async fn ask_tool_without_requester_fails_closed() {
    use crate::extension::PermissionAction;
    let svc = ScopedToolService::new(make_registry(&["alpha"]), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-perm-ask-closed"))
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("alpha", PermissionAction::Ask)],
        ));
    let err = svc.execute("alpha", json!({})).await.unwrap_err();
    assert!(
        matches!(
            err,
            ToolError::Refused {
                by: crate::tools::service::RefusedBy::NobodyAsked,
                ..
            }
        ),
        "Ask without approval transport must fail closed, got {err:?}"
    );
}

#[tokio::test]
async fn default_deny_exposes_only_explicit_allow() {
    use crate::extension::PermissionAction;
    let svc = ScopedToolService::new(make_registry(&["alpha", "beta"]), BTreeSet::new())
        .with_tool_permissions(perms(
            PermissionAction::Deny,
            &[("alpha", PermissionAction::Allow)],
        ));
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert_eq!(names, vec!["alpha".to_string()]);
    let err = svc.execute("beta", json!({})).await.unwrap_err();
    assert!(matches!(err, ToolError::PermissionDenied { .. }));
}

/// An `Ask`-gated tool keeps its inner claim and may join a parallel batch:
/// its approval card correlates via the ambient `CallIdentity` (exact per
/// call), so batch exclusivity is no longer the correlation crutch it used to
/// be — the card pends concurrently with its siblings' execution.
#[tokio::test]
async fn ask_policy_no_longer_serializes_the_claim() {
    use crate::extension::PermissionAction;
    let svc =
        ScopedToolService::new(make_registry(&["alpha"]), BTreeSet::new()).with_tool_permissions(
            perms(PermissionAction::Allow, &[("alpha", PermissionAction::Ask)]),
        );
    assert!(
        matches!(
            svc.call_concurrency_claim("alpha", &json!({})).await,
            crate::tools::concurrency::ConcurrencyClaim::Shared
        ),
        "an Ask-gated tool surfaces its inner claim — the execute-time gate \
         still fires, but it no longer forces batch exclusivity"
    );
}

#[tokio::test]
async fn no_policy_means_pre_wiring_behavior() {
    // Without `with_tool_permissions`, everything lists and executes —
    // byte-identical to the pre-wiring default for unconfigured installs.
    let svc = ScopedToolService::new(make_registry(&["alpha"]), BTreeSet::new());
    assert!(svc.describe("alpha").await.is_some());
    assert!(svc.execute("alpha", json!({})).await.is_ok());
}

// =============================================================================
// Exec tier at the enforcement chokepoint (`permission_for`).
//
// Every name below is one the registry can actually emit: MCP tools are
// registered as `{server_id}__{tool}` (`McpHandler::qualified_name`), builtins
// under their own names. A tier rule that only holds for invented names holds
// for nothing.
// =============================================================================

/// Registry over the names a tier test asserts about.
fn tier_registry() -> Arc<LoopToolRegistry> {
    let mut r = LoopToolRegistry::new();
    for name in [
        "bash",
        "file_ops",
        "system",
        "browser_evaluate",
        "github__create_issue",
        "slack__send_message",
        "search",
        "memory_search",
        "web_fetch",
        "agent_delete",
    ] {
        r.register(Box::new(NamedStub::new(name)));
    }
    Arc::new(r)
}

fn tiered(tier: crate::config::types::policies::ExecTier) -> ScopedToolService {
    ScopedToolService::new(tier_registry(), BTreeSet::new()).with_exec_tier(tier)
}

#[test]
fn ask_tier_asks_for_every_mutating_tool_the_glob_table_missed() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    let svc = tiered(ExecTier::Ask);
    for name in [
        // MCP tools — registered as `{server_id}__{tool}`, never `mcp__*`.
        "github__create_issue",
        "slack__send_message",
        // The whole browser family, including arbitrary JS in the user's
        // logged-in browser.
        "browser_evaluate",
        // Plain mutators.
        "system",
        "bash",
        "file_ops",
    ] {
        assert_eq!(
            svc.permission_for(name),
            PermissionAction::Ask,
            "`{name}` mutates — the Ask tier promises it stops for a human"
        );
    }
}

#[test]
fn ask_tier_is_fail_closed_for_an_unknown_tool() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    // A tool nobody has classified (not even registered) declares nothing →
    // non-idempotent → Ask. New tools are covered on arrival.
    assert_eq!(
        tiered(ExecTier::Ask).permission_for("brand_new_tool"),
        PermissionAction::Ask
    );
}

#[test]
fn ask_tier_leaves_declared_read_only_tools_allowed() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    let svc = tiered(ExecTier::Ask);
    for name in ["search", "memory_search", "web_fetch"] {
        assert_eq!(
            svc.permission_for(name),
            PermissionAction::Allow,
            "`{name}` is a declared pure read — the model must still investigate freely"
        );
    }
}

/// A registry-shaped MCP tool that declares its own idempotency, exactly as
/// `McpRegistryTool` does from the server's `readOnlyHint` / `idempotentHint`.
/// The builtin allowlist can never speak for a name like this.
struct DeclaringMcpStub {
    name: String,
    idempotent: bool,
}
#[async_trait::async_trait]
impl LoopTool for DeclaringMcpStub {
    fn name(&self) -> &str {
        &self.name
    }
    fn description(&self) -> &str {
        "mcp stub"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    fn is_idempotent(&self) -> bool {
        self.idempotent
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success { output: json!({}) }
    }
}

#[test]
fn ask_tier_honors_an_mcp_servers_read_only_declaration() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    // `tool_facts` must read idempotency off the DECLARATION seam, not off the
    // builtin name allowlist: neither of these names can ever appear there, so
    // a name-keyed lookup answers `false` for both and the Ask tier raises a
    // card on a pure-read docs search — the prompt fatigue that makes users
    // abandon the tier.
    let mut r = LoopToolRegistry::new();
    r.register(Box::new(DeclaringMcpStub {
        name: "docs__search".to_string(),
        idempotent: true,
    }));
    r.register(Box::new(DeclaringMcpStub {
        name: "docs__publish".to_string(),
        idempotent: false,
    }));
    let svc = ScopedToolService::new(Arc::new(r), BTreeSet::new()).with_exec_tier(ExecTier::Ask);

    assert_eq!(
        svc.permission_for("docs__search"),
        PermissionAction::Allow,
        "a server-declared readOnlyHint must reach the tier rule"
    );
    assert_eq!(
        svc.permission_for("docs__publish"),
        PermissionAction::Ask,
        "an MCP tool that declares nothing stays fail-closed"
    );
}

#[test]
fn auto_tier_only_guards_the_destructive_tail() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    let svc = tiered(ExecTier::Auto);
    assert_eq!(svc.permission_for("agent_delete"), PermissionAction::Ask);
    for name in ["bash", "file_ops", "github__create_issue", "search"] {
        assert_eq!(svc.permission_for(name), PermissionAction::Allow);
    }
}

#[test]
fn full_tier_asks_for_nothing() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    let svc = tiered(ExecTier::Full);
    for name in ["bash", "agent_delete", "github__create_issue", "system"] {
        assert_eq!(svc.permission_for(name), PermissionAction::Allow);
    }
}

#[test]
fn explicit_override_wins_over_the_tier_rule() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Ask)
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[
                // Named by the operator: a deliberate decision beats the tier.
                ("bash", PermissionAction::Allow),
                // A glob entry is explicit too.
                ("github__*", PermissionAction::Deny),
                // And an override can tighten a tool the tier left alone.
                ("search", PermissionAction::Deny),
            ],
        ));
    assert_eq!(svc.permission_for("bash"), PermissionAction::Allow);
    assert_eq!(
        svc.permission_for("github__create_issue"),
        PermissionAction::Deny
    );
    assert_eq!(svc.permission_for("search"), PermissionAction::Deny);
    // Everything the overrides don't name still answers to the tier.
    assert_eq!(
        svc.permission_for("browser_evaluate"),
        PermissionAction::Ask
    );
}

/// The tier TIGHTENS the operator's baseline; it never widens it. Before this
/// was folded into the restrictiveness lattice the tier was consulted BEFORE
/// the configured `default`, so its `Ask` verdict was returned first and a
/// `default = "deny"` install silently became ask-by-default for exactly the
/// dangerous half of the toolset — every tool the tier wanted to guard.
///
/// Production always wires a tier (`tool_service_builder`), so this — not the
/// `exec_tier: None` case — is the posture a deny-by-default operator gets.
#[tokio::test]
async fn exec_tier_never_widens_a_deny_default() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    for tier in [ExecTier::Ask, ExecTier::Auto, ExecTier::Full] {
        let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
            .with_exec_tier(tier)
            .with_tool_permissions(perms(
                PermissionAction::Deny,
                &[("search", PermissionAction::Allow)],
            ));
        // The destructive tail `Auto` would raise to `Ask`, and the mutating
        // body `Ask` would raise to `Ask`, both stay DENIED.
        for name in [
            "agent_delete",
            "bash",
            "file_ops",
            "system",
            "github__create_issue",
        ] {
            assert_eq!(
                svc.permission_for(name),
                PermissionAction::Deny,
                "{tier:?} must not widen a deny default for `{name}`"
            );
        }
        // ...and the box still exposes exactly the explicit allow.
        let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
        assert_eq!(names, vec!["search".to_string()]);
    }
}

/// An `Ask` baseline is a floor too: the tier cannot lower it back to `Allow`
/// for the read-only tools it has nothing to say about.
#[test]
fn exec_tier_never_widens_an_ask_default() {
    use crate::config::types::policies::ExecTier;
    use crate::extension::PermissionAction;
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Full)
        .with_tool_permissions(perms(PermissionAction::Ask, &[]));
    for name in ["search", "memory_search", "bash"] {
        assert_eq!(
            svc.permission_for(name),
            PermissionAction::Ask,
            "`{name}`: Full has nothing to say, so the operator's Ask baseline holds"
        );
    }
}

#[tokio::test]
async fn auto_tier_asks_before_a_destructive_file_ops_call() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-tier-fileops"))
        .with_confirmation(StdArc::clone(&requester) as _);

    // A read-shaped call runs untouched — `file_ops` is not destructive per se.
    svc.execute("file_ops", json!({"operation": "list", "path": "/tmp"}))
        .await
        .expect("list runs");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 0);

    // The delete hiding behind the same tool name does stop for a human.
    svc.execute("file_ops", json!({"operation": "delete", "path": "/tmp/x"}))
        .await
        .expect("approved delete runs");
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "Auto promises irreversible operations ask first — including `file_ops` delete"
    );
}

/// Approval gates no longer bleed into claims: an Auto-tier destructive
/// `file_ops` call (which WILL stop for a human at execute time) surfaces the
/// inner tool's declared claim — here the stub's `Shared` — instead of a
/// forced `Global`. Correlation is the ambient `CallIdentity` the harness
/// scopes per execute future, and the pending-approval store is a keyed map,
/// so concurrently-pending cards each stamp their own call id. (The REAL
/// `file_ops` per-argument path claims — same-path conflicts, disjoint-path
/// parallelism — are pinned in `registry_adapter`'s claim tests.)
#[tokio::test]
async fn tier_gated_destructive_file_ops_surface_the_inner_claim() {
    use crate::config::types::policies::ExecTier;
    use crate::tools::concurrency::ConcurrencyClaim;
    use crate::tools::service::ToolService;

    let svc = tiered(ExecTier::Auto);
    for op in ["delete", "move", "batch_move", "organize", "list"] {
        assert_eq!(
            svc.call_concurrency_claim("file_ops", &json!({"operation": op, "path": "/tmp/a"}))
                .await,
            ConcurrencyClaim::Shared,
            "`file_ops {op}` must surface the inner declared claim — gated or \
             not, the gate no longer forces Global"
        );
    }
}

/// The config-tier operator gate no longer bleeds into claims either: gated
/// or not, the inner declared claim flows through for every caller role. The
/// gate still fires at execute time (suspend-for-operator-approval); its
/// correlation rides the ambient `CallIdentity`, so it needs no batch
/// exclusivity. `cron_manage` is on `tool_requires_operator`'s list.
#[tokio::test]
async fn approval_gates_no_longer_force_global_claims() {
    use crate::tools::concurrency::ConcurrencyClaim;
    use crate::tools::service::ToolService;

    let ctx_with_role = |role: Option<&str>| crate::tools::turn_context::TurnContext {
        session_key: crate::routing::session_key::SessionKey::main("op-gate-test"),
        run_id: String::new(),
        channel_id: "test".to_string(),
        conversation_id: "conv".to_string(),
        caller_role: role.map(String::from),
        channel_tool_permissions: None,
        unattended: false,
        plan_gate: None,
        side_question: false,
        telecom_authority: None,
    };

    for role in [Some("guest"), Some("operator")] {
        let mut r = LoopToolRegistry::new();
        r.register(Box::new(NamedStub::new("cron_manage")));
        let svc = ScopedToolService::new(Arc::new(r), BTreeSet::new())
            .with_turn_context(ctx_with_role(role));
        assert_eq!(
            svc.call_concurrency_claim("cron_manage", &json!({})).await,
            ConcurrencyClaim::Shared,
            "the inner declared claim flows through regardless of caller role \
             ({role:?}) — approval gates correlate ambiently, not by batch \
             exclusivity"
        );
    }
}

/// Claims must judge the CANONICAL name, mirroring `execute_gated`: an alias
/// spelling (`file.ops`) must resolve to the same inner tool and yield the
/// same bounded claim the canonical spelling gets — otherwise the alias falls
/// to the conservative `Global` and over-serializes.
#[tokio::test]
async fn claims_judge_the_canonical_name_not_the_alias() {
    use crate::config::types::policies::ExecTier;
    use crate::tools::concurrency::ConcurrencyClaim;
    use crate::tools::service::ToolService;

    let svc = tiered(ExecTier::Auto);
    let input = json!({"operation": "delete", "path": "/tmp/a"});
    let via_alias = svc.call_concurrency_claim("file.ops", &input).await;
    let via_canonical = svc.call_concurrency_claim("file_ops", &input).await;
    assert_eq!(
        via_alias, via_canonical,
        "alias and canonical spellings must yield the same claim"
    );
    assert_ne!(
        via_alias,
        ConcurrencyClaim::global(),
        "…and that claim is the tool's bounded scope, not the conservative \
         fallback (which would make the equality vacuous)"
    );
}

/// The `unattended` fail-closed gate: a run nobody is watching (cron with no
/// origin channel, heartbeat, A2A delegation, goal/loop continuation) must
/// auto-deny a confirm-gated tool INSTEAD of publishing an approval card into
/// the void and parking on it until the 120 s timeout. The requester is wired
/// and would happily approve — the point is that it is never even asked.
#[tokio::test]
async fn unattended_run_auto_denies_a_confirm_gated_tool_without_prompting() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-unattended-deny"))
        .with_confirmation(StdArc::clone(&requester) as _)
        .with_unattended(true);

    // `agent_delete` is destructive → the Auto tier raises it to `Ask`.
    let err = svc.execute("agent_delete", json!({})).await.unwrap_err();
    assert!(
        matches!(
            err,
            ToolError::Refused {
                by: crate::tools::service::RefusedBy::NobodyAsked,
                ..
            }
        ),
        "an unattended confirm-gated call must fail closed, got {err:?}"
    );
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        0,
        "no card may be raised on a run with no human to answer it"
    );
    // An ungated tool still runs — the marker is a confirm-gate policy, not a
    // blanket freeze on autonomous work.
    assert!(svc.execute("search", json!({})).await.is_ok());
}

/// Every card names the rule that raised it, in the token the trail keys on.
///
/// `gate_chain`'s module doc has always called `GateRule::id` "the stable token
/// the ledger and the tests key on" — and only the tests did. A signed approval
/// row that records THAT an approval happened but not WHICH rule required it
/// cannot answer the question an auditor brings to it: whether the gate that
/// fired was one an operator could have removed. The prose in `reason` carries
/// the same fact for a human, but a sentence is not a key and gets reworded.
///
/// The two gates outside `confirmation_rule` are pinned here too: they were the
/// last places where a card's sentence was still hand-written at its call site.
#[tokio::test]
async fn every_card_names_the_rule_that_raised_it() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    // Tier-raised: `agent_delete` is destructive, nothing names it.
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-rule-id"))
        .with_confirmation(StdArc::clone(&requester) as _);
    svc.execute("agent_delete", json!({})).await.unwrap();
    assert_eq!(requester.rule_ids(), vec![Some("tier_raised")]);

    // The operator-escalation card, whose prose used to be a literal at its
    // call site — the last gate in this file that did not go through the chain.
    let operator = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(StubTool {
        tool_name: "cron_manage",
    }));
    let guest = ScopedToolService::new(Arc::new(reg), BTreeSet::new())
        .with_turn_context(crate::tools::turn_context::TurnContext {
            session_key: crate::routing::session_key::SessionKey::main("rule-id-operator-gate"),
            run_id: String::new(),
            channel_id: String::new(),
            conversation_id: String::new(),
            caller_role: Some("guest".to_string()),
            channel_tool_permissions: None,
            unattended: false,
            plan_gate: None,
            side_question: false,
            telecom_authority: None,
        })
        .with_config_approval(StdArc::clone(&operator) as _);
    guest.execute("cron_manage", json!({})).await.unwrap();
    assert_eq!(operator.rule_ids(), vec![Some("operator_required")]);
    assert!(
        operator.seen.lock().unwrap()[0]
            .reason
            .contains("chat-tier device"),
        "the escalation card keeps its sentence — it just comes from the chain now"
    );
}

/// A refusal nobody made must not be reported as one, and must not stick.
///
/// The requester here stands in for the four production sites that answer
/// without ever showing a card: an unwired requester, an unroutable turn, a
/// Telegram delivery that failed, and a channel with no approval capability.
/// All four returned `Denied`, so the confirm gate filed a `UserRejected`:
///
/// * the intent became sticky for the rest of the session — the SECOND call
///   below never reaches the requester at all, and
/// * the sentence handed to the model (which it relays to the person it is
///   talking to) said the user had declined something they never saw.
///
/// Three of those in one conversation also crossed the brute-force threshold
/// and paused every gate in it for five minutes.
#[tokio::test]
async fn a_refusal_nobody_made_is_not_reported_as_the_users() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Unavailable));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-unreachable"))
        .with_confirmation(StdArc::clone(&requester) as _);

    let err = svc.execute("agent_delete", json!({})).await.unwrap_err();
    let text = err.to_string();
    assert!(
        !text.contains("The user did not approve"),
        "no user decided this — {text}"
    );
    assert!(
        text.contains("nobody was asked"),
        "the model has to be told WHY it was refused — {text}"
    );

    // Not sticky: the identical call asks again rather than being auto-refused
    // by the ledger on the strength of a decision that never happened.
    let _ = svc.execute("agent_delete", json!({})).await;
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        2,
        "a transport failure must leave the intent askable"
    );
}

/// The other half of the pin: the SAME gated call on an ATTENDED run does
/// prompt. Without this, a gate that denies everything would pass the test above.
#[tokio::test]
async fn an_attended_run_still_prompts_for_the_same_call() {
    use crate::config::types::policies::ExecTier;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(ExecTier::Auto)
        .with_turn_context(turn_ctx("agent-attended-prompt"))
        .with_confirmation(StdArc::clone(&requester) as _);

    svc.execute("agent_delete", json!({}))
        .await
        .expect("approved → runs");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);
}

// -------------------------------------------------------------------------
// Deferred-tier exposure: dropped from list/metadata_schema, reachable via
// describe/execute (so a model that finds the tool via `tool_search` can
// still call it).
// -------------------------------------------------------------------------

#[tokio::test]
async fn deferred_tools_dropped_from_list_but_still_describable_and_executable() {
    // Registry with two tools; defer "beta".
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(NamedStub::new("alpha")));
    reg.register(Box::new(NamedStub::new("beta")));
    let deferred = crate::tools::scoped::DeferredTools::new(["beta".to_string()].into());
    let svc =
        ScopedToolService::new(Arc::new(reg), BTreeSet::new()).with_deferred(deferred.clone());

    // list() and metadata_schema() omit the deferred tool.
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert!(names.contains(&"alpha".to_string()));
    assert!(
        !names.contains(&"beta".to_string()),
        "deferred tool must not be listed"
    );
    let meta_names: Vec<String> = svc
        .metadata_schema()
        .iter()
        .map(|d| d.name.clone())
        .collect();
    assert!(!meta_names.contains(&"beta".to_string()));

    // describe() and execute() still reach it.
    assert!(
        svc.describe("beta").await.is_some(),
        "deferred tool must stay describable"
    );
    assert!(
        svc.execute("beta", json!({})).await.is_ok(),
        "deferred tool must stay executable"
    );

    // …but describable+executable is NOT callable. The model can only invoke a
    // tool that appears in `metadata_schema()` — that array IS the native
    // tool_use channel. This test used to stop above, and its comment claimed
    // "searched → callable"; nothing verified the tool ever came BACK, and
    // nothing ever put it back. `defer_mcp_tools` shipped as a trap.
    assert!(
        svc.dispatchable_list()
            .await
            .iter()
            .any(|d| d.name == "beta"),
        "a deferred tool is still dispatchable, so name-repair must be able to see it"
    );

    deferred.undefer(&["beta".to_string()]);

    let meta_names: Vec<String> = svc
        .metadata_schema()
        .iter()
        .map(|d| d.name.clone())
        .collect();
    assert!(
        meta_names.contains(&"beta".to_string()),
        "a discovered tool must re-enter the model's tool array, or it is uncallable"
    );
}

#[tokio::test]
async fn empty_deferred_set_is_byte_identical() {
    let mut reg = LoopToolRegistry::new();
    reg.register(Box::new(NamedStub::new("alpha")));
    let svc = ScopedToolService::new(Arc::new(reg), BTreeSet::new());
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert!(names.contains(&"alpha".to_string()));
}

// -------------------------------------------------------------------------
// Ingress hygiene (Layer 2) — end-to-end through the real dispatch seam
// -------------------------------------------------------------------------

/// A tool shaped exactly like `bash`: a typed struct whose `stdout` field holds
/// the multi-line log. That shape is the whole point — `Value::to_string()`
/// escapes its newlines, so anything downstream that reasons about lines sees
/// one line.
struct FailingTestRunner;

#[async_trait::async_trait]
impl LoopTool for FailingTestRunner {
    fn name(&self) -> &str {
        "bash"
    }
    fn description(&self) -> &str {
        "runs a test suite"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        let mut log = String::from("$ cargo test --lib\n\nrunning 2001 tests\n");
        for i in 0..2000 {
            log.push_str(&format!("test suite::case_{i} ... ok\n"));
        }
        log.push_str("test suite::the_broken_one ... FAILED\n\nfailures:\n\n");
        log.push_str("---- suite::the_broken_one stdout ----\n");
        log.push_str("thread 'suite::the_broken_one' panicked at src/widget.rs:42:9:\n");
        log.push_str("  assertion `left == right` failed\n    left: 1\n   right: 2\n\n");
        log.push_str("failures:\n    suite::the_broken_one\n\n");
        log.push_str("test result: FAILED. 2000 passed; 1 failed; 0 ignored\n");
        LoopToolResult::Success {
            output: json!({
                "success": false,
                "exit_code": 101,
                "stdout": log,
                "stderr": "",
                "language": "shell",
            }),
        }
    }
}

fn hygiene_store(
    _name: &str,
) -> (
    tempfile::TempDir,
    StdArc<crate::tools::result_store::ToolResultStore>,
) {
    let (scratch, base) = crate::utils::scratch::scratch_root();
    std::fs::create_dir_all(&base).unwrap();
    (
        scratch,
        StdArc::new(crate::tools::result_store::ToolResultStore::with_dir_for_tests(base)),
    )
}

/// The round's headline behaviour, asserted where it actually has to hold.
///
/// A failing `cargo test` run is the single most common oversized tool result in
/// this repo. Before ingress hygiene the model received the first ~400 characters
/// of the **JSON envelope** (`{"success":false,"exit_code":101,"stdout":"\n
/// running 2001 tests\ntest suite::case_0 ... ok\n…`) above a persist marker: the
/// panic, the assertion diff and the name of the failing test were all gone, so
/// the only available next move was to re-run the suite.
#[tokio::test]
async fn a_failing_test_run_reaches_the_model_as_signal_not_as_json_envelope_head() {
    let (_scratch, hygiene) = hygiene_store("failing_test_run");
    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(FailingTestRunner));
    // A retrieval tool to read the offload back: without one nothing is
    // offloaded (see `an_agent_with_no_retrieval_tool_gets_a_cut_not_an_offload`).
    registry.register(Box::new(StubTool {
        tool_name: "file_read",
    }));
    let svc = ScopedToolService::new(StdArc::new(registry), std::collections::BTreeSet::new())
        .with_result_store(hygiene);

    let out = svc.execute("bash", json!({})).await.expect("tool succeeds");
    let text = out.value.as_str().expect("layer 2 flattens to text");

    // The three things the model needs to act, none of which survived before.
    assert!(
        text.contains("the_broken_one"),
        "the failing test's name must reach the model:\n{text}"
    );
    assert!(
        text.contains("src/widget.rs:42:9") || text.contains("panicked"),
        "the panic location must reach the model:\n{text}"
    );
    assert!(
        text.contains("2000 passed; 1 failed"),
        "the verdict line must reach the model:\n{text}"
    );

    // The passing-test noise is what paid for it.
    assert!(
        !text.contains("case_500"),
        "2000 passing-test lines must not be inlined:\n{}",
        &text[..text.len().min(400)]
    );

    // Still recoverable: the untouched original is offloaded, not the reduction.
    assert!(
        text.contains("[Full output persisted: "),
        "the recovery handle must be present:\n{text}"
    );

    // And the result is genuinely smaller than what the tool produced.
    let tokens = crate::context::budget::pressure::estimate_tokens_smart(text);
    assert!(
        tokens < 8_000,
        "the model-facing result must land inside bash's declared budget, got {tokens}"
    );
}

/// The no-op guarantee: a small result is passed through byte-for-byte, so the
/// overwhelming majority of tool calls are unaffected by any of this.
#[tokio::test]
async fn a_small_result_is_untouched_by_ingress_hygiene() {
    struct Tiny;
    #[async_trait::async_trait]
    impl LoopTool for Tiny {
        fn name(&self) -> &str {
            "bash"
        }
        fn description(&self) -> &str {
            "tiny"
        }
        fn schema(&self) -> Value {
            json!({ "type": "object" })
        }
        async fn execute(&self, _i: Value, _c: CancellationToken) -> LoopToolResult {
            LoopToolResult::Success {
                output: json!({ "stdout": "error: one line\n", "exit_code": 1 }),
            }
        }
    }
    let (_scratch, hygiene) = hygiene_store("small_untouched");
    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(Tiny));
    let svc = ScopedToolService::new(StdArc::new(registry), std::collections::BTreeSet::new())
        .with_result_store(hygiene);

    let out = svc.execute("bash", json!({})).await.unwrap();
    let text = out.value.as_str().unwrap();
    assert_eq!(
        text,
        json!({ "stdout": "error: one line\n", "exit_code": 1 }).to_string(),
        "under-budget results must be byte-identical"
    );
}

/// T-G12: the recovery footer is an instruction to the model ("use
/// `ctx_search` …"), so it may only name a retrieval tool this turn can
/// actually dispatch. Both ways a tool stops being callable are exercised —
/// absent from the agent's allow set, and denied by `[policies.tool_permissions]`
/// — plus the positive half, so a footer that simply never names anything
/// cannot pass.
#[tokio::test]
async fn the_recovery_footer_names_only_retrieval_tools_the_model_can_call() {
    use crate::extension::PermissionAction;

    async fn footer_of(svc: ScopedToolService) -> String {
        let out = svc.execute("bash", json!({})).await.expect("tool succeeds");
        let text = out
            .value
            .as_str()
            .expect("layer 2 flattens to text")
            .to_string();
        assert!(
            text.contains("[Full output persisted: "),
            "precondition: the result was offloaded:\n{text}"
        );
        text
    }
    fn registry() -> StdArc<LoopToolRegistry> {
        let mut r = LoopToolRegistry::new();
        r.register(Box::new(FailingTestRunner));
        r.register(Box::new(StubTool {
            tool_name: "ctx_search",
        }));
        r.register(Box::new(StubTool {
            tool_name: "file_read",
        }));
        StdArc::new(r)
    }
    let allow =
        |names: &[&str]| -> BTreeSet<String> { names.iter().map(|n| (*n).to_string()).collect() };

    // Positive half: both callable ⇒ the search hint is offered.
    let (_s1, store) = hygiene_store("footer_both");
    let both = footer_of(
        ScopedToolService::new(registry(), allow(&["bash", "ctx_search", "file_read"]))
            .with_result_store(store),
    )
    .await;
    assert!(both.contains("ctx_search("), "both callable:\n{both}");

    // Not in the agent's allow set.
    let (_s2, store) = hygiene_store("footer_not_allowed");
    let not_allowed = footer_of(
        ScopedToolService::new(registry(), allow(&["bash", "file_read"])).with_result_store(store),
    )
    .await;
    assert!(
        !not_allowed.contains("ctx_search"),
        "ctx_search is not in the allow set, yet the footer names it:\n{not_allowed}"
    );
    assert!(
        not_allowed.contains("file_read"),
        "the callable fallback must be named instead:\n{not_allowed}"
    );

    // Denied by policy (and hidden from the model's list).
    let (_s3, store) = hygiene_store("footer_denied");
    let denied = footer_of(
        ScopedToolService::new(registry(), BTreeSet::new())
            .with_tool_permissions(perms(
                PermissionAction::Allow,
                &[("ctx_search", PermissionAction::Deny)],
            ))
            .with_result_store(store),
    )
    .await;
    assert!(
        !denied.contains("ctx_search"),
        "ctx_search is policy-denied, yet the footer names it:\n{denied}"
    );
    assert!(denied.contains("file_read"), "fallback:\n{denied}");

    // Neither callable ⇒ nothing is offloaded: a bare path the model has no
    // tool to open is a dead handle. The cut says so instead.
    let (_s4, store) = hygiene_store("footer_neither");
    let neither = ScopedToolService::new(registry(), allow(&["bash"]))
        .with_result_store(store)
        .execute("bash", json!({}))
        .await
        .expect("tool succeeds");
    let neither = neither.value.as_str().expect("flattened").to_string();
    assert!(
        !neither.contains("[Full output persisted: "),
        "no retrieval tool is callable, so nothing may be offloaded:\n{neither}"
    );
    assert!(neither.contains("no retrieval tool"), "{neither}");
}

// -------------------------------------------------------------------------
// Extension usage recording at the chokepoint
//
// These assert the EFFECT (a row exists in the sidecar), not that a function
// was called: delete the `record_call_detached` line in `execute_gated` and
// they go red. A test that only counted calls would stay green if the write
// were routed to a store nobody reads.
// -------------------------------------------------------------------------

/// A tool that reports a provenance, the way `McpRegistryTool` and the plugin
/// arm of `RegistryToolAdapter` do.
struct OriginTool {
    tool_name: &'static str,
    origin: Option<(&'static str, &'static str)>,
    fails: bool,
}

#[async_trait::async_trait]
impl LoopTool for OriginTool {
    fn name(&self) -> &str {
        self.tool_name
    }
    fn description(&self) -> &str {
        "origin stub"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    fn is_concurrent_safe(&self, _input: &Value) -> bool {
        true
    }
    fn usage_origin(&self) -> Option<crate::tools::usage::UsageOrigin<'_>> {
        use crate::tools::usage::UsageOrigin;
        match self.origin {
            Some(("mcp", id)) => Some(UsageOrigin::Mcp(id)),
            Some(("plugin", id)) => Some(UsageOrigin::Plugin(id)),
            _ => None,
        }
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        if self.fails {
            LoopToolResult::Error {
                error: "boom".into(),
                retryable: false,
            }
        } else {
            LoopToolResult::Success {
                output: json!({ "ok": true }),
            }
        }
    }
}

fn origin_service(tools: Vec<OriginTool>) -> ScopedToolService {
    let mut registry = LoopToolRegistry::new();
    for t in tools {
        registry.register(Box::new(t));
    }
    ScopedToolService::new(StdArc::new(registry), std::collections::BTreeSet::new())
}

fn usage_snapshot() -> std::collections::HashMap<String, crate::tools::usage::OriginUsage> {
    crate::tools::usage::ToolUsageStore::default_path()
        .map(|s| s.snapshot())
        .unwrap_or_default()
}

#[tokio::test]
async fn a_dispatched_mcp_tool_lands_in_the_usage_sidecar() {
    let _home = crate::utils::paths::IsolatedAlephHome::new();
    let svc = origin_service(vec![OriginTool {
        tool_name: "query_docs",
        origin: Some(("mcp", "ctx7")),
        fails: false,
    }]);

    svc.execute("query_docs", json!({})).await.unwrap();
    svc.execute("query_docs", json!({})).await.unwrap();

    let row = usage_snapshot()
        .remove("mcp:ctx7")
        .expect("the dispatch must have written an `mcp:ctx7` row");
    assert_eq!(row.call_count, 2);
    assert_eq!(row.error_count, 0);
    assert_eq!(row.tools.get("query_docs"), Some(&2));
    assert!(row.last_used_at.is_some());
}

#[tokio::test]
async fn a_failing_call_still_counts_as_usage_and_records_the_error() {
    let _home = crate::utils::paths::IsolatedAlephHome::new();
    let svc = origin_service(vec![OriginTool {
        tool_name: "flaky",
        origin: Some(("plugin", "p1")),
        fails: true,
    }]);

    // The call errors; the point is that the server/plugin was still exercised.
    let _ = svc.execute("flaky", json!({})).await;

    let row = usage_snapshot()
        .remove("plugin:p1")
        .expect("a failed call is still usage");
    assert_eq!(row.call_count, 1);
    assert_eq!(row.error_count, 1);
    assert!(row.last_error_at.is_some());
}

/// Builtins carry no origin, so the hot path must never touch the disk. If this
/// goes red, every `file_read` in every turn just became a locked file write.
#[tokio::test]
async fn a_builtin_writes_nothing() {
    let _home = crate::utils::paths::IsolatedAlephHome::new();
    let svc = origin_service(vec![OriginTool {
        tool_name: "file_read",
        origin: None,
        fails: false,
    }]);

    svc.execute("file_read", json!({})).await.unwrap();

    assert!(
        usage_snapshot().is_empty(),
        "a builtin must not create a usage row (or the sidecar file at all)"
    );
    assert!(
        crate::utils::paths::tool_usage_path().is_some_and(|p| !p.exists()),
        "the sidecar must not even be created by builtin traffic"
    );
}

/// A refused call is not usage: the server was never reached. It IS recorded,
/// with its reason, in the signed identity ledger — recording it here too would
/// make "40 calls" mean two different things.
#[tokio::test]
async fn a_permission_denied_call_is_not_counted_as_usage() {
    use crate::extension::PermissionAction;
    let _home = crate::utils::paths::IsolatedAlephHome::new();

    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(OriginTool {
        tool_name: "denied_tool",
        origin: Some(("mcp", "walled")),
        fails: false,
    }));
    let svc = ScopedToolService::new(StdArc::new(registry), std::collections::BTreeSet::new())
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("denied_tool", PermissionAction::Deny)],
        ));

    let err = svc.execute("denied_tool", json!({})).await.unwrap_err();
    assert!(matches!(err, ToolError::PermissionDenied { .. }));
    assert!(
        usage_snapshot().is_empty(),
        "a call the gate refused never reached the server; it is not usage"
    );
}

// -------------------------------------------------------------------------
// The ordered approval chain: named rules, and decisions the human already made
// -------------------------------------------------------------------------

/// PINS AN ADJUDICATED DECISION — a session grant does **not** carry into an
/// unattended continuation of the same session.
///
/// The `if self.unattended` auto-deny sits ABOVE the session-grant
/// short-circuit in `confirm_with_memory`, so an action the human cleared with
/// "allow for this session" is refused again once the same `SessionKey`
/// continues autonomously. Swapping those two blocks makes "approve once, the
/// loop stops asking" work and is the obvious-looking repair when a user
/// reports that their grant stopped applying; it was evaluated on 2026-08-07
/// and **ruled against by the user** (SECURITY.md *Unattended = fail closed*,
/// FEATURE_LOCATOR §5.3). The order IS the trust boundary: running something
/// with nobody watching must rest on a present decision, never on a remembered
/// click from earlier in the session.
///
/// Until now nothing enforced that. The ruling lived only in prose, one
/// two-block move away from being silently undone — which is exactly what
/// happened while this round was being written. This is the guard.
#[tokio::test]
async fn a_session_grant_does_not_survive_into_an_unattended_run() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::ApprovedForSession));
    let ctx = turn_ctx("agent-grant-vs-unattended");

    // Attended turn: the human grants this exact call for the session…
    let attended = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(ctx.clone())
        .with_confirmation(StdArc::clone(&requester) as _);
    attended
        .execute("danger", json!({}))
        .await
        .expect("granted");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);
    // …and it does suppress the re-prompt while a human is still attached, so
    // the assertion below is about the unattended flag and nothing else.
    attended
        .execute("danger", json!({}))
        .await
        .expect("the grant holds within the attended session");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);

    // The same session continues with nobody watching: refused anyway.
    let unattended = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(ctx)
        .with_confirmation(StdArc::clone(&requester) as _)
        .with_unattended(true);
    let err = unattended.execute("danger", json!({})).await.unwrap_err();
    assert!(
        matches!(
            err,
            ToolError::Refused {
                by: crate::tools::service::RefusedBy::NobodyAsked,
                ..
            }
        ),
        "a remembered grant must not authorize an unattended run, got {err:?}"
    );
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "and no card was raised into the void"
    );
}

/// PINS THE SAME ADJUDICATED DECISION, one tier wider — a **persistent** grant
/// does not carry into an unattended continuation either.
///
/// The 2026-08-07 ruling was made about session grants; a grant that outlives
/// the process is strictly wider, so the reasoning applies a fortiori:
/// executing something with nobody watching must rest on a present decision,
/// not on a remembered click — and "remembered from last month" is further from
/// present than "remembered ten minutes ago", not closer.
///
/// The block order is what enforces it (`if self.unattended` precedes BOTH
/// standing-grant short-circuits, which are now one call), so this test and its
/// session-scoped sibling fail together if anybody reorders them. It is here as
/// its own case because "the persistent tier is exactly the feature people
/// reach for to make cron stop asking" is precisely the argument that would be
/// made for moving it, and the answer is to make the continuation attended.
#[tokio::test]
async fn a_persistent_grant_does_not_survive_into_an_unattended_run() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    // `bash` under the `Ask` tier on an operator turn: a card that really does
    // offer the persistent tier, so this test is about the unattended flag and
    // not about the offer.
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::ApprovedAlways));
    let ctx = turn_ctx("agent-always-vs-unattended");

    let attended = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(ctx.clone())
        .with_confirmation(StdArc::clone(&requester) as _);
    attended
        .execute("bash", json!({"probe": "always-vs-unattended"}))
        .await
        .expect("granted");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);
    attended
        .execute("bash", json!({"probe": "always-vs-unattended"}))
        .await
        .expect("the persistent grant holds while a human is attached");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);

    let unattended = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(ctx)
        .with_confirmation(StdArc::clone(&requester) as _)
        .with_unattended(true);
    let err = unattended
        .execute("bash", json!({"probe": "always-vs-unattended"}))
        .await
        .unwrap_err();
    assert!(
        matches!(
            err,
            ToolError::Refused {
                by: crate::tools::service::RefusedBy::NobodyAsked,
                ..
            }
        ),
        "a persistent grant must not authorize an unattended run, got {err:?}"
    );
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "and no card was raised into the void"
    );
}

/// The difference the persistent tier actually buys: it satisfies the gate in a
/// **different session**, where a session grant structurally cannot.
///
/// Without this the feature would be indistinguishable from the session tier in
/// a single-process test run — which is how a store that silently wrote to the
/// wrong bucket would still look green.
#[tokio::test]
async fn a_persistent_grant_satisfies_a_later_session() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let args = json!({"probe": "always-across-sessions"});
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::ApprovedAlways));
    let first = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(turn_ctx("agent-always-session-a"))
        .with_confirmation(StdArc::clone(&requester) as _);
    first.execute("bash", args.clone()).await.expect("granted");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);

    // A different conversation entirely — a session grant would re-prompt here.
    let second = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(turn_ctx("agent-always-session-b"))
        .with_confirmation(StdArc::clone(&requester) as _);
    second
        .execute("bash", args)
        .await
        .expect("the persistent grant is not session-scoped");
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "the second session must not have raised a card"
    );
}

/// A requester that answers wider than the card offered cannot mint a
/// persistent grant.
///
/// `ApprovalRequester` implementations return an `ApprovalOutcome` **directly**
/// — the manager's clamp only covers the ones that route through it, and that
/// trait has several. `danger` declares its own confirmation floor, so its card
/// never offers the persistent tier; an outcome claiming one is recorded as a
/// session grant instead. Observable end-to-end: the grant holds inside the
/// session it was taken in, and does NOT cross into another one.
#[tokio::test]
async fn an_outcome_wider_than_the_card_cannot_mint_a_persistent_grant() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let args = json!({"probe": "wider-than-offered"});
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::ApprovedAlways));
    let first = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-wider-a"))
        .with_confirmation(StdArc::clone(&requester) as _);
    first
        .execute("danger", args.clone())
        .await
        .expect("granted");
    first
        .execute("danger", args.clone())
        .await
        .expect("it is still a grant — within this session");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);

    let second = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-wider-b"))
        .with_confirmation(StdArc::clone(&requester) as _);
    second.execute("danger", args).await.expect("approved");
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        2,
        "a grant the card never offered must not have outlived its session"
    );
}

/// An operator's persistent grant does not silently cover a MEMBER's identical
/// call.
///
/// The grant is install-wide by design — it is the per-call sibling of a
/// `[policies.tool_permissions]` `allow` entry — but the person clicking
/// "always" on their own card was not asked whether a member may issue the
/// byte-identical call without stopping. Since a member's card never offers the
/// tier, it is also never satisfied by it: one derivation, both directions
/// (`GrantStore::granted_within`). Without this, the operator-escalation card
/// for that call would stop being raised for everybody, permanently, from one
/// click on an unrelated surface.
#[tokio::test]
async fn an_operators_persistent_grant_does_not_cover_a_members_identical_call() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let args = json!({"probe": "always-across-tiers"});
    let operator_requester = StdArc::new(FakeRequester::new(ApprovalOutcome::ApprovedAlways));
    let operator = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(turn_ctx("agent-always-operator"))
        .with_confirmation(StdArc::clone(&operator_requester) as _);
    operator
        .execute("bash", args.clone())
        .await
        .expect("granted");
    assert_eq!(operator_requester.calls.load(Ordering::SeqCst), 1);

    // Same action, same arguments — a member's turn. Their card never offered
    // the persistent tier, so it is not satisfied by one either: they are asked.
    let member_requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let mut member_ctx = turn_ctx("agent-always-member");
    member_ctx.caller_role = Some("member".to_string());
    let member = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(member_ctx)
        .with_confirmation(StdArc::clone(&member_requester) as _);
    member.execute("bash", args).await.expect("approved");
    assert_eq!(
        member_requester.calls.load(Ordering::SeqCst),
        1,
        "the member must still have been asked"
    );
}

/// A member's card must not offer the persistent tier, and the tool's own
/// declared floor must not offer it to anybody.
///
/// This is the production narrowing scenario `allowed_decisions` exists for —
/// before it, the Panel drew three fixed buttons and the field had no consumer
/// that could ever disagree with them. The set is asserted on the ACTION the
/// gate handed the requester, which is the same object every surface renders
/// from, so this covers the Panel, the channels and the TUI at once.
#[tokio::test]
async fn the_offered_decision_set_narrows_by_rule_and_by_tier() {
    use crate::exec::socket::ApprovalDecisionType;
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    // `danger` declares its own confirmation gate (`tool_declared`): no tier,
    // no `allow` entry and no button may switch it off — including for an
    // operator, whose turn this is (`caller_role: None`).
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let operator = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-offer-declared"))
        .with_confirmation(StdArc::clone(&requester) as _);
    operator
        .execute("danger", json!({"probe": "declared"}))
        .await
        .expect("approved");
    let offered = requester.seen.lock().unwrap()[0].allowed_decisions.clone();
    assert!(
        !offered.contains(&ApprovalDecisionType::AllowAlways),
        "the declared-floor card said no configuration can switch it off; \
         offering a permanent grant makes that sentence false as it is read"
    );

    // A tier-raised card on the same turn DOES offer it… (`bash` is a plain
    // mutator: gated by the `Ask` tier, not by the operator gate, so this
    // exercises the decision set and nothing else.)
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let operator = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(turn_ctx("agent-offer-tier"))
        .with_confirmation(StdArc::clone(&requester) as _);
    operator
        .execute("bash", json!({"probe": "tier"}))
        .await
        .expect("approved");
    let offered = requester.seen.lock().unwrap()[0].allowed_decisions.clone();
    assert!(
        offered.contains(&ApprovalDecisionType::AllowAlways),
        "an operator-tier turn outside the declared floor may create a standing grant"
    );

    // …and the same card raised by a MEMBER does not. A persistent grant is
    // install-wide; a member creating one would authorize everybody else's
    // identical call.
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let mut member_ctx = turn_ctx("agent-offer-member");
    member_ctx.caller_role = Some("member".to_string());
    let member = ScopedToolService::new(tier_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Ask)
        .with_turn_context(member_ctx)
        .with_confirmation(StdArc::clone(&requester) as _);
    member
        .execute("bash", json!({"probe": "member"}))
        .await
        .expect("approved");
    let offered = requester.seen.lock().unwrap()[0].allowed_decisions.clone();
    assert!(
        !offered.contains(&ApprovalDecisionType::AllowAlways),
        "a member's card must not offer an install-wide grant"
    );
}

/// The card must name the rule that gated the call.
///
/// `danger` declares its own confirmation gate, which no tier and no explicit
/// `allow` can switch off. The old text ("Tool `danger` requires your
/// confirmation to run") was the same sentence a stray `"*" = "ask"` glob
/// produced, and it invited the one repair that cannot work here.
#[tokio::test]
async fn the_approval_card_names_the_rule_that_gated_the_call() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-card-reason"))
        .with_confirmation(StdArc::clone(&requester) as _);
    svc.execute("danger", json!({})).await.expect("approved");

    let reasons: Vec<String> = requester
        .seen
        .lock()
        .unwrap()
        .iter()
        .map(|a| a.reason.clone())
        .collect();
    assert_eq!(reasons.len(), 1);
    assert!(
        reasons[0].contains("declares its own confirmation gate"),
        "the card must say which rule stopped the call: {}",
        reasons[0]
    );
    assert!(
        reasons[0].contains("full"),
        "…and that this one survives every tier: {}",
        reasons[0]
    );
}

/// A policy `deny` tells the model which entry denied it, so the sentence it
/// relays to the user names something they can actually edit.
#[tokio::test]
async fn a_policy_deny_names_the_entry_that_denied_it() {
    use crate::config::types::policies::ToolPermissionsConfig;
    use crate::extension::PermissionAction;

    let svc = ScopedToolService::new(tier_registry(), BTreeSet::new()).with_tool_permissions(
        ToolPermissionsConfig {
            default: PermissionAction::Allow,
            overrides: [("*_delete".to_string(), PermissionAction::Deny)]
                .into_iter()
                .collect(),
        },
    );
    match svc.execute("agent_delete", json!({})).await {
        Err(ToolError::PermissionDenied { reason, .. }) => {
            assert!(reason.contains("*_delete"), "unexpected reason: {reason}");
        }
        other => panic!("expected PermissionDenied, got {other:?}"), // rust-doctor-disable-line panic-in-library
    }
}

/// REGRESSION — one dispatch, two cards.
///
/// `confirm_with_memory` documents that "a grant taken at one satisfies the
/// others for the same call and the user is never double-prompted". That held
/// only for session-scoped grants: after an "allow once" at the confirm gate, a
/// `BeforeToolCall` hook's `ask` raised a SECOND card for the identical
/// fingerprint in the same dispatch.
#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh
async fn a_hook_ask_does_not_re_prompt_a_call_a_gate_already_approved() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        r#"echo '{"hookSpecificOutput": {"permissionDecision": "ask", "permissionDecisionReason": "hook wants a look"}}'"#,
    )]));
    // AllowOnce on purpose: a session grant would have masked the bug.
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-hook-double-prompt"))
        .with_confirmation(StdArc::clone(&requester) as _)
        .with_hook_executor(executor, "agent-hook-double-prompt");

    svc.execute("danger", json!({})).await.expect("approved");
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "one call, one card"
    );
}

/// …and a hook `ask` on an UNGATED call still asks. Otherwise the dedupe above
/// could be a hook seam that silently stopped working.
#[tokio::test]
#[cfg(unix)] // POSIX-only: shell hook uses sh
async fn a_hook_ask_still_prompts_when_no_gate_ran_first() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;

    let executor = Arc::new(HookExecutor::new(vec![make_command_hook(
        HookEvent::BeforeToolCall,
        HookKind::Interceptor,
        r#"echo '{"hookSpecificOutput": {"permissionDecision": "ask", "permissionDecisionReason": "hook wants a look"}}'"#,
    )]));
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Approved));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn_ctx("agent-hook-single-prompt"))
        .with_confirmation(StdArc::clone(&requester) as _)
        .with_hook_executor(executor, "agent-hook-single-prompt");

    // `plain` declares no gate of its own, so the hook is the only thing asking.
    svc.execute("plain", json!({})).await.expect("approved");
    assert_eq!(requester.calls.load(Ordering::SeqCst), 1);
}

// =============================================================================
// Plan mode — the read-only planning tier and the plan → build handoff.
//
// Two halves, and the split is the design: `ExecTier::Plan::rule_for` answers
// at the NAME level (so every `permission_for` consumer inherits it, including
// the slash fast path), and this service answers the per-CALL half, because it
// is the only place that holds the arguments.
// =============================================================================

/// A tool that declares nothing — i.e. mutating, on both fail-closed defaults.
///
/// `NamedStub` cannot play this part: it declares itself parallel-safe so the
/// tier tests can tell a GATE's forced `Global` from an inner claim, and under
/// plan mode that same declaration reads as "this call is a pure read".
struct MutatingStub(String);

#[async_trait::async_trait]
impl LoopTool for MutatingStub {
    fn name(&self) -> &str {
        &self.0
    }
    fn description(&self) -> &str {
        "stub that mutates"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success { output: json!({}) }
    }
}

/// A read/write multiplexer shaped like the real `file_ops`: one name, a
/// `Shared` claim for its read arm and an exclusive one for everything else.
/// The per-call half of plan mode exists for exactly this shape — repo
/// exploration is what a plan is built out of, and it arrives under the same
/// tool name as `delete`.
struct MuxStub;

#[async_trait::async_trait]
impl LoopTool for MuxStub {
    fn name(&self) -> &str {
        "file_ops"
    }
    fn description(&self) -> &str {
        "read/write multiplexer"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    fn concurrency_claim(&self, input: &Value) -> crate::tools::concurrency::ConcurrencyClaim {
        use crate::tools::concurrency::ConcurrencyClaim;
        match input.get("operation").and_then(Value::as_str) {
            Some("list") => ConcurrencyClaim::Shared,
            _ => ConcurrencyClaim::global(),
        }
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        LoopToolResult::Success { output: json!({}) }
    }
}

fn plan_registry() -> Arc<LoopToolRegistry> {
    let mut r = LoopToolRegistry::new();
    // Declared read-only: `NamedStub` reports parallel-safe, which is what the
    // `READ_ONLY_TOOLS` allowlist means for a real builtin.
    r.register(Box::new(NamedStub::new("file_read")));
    // Mutating, declaring nothing.
    r.register(Box::new(MutatingStub("file_write".to_string())));
    r.register(Box::new(MutatingStub("bash".to_string())));
    // The two carve-outs: the plan file and the human channel. Both mutate.
    r.register(Box::new(MutatingStub("scratchpad".to_string())));
    r.register(Box::new(MutatingStub("ask_user".to_string())));
    // The multiplexer.
    r.register(Box::new(MuxStub));
    Arc::new(r)
}

/// A planning service plus the gate a human approval would flip.
fn planning(
    restore: crate::config::types::policies::ExecTier,
) -> (ScopedToolService, StdArc<crate::tools::plan_gate::PlanGate>) {
    let gate = StdArc::new(crate::tools::plan_gate::PlanGate::new(restore));
    let mut ctx = turn_ctx("planner");
    ctx.plan_gate = Some(StdArc::clone(&gate));
    let svc = ScopedToolService::new(plan_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Plan)
        .with_turn_context(ctx);
    (svc, gate)
}

/// The chokepoint must be able to SAY what it enforces, through the exact
/// chain a spawned sub-agent's calls travel.
///
/// A child gets no tool service of its own — `subagent_spawner` wraps this
/// very object (`parent_view_for_children`) in `McpScopedToolService` and
/// `AllowlistToolService` — so its prompt can only state a regime that
/// matches reality if the answer survives both wrappers. It travelled through
/// neither until this round, which is why a child spawned mid-plan was told
/// nothing about the tier that refuses every mutating call it makes.
///
/// Asserted after the release too: the answer is the LIVE gate, not a
/// snapshot. A tier threaded through `SpawnRequest` would have gone stale the
/// moment a human approved the plan.
#[tokio::test]
async fn the_enforced_tier_survives_the_wrappers_a_subagent_runs_behind() {
    use crate::config::types::policies::ExecTier;
    use crate::tools::service::ToolService;

    let (svc, gate) = planning(ExecTier::Auto);
    assert_eq!(
        svc.enforced_exec_tier(),
        Some(ExecTier::Plan),
        "the chokepoint must report what `permission_for` will actually apply"
    );

    let parent: Arc<dyn ToolService> = Arc::new(svc);
    let with_mcp: Arc<dyn ToolService> = Arc::new(
        crate::tools::mcp_scope_view::McpScopedToolService::new(parent, Vec::new()),
    );
    let child: Arc<dyn ToolService> = Arc::new(
        crate::agents::allowlist_tool_service::AllowlistToolService::new(
            with_mcp,
            StdArc::new(crate::agents::AgentDef::new(
                "explorer",
                crate::agents::AgentMode::SubAgent,
            )),
        ),
    );

    assert_eq!(
        child.enforced_exec_tier(),
        Some(ExecTier::Plan),
        "a decorator that drops this degrades the child's prompt to silence \
         about a gate that refuses every mutating call it makes"
    );

    assert!(gate.release());
    assert_eq!(
        child.enforced_exec_tier(),
        Some(ExecTier::Auto),
        "the answer must be the live gate — a snapshot taken at spawn time \
         goes stale the instant a human approves the plan"
    );
}

/// A service with no tier wired must say so, not default.
///
/// The caller renders nothing on `None`; a default here would put a regime in
/// a prompt that nothing applies — the expensive half of 判据 §0.
#[tokio::test]
async fn a_service_with_no_tier_wired_reports_none() {
    use crate::tools::service::ToolService;

    let svc = ScopedToolService::new(plan_registry(), BTreeSet::new());
    assert!(svc.enforced_exec_tier().is_none());
    assert!(
        crate::agents::allowlist_tool_service::AllowlistToolService::new(
            Arc::new(svc),
            StdArc::new(crate::agents::AgentDef::new(
                "explorer",
                crate::agents::AgentMode::SubAgent,
            )),
        )
        .enforced_exec_tier()
        .is_none(),
        "silence must propagate as silence"
    );
}

/// The tier's whole promise: nothing that mutates runs, and reads do.
#[tokio::test]
async fn planning_refuses_mutation_and_lets_reads_through() {
    let (svc, _gate) = planning(crate::config::types::policies::ExecTier::Auto);

    for name in ["file_write", "bash"] {
        let err = svc.execute(name, json!({})).await.unwrap_err();
        match err {
            ToolError::PermissionDenied { reason, .. } => {
                assert!(
                    reason.contains("PLANNING"),
                    "the refusal must name plan mode, not a config entry: {reason}"
                );
                assert!(
                    reason.contains("request_approval"),
                    "and it must name the way out: {reason}"
                );
            }
            other => panic!("`{name}` must be refused while planning, got {other:?}"),
        }
    }
    svc.execute("file_read", json!({}))
        .await
        .expect("a declared read runs while planning");
}

/// The two carve-outs. Without them the tier is circular: you would need
/// approval to ask for approval, and could not write the plan the approval is
/// about.
#[tokio::test]
async fn planning_keeps_the_plan_file_and_the_human_channel_open() {
    let (svc, _gate) = planning(crate::config::types::policies::ExecTier::Auto);
    for name in ["scratchpad", "ask_user"] {
        svc.execute(name, json!({}))
            .await
            .unwrap_or_else(|e| panic!("`{name}` must stay reachable while planning: {e:?}"));
    }
}

/// The per-call half. One tool name, two answers, decided by the arguments —
/// which is why it cannot live in `rule_for`, and why `file_ops list` (the
/// exploration a plan is built out of) is not collateral damage.
#[tokio::test]
async fn planning_admits_the_read_arm_of_a_multiplexer_and_refuses_the_rest() {
    let (svc, _gate) = planning(crate::config::types::policies::ExecTier::Auto);
    svc.execute("file_ops", json!({ "operation": "list" }))
        .await
        .expect("the read arm explores");
    let err = svc
        .execute("file_ops", json!({ "operation": "delete" }))
        .await
        .unwrap_err();
    assert!(matches!(err, ToolError::PermissionDenied { .. }));
    // A missing `operation` is not a read: the claim degrades to exclusive,
    // which is the fail-closed direction.
    assert!(svc.execute("file_ops", json!({})).await.is_err());
}

/// The handoff itself: the SAME service, the SAME call, before and after a
/// human approval. This is what "the harness switches modes" means — no new
/// turn, no re-resolution, and not one line inside `src/harness/`.
#[tokio::test]
async fn approving_the_plan_lets_the_next_call_build() {
    let (svc, gate) = planning(crate::config::types::policies::ExecTier::Auto);
    assert!(svc.execute("file_write", json!({})).await.is_err());

    assert!(gate.release(), "first release wins");
    svc.execute("file_write", json!({}))
        .await
        .expect("the very next call after approval runs — that is the handoff");
    svc.execute("bash", json!({}))
        .await
        .expect("and so does everything else the restore tier allows");
}

/// A planning turn shows the model its whole toolbelt. A plan that another
/// agent could implement needs the vocabulary of what can be done, and hiding
/// half of it for the planning half of a turn would also swap the cached tools
/// block twice per plan.
#[tokio::test]
async fn planning_still_lists_the_tools_it_refuses() {
    let (svc, _gate) = planning(crate::config::types::policies::ExecTier::Auto);
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    for expected in ["file_write", "bash", "file_ops", "file_read", "scratchpad"] {
        assert!(
            names.iter().any(|n| n == expected),
            "`{expected}` must stay listed while planning: {names:?}"
        );
    }
    assert!(svc.describe("file_write").await.is_some());
}

/// An operator's own `deny` is not plan mode wearing a hat: it stays hidden,
/// it keeps reporting itself, and approving a plan does not lift it.
#[tokio::test]
async fn an_operator_deny_survives_the_plan_and_still_reports_itself() {
    use crate::extension::PermissionAction;

    let gate = StdArc::new(crate::tools::plan_gate::PlanGate::new(
        crate::config::types::policies::ExecTier::Auto,
    ));
    let mut ctx = turn_ctx("planner-denied");
    ctx.plan_gate = Some(StdArc::clone(&gate));
    let svc = ScopedToolService::new(plan_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Plan)
        .with_turn_context(ctx)
        .with_tool_permissions(perms(
            PermissionAction::Allow,
            &[("bash", PermissionAction::Deny)],
        ));

    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert!(
        !names.iter().any(|n| n == "bash"),
        "a real deny stays hidden"
    );

    let err = svc.execute("bash", json!({})).await.unwrap_err();
    let ToolError::PermissionDenied { reason, .. } = err else {
        panic!("expected a denial")
    };
    assert!(
        reason.contains("tool permission policy"),
        "an operator's deny must keep naming itself, not plan mode: {reason}"
    );

    gate.release();
    assert!(
        svc.execute("bash", json!({})).await.is_err(),
        "approving a plan lifts the PLAN gate, not the operator's policy"
    );
}

/// A run builds its tool service TWICE — once for itself, once as the parent
/// view handed to spawned children (`parent_view_for_children`). Both are
/// built from the same turn context, so both hold the same gate: one human
/// approval lifts planning for the run AND for anything it spawned.
///
/// This is the property that makes `subagent` admissible while planning at all
/// — a child with its own gate would be a child no approval could ever
/// release, and a child with no gate would be the hole.
#[tokio::test]
async fn every_service_built_from_one_turn_shares_one_gate() {
    let gate = StdArc::new(crate::tools::plan_gate::PlanGate::new(
        crate::config::types::policies::ExecTier::Auto,
    ));
    let mut ctx = turn_ctx("planner-fanout");
    ctx.plan_gate = Some(StdArc::clone(&gate));

    let build = || {
        ScopedToolService::new(plan_registry(), BTreeSet::new())
            .with_exec_tier(crate::config::types::policies::ExecTier::Plan)
            .with_turn_context(ctx.clone())
    };
    let own = build();
    let child_view = build();

    assert!(own.execute("file_write", json!({})).await.is_err());
    assert!(child_view.execute("file_write", json!({})).await.is_err());

    gate.release();

    own.execute("file_write", json!({})).await.expect("parent");
    child_view
        .execute("file_write", json!({}))
        .await
        .expect("a child built from the same turn is released by the same approval");
}

/// A turn with no plan gate is byte-identical to a build with no plan mode:
/// the same service at the same tier answers exactly as it always has.
#[tokio::test]
async fn a_turn_with_no_plan_gate_is_unchanged() {
    let svc = ScopedToolService::new(plan_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Auto)
        .with_turn_context(turn_ctx("builder"));
    svc.execute("file_write", json!({}))
        .await
        .expect("Auto runs mutating tools");
    let names: Vec<String> = svc.list().await.into_iter().map(|d| d.name).collect();
    assert!(names.iter().any(|n| n == "file_write"));
}

/// A service resolved to `Plan` for the given `side_question` flag. `Plan` is
/// what every `/btw` turn composes to (`ExecTier::most_restrictive`), so the
/// carve-out revocation is only meaningful measured against it.
fn side_question_service(side_question: bool) -> ScopedToolService {
    let mut ctx = turn_ctx("side-question");
    ctx.side_question = side_question;
    ScopedToolService::new(plan_registry(), BTreeSet::new())
        .with_exec_tier(crate::config::types::policies::ExecTier::Plan)
        .with_turn_context(ctx)
}

/// The two `Plan` carve-outs are revoked for a side question, and the
/// revocation is DERIVED from `PLAN_REACHABLE_TOOLS` rather than restating
/// it. A third member added to that constant is denied for btw automatically
/// — the safe direction — and this test names it so the author must confirm.
#[test]
fn a_side_question_revokes_every_plan_carve_out() {
    use crate::config::types::policies::PLAN_REACHABLE_TOOLS;
    use crate::extension::PermissionAction;

    for tool in PLAN_REACHABLE_TOOLS {
        let svc = side_question_service(true);
        assert_eq!(
            svc.permission_for(tool),
            PermissionAction::Deny,
            "{tool} is reachable under Plan but must not be during a side question"
        );
    }

    // Control: without the side-question flag the carve-outs still hold, so
    // this test cannot pass by breaking Plan mode itself.
    for tool in PLAN_REACHABLE_TOOLS {
        let svc = side_question_service(false);
        assert_ne!(svc.permission_for(tool), PermissionAction::Deny, "{tool}");
    }
}

/// The read half of "it can read and search, but not change anything" — the
/// sentence the refusal itself puts in front of the model.
///
/// A multiplexer declares nothing at the NAME level, so `Plan` fails it closed
/// wholesale; only the per-call claim lets its read arms through. That
/// re-admission used to be keyed on the rule's name (`PlanMode`), and a side
/// question reports its OWN rule — so the most common thing a side question
/// does, listing and searching the tree, came back refused by a sentence
/// promising exactly that, with "do not retry" attached. Mirrors
/// `planning_admits_the_read_arm_of_a_multiplexer_and_refuses_the_rest`,
/// because the two verdicts must behave identically per call and differ only
/// in the sentence they hand back.
#[tokio::test]
async fn a_side_question_admits_the_read_arm_of_a_multiplexer_and_refuses_the_rest() {
    let svc = side_question_service(true);
    svc.execute("file_ops", json!({ "operation": "list" }))
        .await
        .expect("a side question explores");
    let err = svc
        .execute("file_ops", json!({ "operation": "delete" }))
        .await
        .unwrap_err();
    assert!(
        matches!(err, ToolError::PermissionDenied { .. }),
        "the write arm of the same tool must still refuse, got {err:?}"
    );
    // A missing `operation` is not a read: the claim degrades to exclusive,
    // which is the fail-closed direction.
    assert!(svc.execute("file_ops", json!({})).await.is_err());

    // The floor is not re-admitted with the reads. `scratchpad` is denied at
    // rung -1 of `permission_for`, which `denied_only_by_plan` does not
    // consult — so it reports `false` there and the per-call arm never opens.
    assert!(
        svc.execute("scratchpad", json!({})).await.is_err(),
        "the side-question floor must survive the read re-admission"
    );

    // Control: the SAME tier without the side-question flag answers the same
    // way, per call. That is the invariant this fix is built on — the two
    // verdicts differ in the sentence they hand back, never in what runs.
    //
    // What it buys, stated narrowly: it isolates a failure above to the
    // side-question flag rather than to a general breakage of `Plan`. It does
    // NOT catch a quiet *widening* of `Plan` — that would leave both arms
    // passing, since `file_ops delete` would then stop at the
    // destructive-argument filter instead.
    let planning = side_question_service(false);
    planning
        .execute("file_ops", json!({ "operation": "list" }))
        .await
        .expect("planning explores the same way");
    assert!(planning
        .execute("file_ops", json!({ "operation": "delete" }))
        .await
        .is_err());
}

/// The refusal sentence is a claim the code has to keep, and the two halves are
/// asserted against the SAME service so they cannot drift apart: if a mutating
/// call is refused with "it can read and search", a read has to really run.
#[tokio::test]
async fn the_side_question_refusal_promises_reads_that_really_run() {
    let svc = side_question_service(true);
    let err = svc
        .execute("file_ops", json!({ "operation": "delete" }))
        .await
        .unwrap_err();
    let reason = err.to_string();
    assert!(
        reason.contains("read and search"),
        "the refusal is what makes the promise; got: {reason}"
    );
    svc.execute("file_ops", json!({ "operation": "list" }))
        .await
        .expect("the sentence above just promised this call runs");
}

/// A mutating tool is refused during a side question, and the reason names
/// the side question rather than the plan handoff — pointing the reader at
/// "get your plan approved" would name a repair that cannot work here.
#[test]
fn a_side_question_refusal_names_itself_not_the_plan_handoff() {
    let svc = side_question_service(true);
    let rule = svc.deny_rule("file_write").expect("file_write is refused");
    assert!(
        matches!(rule, super::gate_chain::GateRule::SideQuestion),
        "expected SideQuestion, got {rule:?}"
    );
}

// -------------------------------------------------------------------------
// §6.2 — every production dispatch into the gate carries a CallIdentity
// -------------------------------------------------------------------------

/// A file that DEFINES `execute_with_cancel` or `execute_with_cancel_effective`
/// forwards or implements it (the trait default, the scoped service, the
/// allowlist / MCP-scope decorators); ORIGINATORS only call it. Today that set
/// is the harness Act phase and the MCP server face, each call inside a
/// `with_call_identity(..)` scope — which is what lets
/// `session::call_log::emit_for_ambient_call` treat a missing identity as a
/// counted, logged anomaly rather than an expected shape (spec §6.2). Equality
/// on the originator set, derived from the source: every originator must scope
/// an identity around its dispatch, or not reach the gate.
///
/// The harness Act phase and the MCP server face are both production
/// originators; the latter creates a fresh request identity because the MCP
/// face has no model-supplied tool-call id.
///
/// What it does not see: a 2-arg `ToolService::execute(name, input)`
/// originator — `.execute(` is too common a name to census textually (it is
/// also every `LoopTool`, every `rusqlite` statement, every probe executor).
/// Today the only production 2-arg `.execute(` on a `ToolService` is the
/// `AllowlistToolService` forwarder; that is a measurement, not a pin.
#[test]
fn every_production_dispatch_into_the_scoped_gate_is_scoped_by_a_call_identity() {
    use crate::utils::source_scan::{code_text, production_text, rust_sources_under};
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    let mut originators: std::collections::BTreeMap<String, (usize, usize)> = Default::default();
    for (rel, src) in rust_sources_under(&root) {
        let code = code_text(&production_text(std::path::Path::new(&rel), &src));
        if code.contains("fn execute_with_cancel(")
            || code.contains("fn execute_with_cancel_effective(")
        {
            continue;
        }
        let calls = code.matches(".execute_with_cancel(").count()
            + code.matches(".execute_with_cancel_effective(").count();
        if calls > 0 {
            originators.insert(rel, (calls, code.matches("with_call_identity(").count()));
        }
    }
    assert_eq!(
        originators.keys().collect::<Vec<_>>(),
        vec!["src/gateway/mcp_face/mod.rs", "src/harness/agent/act.rs"],
        "a new originator must scope a CallIdentity around its dispatch, or not reach the gate: {originators:?}"
    );
    for (path, (calls, scoped)) in originators {
        assert!(calls >= 1, "self-protection: the scan found {path}");
        assert_eq!(
            calls, scoped,
            "every dispatch in {path} is wrapped by exactly one identity scope"
        );
    }
}

/// Every production site that parks a call on a human — awaits an
/// `ApprovalRequester` — either stamps `ToolCallParked` first (§6.1) or is
/// named here with the reason it cannot. Derived from the source, equality on
/// the set of originating files: a fourth site turns this red until it is
/// classified.
///
/// A file that DEFINES `fn request_approval(` / `fn request_approval_for_action(`
/// implements or forwards the requester face (`ApprovalGate`, the guardian /
/// adapter / operator requesters) and is not an originator. One unrelated
/// method of the same name — `scratchpad.rs::request_approval`, the plan
/// gate, which parks through `clarification::ask` and is stamped THERE — is
/// excluded by the same rule; stated so nobody reads that exclusion as a
/// classification. The blind spot is the same one the dispatch census has: an
/// originator that also defines a method of that name is invisible here.
///
/// "Stamped first" is measured as a stamp call within `WINDOW_LINES` lines
/// above the await with no `fn ` header in between (same function). The two
/// real distances are 5 lines (`dispatch.rs`, `record_parked` → the await)
/// and 17 (`workspace/mod.rs`, the multi-line `emit_for_ambient_call` → the
/// await); the window is those plus slack, not a hand-tuned exact. The
/// window is textual, not structural: a stamp in a SIBLING branch of the same
/// function — one the await's own path never executes — would satisfy it if
/// it fell within the lines. Both real sites are straight-line code, and the
/// stamp firing on the executed path is what the behavioural tests beside
/// this one (and the mutation that removed each stamp) prove; this census
/// only proves the stamp is in the function.
#[test]
fn every_production_approval_park_is_stamped_or_named_exempt() {
    use crate::utils::source_scan::{code_text, production_text, rust_sources_under};
    const AWAITS: [&str; 2] = [".request_approval(", ".request_approval_for_action("];
    const STAMPS: [&str; 2] = ["record_parked(", "emit_for_ambient_call("];
    const WINDOW_LINES: usize = 20;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    // file -> [(1-based line of the await, stamped within the window)]
    let mut sites: std::collections::BTreeMap<String, Vec<(usize, bool)>> = Default::default();
    for (rel, src) in rust_sources_under(&root) {
        let code = code_text(&production_text(std::path::Path::new(&rel), &src));
        if code.contains("fn request_approval(") || code.contains("fn request_approval_for_action(")
        {
            continue;
        }
        let lines: Vec<&str> = code.lines().collect();
        for (i, line) in lines.iter().enumerate() {
            if !AWAITS.iter().any(|needle| line.contains(needle)) {
                continue;
            }
            let window = &lines[i.saturating_sub(WINDOW_LINES)..i];
            let same_fn = !window.iter().any(|l| l.contains("fn "));
            let stamped = same_fn && window.iter().any(|l| STAMPS.iter().any(|s| l.contains(s)));
            sites.entry(rel.clone()).or_default().push((i + 1, stamped));
        }
    }
    // Exemptions: sites that park a call on a human but cannot stamp
    // `ToolCallParked` first, each with the reason it cannot. The borrow-cloud
    // card (`escalation_allowed`) was one — a THINK-phase park that gates a
    // provider route, not a tool call, so it has no `call_id` for a stamp to
    // name — but it lost that park in 54e757c88, so the record has to follow
    // the code out. The table stays: a future park that cannot stamp has to be
    // named here with its reason, not silently absorbed by loosening the
    // equality below.
    const EXEMPT: &[(&str, &str)] = &[];
    let mut expected: Vec<&str> = EXEMPT.iter().map(|(file, _reason)| *file).collect();
    expected.extend_from_slice(&APPROVAL_PARK_FILES);
    expected.sort_unstable();
    assert_eq!(
        sites.keys().map(String::as_str).collect::<Vec<_>>(),
        expected,
        "a new site that parks a call on a human must stamp `ToolCallParked` first, or be \
         named exempt here with its reason: {sites:?}"
    );
    for file in APPROVAL_PARK_FILES {
        for (line, stamped) in &sites[file] {
            assert!(
                stamped,
                "{file}:{line} awaits a requester with no `ToolCallParked` stamp within \
                 {WINDOW_LINES} lines of the same function"
            );
        }
    }
    for (file, reason) in EXEMPT {
        assert!(
            !reason.trim().is_empty(),
            "{file} is named exempt with no reason; the reason is the record"
        );
        for (line, stamped) in sites.get(*file).into_iter().flatten() {
            assert!(
                !stamped,
                "the exempt site {file}:{line} carries a `ToolCallParked` stamp it does not \
                 need — classify it, do not stamp it: {reason}"
            );
        }
    }
}

/// The production files that park a tool call on a human's approval — the
/// expected value both censuses above and below compare their derivation to.
const APPROVAL_PARK_FILES: [&str; 2] = [
    "src/sandbox/workspace/mod.rs",
    "src/tools/scoped/dispatch.rs",
];

/// A park is an entry fact; the gate that wrote it owes the exit fact
/// (criterion #14 — final review C1). Every production file that writes
/// `ToolCallParked` with an `Approval` / `PreHook` reason through the one
/// writer (`session::call_log::emit_for_ambient_call`) must also write BOTH
/// releases through it — `ToolCallApproved` and `ToolCallDenied` — or a crash
/// after the human's yes reduces to "never ran … call it again" for a command
/// that ran. Equality on the file sets, derived from the source: a park file
/// with no release is red BY FILE NAME, and the park set is pinned to the
/// requester census above so the two cannot drift apart.
///
/// Files that DEFINE the writer are not writers; `clarification::ask` parks
/// with `Clarification`, whose release is the ask tool's own receipt, so the
/// reason filter leaves it out by construction rather than by name. Textual,
/// like its sibling: it proves each release is in the file, and the
/// behavioural pins (`sandbox::workspace::tests::an_approved_capability_card_
/// is_released_in_the_log_before_the_spawn`, `an_answered_gate_leaves_park_
/// then_decision_in_the_session_log`) prove it fires on the executed path.
#[test]
fn every_file_that_parks_on_an_approval_also_writes_both_releases() {
    use crate::utils::source_scan::{code_text, production_text, rust_sources_under};
    const WRITER: &str = "emit_for_ambient_call(";
    const REASONS: [&str; 2] = ["ParkReason::Approval", "ParkReason::PreHook"];
    const RELEASES: [&str; 2] = ["ToolCallApproved {", "ToolCallDenied {"];
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    let mut parks: std::collections::BTreeSet<String> = Default::default();
    let mut releases: std::collections::BTreeMap<String, Vec<&str>> = Default::default();
    for (rel, src) in rust_sources_under(&root) {
        let code = code_text(&production_text(std::path::Path::new(&rel), &src));
        if code.contains(&format!("fn {WRITER}")) || !code.contains(WRITER) {
            continue;
        }
        if REASONS.iter().any(|r| code.contains(r)) {
            parks.insert(rel.clone());
        }
        let written: Vec<&str> = RELEASES
            .iter()
            .copied()
            .filter(|needle| code.contains(needle))
            .collect();
        if written.len() == RELEASES.len() {
            releases.insert(rel, written);
        }
    }
    assert_eq!(
        parks.iter().map(String::as_str).collect::<Vec<_>>(),
        APPROVAL_PARK_FILES,
        "self-protection: the park set is the requester census's, or the scan is reading \
         the wrong thing: {parks:?}"
    );
    assert_eq!(
        releases.keys().collect::<std::collections::BTreeSet<_>>(),
        parks.iter().collect::<std::collections::BTreeSet<_>>(),
        "a file that parks a call on an approval must write its release (`ToolCallApproved`) \
         and its twin (`ToolCallDenied`) through the same writer — parks {parks:?}, \
         releases {releases:?}"
    );
}

/// §6.1 from the writer's side, through the one writer and the real actor
/// service: a gate that is asked and answered leaves `ToolCallParked` and THEN
/// the decision, in that order, in one session's log — the shape the
/// reducer's `an_answered_gate_ends_the_park` reads. The "before the
/// requester" half is `tests/parked_gate_integration.rs`; this pins the pair.
/// `SessionKey::ephemeral` so the shared test service's other users cannot
/// interleave rows here.
#[tokio::test]
async fn an_answered_gate_leaves_park_then_decision_in_the_session_log() {
    use crate::sandbox::exec_approval::gate::ApprovalOutcome;
    use crate::session::events::{ParkReason, SessionEvent, TurnId};
    use crate::session::service::SessionService as _;
    let sessions = crate::session::in_process::install_test_session_service();
    let key = crate::routing::session_key::SessionKey::ephemeral("parked-gate-unit");
    let mut turn = turn_ctx("parked-gate-unit");
    turn.session_key = key.clone();
    let requester = StdArc::new(FakeRequester::new(ApprovalOutcome::Denied));
    let svc = ScopedToolService::new(confirm_registry(), BTreeSet::new())
        .with_turn_context(turn)
        .with_confirmation(StdArc::clone(&requester) as _);
    let identity = crate::approval::CallIdentity {
        turn_id: TurnId::new_v4(),
        call_id: "toolu_unit".into(),
    };
    let result =
        crate::approval::with_call_identity(Some(identity), svc.execute("danger", json!({}))).await;
    assert!(result.is_err(), "a denied card does not run the tool");
    assert_eq!(
        requester.calls.load(Ordering::SeqCst),
        1,
        "the gate asked once"
    );

    let rows = sessions.get_events(&key, None, None).await.unwrap();
    let kinds: Vec<&str> = rows
        .iter()
        .map(|r| crate::session::store::event_type_tag(&r.event))
        .collect();
    // park -> decision -> memo, in that order: the gate's entry fact, its
    // exit fact, and the durable memo the decision leaves behind (§6.1 plus
    // the atomic memo batch — the memo rides the decision's `emit_batch`, not
    // a separate park).
    assert_eq!(
        kinds,
        ["tool_call_parked", "tool_call_denied", "approval_memo"]
    );
    assert!(
        matches!(
            &rows[0].event,
            SessionEvent::ToolCallParked { call_id, reason: ParkReason::Approval, .. }
                if call_id == "toolu_unit"
        ),
        "the confirm card parks as `Approval`, under the ambient call id: {:?}",
        rows[0].event
    );
    assert!(
        matches!(
            &rows[1].event,
            SessionEvent::ToolCallDenied { call_id, .. } if call_id == "toolu_unit"
        ),
        "the decision releases the same call id the park named: {:?}",
        rows[1].event
    );
    assert!(
        matches!(
            &rows[2].event,
            SessionEvent::ApprovalMemo { request_id, .. } if request_id == "toolu_unit"
        ),
        "the memo lands after the decision, under the same call id: {:?}",
        rows[2].event
    );
}

/// Reports the retrieval tools its dispatch scoped for it.
struct RecoveryProbe;

#[async_trait::async_trait]
impl LoopTool for RecoveryProbe {
    fn name(&self) -> &str {
        "recovery_probe"
    }
    fn description(&self) -> &str {
        "reports dispatch_recovery_tools"
    }
    fn schema(&self) -> Value {
        json!({ "type": "object" })
    }
    async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
        let seen = match crate::tools::result_processing::dispatch_recovery_tools() {
            Some(t) => format!("ctx_search={} file_read={}", t.ctx_search, t.file_read),
            None => "unscoped".to_string(),
        };
        LoopToolResult::Success {
            output: json!(seen),
        }
    }
}

/// A tool that offloads its own output (`web_fetch`'s fetch by intent) sees
/// the same callable retrieval tools Layer 2 derives for this dispatch — here
/// `file_read` is registered and `ctx_search` is not — so its footer never
/// names a tool the model cannot call.
///
/// Mutation-checked: dropping the dispatcher's `with_recovery_tools` scope
/// turns this red (`unscoped`).
#[tokio::test]
async fn a_dispatched_tool_sees_the_dispatchs_callable_retrieval_tools() {
    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(RecoveryProbe));
    registry.register(Box::new(NamedStub::new("file_read")));
    let svc = ScopedToolService::new(Arc::new(registry), BTreeSet::new());
    let out = svc
        .execute("recovery_probe", json!({}))
        .await
        .expect("the probe runs");
    let text = out.value.as_str().unwrap_or_default().to_string();
    assert!(
        text.contains("ctx_search=false file_read=true"),
        "got {text:?}"
    );
}

/// A subagent's allowlist narrows the retrieval set for everything under it —
/// the dispatched tool's own view and Layer 2's footer — through the real
/// chain (`AllowlistToolService` → `ScopedToolService`). The inner dispatcher
/// knows only its own gates, under which both retrieval tools are callable;
/// the wrapper's narrowing (no `ctx_search`) must win.
///
/// Mutation-checked: dropping the allowlist's `with_recovery_tools` scope, or
/// letting an inner scope replace an outer one instead of intersecting, turns
/// this red.
#[tokio::test]
async fn an_allowlist_narrows_the_retrieval_set_under_it() {
    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(RecoveryProbe));
    registry.register(Box::new(FailingTestRunner));
    registry.register(Box::new(StubTool {
        tool_name: "ctx_search",
    }));
    registry.register(Box::new(StubTool {
        tool_name: "file_read",
    }));
    let (_scratch, store) = hygiene_store("allowlist_chain");
    let parent: StdArc<dyn ToolService> = StdArc::new(
        ScopedToolService::new(StdArc::new(registry), BTreeSet::new()).with_result_store(store),
    );
    let mut def = crate::agents::AgentDef::new("narrow", crate::agents::AgentMode::SubAgent);
    def.allowed_tools = ["recovery_probe", "bash", "file_read"]
        .into_iter()
        .map(String::from)
        .collect();
    let child =
        crate::agents::allowlist_tool_service::AllowlistToolService::new(parent, StdArc::new(def));

    let seen = child
        .execute("recovery_probe", json!({}))
        .await
        .expect("the probe runs");
    assert_eq!(
        seen.value.as_str(),
        Some("ctx_search=false file_read=true"),
        "the tool's own view"
    );

    let out = child
        .execute("bash", json!({}))
        .await
        .expect("tool succeeds");
    let text = out.value.as_str().expect("flattened").to_string();
    let footer = text
        .split("[Full output persisted: ")
        .nth(1)
        .unwrap_or_else(|| panic!("precondition: the result was offloaded:\n{text}"));
    assert!(
        !footer.contains("ctx_search"),
        "the agent may not call ctx_search, yet Layer 2's footer names it:\n{footer}"
    );
    assert!(footer.contains("file_read"), "{footer}");
}

/// An agent that may call neither retrieval tool gets no offload — a path it
/// has no tool to open is a dead handle — but a cut that says the rest is
/// gone. Through the real chain: the inner dispatcher can call both, the
/// allowlist removes both.
///
/// Mutation-checked: dropping the empty-set check in `offload` turns this red.
#[tokio::test]
async fn an_agent_with_no_retrieval_tool_gets_a_cut_not_an_offload() {
    let mut registry = LoopToolRegistry::new();
    registry.register(Box::new(FailingTestRunner));
    registry.register(Box::new(StubTool {
        tool_name: "ctx_search",
    }));
    registry.register(Box::new(StubTool {
        tool_name: "file_read",
    }));
    let (_scratch, store) = hygiene_store("no_retrieval_chain");
    let parent: StdArc<dyn ToolService> = StdArc::new(
        ScopedToolService::new(StdArc::new(registry), BTreeSet::new()).with_result_store(store),
    );
    let mut def = crate::agents::AgentDef::new("sealed", crate::agents::AgentMode::SubAgent);
    def.allowed_tools = vec!["bash".to_string()];
    let child =
        crate::agents::allowlist_tool_service::AllowlistToolService::new(parent, StdArc::new(def));

    let out = child
        .execute("bash", json!({}))
        .await
        .expect("tool succeeds");
    let text = out.value.as_str().expect("flattened").to_string();
    assert!(
        !text.contains("[Full output persisted: "),
        "an offload this agent cannot read back:\n{text}"
    );
    assert!(
        text.contains("no retrieval tool"),
        "the cut says so:\n{text}"
    );
}

// A3 acceptance tests use the real registry projection, gates, hooks and retry
// pipeline. Only the terminal transport and human approval transport are doubles.
mod a3 {
    use super::*;
    use crate::approval::{with_call_identity, CallIdentity};
    use crate::sandbox::exec_approval::gate::{
        ApprovalOutcome, ApprovalRequester, ApprovalResponse,
    };
    use crate::sandbox::exec_approval::ApprovalAction;
    use crate::tools::descriptor::{ReplayPolicy, ToolCallIdentity, ToolCapabilityDescriptor};
    use crate::tools::handlers::ToolHandler;
    use crate::tools::registry::ToolHandlerRegistry;
    use crate::tools::service::ToolDefinitionMetadata;
    use std::collections::VecDeque;
    use tokio::sync::Barrier;
    // Planned readonly gate API, not a fixture-produced or writable verdict.
    use super::super::current_dispatch_verdict;

    #[derive(Debug, PartialEq)]
    struct VerdictAudit {
        own: bool,
        sibling_call: bool,
        wrong_name: bool,
        wrong_revision: bool,
        wrong_schema_version: bool,
        wrong_replay_policy: bool,
        wrong_fingerprint: bool,
        wrong_input: bool,
        sibling_actor: bool,
    }

    // The handler owns its expected identity independently of live registry
    // lookup: rev1 must remain rev1 even after the registry publishes rev2.
    fn unsafe_identity(revision: u64) -> ToolCallIdentity {
        ToolCallIdentity {
            schema_version: crate::tools::descriptor::SCHEMA_VERSION,
            revision,
            replay_policy: ReplayPolicy::Unsafe,
            replay_contract_fingerprint: None,
        }
    }

    // Planned matches borrowing shape: (&str, &str, &ToolCallIdentity,
    // &Value, Option<&str>). No test constructs DispatchVerdict; only the
    // actual production gates may mint it. Each negative changes ONE field.
    fn audit_verdict(name: &str, own_identity: &ToolCallIdentity, input: &Value) -> VerdictAudit {
        let call_id = crate::approval::current_tool_call_id().expect("handler has a call ID");
        let actor = crate::identity::current_actor();
        let verdict = current_dispatch_verdict().expect("gate must publish a dispatch verdict");
        let sibling_call = if call_id == "parallel-allow-a" {
            "parallel-allow-b"
        } else {
            "parallel-allow-a"
        };
        let sibling_actor = if actor.as_deref() == Some("actor-allow-a") {
            "actor-allow-b"
        } else {
            "actor-allow-a"
        };
        let wrong_identity = ToolCallIdentity {
            revision: own_identity.revision + 1,
            ..*own_identity
        };
        let wrong_schema_version = ToolCallIdentity {
            schema_version: own_identity.schema_version + 1,
            ..*own_identity
        };
        let wrong_replay_policy = ToolCallIdentity {
            replay_policy: ReplayPolicy::Safe,
            ..*own_identity
        };
        let mut fingerprint_source =
            ToolCapabilityDescriptor::from_definition(&definition(name, false), 0);
        fingerprint_source.replay_policy = ReplayPolicy::Safe;
        fingerprint_source.implementation_contract =
            Some(crate::tools::descriptor::ImplementationContract {
                id: "test:unrelated-contract".into(),
                version: "1".into(),
            });
        let wrong_fingerprint = ToolCallIdentity {
            replay_contract_fingerprint: Some(
                fingerprint_source.replay_contract_fingerprint().unwrap(),
            ),
            ..*own_identity
        };
        VerdictAudit {
            own: verdict.matches(&call_id, name, own_identity, input, actor.as_deref()),
            sibling_call: verdict.matches(
                sibling_call,
                name,
                own_identity,
                input,
                actor.as_deref(),
            ),
            wrong_name: verdict.matches(
                &call_id,
                "other-tool",
                own_identity,
                input,
                actor.as_deref(),
            ),
            wrong_revision: verdict.matches(
                &call_id,
                name,
                &wrong_identity,
                input,
                actor.as_deref(),
            ),
            wrong_schema_version: verdict.matches(
                &call_id,
                name,
                &wrong_schema_version,
                input,
                actor.as_deref(),
            ),
            wrong_replay_policy: verdict.matches(
                &call_id,
                name,
                &wrong_replay_policy,
                input,
                actor.as_deref(),
            ),
            wrong_fingerprint: verdict.matches(
                &call_id,
                name,
                &wrong_fingerprint,
                input,
                actor.as_deref(),
            ),
            wrong_input: verdict.matches(
                &call_id,
                name,
                own_identity,
                &json!({"different": true}),
                actor.as_deref(),
            ),
            sibling_actor: verdict.matches(
                &call_id,
                name,
                own_identity,
                input,
                Some(sibling_actor),
            ),
        }
    }

    fn assert_bound_verdict(audit: &VerdictAudit) {
        assert!(
            audit.own,
            "handler must hold authority for its exact tuple: {audit:?}"
        );
        assert!(
            !audit.sibling_call,
            "a sibling call cannot borrow proof: {audit:?}"
        );
        assert!(
            !audit.wrong_name,
            "proof must bind the tool name: {audit:?}"
        );
        assert!(
            !audit.wrong_revision,
            "proof must bind the captured revision: {audit:?}"
        );
        assert!(
            !audit.wrong_schema_version,
            "proof must bind the schema version: {audit:?}"
        );
        assert!(
            !audit.wrong_replay_policy,
            "proof must bind replay policy: {audit:?}"
        );
        assert!(
            !audit.wrong_fingerprint,
            "proof must bind the contract fingerprint: {audit:?}"
        );
        assert!(
            !audit.wrong_input,
            "proof must bind the executed bytes: {audit:?}"
        );
        assert!(
            !audit.sibling_actor,
            "a sibling actor cannot borrow proof: {audit:?}"
        );
    }

    #[derive(Debug, PartialEq)]
    struct Invocation {
        handler: &'static str,
        call_id: Option<String>,
        actor: Option<String>,
        input: Value,
        identity: ToolCallIdentity,
        before_yield: VerdictAudit,
        after_yield: VerdictAudit,
    }

    struct RecordingHandler {
        definition: ToolDefinition,
        tag: &'static str,
        invoked: StdArc<StdMutex<Vec<Invocation>>>,
        partial_write: Option<std::path::PathBuf>,
        own_identity: ToolCallIdentity,
        overlap: Option<StdArc<Barrier>>,
    }

    #[async_trait::async_trait]
    impl ToolHandler for RecordingHandler {
        fn definition(&self) -> ToolDefinition {
            self.definition.clone()
        }

        async fn invoke(&self, input: Value) -> Result<ToolOutput, ToolError> {
            let before_yield = audit_verdict(&self.definition.name, &self.own_identity, &input);
            if let Some(overlap) = &self.overlap {
                // Both authorized handlers must be live before either reads
                // its verdict again. join! interleaves them on ONE Tokio task.
                overlap.wait().await;
            }
            let after_yield = audit_verdict(&self.definition.name, &self.own_identity, &input);
            self.invoked.lock().unwrap().push(Invocation {
                handler: self.tag,
                call_id: crate::approval::current_tool_call_id(),
                actor: crate::identity::current_actor(),
                input,
                identity: self.own_identity,
                before_yield,
                after_yield,
            });
            if let Some(path) = &self.partial_write {
                use std::io::Write;
                let mut sink = std::fs::OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(path)
                    .unwrap();
                // The first bytes reached the terminal before transport failed.
                sink.write_all(b"partial\n").unwrap();
                sink.flush().unwrap();
                return Err(ToolError::Transport {
                    name: self.definition.name.clone(),
                    cause: "terminal disconnected after partial write".into(),
                });
            }
            Ok(ToolOutput {
                value: json!({"handler": self.tag}),
                metadata: Default::default(),
            })
        }
    }

    fn definition(name: &str, idempotent: bool) -> ToolDefinition {
        ToolDefinition {
            name: name.into(),
            description: "A3 terminal transport fixture".into(),
            input_schema: json!({"type": "object"}),
            source: ToolSource::Builtin,
            metadata: ToolDefinitionMetadata {
                requires_approval: true,
                idempotent,
                max_duration_ms: Some(2_000),
                ..Default::default()
            },
        }
    }

    fn register(registry: &ToolHandlerRegistry, handler: impl ToolHandler) {
        let descriptor = ToolCapabilityDescriptor::from_definition(&handler.definition(), 0);
        registry.register(descriptor, StdArc::new(handler)).unwrap();
    }

    // The projection remains the real production adapter, for discovery.
    // PLANNED INTERNAL SEAM / COMPILE RED: ScopedToolService needs a retained
    // Arc<ToolHandlerRegistry> to resolve_entry ONCE before gates, then dispatch
    // that captured entry. This test-only helper assumes private storage named
    // `canonical_registry`; no new public builder or fake live adapter is used.
    // Today neither LoopToolRegistry nor McpRegistryTool retains that link or
    // a full RegistryEntry, so fixing only resolve_entry cannot make this green.
    fn service(registry: &StdArc<ToolHandlerRegistry>) -> ScopedToolService {
        let mut inner = LoopToolRegistry::new();
        for entry in registry.entries_snapshot().values() {
            inner.register(Box::new(
                crate::tools::adapters::McpRegistryTool::from_registry_entry(
                    StdArc::clone(&entry.handler),
                    &entry.descriptor,
                ),
            ));
        }
        let mut svc = ScopedToolService::new(StdArc::new(inner), BTreeSet::new());
        svc.canonical_registry = Some(StdArc::clone(registry));
        svc
    }

    fn identity(id: &str) -> CallIdentity {
        CallIdentity {
            turn_id: crate::session::events::TurnId::nil(),
            call_id: id.into(),
        }
    }

    struct SequenceRequester {
        answers: StdMutex<VecDeque<ApprovalOutcome>>,
        seen: StdMutex<Vec<(Option<String>, ApprovalAction)>>,
    }

    impl SequenceRequester {
        fn new(answers: impl IntoIterator<Item = ApprovalOutcome>) -> Self {
            Self {
                answers: StdMutex::new(answers.into_iter().collect()),
                seen: StdMutex::new(Vec::new()),
            }
        }
    }

    #[async_trait::async_trait]
    impl ApprovalRequester for SequenceRequester {
        async fn request_approval(&self, action: &ApprovalAction) -> ApprovalResponse {
            self.seen
                .lock()
                .unwrap()
                .push((crate::approval::current_tool_call_id(), action.clone()));
            self.answers
                .lock()
                .unwrap()
                .pop_front()
                .unwrap_or(ApprovalOutcome::Denied)
                .into()
        }
    }

    /// Exercise the real inline gate while retaining the admitted descriptor.
    struct OperatorProofProbe {
        name: &'static str,
        approved: bool,
    }

    #[async_trait::async_trait]
    impl ToolHandler for OperatorProofProbe {
        fn definition(&self) -> ToolDefinition {
            definition(self.name, false)
        }

        async fn invoke(&self, input: Value) -> Result<ToolOutput, ToolError> {
            use crate::tools::dispatch_verdict::{
                consume_operator_approval, with_admitted_handler,
            };
            use crate::tools::turn_context::{current_turn_context, TURN_CONTEXT};
            let name = self.name;
            assert!(!consume_operator_approval("terminal_sessions_read", &input));
            assert!(!consume_operator_approval(
                name,
                &json!({"different": true})
            ));
            assert!(
                !with_call_identity(Some(identity("wrong-call")), async {
                    consume_operator_approval(name, &input)
                })
                .await
            );
            assert!(
                !crate::identity::as_actor("wrong-actor", async {
                    consume_operator_approval(name, &input)
                })
                .await
            );
            let mut other = current_turn_context().unwrap();
            other.run_id.push_str("-another-run");
            assert!(
                !TURN_CONTEXT
                    .scope(other, async { consume_operator_approval(name, &input) })
                    .await
            );
            let verdict = current_dispatch_verdict().unwrap();
            let mut wrong_identity = unsafe_identity(999);
            assert!(
                !with_admitted_handler(wrong_identity, async {
                    consume_operator_approval(name, &input)
                })
                .await
            );
            wrong_identity.revision = 1;
            wrong_identity.schema_version += 1;
            assert!(
                !with_admitted_handler(wrong_identity, async {
                    consume_operator_approval(name, &input)
                })
                .await
            );
            let child_input = input.clone();
            let ctx = current_turn_context().unwrap();
            assert!(!tokio::spawn(async move {
                TURN_CONTEXT
                    .scope(
                        ctx,
                        with_call_identity(Some(identity("proof-call")), async {
                            consume_operator_approval(name, &child_input)
                        }),
                    )
                    .await
            })
            .await
            .unwrap());
            assert!(current_turn_context().unwrap().caller_role.as_deref() == Some("guest"));
            // Actual runtime query, not merely a proof predicate or mocked effect.
            let first = crate::builtin_tools::terminal::capabilities::invoke_observation(
                "terminal_sessions_list",
                input.clone(),
            )
            .await?;
            assert_eq!(first.value["success"], json!(self.approved));
            if self.approved {
                assert!(first.value["data"].is_object() || first.value["data"].is_array());
            } else {
                assert!(first.value["data"].is_null());
            }
            let second = crate::builtin_tools::terminal::capabilities::invoke_observation(
                "terminal_sessions_list",
                input.clone(),
            )
            .await?;
            assert_eq!(
                second.value["success"],
                json!(false),
                "approval is one-shot"
            );
            assert!(!consume_operator_approval(name, &input));
            assert!(current_dispatch_verdict().is_some());
            drop(verdict);
            assert_eq!(
                current_turn_context().unwrap().caller_role.as_deref(),
                Some("guest")
            );
            Ok(first)
        }
    }

    #[tokio::test]
    async fn operator_proof_is_exact_single_use_and_not_generic_admission() {
        for (name, approved) in [("terminal_sessions_list", true), ("file_read", false)] {
            let registry = StdArc::new(ToolHandlerRegistry::new());
            register(&registry, OperatorProofProbe { name, approved });
            let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
            let mut ctx = turn_ctx(if approved {
                "operator-proof"
            } else {
                "generic-proof"
            });
            ctx.caller_role = Some("guest".into());
            let svc = service(&registry)
                .with_turn_context(ctx)
                .with_config_approval(requester.clone())
                .with_confirmation(StdArc::new(SequenceRequester::new([
                    ApprovalOutcome::Approved,
                ])));
            crate::identity::as_actor(
                "proof-actor",
                with_call_identity(Some(identity("proof-call")), svc.execute(name, json!({}))),
            )
            .await
            .expect("the admitted probe executes");
            assert_eq!(requester.seen.lock().unwrap().len(), usize::from(approved));
            assert!(!crate::tools::dispatch_verdict::consume_operator_approval(
                name,
                &json!({})
            ));
        }
    }

    #[tokio::test]
    async fn operator_proof_reaches_registered_terminal_without_changing_role() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let mut scope = crate::tools::ToolRegistrationScope::new("operator-proof-real");
        crate::builtin_tools::terminal::capabilities::register_observation_capabilities(
            &registry, &mut scope,
        )
        .unwrap();
        let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
        let confirmation = StdArc::new(SequenceRequester::new([]));
        let mut ctx = turn_ctx("operator-proof-real");
        ctx.caller_role = Some("guest".into());
        let svc = service(&registry)
            .with_turn_context(ctx.clone())
            .with_config_approval(requester.clone())
            .with_confirmation(confirmation.clone());
        let output = with_call_identity(
            Some(identity("operator-proof-real")),
            svc.execute("terminal_sessions_list", json!({})),
        )
        .await
        .expect("approved guest reaches the actual registered terminal handler");
        let value = parse_tool_output(&output.value);
        assert_eq!(value["success"], json!(true));
        assert!(!value["data"].is_null());
        assert_eq!(ctx.caller_role.as_deref(), Some("guest"));
        assert_eq!(requester.seen.lock().unwrap().len(), 1);
        assert!(confirmation.seen.lock().unwrap().is_empty());
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn operator_proof_requires_approval_of_rewritten_terminal_input() {
        for allow_rewrite in [false, true] {
            let registry = StdArc::new(ToolHandlerRegistry::new());
            let mut scope = crate::tools::ToolRegistrationScope::new("operator-proof-rewrite");
            crate::builtin_tools::terminal::capabilities::register_observation_capabilities(
                &registry, &mut scope,
            )
            .unwrap();
            let requester = StdArc::new(SequenceRequester::new([
                ApprovalOutcome::Approved,
                if allow_rewrite {
                    ApprovalOutcome::Approved
                } else {
                    ApprovalOutcome::Denied
                },
            ]));
            let hooks = StdArc::new(HookExecutor::new(vec![make_command_hook(
                HookEvent::BeforeToolCall,
                HookKind::Interceptor,
                r#"printf '%s\n' 'update_input: {"session_id":"rewritten"}'"#,
            )]));
            let mut ctx = turn_ctx(if allow_rewrite {
                "proof-rewrite-yes"
            } else {
                "proof-rewrite-no"
            });
            ctx.caller_role = Some("guest".into());
            let svc = service(&registry)
                .with_turn_context(ctx)
                .with_config_approval(requester.clone())
                .with_hook_executor(hooks, "proof-rewrite");
            let (result, effective) = with_call_identity(
                Some(identity("proof-rewrite")),
                svc.execute_with_cancel_effective(
                    "terminal_sessions_list",
                    json!({}),
                    CancellationToken::new(),
                ),
            )
            .await;
            let seen = requester.seen.lock().unwrap();
            assert_eq!(seen.len(), 2);
            assert_ne!(seen[0].1.grant_key, seen[1].1.grant_key);
            if allow_rewrite {
                assert_eq!(
                    parse_tool_output(&result.unwrap().value)["success"],
                    json!(true)
                );
                assert_eq!(effective, Some(json!({"session_id": "rewritten"})));
            } else {
                assert!(matches!(result, Err(ToolError::PermissionDenied { .. })));
                assert_eq!(effective, None);
            }
        }
    }

    struct OperatorScopeProbe {
        concurrent: bool,
    }

    #[async_trait::async_trait]
    impl ToolHandler for OperatorScopeProbe {
        fn definition(&self) -> ToolDefinition {
            definition("terminal_sessions_list", false)
        }

        async fn invoke(&self, input: Value) -> Result<ToolOutput, ToolError> {
            use crate::tools::dispatch_verdict::{
                consume_operator_approval, current_admitted_handler_identity, without_admission,
            };
            let name = "terminal_sessions_list";
            let outer_identity = current_admitted_handler_identity().expect("registry identity");
            assert!(current_dispatch_verdict().is_some());
            if self.concurrent {
                // Both futures arrive before either may consume the same proof.
                // Directly awaited futures retain the actual admission scope;
                // spawning tasks would lose it and only test two refusals.
                let ready = Barrier::new(2);
                let consume = || async {
                    ready.wait().await;
                    consume_operator_approval(name, &input)
                };
                let (first, second) = tokio::join!(consume(), consume());
                assert_eq!(usize::from(first) + usize::from(second), 1);
                assert!(!consume_operator_approval(name, &input));
            } else {
                without_admission(Box::pin(async {
                    assert!(current_dispatch_verdict().is_none());
                    assert!(current_admitted_handler_identity().is_none());
                    assert!(!consume_operator_approval(name, &input));
                    // A second nested scope must remain empty too.
                    without_admission(Box::pin(async {
                        assert!(current_dispatch_verdict().is_none());
                        assert!(current_admitted_handler_identity().is_none());
                    }))
                    .await;
                }))
                .await;
                assert_eq!(current_admitted_handler_identity(), Some(outer_identity));
                assert!(current_dispatch_verdict().is_some());
                assert!(
                    consume_operator_approval(name, &input),
                    "parent proof restored unused"
                );
            }
            assert_eq!(
                crate::tools::turn_context::current_turn_context()
                    .unwrap()
                    .caller_role
                    .as_deref(),
                Some("guest"),
            );
            Ok(ToolOutput {
                value: json!({"checked": true}),
                metadata: Default::default(),
            })
        }
    }

    async fn run_operator_scope_probe(concurrent: bool) {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        register(&registry, OperatorScopeProbe { concurrent });
        let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
        let mut ctx = turn_ctx(if concurrent {
            "proof-race"
        } else {
            "proof-nested"
        });
        ctx.caller_role = Some("guest".into());
        let svc = service(&registry)
            .with_turn_context(ctx)
            .with_config_approval(requester.clone());
        crate::identity::as_actor(
            "proof-scope-actor",
            with_call_identity(
                Some(identity("proof-scope-call")),
                svc.execute("terminal_sessions_list", json!({})),
            ),
        )
        .await
        .expect("real operator-approved admission reaches probe");
        assert_eq!(requester.seen.lock().unwrap().len(), 1);
        assert!(current_dispatch_verdict().is_none());
        assert!(crate::tools::dispatch_verdict::current_admitted_handler_identity().is_none());
    }

    #[tokio::test]
    async fn operator_proof_nested_admission_masks_identity_and_restores_parent() {
        run_operator_scope_probe(false).await;
    }

    #[tokio::test]
    async fn operator_proof_concurrent_consumers_claim_once() {
        run_operator_scope_probe(true).await;
    }

    struct BoundaryRequester {
        registry: StdArc<ToolHandlerRegistry>,
        arrived: StdArc<Barrier>,
        release: StdArc<Barrier>,
        seen: StdMutex<Vec<(String, ToolCallIdentity)>>,
    }

    #[async_trait::async_trait]
    impl ApprovalRequester for BoundaryRequester {
        async fn request_approval(&self, action: &ApprovalAction) -> ApprovalResponse {
            let entry = self.registry.resolve_entry(&action.tool_name).unwrap();
            let first = {
                let mut seen = self.seen.lock().unwrap();
                let first = seen.is_empty();
                seen.push((
                    crate::approval::current_tool_call_id().unwrap(),
                    ToolCallIdentity::from_descriptor(&entry.descriptor),
                ));
                first
            };
            if first {
                self.arrived.wait().await;
                self.release.wait().await;
            }
            ApprovalOutcome::Approved.into()
        }
    }

    // Break caught: re-resolving by name after approval executes rev2 under
    // rev1 authority instead of the captured handler.
    // The same service must refresh only the NEXT call. Authority is observed
    // inside the real handlers, not inferred from ambient ID or registry reads.
    #[tokio::test]
    async fn replacement_between_gate_and_dispatch_uses_captured_entry() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        register(
            &registry,
            RecordingHandler {
                definition: definition("terminal", false),
                tag: "handler1",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        let arrived = StdArc::new(Barrier::new(2));
        let release = StdArc::new(Barrier::new(2));
        let requester = StdArc::new(BoundaryRequester {
            registry: registry.clone(),
            arrived: arrived.clone(),
            release: release.clone(),
            seen: StdMutex::new(Vec::new()),
        });
        let svc = StdArc::new(
            service(&registry)
                .with_turn_context(turn_ctx("a3-replacement"))
                .with_confirmation(requester.clone()),
        );
        let first_svc = svc.clone();
        let first = tokio::spawn(with_call_identity(
            Some(identity("replace-a")),
            async move {
                first_svc
                    .execute("terminal", json!({"action": "write", "data": "one"}))
                    .await
            },
        ));
        tokio::time::timeout(std::time::Duration::from_secs(5), arrived.wait())
            .await
            .expect("rev1 must reach the approval barrier");
        let replacement = RecordingHandler {
            definition: definition("terminal", false),
            tag: "handler2",
            invoked: invoked.clone(),
            partial_write: None,
            own_identity: unsafe_identity(2),
            overlap: None,
        };
        registry
            .replace(
                ToolCapabilityDescriptor::from_definition(&replacement.definition(), 0),
                StdArc::new(replacement),
            )
            .unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(5), release.wait())
            .await
            .expect("replacement must release the in-flight gate");
        let first_output = tokio::time::timeout(std::time::Duration::from_secs(5), first)
            .await
            .expect("captured rev1 dispatch must complete")
            .unwrap()
            .expect("in-flight approval was granted");
        assert_eq!(
            parse_tool_output(&first_output.value),
            json!({"handler": "handler1"})
        );
        assert_eq!(requester.seen.lock().unwrap()[0].1.revision, 1);
        assert_eq!(invoked.lock().unwrap()[0].handler, "handler1");

        // Deliberately no service rebuild: stale request projection is not
        // an acceptable substitute for the canonical next-call snapshot.
        let next_output = with_call_identity(
            Some(identity("replace-b")),
            svc.execute("terminal", json!({"action": "write", "data": "two"})),
        )
        .await
        .expect("next call was separately approved");
        let boundary = requester.seen.lock().unwrap();
        assert_eq!(
            boundary
                .iter()
                .map(|(id, i)| (id.as_str(), i.revision))
                .collect::<Vec<_>>(),
            vec![("replace-a", 1), ("replace-b", 2)]
        );
        let calls = invoked.lock().unwrap();
        assert_eq!(calls.len(), 2);
        assert_eq!(calls[0].call_id.as_deref(), Some("replace-a"));
        assert_eq!(calls[1].call_id.as_deref(), Some("replace-b"));
        assert_eq!(calls[0].identity, unsafe_identity(1));
        assert_eq!(calls[1].identity, unsafe_identity(2));
        assert_eq!(calls[0].input, json!({"action": "write", "data": "one"}));
        assert_eq!(calls[1].input, json!({"action": "write", "data": "two"}));
        for call in calls.iter() {
            assert_bound_verdict(&call.before_yield);
            assert_bound_verdict(&call.after_yield);
        }
        assert!(
            current_dispatch_verdict().is_none(),
            "proof must leave the dispatch scope"
        );
        assert_eq!(
            calls[1].handler, "handler2",
            "rev2 boundary identity must name the executed handler"
        );
        assert_eq!(
            parse_tool_output(&next_output.value),
            json!({"handler": "handler2"})
        );
    }

    // Break caught: `authorized` on the original bytes skips the gate after a
    // hook replaces them, letting an AllowOnce authorize different terminal I/O.
    #[cfg(unix)]
    #[tokio::test]
    async fn proof_for_original_input_cannot_authorize_rewrite() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        register(
            &registry,
            RecordingHandler {
                definition: definition("terminal", false),
                tag: "terminal",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        let requester = StdArc::new(SequenceRequester::new([
            ApprovalOutcome::Approved,
            ApprovalOutcome::Denied,
        ]));
        let executor = StdArc::new(HookExecutor::new(vec![make_command_hook(
            HookEvent::BeforeToolCall,
            HookKind::Interceptor,
            r#"printf '%s\n' 'update_input: {"action":"write","data":"rewritten"}'"#,
        )]));
        let svc = service(&registry)
            .with_turn_context(turn_ctx("a3-rewrite"))
            .with_confirmation(requester.clone())
            .with_hook_executor(executor, "a3-rewrite");
        let (result, effective) = with_call_identity(
            Some(identity("rewrite-a")),
            svc.execute_with_cancel_effective(
                "terminal",
                json!({"action": "write", "data": "original"}),
                CancellationToken::new(),
            ),
        )
        .await;
        assert!(
            invoked.lock().unwrap().is_empty(),
            "no rewritten bytes were approved; terminal must not be reached"
        );
        assert!(
            matches!(result, Err(ToolError::Refused { .. })),
            "rewritten input must be refused, got {result:?}"
        );
        assert_eq!(
            effective, None,
            "a refused rewrite never crosses the dispatch line"
        );
        let seen = requester.seen.lock().unwrap();
        assert_eq!(seen.len(), 2, "the rewrite needs a new decision");
        assert_eq!(seen[0].0.as_deref(), Some("rewrite-a"));
        assert_eq!(seen[1].0.as_deref(), Some("rewrite-a"));
        assert_ne!(seen[0].1.grant_key, seen[1].1.grant_key);
        assert!(seen[0].1.summary.contains("original"));
        assert!(seen[1].1.summary.contains("rewritten"));
    }

    struct ParallelRequester {
        barrier: Barrier,
        seen: StdMutex<Vec<(String, String, Option<String>)>>,
    }

    #[async_trait::async_trait]
    impl ApprovalRequester for ParallelRequester {
        async fn request_approval(&self, action: &ApprovalAction) -> ApprovalResponse {
            assert!(
                current_dispatch_verdict().is_none(),
                "pending approval has no proof yet"
            );
            let id = crate::approval::current_tool_call_id().unwrap();
            self.seen.lock().unwrap().push((
                id.clone(),
                action.tool_name.clone(),
                crate::identity::current_actor(),
            ));
            self.barrier.wait().await;
            assert!(
                current_dispatch_verdict().is_none(),
                "a sibling's live proof cannot enter this gate"
            );
            if id == "parallel-allow-a" || id == "parallel-allow-b" {
                ApprovalOutcome::Approved.into()
            } else {
                ApprovalOutcome::Denied.into()
            }
        }
    }

    // Break caught: a name-keyed/shared verdict authorizes the wrong call or
    // actor while two approved handlers overlap. A denied third sibling must
    // never reach the handler. Same name AND identical input on purpose.
    #[tokio::test]
    async fn same_name_parallel_calls_do_not_share_verdict() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        register(
            &registry,
            RecordingHandler {
                definition: definition("terminal", false),
                tag: "terminal",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: Some(StdArc::new(Barrier::new(2))),
            },
        );
        let requester = StdArc::new(ParallelRequester {
            barrier: Barrier::new(3),
            seen: StdMutex::new(Vec::new()),
        });
        let svc = service(&registry)
            .with_turn_context(turn_ctx("a3-parallel"))
            .with_confirmation(requester.clone());
        let input = json!({"action": "write", "data": "same-bytes"});
        let allow_a = crate::identity::as_actor(
            "actor-allow-a",
            with_call_identity(
                Some(identity("parallel-allow-a")),
                svc.execute("terminal", input.clone()),
            ),
        );
        let allow_b = crate::identity::as_actor(
            "actor-allow-b",
            with_call_identity(
                Some(identity("parallel-allow-b")),
                svc.execute("terminal", input.clone()),
            ),
        );
        let deny = crate::identity::as_actor(
            "actor-deny",
            with_call_identity(
                Some(identity("parallel-deny")),
                svc.execute("terminal", input.clone()),
            ),
        );
        assert!(current_dispatch_verdict().is_none());
        let (allowed_a, allowed_b, denied) =
            tokio::time::timeout(std::time::Duration::from_secs(5), async {
                // Deliberately not spawn: sibling futures share a Tokio task,
                // so per-future restoration must work across handler awaits.
                tokio::join!(allow_a, allow_b, deny)
            })
            .await
            .expect("three decisions and two live handlers must cross their barriers");
        assert!(
            allowed_a.is_ok(),
            "approved sibling A must run: {allowed_a:?}"
        );
        assert!(
            allowed_b.is_ok(),
            "approved sibling B must run: {allowed_b:?}"
        );
        assert!(
            matches!(denied, Err(ToolError::Refused { .. })),
            "denied sibling must not run: {denied:?}"
        );
        assert!(
            current_dispatch_verdict().is_none(),
            "proof must not escape join!"
        );
        let mut calls = invoked.lock().unwrap();
        calls.sort_by(|a, b| a.call_id.cmp(&b.call_id));
        assert_eq!(
            calls.len(),
            2,
            "denied sibling cannot borrow either live proof"
        );
        for (call, id, actor) in [
            (&calls[0], "parallel-allow-a", "actor-allow-a"),
            (&calls[1], "parallel-allow-b", "actor-allow-b"),
        ] {
            assert_eq!(call.handler, "terminal");
            assert_eq!(call.call_id.as_deref(), Some(id));
            assert_eq!(call.actor.as_deref(), Some(actor));
            assert_eq!(call.input, input);
            assert_eq!(call.identity, unsafe_identity(1));
            assert_bound_verdict(&call.before_yield);
            assert_bound_verdict(&call.after_yield);
        }
        let mut seen = requester.seen.lock().unwrap().clone();
        seen.sort_by(|a, b| a.0.cmp(&b.0));
        assert_eq!(
            seen,
            vec![
                (
                    "parallel-allow-a".into(),
                    "terminal".into(),
                    Some("actor-allow-a".into())
                ),
                (
                    "parallel-allow-b".into(),
                    "terminal".into(),
                    Some("actor-allow-b".into())
                ),
                (
                    "parallel-deny".into(),
                    "terminal".into(),
                    Some("actor-deny".into())
                ),
            ]
        );
    }

    struct SpawningHandler {
        definition: ToolDefinition,
        service: StdArc<std::sync::OnceLock<std::sync::Weak<ScopedToolService>>>,
        writes: StdArc<AtomicUsize>,
        parent_audits: StdArc<StdMutex<Vec<VerdictAudit>>>,
        own_identity: ToolCallIdentity,
    }

    #[async_trait::async_trait]
    impl ToolHandler for SpawningHandler {
        fn definition(&self) -> ToolDefinition {
            self.definition.clone()
        }

        async fn invoke(&self, input: Value) -> Result<ToolOutput, ToolError> {
            // The second invocation is the unauthorized child if the gate leaks.
            // Do not recurse forever when demonstrating that failure.
            if self.writes.fetch_add(1, Ordering::SeqCst) != 0 {
                return Ok(ToolOutput {
                    value: json!({"unauthorized_child_write": true}),
                    metadata: Default::default(),
                });
            }
            self.parent_audits.lock().unwrap().push(audit_verdict(
                &self.definition.name,
                &self.own_identity,
                &input,
            ));
            let svc = self.service.get().unwrap().upgrade().unwrap();
            let name = self.definition.name.clone();
            let child_input = input.clone();
            let child = tokio::spawn(async move {
                let call_id = crate::approval::current_tool_call_id();
                let actor = crate::identity::current_actor();
                let proof_before = current_dispatch_verdict().is_some();
                let result = svc.execute(&name, child_input).await;
                let proof_after = current_dispatch_verdict().is_some();
                json!({
                    "child_call_id": call_id,
                    "child_actor": actor,
                    "child_proof_before": proof_before,
                    "child_proof_after": proof_after,
                    "child_denied": matches!(result, Err(ToolError::Refused { .. }) | Err(ToolError::PermissionDenied { .. })),
                })
            }).await.unwrap();
            // Awaiting a child must not consume or overwrite the parent's proof.
            self.parent_audits.lock().unwrap().push(audit_verdict(
                &self.definition.name,
                &self.own_identity,
                &input,
            ));
            Ok(ToolOutput {
                value: child,
                metadata: Default::default(),
            })
        }
    }

    // Break caught: publishing a call proof on the shared service (or copying
    // it into spawned children) authorizes a child without its own decision.
    // Observe actual proof absence in the child AND parent proof on both sides
    // of spawn. Merely failing at the parent's operator gate cannot pass this.
    #[tokio::test]
    async fn child_task_does_not_inherit_human_or_operator_proof() {
        for (name, session, parent_id) in [
            ("terminal", "a3-child-human", "parent-human"),
            ("vault_store", "a3-child-operator", "parent-operator"),
        ] {
            let registry = StdArc::new(ToolHandlerRegistry::new());
            let cell = StdArc::new(std::sync::OnceLock::new());
            let writes = StdArc::new(AtomicUsize::new(0));
            let parent_audits = StdArc::new(StdMutex::new(Vec::new()));
            register(
                &registry,
                SpawningHandler {
                    definition: definition(name, false),
                    service: cell.clone(),
                    writes: writes.clone(),
                    parent_audits: parent_audits.clone(),
                    own_identity: unsafe_identity(1),
                },
            );
            let requester = StdArc::new(SequenceRequester::new([
                ApprovalOutcome::Approved,
                ApprovalOutcome::Denied,
            ]));
            let own_channel = StdArc::new(SequenceRequester::new([]));
            let mut ctx = turn_ctx(session);
            // terminal also requires operator status. Keep its parent
            // operator-tier (None) so it reaches HUMAN confirmation; only the
            // vault case is guest-tier and exercises live operator approval.
            if name == "vault_store" {
                ctx.caller_role = Some("guest".into());
            }
            let svc = service(&registry).with_turn_context(ctx);
            let svc = StdArc::new(if name == "vault_store" {
                svc.with_config_approval(requester.clone())
                    .with_confirmation(own_channel.clone())
            } else {
                svc.with_confirmation(requester.clone())
            });
            assert!(cell.set(StdArc::downgrade(&svc)).is_ok());
            let output = tokio::time::timeout(
                std::time::Duration::from_secs(5),
                crate::identity::as_actor(
                    "parent-actor",
                    with_call_identity(
                        Some(identity(parent_id)),
                        svc.execute(name, json!({"data": "same-bytes"})),
                    ),
                ),
            )
            .await
            .expect("parent and its independently gated child must complete")
            .expect("only the parent call is approved");
            assert_eq!(
                writes.load(Ordering::SeqCst),
                1,
                "{name}: child must not reach the write transport"
            );
            assert_eq!(
                parse_tool_output(&output.value),
                json!({
                    "child_call_id": null, "child_actor": null, "child_denied": true,
                    "child_proof_before": false, "child_proof_after": false,
                }),
                "{name}: child requires its own identity and decision"
            );
            let audits = parent_audits.lock().unwrap();
            assert_eq!(
                audits.len(),
                2,
                "{name}: parent must reach the handler and survive spawn"
            );
            for audit in audits.iter() {
                assert_bound_verdict(audit);
            }
            assert!(
                current_dispatch_verdict().is_none(),
                "parent proof must be scoped"
            );
            let seen = requester.seen.lock().unwrap();
            assert_eq!(seen.len(), 2, "{name}: child must ask independently");
            assert_eq!(seen[0].0.as_deref(), Some(parent_id));
            assert_eq!(seen[1].0, None);
            assert!(
                own_channel.seen.lock().unwrap().is_empty(),
                "operator approval must not double-prompt the parent's own channel"
            );
        }
    }

    // Break caught: an optimistic legacy idempotent bit overrides explicit
    // Unsafe replay policy and respins a terminal write after bytes escaped.
    #[tokio::test]
    async fn unsafe_terminal_write_error_is_not_retried() {
        let dir = tempfile::tempdir().unwrap();
        let sink = dir.path().join("terminal-bytes");
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        // Unsafe is a separate contract, not inferred from idempotency. Keep
        // the old bit optimistic so this cannot pass merely on a static list.
        register(
            &registry,
            RecordingHandler {
                definition: definition("terminal", true),
                tag: "terminal",
                invoked: invoked.clone(),
                partial_write: Some(sink.clone()),
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        assert_eq!(
            registry.descriptor("terminal").unwrap().replay_policy,
            ReplayPolicy::Unsafe
        );
        let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
        let svc = service(&registry)
            .with_turn_context(turn_ctx("a3-partial-write"))
            .with_confirmation(requester.clone());
        let result = with_call_identity(
            Some(identity("partial-write")),
            svc.execute("terminal", json!({"action": "write", "data": "partial"})),
        )
        .await;
        assert!(
            matches!(result, Err(ToolError::Transport { .. })),
            "partial-write error must reach the caller: {result:?}"
        );
        assert_eq!(
            std::fs::read(&sink).unwrap(),
            b"partial\n",
            "partial bytes must reach the terminal exactly once"
        );
        assert_eq!(
            invoked.lock().unwrap().len(),
            1,
            "Unsafe terminal I/O must have exactly one attempt"
        );
        for call in invoked.lock().unwrap().iter() {
            assert_bound_verdict(&call.before_yield);
            assert_bound_verdict(&call.after_yield);
        }
        assert!(
            current_dispatch_verdict().is_none(),
            "error must clear the dispatch proof"
        );
        assert_eq!(
            requester.seen.lock().unwrap().len(),
            1,
            "a retry must not hide behind the original approval"
        );
    }

    #[tokio::test]
    async fn removed_canonical_entry_never_resurrects_its_projection() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        register(
            &registry,
            RecordingHandler {
                definition: definition("terminal", false),
                tag: "old",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
        let svc = service(&registry).with_confirmation(requester.clone());
        registry.unregister("terminal").unwrap();
        let (result, effective) = with_call_identity(
            Some(identity("removed")),
            svc.execute_with_cancel_effective(
                "terminal",
                json!({"action": "write"}),
                CancellationToken::new(),
            ),
        )
        .await;
        assert!(matches!(result, Err(ToolError::NotFound { .. })));
        assert_eq!(effective, None);
        assert!(
            invoked.lock().unwrap().is_empty(),
            "old projection is not fallback authority"
        );
        assert!(
            requester.seen.lock().unwrap().is_empty(),
            "removed entry cannot even request admission"
        );
        assert!(current_dispatch_verdict().is_none());
    }

    #[tokio::test]
    async fn source_changed_canonical_entry_fails_closed_for_same_service() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        register(
            &registry,
            RecordingHandler {
                definition: definition("terminal", false),
                tag: "old",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        let svc = service(&registry);
        let mut changed = definition("terminal", false);
        changed.source = ToolSource::Mcp {
            server_id: "hidden-server".into(),
        };
        let replacement = RecordingHandler {
            definition: changed,
            tag: "hidden",
            invoked: invoked.clone(),
            partial_write: None,
            own_identity: unsafe_identity(2),
            overlap: None,
        };
        registry
            .replace(
                ToolCapabilityDescriptor::from_definition(&replacement.definition(), 0),
                StdArc::new(replacement),
            )
            .unwrap();
        let (result, effective) = with_call_identity(
            Some(identity("source-change")),
            svc.execute_with_cancel_effective("terminal", json!({}), CancellationToken::new()),
        )
        .await;
        assert!(matches!(result, Err(ToolError::PermissionDenied { .. })));
        assert_eq!(effective, None);
        assert!(invoked.lock().unwrap().is_empty());
    }

    #[tokio::test]
    async fn live_canonical_descriptor_not_stale_projection_decides_next_confirmation() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        let mut first = definition("terminal", true);
        first.metadata.requires_approval = false;
        register(
            &registry,
            RecordingHandler {
                definition: first,
                tag: "old",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Denied]));
        let svc = service(&registry)
            .with_exec_tier(crate::config::types::policies::ExecTier::Full)
            .with_confirmation(requester.clone());
        let replacement = RecordingHandler {
            definition: definition("terminal", false),
            tag: "new-confirmed",
            invoked: invoked.clone(),
            partial_write: None,
            own_identity: unsafe_identity(2),
            overlap: None,
        };
        registry
            .replace(
                ToolCapabilityDescriptor::from_definition(&replacement.definition(), 0),
                StdArc::new(replacement),
            )
            .unwrap();
        let (result, effective) = with_call_identity(
            Some(identity("fresh-floor")),
            svc.execute_with_cancel_effective("terminal", json!({}), CancellationToken::new()),
        )
        .await;
        assert!(
            matches!(result, Err(ToolError::Refused { .. })),
            "rev2's declared floor survives Full"
        );
        assert_eq!(effective, None);
        assert_eq!(requester.seen.lock().unwrap().len(), 1);
        assert!(invoked.lock().unwrap().is_empty());
    }

    #[tokio::test]
    async fn actual_file_ops_read_is_admitted_but_canonical_scheduling_is_global() {
        use crate::tools::concurrency::ConcurrencyClaim;
        let registry = StdArc::new(ToolHandlerRegistry::new());
        register(
            &registry,
            crate::tools::handlers::builtin::BuiltinHandler::new(
                "file_ops".into(),
                StdArc::new(crate::builtin_tools::FileOpsTool::new()),
            ),
        );
        let svc = service(&registry)
            .with_exec_tier(crate::config::types::policies::ExecTier::Plan)
            .with_turn_context({
                let mut ctx = turn_ctx("a3-actual-file-ops-side-question");
                ctx.side_question = true;
                ctx
            });
        let dir = tempfile::tempdir().unwrap();
        let victim = dir.path().join("read-visible.txt");
        std::fs::write(&victim, "must survive denied mutation").unwrap();
        let read = json!({"operation": "list", "path": dir.path().to_str().unwrap()});
        let write = json!({"operation": "delete", "path": victim.to_str().unwrap()});
        let entry = registry.resolve_entry("file_ops").unwrap();
        // The admission wrapper must delegate the captured handler's claim.
        assert_eq!(
            entry.handler.concurrency_claim(&read),
            ConcurrencyClaim::Shared
        );
        assert_eq!(
            svc.call_concurrency_claim("file_ops", &read).await,
            ConcurrencyClaim::global()
        );
        assert_eq!(
            svc.call_concurrency_claim("file_ops", &write).await,
            ConcurrencyClaim::global()
        );

        let listed = crate::identity::as_actor(
            "operator",
            with_call_identity(
                Some(identity("actual-file-ops-read")),
                svc.execute("file_ops", read),
            ),
        )
        .await
        .expect("actual builtin read arm is admitted despite coarse false metadata");
        let listed_value: Value = serde_json::from_str(
            listed
                .value
                .as_str()
                .expect("file_ops output is serialized JSON"),
        )
        .expect("file_ops output JSON parses");
        assert_eq!(listed_value["success"], json!(true));
        assert!(listed_value["files"]
            .as_array()
            .unwrap()
            .iter()
            .any(|file| { file["name"] == json!("read-visible.txt") }));
        let refused = crate::identity::as_actor(
            "operator",
            with_call_identity(
                Some(identity("actual-file-ops-delete")),
                svc.execute("file_ops", write),
            ),
        )
        .await;
        assert!(matches!(refused, Err(ToolError::PermissionDenied { .. })));
        assert_eq!(
            std::fs::read_to_string(&victim).unwrap(),
            "must survive denied mutation"
        );
    }

    #[tokio::test]
    async fn a_replaced_builtin_cannot_use_name_only_shared_claim_to_bypass_side_question() {
        struct CustomFixtureHandler {
            definition: ToolDefinition,
            effects: StdArc<AtomicUsize>,
        }

        #[async_trait::async_trait]
        impl ToolHandler for CustomFixtureHandler {
            fn definition(&self) -> ToolDefinition {
                self.definition.clone()
            }

            async fn invoke(&self, _input: Value) -> Result<ToolOutput, ToolError> {
                self.effects.fetch_add(1, Ordering::SeqCst);
                Ok(ToolOutput {
                    value: json!({"effect": "file_read"}),
                    metadata: Default::default(),
                })
            }
        }

        fn builtin_fixture_definition(idempotent: bool, concurrent_safe: bool) -> ToolDefinition {
            ToolDefinition {
                name: "file_read".into(),
                description: "A3 builtin replacement fixture".into(),
                input_schema: json!({"type": "object"}),
                source: ToolSource::Builtin,
                metadata: ToolDefinitionMetadata {
                    requires_approval: false,
                    idempotent,
                    concurrent_safe,
                    max_duration_ms: Some(2_000),
                    ..Default::default()
                },
            }
        }

        let registry = StdArc::new(ToolHandlerRegistry::new());
        let effects = StdArc::new(AtomicUsize::new(0));
        let rev1 = builtin_fixture_definition(true, true);
        register(
            &registry,
            CustomFixtureHandler {
                definition: rev1.clone(),
                effects: effects.clone(),
            },
        );
        let svc = service(&registry)
            .with_exec_tier(crate::config::types::policies::ExecTier::Plan)
            .with_turn_context({
                let mut ctx = turn_ctx("a3-replaced-builtin-side-question");
                ctx.side_question = true;
                ctx
            });

        // Same canonical name and Builtin source, but rev2 declares the
        // opposite live facts. The registry is the authority for this call;
        // the service projection remains the rev1 discovery snapshot.
        let rev2 = builtin_fixture_definition(false, false);
        registry
            .replace(
                ToolCapabilityDescriptor::from_definition(&rev2, 0),
                StdArc::new(CustomFixtureHandler {
                    definition: rev2,
                    effects: effects.clone(),
                }),
            )
            .expect("same-name canonical replacement must succeed");

        let result = crate::identity::as_actor(
            "operator",
            with_call_identity(
                Some(identity("replaced-builtin-side-question")),
                svc.execute("file_read", json!({"path": "/tmp/fixture"})),
            ),
        )
        .await;

        assert!(
            matches!(result, Err(ToolError::PermissionDenied { .. })),
            "rev2's non-idempotent/non-concurrent-safe declaration must remain denied: {result:?}"
        );
        assert_eq!(
            effects.load(Ordering::SeqCst),
            0,
            "a denied replaced builtin must not reach the actual effect handler"
        );
    }

    #[tokio::test]
    async fn production_projection_link_rechecks_mcp_visibility_at_capture() {
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let invoked = StdArc::new(StdMutex::new(Vec::new()));
        let mut def = definition("server__write", false);
        def.source = ToolSource::Mcp {
            server_id: "server".into(),
        };
        register(
            &registry,
            RecordingHandler {
                definition: def,
                tag: "visible",
                invoked: invoked.clone(),
                partial_write: None,
                own_identity: unsafe_identity(1),
                overlap: None,
            },
        );
        let visibility = StdArc::new(std::sync::atomic::AtomicBool::new(true));
        let switch = visibility.clone();
        let visible: crate::tools::handlers::McpServerFilter =
            StdArc::new(move |_| switch.load(Ordering::SeqCst));
        let mut inner = LoopToolRegistry::new();
        inner.bind_canonical_registry(registry.clone(), visible);
        let entry = registry.resolve_entry("server__write").unwrap();
        inner.register(Box::new(
            crate::tools::adapters::McpRegistryTool::from_registry_entry(
                entry.handler,
                &entry.descriptor,
            ),
        ));
        let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
        let svc = ScopedToolService::new(StdArc::new(inner), BTreeSet::new())
            .with_confirmation(requester.clone());
        assert!(
            StdArc::ptr_eq(svc.canonical_registry.as_ref().unwrap(), &registry),
            "Scoped new retains the production Arc"
        );
        with_call_identity(
            Some(identity("visible-call")),
            svc.execute("server__write", json!({})),
        )
        .await
        .unwrap();
        visibility.store(false, Ordering::SeqCst);
        let (result, effective) = with_call_identity(
            Some(identity("hidden-call")),
            svc.execute_with_cancel_effective("server__write", json!({}), CancellationToken::new()),
        )
        .await;
        assert!(matches!(result, Err(ToolError::PermissionDenied { .. })));
        assert_eq!(effective, None);
        assert_eq!(
            invoked.lock().unwrap().len(),
            1,
            "the hidden server is never called a second time"
        );
        assert_eq!(requester.seen.lock().unwrap().len(), 1);
    }

    // Task53/R0: the result budget is a fact of the captured canonical entry.
    // These tests drive the public `execute` and observe the real Layer 2
    // output (offload marker / inline completeness), never a budget getter.
    mod r0_budget {
        use super::*;

        const NAME: &str = "budget_terminal";
        const SMALL: usize = 128;
        const LARGE: usize = 6_000;

        struct BudgetHandler {
            definition: ToolDefinition,
            tag: &'static str,
            own_identity: ToolCallIdentity,
            invoked: StdArc<StdMutex<Vec<(&'static str, Option<String>, VerdictAudit)>>>,
            structured: bool,
        }

        // Varied, non-repeating rows so ingress compression cannot erase the
        // evidence; HEAD/MID/TAIL markers name the producing handler.
        fn body(tag: &str) -> String {
            let mut text = format!("BUDGET-HEAD-{tag}\n");
            for i in 0..80u64 {
                let mix = (i + 17).wrapping_mul(0x9E37_79B9_7F4A_7C15) ^ (i << 7);
                text.push_str(&format!("{tag}-row-{i:04} {mix:016x} {}\n", i * i + 3));
            }
            text.push_str(&format!("BUDGET-TAIL-{tag}"));
            text
        }

        #[async_trait::async_trait]
        impl ToolHandler for BudgetHandler {
            fn definition(&self) -> ToolDefinition {
                self.definition.clone()
            }

            async fn invoke(&self, input: Value) -> Result<ToolOutput, ToolError> {
                // The sealed admission proof must be present and exact.
                let audit = audit_verdict(&self.definition.name, &self.own_identity, &input);
                assert_bound_verdict(&audit);
                self.invoked.lock().unwrap().push((
                    self.tag,
                    crate::approval::current_tool_call_id(),
                    audit,
                ));
                let value = if self.structured {
                    json!({"handler": self.tag, "blob": body(self.tag)})
                } else {
                    Value::String(body(self.tag))
                };
                Ok(ToolOutput {
                    value,
                    metadata: Default::default(),
                })
            }
        }

        type Calls = StdArc<StdMutex<Vec<(&'static str, Option<String>, VerdictAudit)>>>;

        fn handler(tag: &'static str, revision: u64, calls: &Calls) -> BudgetHandler {
            BudgetHandler {
                definition: definition(NAME, false),
                tag,
                own_identity: unsafe_identity(revision),
                invoked: calls.clone(),
                structured: false,
            }
        }

        fn descriptor(h: &BudgetHandler) -> ToolCapabilityDescriptor {
            ToolCapabilityDescriptor::from_definition(&h.definition(), 0)
        }

        fn all_visible() -> crate::tools::handlers::McpServerFilter {
            StdArc::new(|_: &str| true)
        }

        /// Discovery projection built from the CURRENT entry via the real
        /// entry-based adapter, then frozen: a later replace makes it stale.
        /// `file_read` is callable so an over-budget result is offloaded.
        fn budget_service(
            registry: &StdArc<ToolHandlerRegistry>,
            expected_projection_budget: Option<usize>,
            store: StdArc<crate::tools::result_store::ToolResultStore>,
        ) -> ScopedToolService {
            let visible = all_visible();
            let mut inner = LoopToolRegistry::new();
            inner.bind_canonical_registry(StdArc::clone(registry), visible.clone());
            let entry = registry.resolve_entry(NAME).expect("entry published");
            inner.register(Box::new(
                crate::tools::adapters::McpRegistryTool::from_canonical_entry(&entry, &visible),
            ));
            inner.register(Box::new(StubTool {
                tool_name: "file_read",
            }));
            assert_eq!(
                inner.max_result_tokens_for(NAME),
                expected_projection_budget,
                "precondition: the discovery projection carries the old budget"
            );
            let svc = ScopedToolService::new(StdArc::new(inner), BTreeSet::new())
                .with_result_store(store);
            assert!(StdArc::ptr_eq(
                svc.canonical_registry.as_ref().expect("link retained"),
                registry
            ));
            svc
        }

        /// The produced size must sit strictly between the two budgets the
        /// real resolver would enforce, or the test proves nothing.
        fn assert_discriminating_size() -> usize {
            let produced = crate::context::budget::pressure::estimate_tokens_smart(&body("x"));
            let resolve = crate::tools::result_processing::resolve_result_budget;
            assert_eq!(resolve(NAME, Some(SMALL)), Some(SMALL));
            assert_eq!(resolve(NAME, Some(LARGE)), Some(LARGE));
            let default = resolve(NAME, None).unwrap();
            assert!(
                produced > SMALL * 2 && produced < LARGE.min(default),
                "fixture size {produced} must discriminate {SMALL} from {LARGE}/{default}"
            );
            produced
        }

        fn assert_offloaded(text: &str, tag: &str, produced: usize) {
            assert!(
                text.contains("[Full output persisted: "),
                "small budget must offload {tag}'s result:\n{text}"
            );
            let inline = crate::context::budget::pressure::estimate_tokens_smart(text);
            assert!(
                inline < produced,
                "offloaded result must be smaller inline ({inline} >= {produced})"
            );
        }

        fn assert_inline_whole(text: &str, tag: &str) {
            assert!(
                !text.contains("[Full output persisted: "),
                "large/default budget must not offload {tag}'s result:\n{text}"
            );
            for marker in [
                format!("BUDGET-HEAD-{tag}"),
                format!("{tag}-row-0040 "),
                format!("BUDGET-TAIL-{tag}"),
            ] {
                assert!(text.contains(&marker), "missing {marker}:\n{text}");
            }
        }

        // Break caught: Scoped consumes the stale discovery projection's
        // budget (or a second live lookup) instead of the entry it captured.
        #[tokio::test]
        async fn replacement_before_execute_uses_replacement_entry_budget() {
            let produced = assert_discriminating_size();
            let registry = StdArc::new(ToolHandlerRegistry::new());
            let calls: Calls = StdArc::new(StdMutex::new(Vec::new()));
            let a = handler("budgetA", 1, &calls);
            registry
                .register_with_result_budget(descriptor(&a), StdArc::new(a), Some(SMALL))
                .unwrap();
            let (_scratch, store) = hygiene_store("r0_replace_before");
            let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
            let svc = budget_service(&registry, Some(SMALL), store)
                .with_turn_context(turn_ctx("r0-replace-before-execute"))
                .with_confirmation(requester.clone());

            let b = handler("budgetB", 2, &calls);
            registry
                .replace_with_result_budget(descriptor(&b), StdArc::new(b), Some(LARGE))
                .unwrap();
            let current = registry.resolve_entry(NAME).unwrap();
            assert_eq!(current.max_result_tokens, Some(LARGE));
            assert_eq!(current.descriptor.revision, 2);

            let out = with_call_identity(
                Some(identity("r0-before")),
                svc.execute(NAME, json!({"action": "write"})),
            )
            .await
            .expect("approved call succeeds");
            let text = out.value.as_str().expect("layer 2 flattens to text");
            assert_inline_whole(text, "budgetB");
            assert!(!text.contains("budgetA"), "stale handler must not run");
            let calls = calls.lock().unwrap();
            assert_eq!(calls.len(), 1);
            assert_eq!(calls[0].0, "budgetB");
            assert_eq!(calls[0].1.as_deref(), Some("r0-before"));
            let seen = requester.seen.lock().unwrap();
            assert_eq!(seen.len(), 1, "exactly one real approval");
            let _ = produced;
        }

        // Break caught: a call captured at rev1 adopts rev2's budget after the
        // gate suspends, or the next call keeps the stale rev1 budget.
        #[tokio::test]
        async fn gate_held_capture_keeps_old_budget_and_next_call_uses_new() {
            let produced = assert_discriminating_size();
            let registry = StdArc::new(ToolHandlerRegistry::new());
            let calls: Calls = StdArc::new(StdMutex::new(Vec::new()));
            let a = handler("budgetA", 1, &calls);
            registry
                .register_with_result_budget(descriptor(&a), StdArc::new(a), Some(SMALL))
                .unwrap();
            let arrived = StdArc::new(Barrier::new(2));
            let release = StdArc::new(Barrier::new(2));
            let requester = StdArc::new(BoundaryRequester {
                registry: registry.clone(),
                arrived: arrived.clone(),
                release: release.clone(),
                seen: StdMutex::new(Vec::new()),
            });
            let (_scratch, store) = hygiene_store("r0_gate_held");
            let svc = StdArc::new(
                budget_service(&registry, Some(SMALL), store.clone())
                    .with_turn_context(turn_ctx("r0-gate-held-capture"))
                    .with_confirmation(requester.clone()),
            );
            let first_svc = svc.clone();
            let first = tokio::spawn(with_call_identity(
                Some(identity("r0-held-a")),
                async move { first_svc.execute(NAME, json!({"action": "write"})).await },
            ));
            tokio::time::timeout(std::time::Duration::from_secs(5), arrived.wait())
                .await
                .expect("rev1 must reach the approval barrier");
            let b = handler("budgetB", 2, &calls);
            registry
                .replace_with_result_budget(descriptor(&b), StdArc::new(b), Some(LARGE))
                .unwrap();
            tokio::time::timeout(std::time::Duration::from_secs(5), release.wait())
                .await
                .expect("replacement must release the in-flight gate");
            let first_out = tokio::time::timeout(std::time::Duration::from_secs(5), first)
                .await
                .expect("captured rev1 dispatch completes")
                .unwrap()
                .expect("in-flight approval was granted");
            let first_text = first_out.value.as_str().expect("flattened");
            assert_offloaded(first_text, "budgetA", produced);
            let persisted_path = crate::tools::result_store::extract_persisted_path(first_text)
                .expect("offload must name an actual recovery file");
            let persisted = store
                .read_call_blob(std::path::Path::new(persisted_path), "r0-held-a")
                .expect("the captured call must own a readable persisted result");
            assert_eq!(persisted, body("budgetA"));
            assert!(!first_text.contains("budgetB"), "{first_text}");

            // Same service, no rebuild: projection still says SMALL.
            let next_out = with_call_identity(
                Some(identity("r0-held-b")),
                svc.execute(NAME, json!({"action": "write"})),
            )
            .await
            .expect("next call separately approved");
            let next_text = next_out.value.as_str().expect("flattened");
            assert_inline_whole(next_text, "budgetB");

            let boundary = requester.seen.lock().unwrap();
            assert_eq!(
                boundary
                    .iter()
                    .map(|(id, i)| (id.as_str(), i.revision))
                    .collect::<Vec<_>>(),
                vec![("r0-held-a", 1), ("r0-held-b", 2)]
            );
            let calls = calls.lock().unwrap();
            assert_eq!(
                calls
                    .iter()
                    .map(|(tag, id, _)| (*tag, id.as_deref()))
                    .collect::<Vec<_>>(),
                vec![
                    ("budgetA", Some("r0-held-a")),
                    ("budgetB", Some("r0-held-b"))
                ]
            );
        }

        // Break caught: `.or_else` turns the canonical authoritative None into
        // the stale projection's Some(SMALL).
        #[tokio::test]
        async fn canonical_none_ignores_stale_projection_budget() {
            assert_discriminating_size();
            let registry = StdArc::new(ToolHandlerRegistry::new());
            let calls: Calls = StdArc::new(StdMutex::new(Vec::new()));
            let a = handler("budgetA", 1, &calls);
            registry
                .register_with_result_budget(descriptor(&a), StdArc::new(a), Some(SMALL))
                .unwrap();
            let (_scratch, store) = hygiene_store("r0_none");
            let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
            let svc = budget_service(&registry, Some(SMALL), store)
                .with_turn_context(turn_ctx("r0-canonical-none"))
                .with_confirmation(requester);
            let b = handler("budgetB", 2, &calls);
            registry
                .replace_with_result_budget(descriptor(&b), StdArc::new(b), None)
                .unwrap();
            assert_eq!(
                registry.resolve_entry(NAME).unwrap().max_result_tokens,
                None
            );

            let out = with_call_identity(
                Some(identity("r0-none")),
                svc.execute(NAME, json!({"action": "write"})),
            )
            .await
            .expect("approved call succeeds");
            let text = out.value.as_str().expect("flattened");
            // None resolves to the default budget, which fits the fixture.
            assert_inline_whole(text, "budgetB");
            assert_eq!(calls.lock().unwrap()[0].0, "budgetB");
        }

        // StructuredRpc stays an early return even when the captured entry
        // carries a small budget: no flatten, no offload.
        #[tokio::test]
        async fn structured_rpc_ignores_captured_small_budget() {
            assert_discriminating_size();
            let registry = StdArc::new(ToolHandlerRegistry::new());
            let calls: Calls = StdArc::new(StdMutex::new(Vec::new()));
            let mut a = handler("budgetA", 1, &calls);
            a.structured = true;
            registry
                .register_with_result_budget(descriptor(&a), StdArc::new(a), Some(SMALL))
                .unwrap();
            let (_scratch, store) = hygiene_store("r0_rpc");
            let requester = StdArc::new(SequenceRequester::new([ApprovalOutcome::Approved]));
            let svc = budget_service(&registry, Some(SMALL), store)
                .with_structured_rpc_transport()
                .with_turn_context(turn_ctx("r0-structured-rpc"))
                .with_confirmation(requester);
            let out = with_call_identity(
                Some(identity("r0-rpc")),
                svc.execute(NAME, json!({"action": "write"})),
            )
            .await
            .expect("approved call succeeds");
            let blob = out
                .value
                .get("blob")
                .and_then(Value::as_str)
                .unwrap_or_else(|| panic!("structured value preserved: {:?}", out.value));
            assert_eq!(blob, body("budgetA"));
            assert_eq!(out.value.get("handler"), Some(&json!("budgetA")));
        }
    }
}

// -------------------------------------------------------------------------
// Task55 / R1-A — bounded source-authorized consumer effects.
// -------------------------------------------------------------------------
mod r1a {
    use super::*;
    use crate::approval::{with_call_identity, CallIdentity};
    use crate::session::events::ToolOutput;
    use crate::sync_primitives::Arc as StdArc;
    use crate::tools::descriptor::ToolCapabilityDescriptor;
    use crate::tools::handlers::ToolHandler;
    use crate::tools::registry::ToolHandlerRegistry;
    use crate::tools::runtime::{LoopTool, ToolResult as LoopToolResult};
    use crate::tools::service::{ToolDefinition, ToolDefinitionMetadata, ToolError, ToolSource};
    use crate::tools::usage::UsageOrigin;
    use serde_json::{json, Value};
    use std::collections::{BTreeSet, HashMap};
    use std::sync::atomic::{AtomicUsize, Ordering};
    use tokio_util::sync::CancellationToken;

    struct CountingHandler {
        definition: ToolDefinition,
        calls: StdArc<AtomicUsize>,
        fails: bool,
        shared: bool,
    }

    #[async_trait::async_trait]
    impl ToolHandler for CountingHandler {
        async fn invoke(&self, _input: Value) -> Result<ToolOutput, ToolError> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            if self.fails {
                Err(ToolError::Execution {
                    name: self.definition.name.clone(),
                    cause: "handler failed".into(),
                })
            } else {
                Ok(ToolOutput {
                    value: json!({"handler": self.definition.name}),
                    metadata: Default::default(),
                })
            }
        }

        fn definition(&self) -> ToolDefinition {
            self.definition.clone()
        }

        fn concurrency_claim(&self, _input: &Value) -> crate::tools::concurrency::ConcurrencyClaim {
            if self.shared {
                crate::tools::concurrency::ConcurrencyClaim::Shared
            } else {
                crate::tools::concurrency::ConcurrencyClaim::global()
            }
        }
    }

    struct Projection {
        name: String,
        descriptor: Option<StdArc<ToolCapabilityDescriptor>>,
        owner: String,
        calls: StdArc<AtomicUsize>,
        shared: bool,
    }

    #[async_trait::async_trait]
    impl LoopTool for Projection {
        fn name(&self) -> &str {
            &self.name
        }
        fn description(&self) -> &str {
            "R1-A discovery projection"
        }
        fn schema(&self) -> Value {
            json!({"type": "object"})
        }
        fn is_concurrent_safe(&self, _input: &Value) -> bool {
            self.shared
        }
        fn capability_descriptor(&self) -> Option<&ToolCapabilityDescriptor> {
            self.descriptor.as_deref()
        }
        fn usage_origin(&self) -> Option<UsageOrigin<'_>> {
            Some(UsageOrigin::Plugin(&self.owner))
        }
        async fn execute(&self, _input: Value, _cancel: CancellationToken) -> LoopToolResult {
            self.calls.fetch_add(1, Ordering::SeqCst);
            LoopToolResult::Success {
                output: json!({"projection": self.name}),
            }
        }
    }

    fn definition(name: &str, source: ToolSource, shared: bool) -> ToolDefinition {
        ToolDefinition {
            name: name.into(),
            description: "R1-A canonical fixture".into(),
            input_schema: json!({"type": "object"}),
            source,
            metadata: ToolDefinitionMetadata {
                concurrent_safe: shared,
                idempotent: true,
                ..Default::default()
            },
        }
    }

    fn register(
        registry: &ToolHandlerRegistry,
        definition: ToolDefinition,
        calls: StdArc<AtomicUsize>,
        fails: bool,
        shared: bool,
    ) -> crate::tools::registry::RegistryEntry {
        let name = definition.name.clone();
        let descriptor = ToolCapabilityDescriptor::from_definition(&definition, 0);
        registry
            .register(
                descriptor,
                StdArc::new(CountingHandler {
                    definition,
                    calls,
                    fails,
                    shared,
                }),
            )
            .expect("actual registry admission");
        registry
            .resolve_entry(&name)
            .expect("actual admitted entry")
    }

    fn service(
        registry: &StdArc<ToolHandlerRegistry>,
        projection: Projection,
    ) -> ScopedToolService {
        let mut inner = LoopToolRegistry::new();
        let visible: crate::tools::handlers::McpServerFilter = StdArc::new(|_| true);
        inner.bind_canonical_registry(StdArc::clone(registry), visible);
        inner.register(Box::new(projection));
        ScopedToolService::new(StdArc::new(inner), BTreeSet::new())
    }

    fn identity(id: &str) -> CallIdentity {
        CallIdentity {
            turn_id: crate::session::events::TurnId::nil(),
            call_id: id.into(),
        }
    }

    fn snapshot() -> HashMap<String, crate::tools::usage::OriginUsage> {
        crate::tools::usage::ToolUsageStore::default_path()
            .map(|store| store.snapshot())
            .unwrap_or_default()
    }

    fn projection(
        name: &str,
        entry: Option<&crate::tools::registry::RegistryEntry>,
        owner: &str,
        calls: StdArc<AtomicUsize>,
        shared: bool,
    ) -> Projection {
        Projection {
            name: name.into(),
            descriptor: entry.map(|entry| StdArc::clone(&entry.descriptor)),
            owner: owner.into(),
            calls,
            shared,
        }
    }

    #[tokio::test]
    async fn adapter_origins_follow_actual_descriptor_sources() {
        let registry = ToolHandlerRegistry::new();
        let cases = [
            (
                "r1a_ext",
                ToolSource::Extension {
                    plugin_id: "REAL".into(),
                },
                Some(UsageOrigin::Plugin("REAL")),
            ),
            (
                "r1a_mcp",
                ToolSource::Mcp {
                    server_id: "server".into(),
                },
                Some(UsageOrigin::Mcp("server")),
            ),
            (
                "r1a_empty",
                ToolSource::Mcp {
                    server_id: String::new(),
                },
                None,
            ),
            ("r1a_builtin", ToolSource::Builtin, None),
        ];
        for (name, source, expected) in cases {
            let calls = StdArc::new(AtomicUsize::new(0));
            let def = definition(name, source, true);
            let descriptor = ToolCapabilityDescriptor::from_definition(&def, 0);
            registry
                .register(
                    descriptor,
                    StdArc::new(CountingHandler {
                        definition: def,
                        calls: StdArc::clone(&calls),
                        fails: false,
                        shared: true,
                    }),
                )
                .unwrap();
            let entry = registry.resolve_entry(name).unwrap();
            let adapter = crate::tools::adapters::McpRegistryTool::from_registry_entry(
                StdArc::clone(&entry.handler),
                &entry.descriptor,
            );
            assert_eq!(adapter.usage_origin(), expected);
            let result = adapter.execute(json!({}), CancellationToken::new()).await;
            assert!(matches!(
                result,
                crate::tools::runtime::ToolResult::Error { error, .. }
                    if error.contains(
                        "canonical invocation requires exact dispatch or sealed Safe replay admission"
                    )
            ));
            assert_eq!(
                calls.load(Ordering::SeqCst),
                0,
                "direct adapter invoke is not admitted"
            );
        }
    }

    #[tokio::test]
    async fn captured_plugin_owner_beats_spoofed_projection_usage() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let canonical_calls = StdArc::new(AtomicUsize::new(0));
        let def = definition(
            "r1a_tool",
            ToolSource::Extension {
                plugin_id: "REAL".into(),
            },
            true,
        );
        let entry = register(&registry, def, StdArc::clone(&canonical_calls), false, true);
        let projection_calls = StdArc::new(AtomicUsize::new(0));
        let svc = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry),
                "SPOOF",
                StdArc::clone(&projection_calls),
                true,
            ),
        );
        let result = with_call_identity(
            Some(identity("r1a-spoof")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(
            result.is_ok(),
            "actual canonical handler must execute: {result:?}"
        );
        assert_eq!(canonical_calls.load(Ordering::SeqCst), 1);
        assert_eq!(projection_calls.load(Ordering::SeqCst), 0);
        let rows = snapshot();
        assert_eq!(rows.get("plugin:REAL").map(|r| r.call_count), Some(1));
        assert_eq!(rows.get("plugin:SPOOF").map(|r| r.call_count), None);
        assert_eq!(rows.get("mcp:SPOOF").map(|r| r.call_count), None);
    }

    #[tokio::test]
    async fn canonical_builtin_none_never_inherits_spoofed_projection_usage() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let canonical_calls = StdArc::new(AtomicUsize::new(0));
        let entry = register(
            &registry,
            definition("r1a_tool", ToolSource::Builtin, true),
            StdArc::clone(&canonical_calls),
            false,
            true,
        );
        let projection_calls = StdArc::new(AtomicUsize::new(0));
        let svc = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry),
                "SPOOF",
                StdArc::clone(&projection_calls),
                true,
            ),
        );
        let result = with_call_identity(
            Some(identity("r1a-builtin")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(
            result.is_ok(),
            "actual builtin handler must execute: {result:?}"
        );
        assert_eq!(canonical_calls.load(Ordering::SeqCst), 1);
        assert_eq!(projection_calls.load(Ordering::SeqCst), 0);
        assert!(snapshot().is_empty());
        assert!(crate::utils::paths::tool_usage_path().is_some_and(|path| !path.exists()));
    }

    #[tokio::test]
    async fn captured_plugin_execution_error_counts_real_owner_error() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let calls = StdArc::new(AtomicUsize::new(0));
        let entry = register(
            &registry,
            definition(
                "r1a_tool",
                ToolSource::Extension {
                    plugin_id: "REAL".into(),
                },
                true,
            ),
            StdArc::clone(&calls),
            true,
            true,
        );
        let projection_calls = StdArc::new(AtomicUsize::new(0));
        let svc = service(
            &registry,
            projection("r1a_tool", Some(&entry), "SPOOF", projection_calls, true),
        );
        let result = with_call_identity(
            Some(identity("r1a-error")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(matches!(result, Err(ToolError::Execution { .. })));
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        let row = snapshot()
            .remove("plugin:REAL")
            .expect("real error usage row");
        assert_eq!(row.call_count, 1);
        assert_eq!(row.error_count, 1);
    }

    #[tokio::test]
    async fn admitted_extension_permission_deny_has_no_usage_effect() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let calls = StdArc::new(AtomicUsize::new(0));
        let entry = register(
            &registry,
            definition(
                "r1a_tool",
                ToolSource::Extension {
                    plugin_id: "REAL".into(),
                },
                true,
            ),
            StdArc::clone(&calls),
            false,
            true,
        );
        let svc = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry),
                "SPOOF",
                StdArc::new(AtomicUsize::new(0)),
                true,
            ),
        )
        .with_tool_permissions(perms(
            crate::extension::PermissionAction::Allow,
            &[("r1a_tool", crate::extension::PermissionAction::Deny)],
        ));
        let result = with_call_identity(
            Some(identity("r1a-deny")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(matches!(result, Err(ToolError::PermissionDenied { .. })));
        assert_eq!(calls.load(Ordering::SeqCst), 0);
        assert!(snapshot().is_empty());
    }

    #[tokio::test]
    async fn removed_descriptor_backed_projection_has_no_legacy_fallback() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let calls = StdArc::new(AtomicUsize::new(0));
        let entry = register(
            &registry,
            definition(
                "r1a_tool",
                ToolSource::Extension {
                    plugin_id: "REAL".into(),
                },
                true,
            ),
            StdArc::clone(&calls),
            false,
            true,
        );
        let projection_calls = StdArc::new(AtomicUsize::new(0));
        let svc = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry),
                "SPOOF",
                StdArc::clone(&projection_calls),
                true,
            ),
        );
        registry.unregister("r1a_tool").unwrap();
        let result = with_call_identity(
            Some(identity("r1a-removed")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(matches!(result, Err(ToolError::NotFound { .. })));
        assert_eq!(calls.load(Ordering::SeqCst), 0);
        assert_eq!(projection_calls.load(Ordering::SeqCst), 0);
        assert!(snapshot().is_empty());
    }

    #[tokio::test]
    async fn same_source_replacement_captures_new_generation() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let calls_a = StdArc::new(AtomicUsize::new(0));
        let source = ToolSource::Extension {
            plugin_id: "REAL".into(),
        };
        let entry_a = register(
            &registry,
            definition("r1a_tool", source.clone(), true),
            StdArc::clone(&calls_a),
            false,
            true,
        );
        let projection_calls = StdArc::new(AtomicUsize::new(0));
        let svc = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry_a),
                "SPOOF",
                StdArc::clone(&projection_calls),
                true,
            ),
        );
        let calls_b = StdArc::new(AtomicUsize::new(0));
        let def_b = definition("r1a_tool", source, true);
        registry
            .replace(
                ToolCapabilityDescriptor::from_definition(&def_b, 0),
                StdArc::new(CountingHandler {
                    definition: def_b,
                    calls: StdArc::clone(&calls_b),
                    fails: false,
                    shared: true,
                }),
            )
            .unwrap();
        let result = with_call_identity(
            Some(identity("r1a-same")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(result.is_ok());
        assert_eq!(calls_a.load(Ordering::SeqCst), 0);
        assert_eq!(calls_b.load(Ordering::SeqCst), 1);
        assert_eq!(projection_calls.load(Ordering::SeqCst), 0);
        assert_eq!(snapshot().get("plugin:REAL").map(|r| r.call_count), Some(1));
    }

    #[tokio::test]
    async fn changed_source_replacement_refuses_without_usage() {
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let calls_old = StdArc::new(AtomicUsize::new(0));
        let entry = register(
            &registry,
            definition(
                "r1a_tool",
                ToolSource::Extension {
                    plugin_id: "REAL".into(),
                },
                true,
            ),
            StdArc::clone(&calls_old),
            false,
            true,
        );
        let projection_calls = StdArc::new(AtomicUsize::new(0));
        let svc = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry),
                "SPOOF",
                StdArc::clone(&projection_calls),
                true,
            ),
        );
        let changed = definition(
            "r1a_tool",
            ToolSource::Extension {
                plugin_id: "OTHER".into(),
            },
            true,
        );
        let calls_changed = StdArc::new(AtomicUsize::new(0));
        registry
            .replace(
                ToolCapabilityDescriptor::from_definition(&changed, 0),
                StdArc::new(CountingHandler {
                    definition: changed,
                    calls: StdArc::clone(&calls_changed),
                    fails: false,
                    shared: true,
                }),
            )
            .unwrap();
        let result = with_call_identity(
            Some(identity("r1a-owner-change")),
            svc.execute("r1a_tool", json!({})),
        )
        .await;
        assert!(matches!(result, Err(ToolError::PermissionDenied { .. })));
        assert_eq!(calls_old.load(Ordering::SeqCst), 0);
        assert_eq!(calls_changed.load(Ordering::SeqCst), 0);
        assert_eq!(projection_calls.load(Ordering::SeqCst), 0);
        assert!(snapshot().is_empty());
    }

    #[tokio::test]
    async fn public_scheduler_keeps_global_canonical_and_shared_compatibility_claims() {
        use crate::tools::concurrency::ConcurrencyClaim;
        let _home = crate::utils::paths::IsolatedAlephHome::new();
        let registry = StdArc::new(ToolHandlerRegistry::new());
        let calls = StdArc::new(AtomicUsize::new(0));
        let entry = register(
            &registry,
            definition(
                "r1a_tool",
                ToolSource::Extension {
                    plugin_id: "REAL".into(),
                },
                true,
            ),
            StdArc::clone(&calls),
            false,
            true,
        );
        let canonical = service(
            &registry,
            projection(
                "r1a_tool",
                Some(&entry),
                "SPOOF",
                StdArc::new(AtomicUsize::new(0)),
                true,
            ),
        );
        assert_eq!(
            canonical
                .call_concurrency_claim("r1a_tool", &json!({}))
                .await,
            ConcurrencyClaim::global()
        );

        let compat_calls = StdArc::new(AtomicUsize::new(0));
        let compat = service(
            &registry,
            projection(
                "r1a_compat",
                None,
                "COMPAT",
                StdArc::clone(&compat_calls),
                true,
            ),
        );
        assert_eq!(
            compat
                .call_concurrency_claim("r1a_compat", &json!({}))
                .await,
            ConcurrencyClaim::Shared
        );
        let result = with_call_identity(
            Some(identity("r1a-compat")),
            compat.execute("r1a_compat", json!({})),
        )
        .await;
        // Task59: descriptorless bypass removed, compatibility tools must fail
        assert!(result.is_err());
        assert_eq!(compat_calls.load(Ordering::SeqCst), 0);
        assert_eq!(snapshot().get("plugin:COMPAT").map(|r| r.call_count), None);
    }
}

mod task11_rewrite_tests;
