//! Tool-tier authorization (config-mutating tools require operator).
//!
//! Scope after the Panel collapsed to single-tier Gateway-token auth: the Panel
//! no longer has a Chat/Config sub-tier — a connection is either authorized
//! (operator, full local-equivalent authority) or walled at `connect`. So the
//! classifier below is now purely the **channel** config-tier gate: the
//! inbound router (`inbound_router::executor`) stamps each channel run's
//! `caller_role` from its `ChannelPermissionLevel` (default `Chat` ⇒ `guest`),
//! and `ScopedToolService` (`src/tools/scoped/dispatch.rs`) consults it here to
//! refuse self-config tools to a chat-tier channel (e.g. a default Telegram
//! bot).
//!
//! ⚠️ **"Panel runs are always operator once authorized, so this gate is a no-op
//! for them"** was true when this module was written and stopped being true when
//! P0 introduced `UserRole::Member` (2026-08-04): an authorized Panel connection
//! now resolves to `operator` OR `member`, and a member's run reaches this
//! classifier just like a chat-tier channel does. That is deliberate — the gate
//! covers both surfaces — but it means the gate is load-bearing on the Panel and
//! must be reasoned about as such. In particular the gate does not *deny*: it
//! escalates to an operator via `config_approval_requester`, and that escalation
//! is only a gate if the person who tripped it cannot answer it. See
//! [`crate::approval::operator_requester`] for the half of that which does not
//! live here.

/// Self-management tool names that mutate Aleph's OWN configuration. A
/// chat-tier channel run is rejected from these at the tool-dispatch gate
/// (`ScopedToolService::execute_inner`).
///
/// Read-only self-management tools (`config_audit`, `gateway_route`,
/// `*_list`/`*_status`/`*_read`) are deliberately absent — chat tier keeps them.
const OPERATOR_TOOLS: &[&str] = &[
    "self_config",
    "self_manage",
    "vault_store",
    "cron_manage",
    "heartbeat_create",
    "heartbeat_update",
    "heartbeat_delete",
    "heartbeat_toggle",
    "skill_install",
    "skill_manage",
    "agent_create",
    "agent_delete",
    "agent_switch",
    // The two siblings the list forgot. `agent_create`/`agent_delete`/
    // `agent_switch` were gated from the start, which made the omissions read
    // as "already covered" rather than as holes:
    //
    // `agent_update` writes `allowed_users`, the list the run-start gate
    // reads: leaving it open would let the people that gate refuses add
    // themselves to it — the "the gate must cover the verb that removes the
    // gate" rule. Since 2026-08-10 that write is also LIVE
    // (`AgentRegistry::set_allowed_users`), so an ungated version would not
    // even cost the attacker a restart.
    //
    // ⚠️ The reason recorded here until 2026-08-10 was "it rewrites a live
    // agent's `system_prompt`", and that was never true: the tool accepted a
    // `system_prompt` argument that `AgentPatch` had no field for and no
    // surface ever persisted. The argument has been cut; the gate stands on
    // `allowed_users` alone, which is the stronger of the two anyway.
    "agent_update",
    // `agent_unbind` drops a channel→agent binding, i.e. it edits routing. A
    // chat-tier participant severing the binding that decides which agent
    // answers a channel is a config change wearing a conversation's clothes.
    "agent_unbind",
    "channel_pairing",
    "hub_install_run",
    // `runtime_manage{install}` runs `ensure_capability`, i.e. the ledger's
    // bootstrap installers — an npm global install, a `curl … | sh` script, a
    // winget invocation — plus their post-install subcommands. One call
    // installs software on the host. Its three nearest siblings
    // (`skill_install`, `skill_manage`, `hub_install_run`) are already here for
    // the same reason. Deliberately NOT split so `list` stays open: this table
    // matches on the tool NAME, and a chat-tier run that wants to know what is
    // installed has `doctor`, which is open.
    "runtime_manage",
    // Cluster: driving remote execution arms. Local `bash` is deliberately open
    // to chat tier, but the fleet is a different blast radius — one call reaches
    // every machine the center owns, and `node_file` moves bytes across that
    // boundary. Read-only discovery (`node_list`) stays open so a chat-tier run
    // can still *describe* the fleet.
    "node_invoke",
    "node_invoke_many",
    "node_file",
    // Membership is a stronger claim than execution: it decides which machines
    // the center owns at all, and a deregister is only undone by re-enrolling.
    "node_manage",
    // Agent signing keys and the operation ledger. Rotating or revoking an
    // identity changes who the accountability record can attribute actions to;
    // reading it exposes every agent's activity. Neither is chat tier.
    "agent_identity",
    // `hooks_manage` is a control-plane write — adding a shell / HTTP / agent
    // hook fires arbitrary code or POSTs tool I/O to an arbitrary URL on the
    // next lifecycle event. The `HooksManage` ActionType policy already covers
    // the *content* of any added hook, but the chat-tier channel gate exists
    // so a chat-tier run cannot add a hook in the first place.
    "hooks_manage",
    // The governance graph's only write path. Two reasons it sits with
    // `hooks_manage` rather than with the read-only self-management tools:
    // `enable_audit` / `pair` create cron jobs (the capability `cron_manage`
    // is listed for), and a `root:` node's body is re-injected verbatim into
    // every governed session's system prompt on every turn — a persistent
    // prompt-injection surface. The Auto-tier argument card
    // (`ExecTier::asks_for_arguments`) is the only other thing standing in
    // front of it, and on a channel the human it asks IS the chat-tier
    // participant making the request.
    "loop_graph",
    // Workspace records. The `workspace.` RPC family has been admin-gated
    // since 2026-08-08, after real-machine QA watched a member rename and then
    // archive a workspace the operator had just created — both returning `ok`.
    // The tool face is the same verbs over the same seam
    // (`gateway::agent_env::ops`), so leaving it open would reopen exactly that
    // finding one surface over. `"member"` and `"guest"` both fail
    // `turn_context::role_is_operator`, so this one entry covers both.
    "workspace_manage",
    // The capability-projection diagnostics tool. The surface is
    // unusual: it answers with a live snapshot of the capability host /
    // tree (so it is a read of the same Aleph state `runtime_manage`
    // rewrites), and its write operations are the most invasive the
    // toolset exposes — a `Hold` tears down a source plane for a bounded
    // window, `RevokeTool` removes a tool from the live tree, `Close`
    // shuts the host. None of that is chat-tier reach. The handler-local
    // three-part identity check (operator + loopback + conn_id) in
    // `execute_capability_projection_diagnostics` is the only authority
    // on top of this gate, and ALEPH_GATEWAY_TOOLS_ALLOW cannot bypass
    // it — a read-only denylist entry without this operator entry would
    // reopen exactly that finding one surface over, so both halves
    // travel together.
    "capability_projection_diagnostics",
    // The tool face of the wholesale-gated `plugin.` / `plugins.` RPC family
    // (`method_admin::ADMIN_PREFIXES`), and exactly the same shape as the
    // `workspace_manage` entry above. `plugin_manage` became dispatchable on
    // 2026-08-19 and its actions are the same verbs one surface over:
    // `trust_enforce` turns owner-trust enforcement off install-wide,
    // `marketplace_add` registers and fetches an arbitrary catalogue,
    // `config_set` REPLACES a plugin's stored configuration, `enable`/`reload`
    // decide what loads next. A default-tier Telegram bot calling
    // `trust_enforce(false)` is issuing the same request that answers
    // AUTH_REQUIRED over JSON-RPC.
    //
    // The gate keys on the tool NAME (`ScopedToolService::check_operator_gate`),
    // so this covers the read-only actions too. That is the honest trade: if
    // `list` / `show` / `trust_status` must stay chat-reachable they need
    // their own read-only tool name — not a carve-out inside a tool whose
    // other arms rewrite install-wide trust.
    "plugin_manage",
    "context_plugin",
    // `terminal` LOOKS like the `*_list`/`*_status`/`*_read` shape this
    // list's own doc comment says is deliberately absent — it is not one of
    // those. Read-only self-management (`config_audit`, `gateway_route`)
    // discloses THIS server's own config; `terminal` discloses *another
    // principal's* live terminal screen. The repo already made this exact
    // call one face over: `"runtime."` sits in `method_admin::ADMIN_PREFIXES`
    // with the reasoning "read-only agent panel over the same PTY sessions
    // `pty.` gates — a session id, its cwd, and what is running in it, seen
    // through a different lens. Same disclosure, same gate." `terminal` is a
    // THIRD lens on that identical disclosure (herdr runtime port, phase 1,
    // Task 11) — leaving it open would make the tool face a lower-privilege
    // bypass of a decision `pty.*`/`runtime.*` already made twice.
    // Before deleting this entry to "clean up" an apparent `*_read`
    // exception: re-read the paragraph above, not just this line.
    //
    // ⚠️ The escalation card that membership here triggers
    // (`gate_chain::GateRule::OperatorRequired::reason`, in
    // `tools/scoped/gate_chain.rs`) reads "… which changes Aleph's own
    // configuration. Approve to allow this change." That sentence is false
    // for `terminal` — a read-only tool that changes nothing. Nothing is
    // disclosed by it today only because `terminal`'s own inline gate
    // refuses the call anyway even after a human approves that card
    // (`require_operator_caller()` reads an unchanged `TurnContext` — see
    // `terminal/capabilities.rs`). The card's TEXT is still wrong for a
    // read-only tool, and the fix belongs in `gate_chain.rs`, not in this
    // list or in `terminal.rs` (task-11 review F1).
    //
    // The six canonical `terminal_sessions_*` capabilities (one per verb)
    // are the real tool identities; bare `terminal` is kept only because the
    // `tools.invoke` compat rewrite and old operator allow-lists still name
    // it. `capabilities::invoke_observation` repeats the operator check
    // inline for the same reason as above.
    "terminal",
    "terminal_sessions_list",
    "terminal_sessions_read",
    "terminal_sessions_status",
    "terminal_sessions_wait",
    "terminal_sessions_explain",
    "terminal_sessions_attach",
];

/// True when `tool` mutates Aleph's own configuration and therefore requires an
/// operator (config-tier) connection. Names not listed stay open to chat tier.
#[must_use]
pub fn tool_requires_operator(tool: &str) -> bool {
    OPERATOR_TOOLS.contains(&tool)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Gates that must never be removed, whatever else changes.
    ///
    /// Deliberately a **subset**, not a mirror of `OPERATOR_TOOLS`. The full
    /// duplicate this replaced had already drifted — it never learned about
    /// `node_manage`, so the newest operator tool was the one tool the test
    /// meant to pin did not pin. A curated tripwire catches a deletion without
    /// pretending to be a second source of truth.
    const MUST_STAY_GATED: &[&str] = &[
        "self_config",
        "self_manage",
        "vault_store",
        "skill_install",
        "agent_create",
        "agent_delete",
        // Fleet: remote execution, file movement across the trust boundary,
        // and membership itself.
        "node_invoke",
        "node_file",
        "node_manage",
        // Accountability: rotating a signing key changes who the record can
        // name; reading the ledger exposes every agent's activity.
        "agent_identity",
        // Control-plane write: adding a hook fires code on future events.
        "hooks_manage",
        // The tool half of an admin-gated RPC family. Pinned because the two
        // gates are different mechanisms: deleting this entry would not make
        // any `workspace.` RPC test go red, it would only widen the tool.
        "workspace_manage",
        // A third lens on the disclosure `pty.`/`runtime.` already gate
        // operator-only on both their faces (session id, cwd, live screen
        // contents). Deleting this entry would not redden any `pty.*` or
        // `runtime.*` test — it would silently expose another principal's
        // terminal content through the one face nothing else gates.
        "terminal",
        // Writes `allowed_users` — the list the run-start gate
        // (`caller_may_act_as_agent`) reads. Ungated, the people that gate
        // refuses could add themselves to it, and nothing in `handlers::agent`
        // would go red: the gate would still be enforced, faithfully, against
        // a list its own subjects had edited.
        "agent_update",
    ];

    #[test]
    fn config_tools_require_operator() {
        for t in MUST_STAY_GATED {
            assert!(tool_requires_operator(t), "{t} must require operator");
        }
    }

    /// A tool that duplicates an admin-gated RPC family must be operator-gated
    /// too, or the same verbs answer AUTH_REQUIRED on one surface and run on
    /// the other.
    ///
    /// The expectation is DERIVED from the other face's own predicate
    /// (`method_admin::method_requires_admin`) rather than restated: adding a
    /// name to the curated `MUST_STAY_GATED` subset above cannot catch a tool
    /// face nobody has thought about yet, which is how `plugin_manage`
    /// shipped ungated while every `plugin.*` RPC was closed. Each pair names
    /// a method the census pins as registered, so a renamed family goes red in
    /// `method_census` rather than silently making a row here vacuous.
    ///
    /// `method_requires_admin` is a prefix match against `ADMIN_PREFIXES`
    /// (`method_admin.rs`) — it says nothing about whether `rpc` is a method
    /// anything actually dispatches to. A row can be repointed to a
    /// never-registered name that merely shares an admin-gated prefix (this
    /// happened to this exact row: `plugin.enable` stopped being registered
    /// the day it was cut, and the precondition above stayed green throughout
    /// because `"plugin."` is still an `ADMIN_PREFIXES` entry). So the first
    /// assertion below checks the fact the precondition's own doc comment
    /// claims to guard: `rpc` must be live in the real dispatch table, not
    /// merely prefix-shaped like one.
    #[test]
    fn every_tool_face_of_an_admin_rpc_family_is_operator_gated() {
        // (builtin tool name, a registered method of the RPC family it duplicates)
        const TOOL_FACES: &[(&str, &str)] = &[
            ("plugin_manage", "plugins.enable"),
            ("workspace_manage", "workspace.create"),
            ("hooks_manage", "hooks.add"),
            ("skill_manage", "skills.remove"),
            ("skill_install", "skills.install"),
            ("node_manage", "cluster.enroll"),
            ("runtime_manage", "runtimes.install"),
        ];
        // `HandlerRegistry::new()` only reflects registrations made at
        // construction time, inside the `alephcore` library crate. A few RPC
        // methods are wired only at server boot, from the separate
        // `aleph-server` BINARY crate (`register_core_handlers` and friends
        // under `src/bin/aleph-server/commands/start/builder/handlers/`) —
        // the same cross-crate shape `test_identity_handlers_not_registered_
        // until_boot` documents for `identity.*`. A test running inside
        // `alephcore` cannot construct that binary crate's server, so it
        // cannot ask `has_method` about those names; each is named here,
        // with its registration site, rather than silently skipped.
        const BOOT_ONLY_RPCS: &[&str] = &[
            // src/bin/aleph-server/commands/start/builder/handlers/core.rs
            // (`register_core_handlers`), not `HandlerRegistry::new()`.
            "cluster.enroll",
        ];
        let registry = crate::gateway::handlers::HandlerRegistry::new();
        // The allowlist itself needs both directions checked, or it rots
        // into exactly the blind spot this test exists to close: (a) a name
        // could be added here that `HandlerRegistry::new()` actually sees,
        // silently skipping a check that would have passed anyway; (b) a
        // name could be typo'd or a method could be deleted entirely, and
        // "boot-only" would then be indistinguishable from "does not exist".
        // `method_census::sweep_rpc_methods` is the oracle for (b): it scrapes
        // every `.register(...)` call out of `src/**/*.rs`, which includes the
        // `aleph-server` binary crate's boot-time registrations — the same
        // fact this module's own census guards already trust it for.
        let (swept, _unknown) = crate::gateway::method_census::tests::sweep_rpc_methods();
        for name in BOOT_ONLY_RPCS {
            assert!(
                !registry.has_method(name),
                "`{name}` is in BOOT_ONLY_RPCS but IS registered in \
                 `HandlerRegistry::new()` — the exemption is no longer \
                 needed; remove it so `has_method` checks this name like \
                 every other row"
            );
            assert!(
                swept.contains_key(*name),
                "`{name}` is in BOOT_ONLY_RPCS but the production-source \
                 sweep cannot find it registered anywhere — it is not \
                 boot-only, it does not exist; remove it from `TOOL_FACES` \
                 instead of exempting it here"
            );
        }
        for (tool, rpc) in TOOL_FACES {
            if !BOOT_ONLY_RPCS.contains(rpc) {
                assert!(
                    registry.has_method(rpc),
                    "`{rpc}` is not a registered RPC method — the pairing with \
                     `{tool}` must point at a method the dispatch table actually \
                     serves, or the admin-gated precondition below proves nothing"
                );
            }
            assert!(
                super::super::method_admin::method_requires_admin(rpc),
                "precondition: `{rpc}` is supposed to be the admin-gated RPC \
                 half of `{tool}`. If it stopped being admin-gated this row \
                 proves nothing and the pairing needs re-deciding, not deleting"
            );
            assert!(
                tool_requires_operator(tool),
                "`{tool}` is the tool face of the admin-gated `{rpc}` family, \
                 so a chat-tier channel can run over the tool what it is \
                 refused over JSON-RPC"
            );
        }
    }

    /// A4 RED: the six canonical terminal observation capabilities are the
    /// tool face of the operator-only `pty.`/`runtime.` disclosure; the legacy
    /// `terminal` entry stays until the compat ingress is gone.
    #[test]
    fn terminal_capability_canonical_read_names_require_operator() {
        for name in [
            "terminal_sessions_list",
            "terminal_sessions_read",
            "terminal_sessions_status",
            "terminal_sessions_wait",
            "terminal_sessions_explain",
            "terminal_sessions_attach",
        ] {
            assert!(
                tool_requires_operator(name),
                "`{name}` exposes another principal's terminal content and must be OPERATOR_TOOLS"
            );
        }
        assert!(
            tool_requires_operator("terminal"),
            "legacy `terminal` stays operator-gated (compat ingress)"
        );
    }

    #[test]
    fn operator_tools_has_no_duplicates() {
        let unique: std::collections::HashSet<_> = OPERATOR_TOOLS.iter().collect();
        assert_eq!(
            unique.len(),
            OPERATOR_TOOLS.len(),
            "OPERATOR_TOOLS must not list a tool twice"
        );
    }

    #[test]
    fn diagnostics_is_in_operator_tools() {
        // The capability_projection_diagnostics tool is wired only when
        // `ALEPH_CAPABILITY_DIAGNOSTICS=1` at startup, but the OPERATOR
        // gate is unconditional: even when the tool is *advertised*, it
        // must never be reachable from a chat-tier caller. The
        // handler-local three-part check (operator + loopback + conn_id)
        // is the *inner* guard; this entry is the *outer* guard and the
        // first line a chat-tier path crosses. Splitting the two guards
        // (one in OPERATOR_TOOLS, one in DANGEROUS_TOOLS) is the same
        // shape as the plugin_manage / workspace_manage entries above
        // and exists for the same reason: any one guard missing
        // re-opens the closed capability-runtime control surface to
        // exactly the path that tripwire's `findings/4` calls out.
        assert!(
            tool_requires_operator("capability_projection_diagnostics"),
            "capability_projection_diagnostics must require the operator role; \
             the inner three-part check only runs if the outer gate passes"
        );
    }

    #[test]
    fn chat_safe_tools_stay_open() {
        for t in [
            "search",
            "web_fetch",
            "file_read",
            "config_audit",
            "gateway_route",
            "heartbeat_list",
            "skill_list",
            "agent_list",
            "memory_search",
            "ask_user",
            "bash",
            "code_exec",
            "select_model",
            // Read-only fleet discovery stays open — it names nodes, it cannot
            // drive them.
            "node_list",
        ] {
            assert!(
                !tool_requires_operator(t),
                "{t} must stay open to chat tier"
            );
        }
    }

    #[test]
    fn config_tools_have_a_model_pick_branch() {
        // `select_model` mutates session model state and persists it across
        // turns (a non-trivial blast radius). Historically the channel gate
        // had a historical special-case for the removed `moa:` model picks;
        // any other model name was implicitly trusted. Tightening the policy
        // requires an audit entry; this tripwire keeps the audit honest if the
        // legacy compatibility carve-out ever narrows back to `moa:` only.
        assert!(
            !tool_requires_operator("select_model"),
            "select_model currently stays open to chat tier; revisit if the \
             blast-radius story changes"
        );
    }
}
