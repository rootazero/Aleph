use super::*;
use aleph_protocol::runtime::RUNTIME_AGENTS_CHANGED_TOPIC;
use aleph_protocol::terminate::{self, UiLocale};
use aleph_protocol::{
    AgentTraceEvent, AgentTraceReplay, AgentTraceSessionOutcome, AgentTraceTextKind,
    SessionSnapshot, StreamEvent,
};
use serde_json::json;
use shared_ui_logic::transcript::RowStatus;
use std::time::Duration;

/// Everything the transcript holds as reasoning, joined.
///
/// Reasoning is its own chronological entry now rather than a field on the
/// assistant message, so a test that used to read `Assistant { reasoning }`
/// asks the transcript instead. Joining is right rather than a convenience:
/// the projection appends into the trailing reasoning entry, so a turn's
/// reasoning is one entry unless something ran in between — and if something
/// did, these assertions are about the text, not the split.
fn reasoning_text(state: &AppState) -> Option<String> {
    let parts: Vec<&str> = state
        .messages
        .iter()
        .filter_map(|m| match m {
            TranscriptEntry::Reasoning { text, .. } => Some(text.as_str()),
            TranscriptEntry::Step(step) => step.thinking.as_ref().map(|v| v.text.as_str()),
            _ => None,
        })
        .collect();
    (!parts.is_empty()).then(|| parts.join("\n"))
}

/// Every assistant text entry, joined the way a reader sees them.
fn assistant_text(state: &AppState) -> String {
    state
        .messages
        .iter()
        .filter_map(|m| match m {
            TranscriptEntry::AssistantText { markdown, .. } => Some(markdown.as_str()),
            TranscriptEntry::Step(step) => step.text.as_deref(),
            _ => None,
        })
        .collect::<Vec<_>>()
        .join("")
}

/// Every tool row, in transcript order.
fn tool_rows(state: &AppState) -> Vec<&ToolRow> {
    state
        .messages
        .iter()
        .flat_map(|m| match m {
            TranscriptEntry::Tool(row) => vec![row],
            TranscriptEntry::Step(step) => step.tools.iter().collect(),
            _ => Vec::new(),
        })
        .collect()
}

#[test]
fn failure_receipt_after_run_complete_stays_visible_without_reopening_the_run() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "failed-run".into(),
        session_key: "s".into(),
        accepted_at: "2026-10-16T00:00:00Z".into(),
    });
    state.transcript_needs_resync = false;
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "failed-run".into(),
        seq: 1,
        summary: RunSummary {
            terminate_reason: Some("failed".into()),
            ..Default::default()
        },
        total_duration_ms: 10,
    });
    state.handle_gateway_event(StreamEvent::RunError {
        run_id: "failed-run".into(),
        seq: 2,
        error: "Provider credentials unavailable".into(),
        error_code: Some("FAILED".into()),
    });
    assert!(state.current_run.is_none());
    assert!(
        !state.transcript_needs_resync,
        "a late receipt must not schedule a rebuild that erases itself"
    );
    assert!(state.messages.iter().any(|entry| matches!(entry,
        TranscriptEntry::SystemNotice { text, .. } if text.contains("Provider credentials unavailable"))));
}

#[test]
fn live_run_has_one_reducer_owned_step_and_recursive_tool_lookup() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::Reasoning {
        run_id: "run".into(),
        seq: 2,
        content: "thinking".into(),
        is_complete: false,
    });
    state.handle_gateway_event(StreamEvent::ToolStart {
        run_id: "run".into(),
        seq: 3,
        tool_id: "t".into(),
        tool_name: "file_read".into(),
        params: json!({"path":"a.rs"}),
    });
    assert_eq!(reasoning_text(&state).as_deref(), Some("thinking"));
    assert_eq!(state.tool_name_of("t").as_deref(), Some("file_read"));
    assert_eq!(tool_rows(&state).len(), 1);
    assert_eq!(
        state
            .messages
            .iter()
            .filter(|e| matches!(e, TranscriptEntry::Step(_)))
            .count(),
        1
    );
    assert!(!state.messages.iter().any(|e| matches!(
        e,
        TranscriptEntry::Tool(_) | TranscriptEntry::Reasoning { .. }
    )));
}

/// The lead-in and the label have to move together — a localised label under an
/// English lead-in is a sentence in neither language.
#[test]
fn a_halt_notice_is_written_in_one_language() {
    use super::events::halt_notice;
    let en = halt_notice("hit_max_iterations", Some(UiLocale::En));
    assert_eq!(en, "Run stopped: hit max iterations");
    let zh = halt_notice("hit_max_iterations", Some(UiLocale::Zh));
    assert_eq!(zh, "运行已停止：已达迭代上限");
    // An unrecognised token still says something true.
    assert!(halt_notice("quota_exceeded_v9", Some(UiLocale::En)).contains("quota_exceeded_v9"));
}

/// Before locale is resolved (the first frame a TUI may paint while the
/// environment read is still settling), the surface must not flash a raw
/// token. It defaults to English — which has a row for every known token
/// — so an unrecognised token falls through the label verbatim inside a
/// localised sentence rather than appearing naked.
#[test]
fn halt_notice_falls_back_when_locale_is_unset() {
    use super::events::halt_notice;
    let token = "halt-token-x";
    let notice = halt_notice(token, None);
    assert!(!notice.is_empty());
    assert!(notice.contains("halt-token-x") || notice.contains(token));
}

/// The arm fires, and it reads `terminate_detail` before `terminate_reason`.
///
/// Deliberately asserted against `terminate::label(.., from_env())` rather than
/// against a fixed string: the notice is written in whatever language the
/// developer's shell asks for, and pinning one of them would make this test
/// pass or fail on `LANG`. What is being pinned here is *which token* was
/// rendered, which is the thing the surface used to get wrong.
#[test]
fn a_capped_run_names_the_cap_under_the_umbrella_token() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 1,
        summary: RunSummary {
            terminate_reason: Some("budget_exhausted_partial_result".into()),
            terminate_detail: Some("hit_max_iterations".into()),
            ..Default::default()
        },
        total_duration_ms: 10,
    });
    let notice = state
        .messages
        .iter()
        .filter_map(|m| match m {
            TranscriptEntry::SystemNotice { text: content, .. } => Some(content.clone()),
            _ => None,
        })
        .find(|c| c.contains("stopped") || c.contains("已停止"))
        .expect("a non-clean run must leave a system line");
    let locale = UiLocale::from_env();
    assert!(
        notice.contains(terminate::label("hit_max_iterations", locale)),
        "{notice}",
    );
    assert!(
        !notice.contains(terminate::label("budget_exhausted_partial_result", locale)),
        "the umbrella hid the cap that was actually hit: {notice}",
    );
}

/// And a clean run leaves none.
#[test]
fn a_clean_run_leaves_no_halt_line() {
    let mut state = AppState::new("s".into(), "m".into());
    let before = state.messages.len();
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 1,
        summary: RunSummary {
            terminate_reason: Some("completed".into()),
            final_response: Some("done".into()),
            ..Default::default()
        },
        total_duration_ms: 10,
    });
    assert!(
        !state.messages[before..].iter().any(
            |m| matches!(m, TranscriptEntry::SystemNotice { text: content, .. } if content.contains("stopped")
                || content.contains("已停止"))
        ),
        "a clean finish must not be badged",
    );
}

/// A new screen opens on an EMPTY transcript.
///
/// It used to open on a welcome `SystemNotice` naming the session key and the
/// model. Both facts now have one live home each — the model on the derived
/// header line, the key on the status bar — and a frozen string repeating them
/// would be the copy that goes stale: the model in it is only correct until
/// the first session snapshot arrives, which is usually within a second of
/// launch (判据 §1).
#[test]
fn a_new_screen_has_nothing_stored_in_its_transcript() {
    let state = AppState::new("test-session".into(), "claude-3".into());
    assert!(
        state.messages.is_empty(),
        "got: {:?}",
        state.messages.first()
    );
    assert!(state.stuck_to_bottom());
    assert_eq!(state.focus, Focus::Input);
    assert!(!state.should_quit);
}

#[test]
fn scrolling_up_stops_following_the_bottom() {
    let mut state = AppState::new("s".into(), "m".into());
    assert!(state.stuck_to_bottom());

    state.scroll_up(5);
    assert_eq!(state.scroll_offset, 5);
    assert!(!state.stuck_to_bottom());

    // Scrolling up more adds to offset
    state.scroll_up(3);
    assert_eq!(state.scroll_offset, 8);
    assert!(!state.stuck_to_bottom());
}

#[test]
fn scroll_to_bottom_resumes_following() {
    let mut state = AppState::new("s".into(), "m".into());
    state.scroll_up(10);
    assert!(!state.stuck_to_bottom());
    assert_eq!(state.scroll_offset, 10);

    state.scroll_to_bottom();
    assert!(state.stuck_to_bottom());
    assert_eq!(state.scroll_offset, 0);
}

#[test]
fn scrolling_down_to_zero_resumes_following() {
    let mut state = AppState::new("s".into(), "m".into());
    state.scroll_up(3);
    assert!(!state.stuck_to_bottom());

    state.scroll_down(3);
    assert_eq!(state.scroll_offset, 0);
    assert!(state.stuck_to_bottom());
}

/// Returning to the bottom clears the "there is something new down there"
/// marker — otherwise the docked control keeps shouting about rows the user
/// is now looking at.
#[test]
fn arriving_at_the_bottom_clears_the_unseen_marker() {
    let mut state = AppState::new("s".into(), "m".into());
    // Settle once first: the very first observation is a conversation
    // *opening*, which pins to the bottom whatever the offset says.
    state.settle_scroll();
    state.scroll_up(4);
    state.add_system_message("a peer said something".into());
    state.settle_scroll();
    assert!(state.unseen_below, "a new row below the reader is unseen");

    state.scroll_to_bottom();
    assert!(!state.unseen_below);
}

/// The behaviour the old `auto_scroll` bool could not express: the viewer
/// scrolls up to re-read, then sends. The answer must not stream in
/// off-screen.
///
/// # When this goes red
///
/// Dropping the `sends` counter (or deriving it from "the number of user
/// rows grew", which a room peer's message also satisfies — see
/// `chat_scroll`'s module doc).
#[test]
fn my_own_send_pulls_the_viewport_back_down() {
    let mut state = AppState::new("s".into(), "m".into());
    state.settle_scroll();
    state.scroll_up(12);
    // A peer speaking while I read back must NOT move me.
    state.messages.push(TranscriptEntry::UserText {
        id: "peer-1".into(),
        text: "a teammate".into(),
        at_ms: None,
        attachments: Vec::new(),
    });
    state.settle_scroll();
    assert_eq!(state.scroll_offset, 12, "a peer's row moved my viewport");
    assert!(state.unseen_below);

    // My own send does.
    state.add_user_message("mine".into(), vec![]);
    state.settle_scroll();
    assert_eq!(state.scroll_offset, 0);
    assert!(!state.unseen_below);
}

/// An in-place change — a tool row settling, a bubble rewritten — raises
/// nothing: the transcript changed but nothing landed below the reader.
#[test]
fn an_in_place_change_does_not_raise_the_unseen_marker() {
    let mut state = AppState::new("s".into(), "m".into());
    state.settle_scroll();
    state.scroll_up(6);
    state.settle_scroll();
    assert!(!state.unseen_below);

    // Same row count, different content.
    if let Some(TranscriptEntry::SystemNotice { text, .. }) = state.messages.first_mut() {
        text.push_str(" (edited)");
    }
    state.settle_scroll();
    assert!(!state.unseen_below);
    assert_eq!(state.scroll_offset, 6);
}

#[test]
fn toggle_verbose() {
    let mut state = AppState::new("s".into(), "m".into());
    assert!(!state.verbose);

    state.toggle_verbose();
    assert!(state.verbose);

    state.toggle_verbose();
    assert!(!state.verbose);
}

/// R8-9: the agent panel starts hidden — it is a new, opt-in surface, not
/// on screen until `/agents` asks for it — and `toggle_agent_panel` flips
/// exactly that one flag.
#[test]
fn agent_panel_starts_hidden_and_toggles() {
    let mut state = AppState::new("s".into(), "m".into());
    assert!(!state.agent_panel_visible);

    state.toggle_agent_panel();
    assert!(state.agent_panel_visible);

    state.toggle_agent_panel();
    assert!(!state.agent_panel_visible);
}

#[test]
fn ensure_assistant_message_creates_one() {
    let mut state = AppState::new("s".into(), "m".into());
    // A fresh transcript is empty: the header is derived, not stored.
    assert_eq!(state.messages.len(), 0);

    state.ensure_assistant_message();
    assert_eq!(state.messages.len(), 1);
    assert!(matches!(
        state.messages[0],
        TranscriptEntry::AssistantText {
            streaming: true,
            ..
        }
    ));
}

#[test]
fn ensure_assistant_message_idempotent() {
    let mut state = AppState::new("s".into(), "m".into());
    state.ensure_assistant_message();
    assert_eq!(state.messages.len(), 1);

    // Calling again should not create another
    state.ensure_assistant_message();
    assert_eq!(state.messages.len(), 1);
}

#[test]
fn add_user_message_appended() {
    let mut state = AppState::new("s".into(), "m".into());
    state.add_user_message("hello".into(), vec![]);
    assert_eq!(state.messages.len(), 1);
    match &state.messages[0] {
        TranscriptEntry::UserText { text: content, .. } => assert_eq!(content, "hello"),
        other => panic!("Expected User message, got: {other:?}"),
    }
}

#[test]
fn find_tool_mut_returns_correct_tool() {
    let mut state = AppState::new("s".into(), "m".into());
    state.ensure_assistant_message();
    state.start_tool_execution("tool-1".into(), "shell".into(), &json!({"command": "ls"}));
    state.start_tool_execution(
        "tool-2".into(),
        "file_read".into(),
        &json!({"path": "file.txt"}),
    );

    let tool = state.find_tool_mut("tool-2");
    assert!(tool.is_some());
    assert_eq!(tool.unwrap().tool, "file_read");

    let missing = state.find_tool_mut("tool-999");
    assert!(missing.is_none());
}

#[test]
fn open_command_palette_sets_focus() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_command_palette();
    assert_eq!(state.focus, Focus::CommandPalette);
    assert!(state.palette.is_some());

    let palette = state.palette.as_ref().unwrap();
    assert!(palette.input.is_empty());
    assert!(!palette.filtered.is_empty());
    assert_eq!(palette.selected, 0);
}

#[test]
fn close_overlay_resets_focus() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_command_palette();
    assert_eq!(state.focus, Focus::CommandPalette);

    state.close_overlay();
    assert_eq!(state.focus, Focus::Input);
    assert!(state.palette.is_none());
    assert!(state.dialog.is_none());
}

/// A menu question, with the two labels this fixture reuses.
fn menu_view(question: &str) -> AskDialogView {
    AskDialogView {
        question: question.to_string(),
        options: vec!["Yes".into(), "No".into()],
        multi_select: false,
        secret: false,
    }
}

#[test]
fn show_dialog_sets_focus() {
    let mut state = AppState::new("s".into(), "m".into());
    state.show_dialog("telegram:bot:1:u1".into(), menu_view("Approve?"));
    assert_eq!(state.focus, Focus::Dialog);
    let dialog = state.dialog.as_ref().unwrap();
    assert_eq!(dialog.session_key, "telegram:bot:1:u1");
    assert_eq!(dialog.question, "Approve?");
    assert_eq!(dialog.options.len(), 2);
    assert_eq!(dialog.selected, 0);
    // A menu question opens on the menu.
    assert!(!dialog.typing);
    assert!(dialog.has_quick_pick());
}

/// The defect the answer buffer exists to close: a question with no choices had
/// no answerable key at all, and `Esc` is swallowed for this overlay, so the
/// TUI was held by a modal nothing could dismiss. Such a question must open
/// straight into text mode.
#[test]
fn a_free_text_question_opens_ready_to_type() {
    let mut state = AppState::new("s".into(), "m".into());
    state.show_dialog(
        "telegram:bot:1:u1".into(),
        AskDialogView {
            question: "Which language?".into(),
            options: vec![],
            multi_select: false,
            secret: false,
        },
    );
    let dialog = state.dialog.as_ref().unwrap();
    assert!(dialog.typing, "a question with no menu must accept typing");
    assert!(!dialog.has_quick_pick());
    // Nothing typed yet ⇒ Enter has nothing to send (rather than sending "").
    assert_eq!(dialog.pending_reply(), None);
}

/// A single index cannot express a multi-select answer, so there is nothing to
/// quick-pick — the same reason the server suppresses a channel's inline
/// keyboard for these (`clarification::render::keyboard_for`).
#[test]
fn a_multi_select_question_opens_ready_to_type() {
    let mut state = AppState::new("s".into(), "m".into());
    state.show_dialog(
        "telegram:bot:1:u1".into(),
        AskDialogView {
            multi_select: true,
            ..menu_view("Which ones?")
        },
    );
    let dialog = state.dialog.as_ref().unwrap();
    assert!(dialog.typing);
    assert!(!dialog.has_quick_pick());
}

/// A pick sends the 1-BASED INDEX. Labels carry a `— description` suffix and
/// core matches labels exactly, so replying with the label would arrive as free
/// text with no selected index — right to a human, `custom` to the model.
#[test]
fn a_pick_replies_with_the_index_not_the_label() {
    let mut state = AppState::new("s".into(), "m".into());
    state.show_dialog(
        "k".into(),
        AskDialogView {
            options: vec!["staging — shared QA".into(), "prod — live".into()],
            ..menu_view("Deploy where?")
        },
    );
    let dialog = state.dialog.as_mut().unwrap();
    assert_eq!(dialog.pending_reply().as_deref(), Some("1"));
    dialog.selected = 1;
    assert_eq!(dialog.pending_reply().as_deref(), Some("2"));
}

/// Free text always beats the menu in text mode — a menu never forbids it,
/// which is why `ask_user` tells the model never to add an "other" choice.
#[test]
fn a_typed_answer_is_sent_verbatim() {
    let mut state = AppState::new("s".into(), "m".into());
    state.show_dialog("k".into(), menu_view("Approve?"));
    let dialog = state.dialog.as_mut().unwrap();
    dialog.typing = true;
    dialog.input = "  neither, wait for Ana  ".into();
    assert_eq!(
        dialog.pending_reply().as_deref(),
        Some("neither, wait for Ana")
    );
    // Tabbing back to the list means the list, buffer or no buffer.
    dialog.typing = false;
    assert_eq!(dialog.pending_reply().as_deref(), Some("1"));
}

#[test]
fn switch_session_clears_messages() {
    let mut state = AppState::new("s1".into(), "m".into());
    state.add_user_message("hello".into(), vec![]);
    assert_eq!(state.messages.len(), 1);

    state.switch_session("s2");
    assert_eq!(state.session_key, "s2");
    // Should have 1 message: the switch notification
    assert_eq!(state.messages.len(), 1);
    match &state.messages[0] {
        TranscriptEntry::SystemNotice { text: content, .. } => assert!(content.contains("s2")),
        other => panic!("Expected System message, got: {other:?}"),
    }
}

#[test]
fn switch_session_drops_stale_cache_stat() {
    // The old session's cache hit% is meaningless for a different prefix; a
    // cache-less provider in the new session would otherwise display it
    // forever (the stat only updates when a call reports cache activity).
    let mut state = AppState::new("s1".into(), "m".into());
    state.cache_stat = Some(87);

    state.switch_session("s2");
    assert_eq!(state.cache_stat, None, "stale cache stat must not survive");
}

#[test]
fn provider_usage_cache_stat_matches_canonical_formula() {
    // The status bar percentage must be the canonical `read / (input + read)`
    // from `aleph_protocol::cache_hit_ratio` — the same number the core DB
    // rollup and Panel Usage show for the same call. Regression guard for the
    // old local recompute (`input + creation + read` denominator), which read
    // systematically lower on cold starts and prefix rewrites.
    let mut state = AppState::new("s1".into(), "m".into());
    state.apply_agent_trace_event(&AgentTraceEvent::ProviderUsage {
        agent_id: "root".into(),
        input_tokens: 100,
        output_tokens: 10,
        cache_read_tokens: Some(870),
        cache_creation_tokens: Some(30),
        thinking_tokens: None,
    });
    // 870 / (100 + 870) ≈ 89.7% → 90, NOT the 87% the old denominator gave.
    let expected =
        (aleph_protocol::cache_hit_ratio(100, Some(870)).unwrap() * 100.0).round() as u64;
    assert_eq!(state.cache_stat, Some(expected));
    assert_eq!(state.cache_stat, Some(90));

    // A pure cold write (creation only) reads as 0%, not "unknown".
    state.apply_agent_trace_event(&AgentTraceEvent::ProviderUsage {
        agent_id: "root".into(),
        input_tokens: 500,
        output_tokens: 10,
        cache_read_tokens: Some(0),
        cache_creation_tokens: Some(500),
        thinking_tokens: None,
    });
    assert_eq!(state.cache_stat, Some(0));

    // A call with no cache activity at all must not clobber the stat with a
    // misleading 0% (providers without prompt caching).
    state.cache_stat = Some(90);
    state.apply_agent_trace_event(&AgentTraceEvent::ProviderUsage {
        agent_id: "root".into(),
        input_tokens: 500,
        output_tokens: 10,
        cache_read_tokens: None,
        cache_creation_tokens: None,
        thinking_tokens: None,
    });
    assert_eq!(state.cache_stat, Some(90));
}

#[test]
fn clear_screen_restores_startup_view_but_keeps_session_facts() {
    use ratatui::{backend::TestBackend, Terminal};
    use tui_textarea::TextArea;

    let mut state = AppState::new("s1".into(), "m".into());
    state.add_user_message("OLD_TRANSCRIPT".into(), vec![]);
    state.add_system_message("New conversation started".into());
    state.total_tokens = 500;
    state.push_send_history("old prompt".into());
    state.history_index = Some(0);
    state.scroll_up(20);
    state.unseen_below = true;
    state.sticky_user.jump_to_entry("s1", "old-entry".into());
    state.open_tool_output("old-tool".into());
    state.open_theme_picker(vec!["amber".into()], vec![]);
    state.btw.composer = "side draft".into();
    state.agent_panel_visible = true;
    state.ctrl_c_count = 1;
    let generation = state.transcript_generation;

    state.clear_screen();
    assert_eq!(state.session_key, "s1");
    assert_eq!(state.total_tokens, 500);
    assert_eq!(state.model_name, "m");
    assert!(state.messages.is_empty());
    assert_eq!(state.transcript_generation, generation.wrapping_add(1));
    assert!(state.stuck_to_bottom());
    assert!(!state.unseen_below);
    assert!(state.sticky_user.anchor.is_none());
    assert!(state.send_history.is_empty());
    assert!(state.history_index.is_none());
    assert!(state.theme_picker.is_none());
    assert!(state.tool_output.is_none());
    assert!(state.btw.composer.is_empty());
    assert!(!state.btw.open);
    assert!(!state.agent_panel_visible);
    assert_eq!(state.ctrl_c_count, 0);
    assert_eq!(state.focus, Focus::Input);

    let mut terminal = Terminal::new(TestBackend::new(100, 30)).unwrap();
    terminal
        .draw(|frame| crate::tui::render::render(frame, &mut state, &TextArea::default()))
        .unwrap();
    let text: String = terminal
        .backend()
        .buffer()
        .content
        .iter()
        .map(|cell| cell.symbol())
        .collect();
    assert!(text.contains("Welcome to Aleph"), "{text}");
    assert!(text.contains("Ask a question to begin"), "{text}");
    for stale in [
        "OLD_TRANSCRIPT",
        "New conversation started",
        "新对话已开始",
        "Screen cleared",
    ] {
        assert!(!text.contains(stale), "{text}");
    }
}

#[test]
fn clear_screen_does_not_complete_runs_or_retire_pending_approvals() {
    let mut state = AppState::new("s1".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "main-run".into(),
        session_key: "s1".into(),
        accepted_at: "2026-10-16T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "main-run".into(),
        seq: 1,
        content: "before reset".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    state.open_btw("side question".into());
    state.btw.claim_pending_run("side-run".into());
    state.open_approval("approval".into(), "command".into(), None, vec![]);
    let started = state.run_started_at;
    let streamed = state.turn_streamed_len;

    state.clear_screen();
    assert!(state.messages.is_empty());
    assert_eq!(state.current_run.as_deref(), Some("main-run"));
    assert_eq!(state.run_started_at, started);
    assert_eq!(state.turn_streamed_len, streamed);
    assert_eq!(state.btw.active_run_id(), Some("side-run"));
    assert!(state.btw.accepts_frame(Some("side-run")));
    assert!(!state.btw.open);
    assert_eq!(state.approval.as_ref().unwrap().id, "approval");
    assert_eq!(state.focus, Focus::Approval);

    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "main-run".into(),
        seq: 2,
        content: "after reset".into(),
        chunk_index: 1,
        is_final: false,
        is_intermediate: false,
    });
    assert_eq!(assistant_text(&state), "after reset");
    assert_eq!(state.current_run.as_deref(), Some("main-run"));
}

#[test]
fn update_token_usage_accumulates() {
    let mut state = AppState::new("s".into(), "m".into());
    let summary = RunSummary {
        total_tokens: 100,
        tool_calls: 2,
        loops: 1,
        final_response: None,
        ..Default::default()
    };
    state.update_token_usage(&summary);
    assert_eq!(state.total_tokens, 100);

    state.update_token_usage(&summary);
    assert_eq!(state.total_tokens, 200);
}

#[test]
fn request_quit_sets_flag() {
    let mut state = AppState::new("s".into(), "m".into());
    assert!(!state.should_quit);
    state.request_quit();
    assert!(state.should_quit);
}

#[test]
fn send_history_is_capped() {
    let mut state = AppState::new("s".into(), "m".into());
    for i in 0..1_002 {
        state.push_send_history(format!("msg-{i}"));
    }
    assert_eq!(state.send_history.len(), 1_000);
    assert_eq!(state.send_history.first().unwrap(), "msg-2");
    assert_eq!(state.send_history.last().unwrap(), "msg-1001");
    assert!(state.history_index.is_none());
}

#[test]
fn handle_run_accepted() {
    let mut state = AppState::new("s".into(), "m".into());
    let event = StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    };
    let action = state.handle_gateway_event(event);
    assert!(matches!(action, Action::None));
    assert_eq!(state.current_run, Some("run-1".into()));
    assert!(state.is_connected);
}

#[test]
fn handle_response_chunk_appends_content() {
    let mut state = AppState::new("s".into(), "m".into());

    let chunk1 = StreamEvent::ResponseChunk {
        run_id: "run-1".into(),
        seq: 1,
        content: "Hello".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    };
    state.handle_gateway_event(chunk1);

    let chunk2 = StreamEvent::ResponseChunk {
        run_id: "run-1".into(),
        seq: 2,
        content: " World".into(),
        chunk_index: 1,
        is_final: false,
        is_intermediate: false,
    };
    state.handle_gateway_event(chunk2);

    // Just the assistant message — there is no welcome entry any more.
    assert_eq!(state.messages.len(), 1);
    assert_eq!(assistant_text(&state), "Hello World");
    assert!(
        matches!(&state.messages[0], TranscriptEntry::Step(step) if step.text.as_deref() == Some("Hello World"))
    );
}

#[test]
fn handle_agent_trace_text_events_populate_assistant_content_and_reasoning() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 0,
        event: AgentTraceEvent::TurnStarted { iteration: 1 },
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::ReasoningEmitted {
            iteration: 1,
            text: "Inspecting replay trace".into(),
        },
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 2,
        event: AgentTraceEvent::TextEmitted {
            iteration: 1,
            stream: AgentTraceTextKind::Final,
            text: "Replay loaded".into(),
        },
    });

    assert_eq!(assistant_text(&state), "Replay loaded");
    assert_eq!(
        reasoning_text(&state).as_deref(),
        Some("Inspecting replay trace")
    );
}

#[test]
fn handle_agent_trace_session_completed_updates_totals_and_closes_stream() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::TextEmitted {
            iteration: 1,
            stream: AgentTraceTextKind::Final,
            text: "Replay loaded".into(),
        },
    });

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 2,
        event: AgentTraceEvent::SessionCompleted {
            outcome: AgentTraceSessionOutcome::Completed,
            iterations: 1,
            tool_calls_made: 0,
            total_tokens: 321,
            hit_limit: false,
            final_text: Some("Replay loaded".into()),
            terminate_reason: None,
            duration_ms: None,
            token_breakdown: None,
            tool_timeline: Vec::new(),
        },
    });

    assert_eq!(
        state.current_run.as_deref(),
        Some("run-1"),
        "retain correlation for the final pricing frame"
    );
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 3,
        summary: RunSummary {
            total_tokens: 321,
            final_response: Some("Replay loaded".into()),
            ..Default::default()
        },
        total_duration_ms: 10,
    });
    assert_eq!(state.total_tokens, 321);
    assert!(state.current_run.is_none());
    assert!(!state.current_run_uses_agent_trace);
    assert_eq!(assistant_text(&state), "Replay loaded");
    assert!(state.messages.iter().all(|entry| !matches!(entry, TranscriptEntry::Step(step) if step.status == shared_ui_logic::transcript::StepStatus::Live)));
}

#[test]
fn handle_agent_trace_decision_events_append_shared_projection_reasoning() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::TurnStarted { iteration: 1 },
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 2,
        event: AgentTraceEvent::TurnStateEntered {
            iteration: 1,
            state: aleph_protocol::AgentTraceState::Think,
        },
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 3,
        event: AgentTraceEvent::TurnCompleted {
            iteration: 1,
            outcome: aleph_protocol::AgentTraceTurnOutcome::Continue,
            metrics: aleph_protocol::AgentTraceTurnMetrics {
                requested_tool_calls: 1,
                executed_tool_calls: 1,
                productive: true,
                total_tokens: 64,
            },
        },
    });

    assert_eq!(
        reasoning_text(&state),
        None,
        "loop lifecycle is not provider thinking"
    );
    assert!(matches!(&state.messages[0], TranscriptEntry::Step(step) if step.iteration == Some(1)));
}

#[test]
fn load_trace_replay_records_session_summary_in_reasoning() {
    let mut state = AppState::new("s".into(), "m".into());

    let replay = AgentTraceReplay {
        task: aleph_protocol::AgentTraceTaskSummary {
            task_id: "task-1".into(),
            session_id: "session-1".into(),
            agent_id: "agent-1".into(),
            status: "completed".into(),
            prompt_preview: "Inspect replay".into(),
            created_at: 10,
            updated_at: 20,
            started_at: Some(11),
            completed_at: Some(19),
            trace_count: 2,
            last_event_kind: Some("session_completed".into()),
        },
        traces: vec![
            aleph_protocol::AgentTraceReplayEntry {
                step: 0,
                event: AgentTraceEvent::TurnStarted { iteration: 1 },
            },
            aleph_protocol::AgentTraceReplayEntry {
                step: 1,
                event: AgentTraceEvent::SessionCompleted {
                    outcome: AgentTraceSessionOutcome::Completed,
                    iterations: 1,
                    tool_calls_made: 0,
                    total_tokens: 33,
                    hit_limit: false,
                    final_text: Some("done".into()),
                    terminate_reason: None,
                    duration_ms: None,
                    token_breakdown: None,
                    tool_timeline: Vec::new(),
                },
            },
        ],
    };
    state.load_trace_replay(&replay);

    assert_eq!(assistant_text(&state), "done");
    assert_eq!(
        reasoning_text(&state),
        None,
        "session bookkeeping cannot invent provider thinking"
    );
    assert!(state.messages.iter().all(|entry| !matches!(entry, TranscriptEntry::Step(step) if step.status == shared_ui_logic::transcript::StepStatus::Live)));
}

#[test]
fn handle_tool_lifecycle() {
    let mut state = AppState::new("s".into(), "m".into());

    // Tool start
    let start = StreamEvent::ToolStart {
        run_id: "run-1".into(),
        seq: 1,
        tool_name: "bash".into(),
        tool_id: "t1".into(),
        params: serde_json::json!({"command": "ls"}),
    };
    state.handle_gateway_event(start);

    // Tool update
    let update = StreamEvent::ToolUpdate {
        run_id: "run-1".into(),
        seq: 2,
        tool_id: "t1".into(),
        progress: "running...".into(),
    };
    state.handle_gateway_event(update);

    {
        let tool = state.find_tool_mut("t1").unwrap();
        assert!(matches!(tool.status, RowStatus::Running { .. }));
        // A progress line IS the row's body while it runs — there is no
        // separate field for it to outlive the call in.
        assert_eq!(tool.body, RowBody::Text("running...".into()));
    }

    // Tool end
    let end = StreamEvent::ToolEnd {
        run_id: "run-1".into(),
        seq: 3,
        tool_id: "t1".into(),
        result: aleph_protocol::ToolResult::success("output"),
        duration_ms: 150,
    };
    state.handle_gateway_event(end);

    let tool = state.find_tool_mut("t1").unwrap();
    assert_eq!(tool.status, RowStatus::Ok { duration_ms: 150 });
    // The result replaced the progress line, which is what "cleared on end"
    // means once the two share one slot.
    assert_eq!(tool.body, RowBody::Text("output".into()));
}

#[test]
fn handle_agent_trace_tool_lifecycle_takes_precedence() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: aleph_protocol::AgentTraceEvent::ToolCallStarted {
            iteration: 1,
            call: aleph_protocol::AgentTraceToolCallStart {
                tool_id: "t1".into(),
                tool_name: "bash".into(),
                input: serde_json::json!({"command": "ls"}),
            },
        },
    });

    state.handle_gateway_event(StreamEvent::ToolStart {
        run_id: "run-1".into(),
        seq: 2,
        tool_name: "bash".into(),
        tool_id: "t1".into(),
        params: serde_json::json!({"command": "ls"}),
    });

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 3,
        event: aleph_protocol::AgentTraceEvent::ToolSummary {
            iteration: 1,
            summary: "Listed the current directory".into(),
        },
    });

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 5,
        event: aleph_protocol::AgentTraceEvent::ToolCallCompleted {
            iteration: 1,
            call: aleph_protocol::AgentTraceToolCallEnd {
                tool_id: "t1".into(),
                tool_name: "bash".into(),
                input: serde_json::json!({"command": "ls"}),
                duration_ms: 120,
                presentation: None,
            },
            result: aleph_protocol::AgentTraceToolResult::Success {
                output: serde_json::json!({"ok": true}),
            },
        },
    });

    let rows = tool_rows(&state);
    assert_eq!(rows.len(), 1);
    assert_eq!(rows[0].id, "t1");
    assert_eq!(rows[0].status, RowStatus::Ok { duration_ms: 120 });
    assert_eq!(reasoning_text(&state), None);
    assert!(state.messages.iter().any(|entry| matches!(entry, TranscriptEntry::Step(step) if step.notes.iter().any(|note| note.text.contains("Listed the current directory")))));
}

#[test]
fn handle_run_complete_clears_run() {
    let mut state = AppState::new("s".into(), "m".into());
    state.current_run = Some("run-1".into());

    // Create an assistant message that's streaming
    state.ensure_assistant_message();

    let event = StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 10,
        summary: RunSummary {
            total_tokens: 500,
            tool_calls: 3,
            loops: 2,
            final_response: Some("Done".into()),
            ..Default::default()
        },
        total_duration_ms: 5000,
    };
    state.handle_gateway_event(event);

    assert!(state.current_run.is_none());
    assert_eq!(state.total_tokens, 500);
    // (`last_run_duration` used to be asserted here. It was a field with no
    // reader — written at every run end and rendered nowhere, 判据 §17 — and
    // the run's duration now reaches the user as the `✻ Worked for` trailer
    // asserted below, which is the thing that was actually missing.)

    // Assistant message should no longer be streaming. Found rather than
    // taken from `.last()`: a completed run now closes with its own trailer
    // rows (`append_turn_trailers`), so the answer's bubble is no longer the
    // final entry.
    match state
        .messages
        .iter()
        .rev()
        .find(|m| matches!(m, TranscriptEntry::AssistantText { .. }))
        .expect("the run's answer must be on the transcript")
    {
        TranscriptEntry::AssistantText {
            streaming: is_streaming,
            ..
        } => assert!(!is_streaming),
        other => panic!("Expected Assistant message, got: {other:?}"),
    }

    // …and it closes with the wall-clock trailer.
    assert!(
        matches!(
            state.messages.last(),
            Some(TranscriptEntry::SystemNotice { text, .. }) if text.starts_with("\u{273b} Worked for 5.0s ·")
        ),
        "got: {:?}",
        state.messages.last()
    );
}

#[test]
fn run_complete_does_not_double_count_after_agent_trace_session_completed() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::SessionCompleted {
            outcome: AgentTraceSessionOutcome::Completed,
            iterations: 1,
            tool_calls_made: 0,
            total_tokens: 321,
            hit_limit: false,
            final_text: Some("done".into()),
            terminate_reason: None,
            duration_ms: None,
            token_breakdown: None,
            tool_timeline: Vec::new(),
        },
    });
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 2,
        summary: RunSummary {
            total_tokens: 321,
            tool_calls: 0,
            loops: 1,
            final_response: Some("done".into()),
            ..Default::default()
        },
        total_duration_ms: 1500,
    });

    assert_eq!(state.total_tokens, 321);
    assert!(!state.current_run_trace_summary_applied);
}

#[test]
fn handle_run_error_adds_system_message() {
    let mut state = AppState::new("s".into(), "m".into());
    state.current_run = Some("run-1".into());

    let event = StreamEvent::RunError {
        run_id: "run-1".into(),
        seq: 5,
        error: "something went wrong".into(),
        error_code: Some("E001".into()),
    };
    state.handle_gateway_event(event);

    assert!(state.current_run.is_none());
    // Last message should be the error system message
    match state.messages.last().unwrap() {
        TranscriptEntry::SystemNotice { text: content, .. } => {
            assert!(content.contains("something went wrong"));
        }
        other => panic!("Expected System message, got: {other:?}"),
    }
}

#[test]
fn open_approval_sets_focus_and_state() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_approval(
        "ap-1".into(),
        "rm -rf /tmp/x".into(),
        Some("destructive".into()),
        DEFAULT_APPROVAL_DECISIONS.to_vec(),
    );
    assert_eq!(state.focus, Focus::Approval);
    let approval = state.approval.as_ref().unwrap();
    assert_eq!(approval.id, "ap-1");
    assert_eq!(approval.command, "rm -rf /tmp/x");
    assert_eq!(approval.selected, 0);
}

#[test]
fn run_error_dismisses_pending_approval() {
    // A run parked on an approval that then errors must not strand the modal:
    // the poll stops once current_run clears, so run-end has to retract it.
    let mut state = AppState::new("s".into(), "m".into());
    state.current_run = Some("run-1".into());
    state.open_approval(
        "ap-1".into(),
        "cmd".into(),
        None,
        DEFAULT_APPROVAL_DECISIONS.to_vec(),
    );
    assert_eq!(state.focus, Focus::Approval);

    state.handle_gateway_event(StreamEvent::RunError {
        run_id: "run-1".into(),
        seq: 1,
        error: "boom".into(),
        error_code: None,
    });

    assert!(state.approval.is_none());
    assert_eq!(state.focus, Focus::Input);
}

#[test]
fn dismiss_pending_approval_is_noop_without_overlay() {
    // The guard must not touch focus when no overlay is up (e.g. a run ending
    // while the user is scrolling chat).
    let mut state = AppState::new("s".into(), "m".into());
    state.focus = Focus::Chat;
    state.dismiss_pending_approval();
    assert_eq!(state.focus, Focus::Chat);
    assert!(state.approval.is_none());
}

#[test]
fn handle_ask_user_shows_dialog() {
    let mut state = AppState::new("s".into(), "m".into());
    let event = StreamEvent::AskUser {
        request_id: String::new(),
        run_id: "run-1".into(),
        seq: 3,
        session_key: "telegram:bot:1:u1".into(),
        question: "Allow file write?".into(),
        options: vec!["Allow".into(), "Deny".into()],
        // A core that predates the structured view sends neither; the overlay
        // must still render from the flat pair.
        questions: vec![],
        answered: 0,
    };
    state.handle_gateway_event(event);

    assert_eq!(state.focus, Focus::Dialog);
    let dialog = state.dialog.as_ref().unwrap();
    // The dialog keeps the clarification key so the answer can resolve it.
    assert_eq!(dialog.session_key, "telegram:bot:1:u1");
    assert_eq!(dialog.question, "Allow file write?");
    assert_eq!(dialog.options, vec!["Allow", "Deny"]);
}

/// With the structured view the overlay must show what the flat pair
/// structurally cannot: the per-option description, the short header, and the
/// position within a multi-question request. Indices stay 1-based and
/// unchanged, which is what lets the answer keep being a bare number.
#[test]
fn handle_ask_user_renders_the_structured_question() {
    use aleph_protocol::{AskUserOption, AskUserQuestion};

    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::AskUser {
        request_id: String::new(),
        run_id: "run-1".into(),
        seq: 3,
        session_key: "telegram:bot:1:u1".into(),
        question: "Ticket id?".into(),
        options: vec![],
        questions: vec![
            AskUserQuestion {
                id: "env".into(),
                header: Some("Env".into()),
                prompt: "Deploy where?".into(),
                options: vec![AskUserOption {
                    label: "staging".into(),
                    description: Some("shared QA".into()),
                }],
                multi_select: false,
                secret: false,
            },
            AskUserQuestion {
                id: "ticket".into(),
                header: None,
                prompt: "Ticket id?".into(),
                options: vec![],
                multi_select: false,
                secret: false,
            },
        ],
        answered: 1,
    });

    let dialog = state.dialog.as_ref().unwrap();
    // Cursor at 1 ⇒ the SECOND question, not the first.
    assert!(
        dialog.question.contains("Ticket id?"),
        "{}",
        dialog.question
    );
    assert!(dialog.question.contains("2/2"), "{}", dialog.question);
}

/// The description reaches this surface at all — the defect the structured
/// view exists to close (a channel rendered `label — description` while every
/// other face rendered a bare label).
#[test]
fn handle_ask_user_shows_option_descriptions() {
    use aleph_protocol::{AskUserOption, AskUserQuestion};

    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::AskUser {
        request_id: String::new(),
        run_id: "run-1".into(),
        seq: 1,
        session_key: "telegram:bot:1:u1".into(),
        question: "Deploy where?".into(),
        options: vec!["staging".into()],
        questions: vec![AskUserQuestion {
            id: "env".into(),
            header: Some("Env".into()),
            prompt: "Deploy where?".into(),
            options: vec![AskUserOption {
                label: "staging".into(),
                description: Some("shared QA".into()),
            }],
            multi_select: false,
            secret: false,
        }],
        answered: 0,
    });

    let dialog = state.dialog.as_ref().unwrap();
    assert_eq!(dialog.options, vec!["staging — shared QA"]);
    assert!(dialog.question.starts_with("[Env] "), "{}", dialog.question);
    // Single question ⇒ no position marker.
    assert!(!dialog.question.contains("(1/"), "{}", dialog.question);
}

#[test]
fn handle_reasoning_appends() {
    let mut state = AppState::new("s".into(), "m".into());

    let event1 = StreamEvent::Reasoning {
        run_id: "run-1".into(),
        seq: 1,
        content: "Let me think".into(),
        is_complete: false,
    };
    state.handle_gateway_event(event1);

    let event2 = StreamEvent::Reasoning {
        run_id: "run-1".into(),
        seq: 2,
        content: " about this...".into(),
        is_complete: true,
    };
    state.handle_gateway_event(event2);

    assert_eq!(
        reasoning_text(&state).as_deref(),
        Some("Let me think about this...")
    );
}

/// A streaming turn puts the same text on the wire twice - as `ResponseChunk`
/// deltas and again in full as `AgentTrace{TextEmitted{Final}}`. The TUI
/// subscribes to no topics, so it receives both, and both used to append.
///
/// The existing single-projection tests stayed green because each feeds only
/// one of the two streams; this one interleaves them in production order.
/// `think.rs` emits `TurnStarted` on every turn, so the "no agent_trace" branch
/// those tests exercise is unreachable in a real run.
#[test]
fn a_streamed_turn_appends_its_text_exactly_once() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::TurnStarted { iteration: 1 },
    });
    for (i, piece) in ["Hel", "lo, ", "世界!"].iter().enumerate() {
        state.handle_gateway_event(StreamEvent::ResponseChunk {
            run_id: "run-1".into(),
            seq: 2 + i as u64,
            content: (*piece).to_string(),
            chunk_index: u32::try_from(i).unwrap(),
            is_final: false,
            is_intermediate: false,
        });
    }
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 9,
        event: AgentTraceEvent::TextEmitted {
            iteration: 1,
            stream: AgentTraceTextKind::Final,
            text: "Hello, 世界!".into(),
        },
    });

    assert_eq!(assistant_text(&state), "Hello, 世界!");
}

/// A turn whose text never streamed (mock provider, or an output guardrail
/// holding the full text back) must still land in full from the trace event.
#[test]
fn an_unstreamed_turn_still_takes_its_full_final_text() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::TurnStarted { iteration: 1 },
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 2,
        event: AgentTraceEvent::TextEmitted {
            iteration: 1,
            stream: AgentTraceTextKind::Final,
            text: "no deltas for this one".into(),
        },
    });

    assert_eq!(assistant_text(&state), "no deltas for this one");
}

/// Every turn restarts the watermark, so turn 2's text is not clipped by how
/// much turn 1 streamed. Both turns land in the same bubble
/// (`ensure_assistant_message` reuses the trailing Assistant message), which is
/// what made the original doubling accumulate rather than show up as a stray
/// second message.
#[test]
fn a_second_turn_is_not_clipped_by_the_first_turns_watermark() {
    let mut state = AppState::new("s".into(), "m".into());

    for iteration in 1..=2usize {
        let base = iteration as u64 * 10;
        state.handle_gateway_event(StreamEvent::AgentTrace {
            run_id: "run-1".into(),
            seq: base,
            event: AgentTraceEvent::TurnStarted { iteration },
        });
        state.handle_gateway_event(StreamEvent::ResponseChunk {
            run_id: "run-1".into(),
            seq: base + 1,
            content: format!("turn{iteration} "),
            chunk_index: 0,
            is_final: false,
            is_intermediate: false,
        });
        state.handle_gateway_event(StreamEvent::AgentTrace {
            run_id: "run-1".into(),
            seq: base + 2,
            event: AgentTraceEvent::TextEmitted {
                iteration,
                stream: AgentTraceTextKind::Final,
                text: format!("turn{iteration} "),
            },
        });
    }

    assert_eq!(assistant_text(&state), "turn1 turn2 ");
}

/// `agent_trace` frames are best-effort (a lagging server-side receiver drops
/// them), so a tool-heavy run can drop a `ToolCallCompleted` and leave the row spinning
/// forever. `RunComplete` must reconcile against the authoritative
/// `summary.tool_summaries` - the invariant the protocol documents and the
/// Panel already implements, and which the TUI was never wired to.
#[test]
fn a_dropped_completion_is_repaired_by_the_run_summary() {
    use aleph_protocol::events::{ToolErrorItem, ToolSummaryItem};

    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::ToolCallStarted {
            iteration: 1,
            call: aleph_protocol::AgentTraceToolCallStart {
                tool_id: "t1".into(),
                tool_name: "bash".into(),
                input: serde_json::json!({"command": "ls"}),
            },
        },
    });
    // ToolCallCompleted for t1 is DROPPED here - that is the whole point.
    assert!(matches!(
        state.find_tool_mut("t1").unwrap().status,
        RowStatus::Running { .. }
    ));

    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 2,
        summary: RunSummary {
            tool_calls: 2,
            tool_summaries: vec![
                ToolSummaryItem {
                    tool_id: "t1".into(),
                    tool_name: "bash".into(),
                    emoji: "\u{1f4bb}".into(),
                    duration_ms: 120,
                    success: true,
                },
                // This one's *start* frame was dropped too: reconstruct the
                // row, do not skip it.
                ToolSummaryItem {
                    tool_id: "t2".into(),
                    tool_name: "file_read".into(),
                    emoji: "\u{1f4c4}".into(),
                    duration_ms: 8,
                    success: false,
                },
            ],
            errors: vec![ToolErrorItem {
                tool_name: "file_read".into(),
                error: "no such file".into(),
                tool_id: "t2".into(),
            }],
            ..Default::default()
        },
        total_duration_ms: 500,
    });

    let t1 = state.find_tool_mut("t1").unwrap();
    assert_eq!(t1.status, RowStatus::Ok { duration_ms: 120 });
    let t2 = state.find_tool_mut("t2").unwrap();
    assert_eq!(
        t2.status,
        RowStatus::Err {
            duration_ms: 8,
            message: "no such file".into()
        }
    );
}

/// A row the authoritative record does not mention either must still stop
/// spinning: the run is over, so `Running` is the one thing it cannot be.
/// `Pending` — the shared model's word for "unknown" — never `Ok`: do not
/// guess a terminal state.
#[test]
fn a_row_absent_from_the_summary_settles_to_unknown() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-1".into(),
        seq: 1,
        event: AgentTraceEvent::ToolCallStarted {
            iteration: 1,
            call: aleph_protocol::AgentTraceToolCallStart {
                tool_id: "ghost".into(),
                tool_name: "bash".into(),
                input: serde_json::json!({}),
            },
        },
    });

    state.handle_gateway_event(StreamEvent::RunError {
        run_id: "run-1".into(),
        seq: 2,
        error: "provider exploded".into(),
        error_code: None,
    });

    assert_eq!(
        state.find_tool_mut("ghost").unwrap().status,
        RowStatus::Pending
    );
}

// ---------------------------------------------------------------------------
// Thread persistence: the settings a reopened terminal must come back with
// ---------------------------------------------------------------------------

fn snapshot(key: &str) -> SessionSnapshot {
    SessionSnapshot {
        session_key: key.to_string(),
        agent_id: "main".into(),
        mode: Some("code".into()),
        exec_tier: Some("ask".into()),
        think_level: Some("high".into()),
        memory_mode: Some("off".into()),
        model_pin: Some("claude-opus-5".into()),
        model_pin_provider: Some("anthropic".into()),
        model: Some("gpt-5".into()),
        model_provider: Some("openai".into()),
        input_tokens: 900,
        output_tokens: 340,
        total_tokens: 1_240,
        estimated_cost_usd: 0.12,
        message_count: 8,
        compaction_count: 1,
        project_root: Some("/tmp/proj".into()),
        label: None,
        // The run-state view rides on the same snapshot; this fixture is about
        // the knobs, so it says nothing about the last run rather than
        // inventing a clean one.
        last_run: None,
    }
}

/// The headline behaviour: reopening a conversation restores its own settings,
/// not the install defaults the client happened to launch with.
#[test]
fn attaching_restores_the_conversations_settings_and_token_count() {
    let mut state = AppState::new(String::new(), "install-default-model".into());
    assert_eq!(state.total_tokens, 0);

    state.apply_session_snapshot(snapshot("agent:main:main:s3"));

    assert_eq!(state.session_key, "agent:main:main:s3");
    assert_eq!(
        state.total_tokens, 1_240,
        "the counter must not restart at 0"
    );
    let knobs = state.session_knobs();
    assert_eq!(knobs.mode, Some("code"));
    assert_eq!(knobs.exec_tier, Some("ask"));
    assert_eq!(knobs.think_level, Some("high"));
    assert_eq!(knobs.memory_mode, Some("off"));
}

/// A pinned model wins over the model that last served: the pick applies from
/// the next run, so showing `model` alone names the model the user just left.
#[test]
fn the_caption_shows_the_pin_not_the_model_it_replaced() {
    let mut state = AppState::new(String::new(), "install-default-model".into());
    state.apply_session_snapshot(snapshot("k"));
    assert_eq!(state.model_name, "claude-opus-5");
}

/// A conversation that has never run names no model. The caption must fall back
/// to the install default rather than keeping whatever the previous session had.
#[test]
fn a_conversation_with_no_model_falls_back_to_the_install_default() {
    let mut state = AppState::new(String::new(), "install-default-model".into());
    state.apply_session_snapshot(snapshot("first"));
    assert_eq!(state.model_name, "claude-opus-5");

    let fresh = SessionSnapshot {
        session_key: "second".into(),
        ..SessionSnapshot::default()
    };
    state.apply_session_snapshot(fresh);
    assert_eq!(state.model_name, "install-default-model");
}

/// Per-conversation state in a singleton component: switching must not carry
/// the previous conversation's spend or settings into the new one's status bar.
#[test]
fn switching_sessions_clears_the_previous_conversations_state() {
    let mut state = AppState::new("old".into(), "install-default-model".into());
    state.apply_session_snapshot(snapshot("old"));
    assert_eq!(state.total_tokens, 1_240);

    state.switch_session("agent:main:main:s9");

    assert_eq!(state.session_key, "agent:main:main:s9");
    assert_eq!(state.total_tokens, 0, "token count bled across the switch");
    assert_eq!(state.session_knobs(), SessionKnobs::default());
    assert_eq!(state.model_name, "install-default-model");
}

/// The gateway is the only authority on which key a run was routed to: an
/// unparseable key does not fail the call, it makes the router mint a fresh
/// epoch. A client that kept its own guess would address nothing.
#[test]
fn the_canonical_key_from_the_server_is_adopted() {
    let mut state = AppState::new(String::new(), "m".into());
    state.adopt_canonical_session_key("agent:main:main:s4");
    assert_eq!(state.session_key, "agent:main:main:s4");
}

/// …but an empty or unchanged key is a no-op: a server that omits the field
/// must not be able to blank the key the client is using.
#[test]
fn an_absent_canonical_key_does_not_blank_the_session() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    state.adopt_canonical_session_key("");
    assert_eq!(state.session_key, "agent:main:main");
}

/// Adopting a *different* key drops the settings we hold: they describe the key
/// we just replaced, and a status bar confidently describing someone else's
/// conversation is worse than one that says nothing.
#[test]
fn adopting_a_different_key_drops_the_stale_settings() {
    let mut state = AppState::new("old".into(), "m".into());
    state.apply_session_snapshot(snapshot("old"));
    state.adopt_canonical_session_key("agent:main:main:s7");
    assert_eq!(state.session_knobs(), SessionKnobs::default());
}

/// A pin set by `select_model` flows through the snapshot the same way as
/// the four settable knobs: the status bar must show it, not the model that
/// last served (which disagrees for exactly one turn after a pick — the
/// caption would otherwise name the model the user just switched away from).
#[test]
fn session_knobs_includes_model_pin_from_session_snapshot() {
    let mut state = AppState::new(String::new(), "install-default-model".into());
    state.apply_session_snapshot(snapshot("agent:main:main:s3"));

    assert_eq!(
        state.session_knobs().model_pin,
        Some("claude-opus-5"),
        "the pin must ride through session_knobs so the status bar can paint it"
    );
}

/// A conversation with no pin must NOT report one — the renderer has to know
/// that "unset" is a real state (the install default is in play), not a
/// missing field.
#[test]
fn session_knobs_with_no_pin_returns_none() {
    let mut state = AppState::new(String::new(), "install-default-model".into());
    state.apply_session_snapshot(SessionSnapshot {
        session_key: "no-pin".into(),
        model_pin: None,
        model_pin_provider: None,
        // The other knobs stay defaulted; the assertion is only about the pin.
        ..SessionSnapshot::default()
    });

    assert!(
        state.session_knobs().model_pin.is_none(),
        "an unset pin must not become a guessed default in the status bar"
    );
    assert_eq!(
        state.session_knobs(),
        SessionKnobs::default(),
        "no other knob moves just because the pin is unset"
    );
}

/// A locally-set knob shows immediately, without waiting for the next attach —
/// but only through `record_local_knob`, which callers reach only after the
/// server has accepted the write.
#[test]
fn a_locally_recorded_knob_is_visible_before_the_next_attach() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    assert_eq!(state.session_knobs().exec_tier, None);

    state.record_local_knob(SessionKnob::ExecTier, Some("full".into()));
    assert_eq!(state.session_knobs().exec_tier, Some("full"));

    // Clearing back to "follow global" is `None`, not a literal.
    state.record_local_knob(SessionKnob::ExecTier, None);
    assert_eq!(state.session_knobs().exec_tier, None);
}

/// A question that ends without this client answering it must take its card
/// with it. Before the protocol carried the terminal frame, an expired or
/// cancelled clarification left the overlay holding focus and claiming the
/// agent was waiting — for up to the 600 s timeout.
#[test]
fn a_clarification_that_ends_elsewhere_retires_the_card() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::AskUser {
        run_id: "run".into(),
        seq: 1,
        request_id: "req".into(),
        session_key: "telegram:bot:1:u1".into(),
        question: "Approve?".into(),
        options: vec![],
        questions: vec![],
        answered: 0,
    });
    assert_eq!(state.focus, Focus::Dialog);

    state.handle_gateway_event(StreamEvent::ClarificationEnded {
        request_id: "req".into(),
        session_key: "telegram:bot:1:u1".into(),
        outcome: "expired".into(),
    });

    assert!(state.dialog.is_none(), "the card must go with the question");
    assert_eq!(state.focus, Focus::Input);
    // The user is told WHICH ending it was: vanishing silently leaves them
    // unable to tell "answered" from "timed out while I was reading".
    match state.messages.last() {
        Some(TranscriptEntry::SystemNotice { text: content, .. }) => {
            assert!(content.contains("expired"), "{content}");
        }
        other => panic!("expected a system line naming the outcome, got {other:?}"),
    }
}

/// …but only its own. Two sessions are live in one TUI whenever a background
/// run answers elsewhere; closing on a foreign frame would yank a card the user
/// is mid-answer on.
#[test]
fn a_clarification_ending_in_another_session_leaves_this_card_alone() {
    let mut state = AppState::new("s".into(), "m".into());
    state.show_dialog("telegram:bot:1:u1".into(), menu_view("Approve?"));

    state.handle_gateway_event(StreamEvent::ClarificationEnded {
        request_id: String::new(),
        session_key: "telegram:bot:1:SOMEONE-ELSE".into(),
        outcome: "cancelled".into(),
    });

    assert!(
        state.dialog.is_some(),
        "a foreign frame must not close this card"
    );
    assert_eq!(state.focus, Focus::Dialog);
}

// ---------------------------------------------------------------------------
// Provider / model picker
// ---------------------------------------------------------------------------

/// A catalogue in a deliberately non-alphabetical, curated order — the order
/// the server sends and the ranker must not shuffle within a tier.
fn catalog() -> Vec<CatalogEntry> {
    vec![
        sample_catalog_entry("openrouter", &["openai/gpt-5.6"]),
        sample_catalog_entry("openai", &["gpt-5.6", "gpt-5.6-luna"]),
    ]
}

/// The two levels share one matcher, so the ranker's rules hold at both.
///
/// A provider named by the query keeps its whole roster; a provider surfaced
/// only because one of its models matched shows that model and says so. A
/// second matcher for the model level is what would let the row a bare Enter
/// selects disagree with the level above it.
#[test]
fn both_picker_levels_rank_through_the_shared_matcher() {
    let c = catalog();

    // Provider level: an exact id outranks a provider that merely resells it,
    // even though the reseller is listed first.
    let rows = provider_picker_rows(&c, None, "openai");
    assert_eq!(
        rows[0],
        PickerRow::Provider {
            index: 1,
            matched: 2
        },
        "the exact id must be the row a bare Enter selects"
    );
    assert_eq!(
        rows[1],
        PickerRow::Provider {
            index: 0,
            matched: 1
        },
        "the reseller surfaced through one model, and reports one match"
    );

    // Model level, same query: it names the provider, so every model stays.
    let ids = model_ids(provider_picker_rows(&c, Some(1), "openai"));
    assert_eq!(ids, vec!["gpt-5.6", "gpt-5.6-luna"]);

    // Model level, a query naming one model: narrowed to it.
    assert_eq!(
        model_ids(provider_picker_rows(&c, Some(1), "luna")),
        vec!["gpt-5.6-luna"]
    );
}

fn model_ids(rows: Vec<PickerRow>) -> Vec<String> {
    rows.into_iter()
        .map(|r| match r {
            PickerRow::Model { model } => model.id,
            other => panic!("expected a model row, got {other:?}"),
        })
        .collect()
}

/// The filter survives a descent.
///
/// Typing a model id and pressing Enter twice has to land on that model. Were
/// the descent to clear the filter, the query that found the provider would
/// have to be typed again against its full roster — and a user has no reason to
/// expect their own keystrokes to be dropped halfway through one act.
#[test]
fn a_descent_keeps_the_query_that_found_the_provider() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_provider_picker(catalog(), "luna".into());
    assert_eq!(state.focus, Focus::ProviderPicker);

    // One provider matched, and through one of its models.
    assert_eq!(state.provider_picker.as_ref().unwrap().rows.len(), 1);
    let Some(ProviderPick::Provider(index)) = state.selected_provider_pick() else {
        panic!("the top level offers providers");
    };
    state.enter_provider(index);

    assert_eq!(
        state.selected_provider_pick(),
        Some(ProviderPick::Model("gpt-5.6-luna".into())),
        "the query has to still be narrowing after the descent"
    );
}

/// Backspace climbs before it closes, and only from a level that has one above.
#[test]
fn going_back_is_only_possible_from_the_model_level() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_provider_picker(catalog(), String::new());

    assert!(
        !state.provider_picker_go_back(),
        "the provider level has nowhere to climb to; the caller closes instead"
    );

    state.enter_provider(1);
    assert!(state.provider_picker_go_back());
    assert!(state.provider_picker.as_ref().unwrap().provider.is_none());
    assert_eq!(
        state.provider_picker.as_ref().unwrap().rows.len(),
        2,
        "climbing back restores the provider rows"
    );
}

/// An empty match set confirms to nothing, rather than to row zero of a list
/// that is not there.
#[test]
fn confirming_an_empty_filter_picks_nothing() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_provider_picker(catalog(), "no-such-vendor".into());
    assert!(state.provider_picker.as_ref().unwrap().rows.is_empty());
    assert_eq!(state.selected_provider_pick(), None);
}

/// Switching conversations drops the picker.
///
/// It is a singleton overlay in a client that holds one conversation at a time:
/// a pick left mid-flight would be confirmed against the session just left.
#[test]
fn switching_session_retires_the_provider_picker() {
    let mut state = AppState::new("s".into(), "m".into());
    state.open_provider_picker(catalog(), String::new());
    state.switch_session("other");
    assert!(state.provider_picker.is_none());
    assert_eq!(state.focus, Focus::Input);
}

// ---------------------------------------------------------------------------
// Cross-session frame routing: the `frame_belongs_here` guard
// ---------------------------------------------------------------------------
//
// Background runs, cron runs and delegated subagents all publish frames
// carrying a `run_id` but, with three exceptions, no `session_key` at all —
// see `StreamEvent::run_id()`'s doc in shared/protocol. The gateway's own
// visibility filter is owner-scoped, not session-scoped, so on a single-user
// box every one of those frames reaches every open TUI connection.
// `RunAccepted` is the one frame that names both `run_id` and `session_key`;
// these tests drive it as the teaching signal `frame_belongs_here` learns
// from, per Controller Ruling R7 (2026-08-20-btw-side-questions).

#[test]
fn frame_belongs_here_learns_from_run_accepted() {
    let mut state = AppState::new("s".into(), "m".into());

    // A run whose OWN `RunAccepted` named a different session is proven
    // foreign: dropped.
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-foreign".into(),
        session_key: "agent:main:ephemeral:btw-abc".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    assert!(!state.frame_belongs_here("run-foreign"));

    // A run whose `RunAccepted` named THIS session: kept.
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-mine".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:01Z".into(),
    });
    assert!(state.frame_belongs_here("run-mine"));

    // A run id this screen has never seen a `RunAccepted` for at all: "I
    // cannot tell" must not become "drop" — a new session's first turn, and
    // every frame from a core too old to send `RunAccepted`, must not go
    // silently missing.
    assert!(state.frame_belongs_here("run-never-announced"));
}

#[test]
fn a_response_chunk_from_another_sessions_run_is_not_appended() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-elsewhere".into(),
        session_key: "agent:main:ephemeral:btw-abc".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-elsewhere".into(),
        seq: 1,
        content: "not for you".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    // Nothing was appended.
    assert_eq!(state.messages.len(), 0);
}

/// The same text a streaming turn produces twice on the wire (see
/// `turn_streamed_len`'s doc: `ResponseChunk` deltas AND, in full,
/// `AgentTrace{TextEmitted{Final}}`, because the TUI subscribes to no
/// topics). Both carriers must be guarded, not just the more obvious one.
#[test]
fn an_agent_trace_text_event_from_another_sessions_run_is_not_appended() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-elsewhere".into(),
        session_key: "agent:main:ephemeral:btw-abc".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::AgentTrace {
        run_id: "run-elsewhere".into(),
        seq: 1,
        event: AgentTraceEvent::TextEmitted {
            iteration: 1,
            stream: AgentTraceTextKind::Final,
            text: "not for you either".into(),
        },
    });
    assert_eq!(state.messages.len(), 0);
}

#[test]
fn a_response_chunk_from_this_sessions_run_is_still_appended() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-mine".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-mine".into(),
        seq: 1,
        content: "hello".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    assert_eq!(state.messages.len(), 1);
    match &state.messages[0] {
        TranscriptEntry::AssistantText {
            markdown: content, ..
        } => assert_eq!(content, "hello"),
        TranscriptEntry::Step(step) => assert_eq!(step.text.as_deref(), Some("hello")),
        other => panic!("Expected Assistant message, got: {other:?}"),
    }
}

#[test]
fn a_response_chunk_from_a_run_never_announced_is_still_appended() {
    // No `RunAccepted` was ever seen for this run_id — a race that lost it,
    // or a core too old to send one at all.
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-never-announced".into(),
        seq: 1,
        content: "hello".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    assert_eq!(state.messages.len(), 1);
}

/// `ModelResolved` and `ContextGauge` do not append visible chat text, but a
/// foreign run's status repainting this screen's gauge/model indicator is
/// the same defect wearing a different hat — the guard covers both, not just
/// the transcript-text arms.
#[test]
fn a_context_gauge_from_another_sessions_run_is_not_applied() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-elsewhere".into(),
        session_key: "agent:main:ephemeral:btw-abc".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::ContextGauge {
        run_id: "run-elsewhere".into(),
        seq: 1,
        context_tokens: 500,
        context_window: 8000,
        total_tokens: 500,
    });
    assert!(state.context_gauge.is_none());
}

/// `AskUser` is deliberately exempt from this guard (see `run_scoped_id`'s
/// doc comment; the original task brief called this out of scope). This test
/// locks the decision in so a future change to the guard's shape does not
/// silently start hiding clarification cards for background/delegated runs.
#[test]
fn an_ask_user_from_another_sessions_run_is_still_shown() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-elsewhere".into(),
        session_key: "agent:main:ephemeral:btw-abc".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::AskUser {
        request_id: String::new(),
        run_id: "run-elsewhere".into(),
        seq: 1,
        session_key: "agent:main:ephemeral:btw-abc".into(),
        question: "Proceed?".into(),
        options: vec!["Yes".into(), "No".into()],
        questions: vec![],
        answered: 0,
    });
    assert!(state.dialog.is_some());
}

/// A conversation switch is the same defect from a different trigger: the
/// run left behind in the old session keeps streaming, and its frames must
/// not leak into the new one.
#[test]
fn a_run_left_behind_by_a_session_switch_does_not_leak_into_the_new_session() {
    let mut state = AppState::new("s1".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s1".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.switch_session("s2");

    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-1".into(),
        seq: 2,
        content: "late arrival".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });

    assert!(
        state
            .messages
            .iter()
            .all(|m| !matches!(m, TranscriptEntry::AssistantText { .. })),
        "the abandoned run's text must not land in the new session's transcript"
    );
}

/// The other half of the same property: a run's home session, once learned,
/// does not get baked in as "foreign forever" — switching away and back
/// must let its frames resume landing where they actually belong. Without
/// this, `mark_run_session`'s "own or foreign" recording would be pointless:
/// a set that only ever grew stale foreign entries would trap this exact
/// case just as badly as the leak it replaced.
#[test]
fn a_run_resumes_appearing_after_switching_back_to_its_own_session() {
    let mut state = AppState::new("s1".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s1".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.switch_session("s2");
    state.switch_session("s1");

    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-1".into(),
        seq: 2,
        content: "still mine".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });

    match state.messages.last() {
        Some(TranscriptEntry::AssistantText {
            markdown: content, ..
        }) => assert_eq!(content, "still mine"),
        Some(TranscriptEntry::Step(step)) => assert_eq!(step.text.as_deref(), Some("still mine")),
        other => panic!("Expected Assistant message, got: {other:?}"),
    }
}

// ---------------------------------------------------------------------------
// `/btw` side questions
// ---------------------------------------------------------------------------

/// Drive a whole side question through the frame path exactly as the gateway
/// would, and prove **nothing about it** reaches the main conversation.
///
/// This is the assertion Step 5 of this task makes on a real machine, made
/// here where it can be run on every commit. It is also the one that fails if
/// the intercept is removed or moved after the cross-session guard: the answer
/// would land in `messages` as an assistant bubble in a conversation the side
/// question was deliberately kept out of.
///
/// The session key on every side frame is the DERIVED one — that is what the
/// engine emits (`execute.rs` redirects before it emits `RunAccepted`), and it
/// is why keying the overlay on the key was never an option from a client that
/// cannot compute it.
#[test]
fn no_side_question_frame_reaches_the_main_transcript() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    let before = state.messages.len();

    // A main run is in flight — a side question exists to be asked *while*
    // one is.
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-main".into(),
        session_key: "agent:main:main".into(),
        accepted_at: "2026-08-20T00:00:00Z".into(),
    });

    // The user asks a side question; the send site claims the run it got back.
    state.open_btw("what files are in src?".into());
    state.btw.claim_pending_run("run-side".into());

    for event in [
        StreamEvent::RunAccepted {
            run_id: "run-side".into(),
            session_key: "agent:main:ephemeral:btw-abc123".into(),
            accepted_at: "2026-08-20T00:00:01Z".into(),
        },
        StreamEvent::AgentTrace {
            run_id: "run-side".into(),
            seq: 1,
            event: AgentTraceEvent::ToolCallStarted {
                iteration: 1,
                call: aleph_protocol::AgentTraceToolCallStart {
                    tool_id: "t1".into(),
                    tool_name: "file_read".into(),
                    input: serde_json::json!({}),
                },
            },
        },
        StreamEvent::ResponseChunk {
            run_id: "run-side".into(),
            seq: 2,
            content: "main.rs, lib.rs".into(),
            chunk_index: 0,
            is_final: false,
            is_intermediate: false,
        },
        StreamEvent::RunComplete {
            run_id: "run-side".into(),
            seq: 3,
            summary: RunSummary::default(),
            total_duration_ms: 12,
        },
    ] {
        state.handle_gateway_event(event);
    }

    // The overlay has the whole exchange…
    let exchange = state.btw.current().expect("the side question settled");
    assert_eq!(exchange.question, "what files are in src?");
    assert_eq!(exchange.answer, "main.rs, lib.rs");

    // …and the main conversation has none of it.
    assert_eq!(
        state.messages.len(),
        before,
        "a side question must add nothing to the main transcript, got: {:?}",
        &state.messages[before..]
    );
    for message in state.messages.iter() {
        // Every entry that carries prose. A tool row's body is a leak path
        // too, so it is included rather than skipped — the answer this test
        // watches for could arrive as a tool result just as easily as text.
        let text: &str = match message {
            TranscriptEntry::UserText { text: content, .. }
            | TranscriptEntry::SystemNotice { text: content, .. }
            | TranscriptEntry::Reasoning { text: content, .. }
            | TranscriptEntry::AssistantText {
                markdown: content, ..
            } => content,
            TranscriptEntry::Tool(row) => match &row.body {
                RowBody::Text(t) => t,
                _ => "",
            },
            // Phase S: the variant exists, no TUI path constructs it yet.
            // Phase T replaces this with the step row; until then an entry
            // that cannot exist renders nothing rather than a guessed shape.
            TranscriptEntry::Step(_) => "",
            TranscriptEntry::ToolGroup(_) | TranscriptEntry::TurnSummary(_) => "",
        };
        assert!(
            !text.contains("main.rs, lib.rs"),
            "the side answer leaked into the transcript: {text}"
        );
    }

    // The main run is untouched: the side question neither claimed the run
    // slot nor cleared it on its own completion.
    assert_eq!(
        state.current_run,
        Some("run-main".into()),
        "a side question's RunComplete must not end the main run"
    );
}

/// The side thread does not survive a `/session` switch.
///
/// `AppState` is a singleton — one conversation's worth of everything — so
/// per-conversation state that outlives a switch reports the previous
/// conversation under the new one's name (`switch_session` wipes `messages`,
/// `total_tokens`, the gauge and the cache stat for exactly this reason). The
/// overlay is per-conversation twice over: its exchanges are that
/// conversation's, and its run claims would route the OLD conversation's side
/// frames into the NEW screen's overlay.
///
/// It is cleared rather than keyed per conversation — see `switch_session` for
/// why, the short version being that the side key embeds the old key's epoch,
/// so after a switch the retained thread is one the server can no longer
/// address at all.
#[test]
fn switching_sessions_takes_the_side_thread_with_it() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    state.open_btw("what files are in src?".into());
    state.btw.claim_pending_run("run-side".into());
    state.btw.push_delta("run-side", "main.rs");
    state.btw.finish_active("run-side", None);
    state.open_btw("and tests?".into());
    state.btw.claim_pending_run("run-side-2".into());
    assert_eq!(state.btw.exchanges.len(), 1);
    assert!(state.btw.open);

    state.switch_session("agent:main:main:s2");

    assert!(
        state.btw.exchanges.is_empty(),
        "the old conversation's side questions are still pageable: {:?}",
        state.btw.exchanges
    );
    assert!(
        state.btw.active.is_none(),
        "an old side run is still active"
    );
    assert!(!state.btw.open, "the overlay is still on screen");
    // The run CLAIMS survive on purpose — they are per-run, not
    // per-conversation, and they are the only thing that can still tell a
    // side frame apart from an ordinary one when that run's `RunAccepted`
    // never arrived. Dropping them is what let the old side answer render
    // into the new conversation.
    assert!(
        state.btw.accepts_frame(Some("run-side-2")),
        "the old conversation's side run is no longer recognised, so its \
         frames will be treated as this conversation's"
    );

    // …and a frame from it now lands nowhere: intercepted, but matching no
    // active question.
    let before = state.messages.len();
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-side-2".into(),
        seq: 1,
        content: "the old side answer".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    assert!(state.btw.active.is_none());
    assert_eq!(
        state.messages.len(),
        before,
        "the old side answer reached the new conversation: {:?}",
        &state.messages[before..]
    );
}

/// A modal raised over the side-question overlay must hand focus back to it,
/// not to the composer.
///
/// A clarification and an approval card are both raised by *frames*, so
/// neither needs the user to have left the overlay first. Returning focus to
/// `Input` left the side question painted over the transcript with every key
/// going to a textarea the user could not see — and `Esc` at `Focus::Input` is
/// a no-op, so there was no way out but `/stop` or quitting.
#[test]
fn answering_a_modal_raised_over_the_overlay_returns_focus_to_it() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    state.open_btw("why?".into());
    assert_eq!(state.focus, Focus::Btw);

    state.show_dialog(
        "agent:main:main".into(),
        AskDialogView {
            question: "which one?".into(),
            options: vec!["a".into()],
            multi_select: false,
            secret: false,
        },
    );
    assert_eq!(state.focus, Focus::Dialog);

    state.close_overlay();
    assert_eq!(
        state.focus,
        Focus::Btw,
        "the side question is still on screen, so it is still what keys mean"
    );

    // And once it is closed, focus goes where it always did.
    state.close_btw();
    assert_eq!(state.focus, Focus::Input);
    state.close_overlay();
    assert_eq!(state.focus, Focus::Input);
}

/// The same for the OTHER modal that can be raised over the overlay by a
/// frame rather than by a keypress.
///
/// `focus_after_modal` has two call sites and the test above exercises one.
/// A tool approval is the second, and it is the more likely of the two to be
/// raised mid-side-question: the poll runs on the tick whenever a run is
/// active, and a `/btw` makes one active. Every path out of the card is
/// covered — resolving it, and the retraction that fires when its run ends by
/// any route (`dismiss_pending_approval`).
#[test]
fn resolving_an_approval_raised_over_the_overlay_returns_focus_to_it() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    state.open_btw("why?".into());
    state.btw.claim_pending_run("run-side".into());

    state.open_approval(
        "a1".into(),
        "rm -rf /".into(),
        Some("destructive".into()),
        DEFAULT_APPROVAL_DECISIONS.to_vec(),
    );
    assert_eq!(state.focus, Focus::Approval);

    state.close_approval();
    assert_eq!(
        state.focus,
        Focus::Btw,
        "the side question is still on screen, so it is still what keys mean"
    );

    // The retraction path (the card's run ended elsewhere) must agree.
    state.open_approval(
        "a2".into(),
        "curl | sh".into(),
        None,
        DEFAULT_APPROVAL_DECISIONS.to_vec(),
    );
    state.dismiss_pending_approval();
    assert_eq!(state.focus, Focus::Btw);

    // With no overlay on screen it lands in the composer, as it always did.
    state.close_btw();
    state.open_approval(
        "a3".into(),
        "ls".into(),
        None,
        DEFAULT_APPROVAL_DECISIONS.to_vec(),
    );
    state.close_approval();
    assert_eq!(state.focus, Focus::Input);
}

/// The case where the intercept is the ONLY thing standing between a side
/// answer and the main transcript: a side run whose recorded home session is
/// this screen's.
///
/// Ordinarily it is the second line of defence — a side run's `RunAccepted`
/// carries the derived key, so `frame_belongs_here` drops everything that
/// follows and the intercept only decides whether the user gets to *see* it.
/// That is not guaranteed. `mark_run_session` is first-write-wins, and the
/// Simulated-fallback handler emits a pre-dispatch `RunAccepted` carrying the
/// **routed (main)** key before the engine emits the canonical one. Today the
/// two live in mutually exclusive `agent.run` registrations, so they cannot
/// race — but "cannot race today" is a fact about how the server is wired this
/// month, and the client should not be one refactor away from replaying a side
/// answer into the conversation it was kept out of.
///
/// So the guard is set up to say "mine" here, deliberately, and the assertion
/// is that nothing arrives anyway.
#[test]
fn the_intercept_holds_even_when_the_screen_thinks_the_side_run_is_its_own() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    let before = state.messages.len();

    // The screen learns `run-side` under its OWN key — the pre-dispatch frame
    // winning first-write-wins.
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-side".into(),
        session_key: "agent:main:main".into(),
        accepted_at: "2026-08-20T00:00:00Z".into(),
    });
    assert!(
        state.frame_belongs_here("run-side"),
        "precondition: the cross-session guard now believes this run is ours, \
         so it will NOT drop what follows"
    );

    state.open_btw("what files are in src?".into());
    state.btw.claim_pending_run("run-side".into());

    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-side".into(),
        seq: 1,
        content: "main.rs, lib.rs".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });

    assert_eq!(
        state.btw.active.as_ref().expect("still answering").answer,
        "main.rs, lib.rs"
    );
    assert_eq!(
        state.messages.len(),
        before,
        "the side answer reached the main transcript: {:?}",
        &state.messages[before..]
    );
}

/// The intercept must be exactly as wide as the runs the overlay asked for.
/// A frame from the main run has to reach the transcript even while a side
/// question is streaming, or `/btw` would silently freeze the conversation it
/// was supposed to run beside.
#[test]
fn a_side_question_in_flight_does_not_swallow_the_main_run() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-main".into(),
        session_key: "agent:main:main".into(),
        accepted_at: "2026-08-20T00:00:00Z".into(),
    });
    state.open_btw("side".into());
    state.btw.claim_pending_run("run-side".into());

    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-main".into(),
        seq: 1,
        content: "the main answer".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });

    match state.messages.last().expect("a message") {
        TranscriptEntry::AssistantText {
            markdown: content, ..
        } => assert_eq!(content, "the main answer"),
        TranscriptEntry::Step(step) => assert_eq!(step.text.as_deref(), Some("the main answer")),
        other => panic!("expected the main run's assistant bubble, got: {other:?}"),
    }
    assert!(
        state
            .btw
            .active
            .as_ref()
            .expect("still answering")
            .answer
            .is_empty(),
        "the main run's text must not be routed into the side question"
    );
}

/// An `AskUser` frame carries no run id, so it is exempt from the screen's
/// cross-session guard by design. The overlay must not swallow it — a parked
/// question hidden behind an overlay that cannot answer it is a 600-second
/// stall with no visible cause.
#[test]
fn the_overlay_does_not_swallow_a_run_less_frame() {
    let mut state = AppState::new("agent:main:main".into(), "m".into());
    state.open_btw("side".into());
    state.btw.claim_pending_run("run-side".into());

    state.handle_gateway_event(StreamEvent::AskUser {
        request_id: String::new(),
        run_id: String::new(),
        seq: 1,
        session_key: "agent:main:main".into(),
        question: "which one?".into(),
        options: vec!["a".into(), "b".into()],
        questions: Vec::new(),
        answered: 0,
    });

    assert!(
        state.dialog.is_some(),
        "a session-keyed clarification must still reach its overlay"
    );
}

// ---------------------------------------------------------------------------
// The terminal answer of a run that produced no other copy of it
// ---------------------------------------------------------------------------

/// A run the gateway SERVED rather than dispatched — `/btw promote` is the
/// first — never emits a chunk or a trace, so `summary.final_response` is the
/// only carrier its answer ever gets.
///
/// This is the surface that owns the `p` key, and before this it showed a
/// spinner and then nothing: for the success receipt AND for "nothing to
/// promote", while the failure receipt (`RunError`) spoke. The asymmetry fell
/// exactly the wrong way round, and it compounded — a user who presses `p`,
/// sees nothing, and presses it again carries a second full-size answer into
/// the main conversation with no signal either time.
#[test]
fn a_run_that_streamed_nothing_still_renders_its_terminal_answer() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-promote".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-promote".into(),
        seq: 1,
        summary: RunSummary {
            final_response: Some("Promoted the side answer into this conversation: why?".into()),
            ..Default::default()
        },
        total_duration_ms: 0,
    });

    let rendered: Vec<&String> = state
        .messages
        .iter()
        .filter_map(|m| match m {
            TranscriptEntry::AssistantText {
                markdown: content, ..
            } => Some(content),
            _ => None,
        })
        .collect();
    assert_eq!(
        rendered.len(),
        1,
        "the receipt must reach the transcript: {:?}",
        state.messages
    );
    assert_eq!(
        rendered[0], "Promoted the side answer into this conversation: why?",
        "the terminal answer is the only copy a served run ever sends"
    );
}

/// The other half, and the reason this is a per-run flag rather than an
/// unconditional render: an ordinary streamed turn puts the same text on the
/// wire twice (deltas, then `final_response`), so rendering the summary
/// unconditionally would double every reply in the transcript.
#[test]
fn a_streamed_answer_is_not_doubled_by_its_own_summary() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-ordinary".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-ordinary".into(),
        seq: 1,
        content: "the answer".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-ordinary".into(),
        seq: 2,
        summary: RunSummary {
            final_response: Some("the answer".into()),
            ..Default::default()
        },
        total_duration_ms: 0,
    });

    // The run's trailer rows sit after the answer now, so this looks for the
    // assistant bubble rather than the final entry.
    match state
        .messages
        .iter()
        .rev()
        .find(|m| matches!(m, TranscriptEntry::AssistantText { .. }))
        .expect("the answer must be on the transcript")
    {
        TranscriptEntry::AssistantText {
            markdown: content, ..
        } => assert_eq!(
            content, "the answer",
            "the summary is a duplicate of what streaming already rendered"
        ),
        other => panic!("expected an assistant message, got {other:?}"),
    }
}

/// The flag belongs to the run, not to the screen: a second served run in the
/// same session must render its own answer even though the first one rendered
/// text a moment earlier.
#[test]
fn the_streamed_flag_is_cleared_when_the_next_run_is_accepted() {
    let mut state = AppState::new("s".into(), "m".into());
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-one".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    state.handle_gateway_event(StreamEvent::ResponseChunk {
        run_id: "run-one".into(),
        seq: 1,
        content: "first".into(),
        chunk_index: 0,
        is_final: false,
        is_intermediate: false,
    });
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-one".into(),
        seq: 2,
        summary: RunSummary::default(),
        total_duration_ms: 0,
    });

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-two".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:01Z".into(),
    });
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-two".into(),
        seq: 3,
        summary: RunSummary {
            final_response: Some("there is nothing to promote".into()),
            ..Default::default()
        },
        total_duration_ms: 0,
    });

    let joined: String = state
        .messages
        .iter()
        .filter_map(|m| match m {
            TranscriptEntry::AssistantText {
                markdown: content, ..
            } => Some(content.as_str()),
            _ => None,
        })
        .collect::<Vec<_>>()
        .join("|");
    assert!(
        joined.contains("there is nothing to promote"),
        "the second run's receipt was suppressed by the first run's text: {joined:?}"
    );
}

// ---------------------------------------------------------------------------
// Joining a running session, and not stealing somebody else's turn
// ---------------------------------------------------------------------------

/// `chat.history`'s answer for a live run with no age reported — the shape an
/// older gateway sends, and the one most of these tests care about.
fn joined(run_id: &str) -> ActiveRunJoin {
    ActiveRunJoin {
        run_id: run_id.to_string(),
        elapsed_ms: None,
    }
}

/// Before the server has answered "what is running here", an unheard-of run id
/// is kept — the posture this screen has always had, and the one an older
/// gateway (no `active_run` field) leaves it in.
#[test]
fn an_unknown_run_is_kept_until_the_server_has_answered() {
    let state = AppState::new("agent:main:main:s1".into(), "m".into());
    assert!(
        state.frame_belongs_here("run-from-somewhere-else"),
        "\"I cannot tell\" must not read as \"not mine\" before reconciling"
    );
}

/// After it has answered, an unheard-of run id can only be somebody else's.
///
/// The reachable case is mundane: this terminal starts while another one is
/// mid-turn on a different session. Its `RunAccepted` was broadcast before this
/// client connected, so `run_sessions` never learns it is foreign — and every
/// later frame of that turn (reasoning, tool rows, streamed answer) used to be
/// rendered into whatever conversation this screen is showing.
#[test]
fn a_run_that_started_before_this_screen_connected_is_dropped_once_reconciled() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(None); // server: nothing running on this session
    assert!(!state.frame_belongs_here("run-started-before-we-connected"));
}

/// Attaching to a session somebody else is driving joins that turn instead of
/// watching a transcript that never moves.
#[test]
fn attaching_to_a_running_session_adopts_its_run() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(joined("run-live")));

    assert_eq!(state.current_run.as_deref(), Some("run-live"));
    assert!(
        state.run_started_at.is_some(),
        "the working indicator is what tells the user the turn is live"
    );
    assert!(state.frame_belongs_here("run-live"));
    // …and reconciliation still holds for everything else.
    assert!(!state.frame_belongs_here("run-elsewhere"));
}

/// The elapsed timer reports the TURN's age, not this screen's attachment.
///
/// Joining a turn already four minutes deep used to start the indicator at
/// zero, and nothing on screen said the number was a floor. The server sends a
/// duration (never a start stamp — a client cannot subtract a timestamp
/// without first answering "whose clock"), so this back-dates by it.
#[test]
fn an_adopted_run_is_back_dated_by_the_age_the_server_reported() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(ActiveRunJoin {
        run_id: "run-live".into(),
        elapsed_ms: Some(240_000),
    }));

    let started = state.run_started_at.expect("a joined run is timed");
    assert!(
        started.elapsed() >= Duration::from_secs(239),
        "the indicator must read the turn's age, not the age of this join"
    );
}

/// No age reported — an older gateway, or a run that left the engine's table
/// between the handler's two lookups — falls back to counting from the join.
/// That is a floor, and it is what this path always did; the one reading that
/// would be a lie is claiming the turn started now.
#[test]
fn an_adopted_run_without_an_age_counts_from_the_join() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(joined("run-live")));

    let started = state.run_started_at.expect("a joined run is timed");
    assert!(started.elapsed() < Duration::from_secs(1));
}

/// An absurd reading must not take the client down. `Instant::now()` minus a
/// duration reaching past the start of the monotonic clock panics, and this
/// number arrives off a wire.
#[test]
fn an_impossible_age_falls_back_instead_of_panicking() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(ActiveRunJoin {
        run_id: "run-live".into(),
        elapsed_ms: Some(u64::MAX),
    }));

    assert!(
        state.run_started_at.is_some(),
        "the indicator still has to come on"
    );
}

/// The elapsed timer's terminal value: `run_started_at` is cleared on
/// `RunComplete` (T2.9).
///
/// `AppState::run_started_at` drives the status-bar working indicator. The
/// chosen contract is "the timer reads while a run is in flight, disappears
/// when it ends" — the inverse of "freeze the final value", which would
/// make the busy spinner stick at the same number for the lifetime of the
/// finished transcript and read as a still-running turn. The render guard
/// in `tui/render.rs` already gates on `current_run.is_some()`, so
/// `None` here cleanly hides the indicator without any extra check at the
/// render site. If this test ever goes red, someone changed either
/// `events.rs`'s `RunComplete` arm or `run_clock.rs` to freeze a sentinel
/// and the status bar will start lying about liveness.
#[test]
fn run_complete_clears_the_elapsed_timer() {
    let mut state = AppState::new("s".into(), "m".into());

    // Accepted → timer is on.
    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-1".into(),
        session_key: "s".into(),
        accepted_at: "2026-03-04T00:00:00Z".into(),
    });
    assert_eq!(state.current_run.as_deref(), Some("run-1"));
    assert!(
        state.run_started_at.is_some(),
        "RunAccepted must light the working indicator"
    );

    // Complete → timer disappears.
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 2,
        summary: RunSummary::default(),
        total_duration_ms: 12_345,
    });
    assert!(
        state.run_started_at.is_none(),
        "RunComplete must clear the indicator — the freeze alternative would \
         keep a stale number on the status bar for the lifetime of the transcript"
    );
}

/// The adopted run is recorded by home session, so a `/session` switch away and
/// back behaves like any other run: dropped while elsewhere, kept on return.
#[test]
fn an_adopted_run_follows_its_home_session_across_switches() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(joined("run-live")));

    state.switch_session("agent:main:main:s2");
    assert!(
        !state.frame_belongs_here("run-live"),
        "s1's run must not render into s2"
    );
    assert!(
        state.frame_belongs_here("run-unknown"),
        "the switch reopens the fail-open window until the caller re-attaches"
    );

    state.switch_session("agent:main:main:s1");
    assert!(state.frame_belongs_here("run-live"));
}

/// `run_sessions` is FIFO-bounded, so a busy install can evict the pair for the
/// very run this screen is watching. That eviction used to be harmless because
/// unknown meant "keep"; with reconciliation it would mean "drop", so the
/// active run is answered before the map is consulted at all.
#[test]
fn the_screens_own_run_survives_fifo_eviction() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(joined("run-live")));

    for i in 0..(super::events::RUN_SESSION_CAP + 8) {
        state.handle_gateway_event(StreamEvent::RunAccepted {
            run_id: format!("noise-{i}"),
            session_key: "agent:main:main:other".into(),
            accepted_at: String::new(),
        });
    }

    assert!(
        state.frame_belongs_here("run-live"),
        "the one turn the user is watching was evicted out of its own transcript"
    );
}

/// Reconciliation must not blind this screen to `RunAccepted` itself.
///
/// That frame is the only thing that ever teaches `run_sessions` where a run
/// lives. Guarding it once the guard can answer "not mine" would drop the
/// teaching frame, and the run would stay unknown forever — so a later
/// `/session` switch onto its actual session could not recognise it either.
#[test]
fn a_foreign_run_is_still_learned_after_reconciling() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(None);

    state.handle_gateway_event(StreamEvent::RunAccepted {
        run_id: "run-elsewhere".into(),
        session_key: "agent:main:main:s2".into(),
        accepted_at: String::new(),
    });
    assert_eq!(
        state.current_run, None,
        "a foreign run must not become this screen's run"
    );
    assert!(!state.frame_belongs_here("run-elsewhere"));

    // Learned, not merely dropped: switching to its home session picks it up.
    state.switch_session("agent:main:main:s2");
    assert!(state.frame_belongs_here("run-elsewhere"));
}

// ---------------------------------------------------------------------------
// A room peer's message
// ---------------------------------------------------------------------------

/// One `stream.session_user_message` frame, addressed to `session_key`.
fn peer_row(session_key: &str, author: &str, content: &str) -> StreamEvent {
    StreamEvent::SessionUserMessage {
        session_key: session_key.to_string(),
        author_user_id: author.to_string(),
        content: content.to_string(),
        timestamp: "2026-08-23T10:00:00Z".to_string(),
        seq: 7,
    }
}

fn user_rows(state: &AppState) -> Vec<&str> {
    state
        .messages
        .iter()
        .filter_map(|m| match m {
            TranscriptEntry::UserText { text: content, .. } => Some(content.as_str()),
            _ => None,
        })
        .collect()
}

/// A teammate's message in a shared room becomes a row here.
///
/// Without it this screen watched a peer's answer stream in with no question
/// above it: `RunAccepted` for their run carries THIS session's key, so the
/// cross-session guard admits every frame of it, while the row behind it only
/// arrived on the next attach — this client never re-hydrates mid-session.
#[test]
fn a_room_peers_message_becomes_a_user_row() {
    let mut state = AppState::new("agent:main:room:s1".into(), "m".into());
    state.my_user_id = Some("u-me".into());

    state.handle_gateway_event(peer_row("agent:main:room:s1", "u-peer", "did you deploy?"));

    assert_eq!(user_rows(&state), vec!["did you deploy?"]);
}

/// The viewer's own message is already on screen, optimistically. Echoing it
/// would render it twice with nothing to clean the duplicate up.
#[test]
fn my_own_message_is_not_echoed_back_onto_the_screen() {
    let mut state = AppState::new("agent:main:room:s1".into(), "m".into());
    state.my_user_id = Some("u-me".into());

    state.handle_gateway_event(peer_row("agent:main:room:s1", "u-me", "mine"));

    assert!(user_rows(&state).is_empty());
}

/// Not knowing who I am is not evidence that somebody else typed it. An older
/// gateway, a failed `users.me`, or a caller with no principal record all land
/// here, and all of them must leave this exactly as it was before the frame
/// existed — the row still arrives on the next attach.
#[test]
fn an_unknown_own_identity_disables_the_echo_rather_than_guessing() {
    let mut state = AppState::new("agent:main:room:s1".into(), "m".into());
    state.my_user_id = None;

    state.handle_gateway_event(peer_row("agent:main:room:s1", "u-peer", "hello"));

    assert!(user_rows(&state).is_empty());
}

/// A row for another conversation is dropped, the same way a foreign run's
/// frames are: this screen holds one transcript and no session list to file it
/// under.
#[test]
fn a_peer_message_for_another_session_is_dropped() {
    let mut state = AppState::new("agent:main:room:s1".into(), "m".into());
    state.my_user_id = Some("u-me".into());

    state.handle_gateway_event(peer_row("agent:main:room:s2", "u-peer", "elsewhere"));

    assert!(user_rows(&state).is_empty());
}

/// The peer's run may have opened its assistant bubble before the row arrives.
/// A question rendered under its own answer reads as a reply to it, so the row
/// goes above the one message still being written — and only that one.
#[test]
fn a_peer_message_lands_above_an_answer_already_streaming() {
    let mut state = AppState::new("agent:main:room:s1".into(), "m".into());
    state.my_user_id = Some("u-me".into());
    state.messages.clear();
    state.messages.push(TranscriptEntry::AssistantText {
        id: "a1".into(),
        markdown: "settled turn".into(),
        streaming: false,
    });
    state.messages.push(TranscriptEntry::AssistantText {
        id: "a2".into(),
        markdown: "answering".into(),
        streaming: true,
    });

    state.handle_gateway_event(peer_row("agent:main:room:s1", "u-peer", "the question"));

    let shapes: Vec<&str> = state
        .messages
        .iter()
        .map(|m| match m {
            TranscriptEntry::UserText { .. } => "user",
            TranscriptEntry::AssistantText {
                streaming: is_streaming,
                ..
            } => {
                if *is_streaming {
                    "streaming"
                } else {
                    "assistant"
                }
            }
            _ => "other",
        })
        .collect();
    assert_eq!(shapes, vec!["assistant", "user", "streaming"]);
}

/// Session-keyed and run-less by construction: the run that produced the row is
/// somebody else's. If it ever carried a run id the cross-session guard would
/// drop the frame before this arm ran — which is the shape that kept this frame
/// exempted from the typed clients in the first place.
#[test]
fn a_peer_message_carries_no_run_id_for_the_guard_to_reject() {
    let event = peer_row("agent:main:room:s1", "u-peer", "x");
    assert_eq!(event.run_id(), "");
}

// ---------------------------------------------------------------------------
// Losing the connection, and coming back
// ---------------------------------------------------------------------------

/// The reconciliation baseline belonged to the connection that just died.
///
/// This is the whole reason a reconnect has to be visible to this screen. Left
/// armed, the guard goes on answering "not mine" about run ids it has never
/// heard of — on the strength of an answer from a server it is no longer
/// talking to, and against runs whose `RunAccepted` it could not have seen
/// because it was offline when they started.
#[test]
fn losing_the_connection_disarms_the_cross_session_guard() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(None);
    assert!(
        !state.frame_belongs_here("run-elsewhere"),
        "reconciled: an unheard-of id is somebody else's"
    );

    state.on_disconnected();

    assert!(
        state.frame_belongs_here("run-elsewhere"),
        "after a drop this screen cannot tell, and cannot-tell must mean keep"
    );
}

/// A turn that was in flight when the socket died is not reported as over.
/// This client stopped hearing it; that is not the same as it stopping.
#[test]
fn losing_the_connection_does_not_end_the_run_it_was_watching() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(joined("run-live")));

    state.on_disconnected();

    assert_eq!(state.current_run.as_deref(), Some("run-live"));
    assert!(
        state.run_started_at.is_some(),
        "the working indicator must stay on: the turn is probably still going"
    );
    assert!(!state.is_connected, "the status dot must report the truth");
}

/// A reattach disarms the reconciliation baseline and forgets the run it
/// believed was in flight — and leaves the transcript alone.
///
/// The transcript is swapped by `attach_session(.., AttachMode::Replace)` once
/// the server's copy has arrived. Clearing it here instead would mean a
/// `chat.history` that fails on a freshly-restored connection leaves the user
/// on a blank screen, which is worse than the stale transcript it replaced.
#[test]
fn beginning_a_reattach_resets_the_run_but_not_the_transcript() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.adopt_active_run(Some(joined("run-live")));
    state.messages.push(TranscriptEntry::UserText {
        id: "u1".into(),
        text: "from before the drop".into(),
        at_ms: None,
        attachments: Vec::new(),
    });
    let before = state.messages.len();

    state.begin_reattach();

    assert_eq!(
        state.messages.len(),
        before,
        "the fetch has not happened yet — nothing may be thrown away on its behalf"
    );
    assert_eq!(state.current_run, None);
    assert!(
        state.frame_belongs_here("run-elsewhere"),
        "nothing has been asked about this session yet — the guard must be disarmed \
         until the attach answers"
    );
}

/// Unlike `switch_session`, a reattach keeps the `/btw` overlay: the side
/// thread belongs to the SAME conversation, which has not changed, and its
/// derived key is still addressable server-side.
#[test]
fn beginning_a_reattach_keeps_the_side_question() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    state.btw.begin("what does this flag do?".into());
    state.btw.claim_run("run-side".into());

    state.begin_reattach();

    assert_eq!(
        state.btw.active_run_id(),
        Some("run-side"),
        "the side question outlives a reconnect on the same conversation"
    );
}

/// `handle_topic_event` is the sync half of Task 8a's wire: it recognises
/// `runtime.agents.changed` and sets `runtime_agents_refetch_due` for the
/// main loop to act on, but does not itself touch `runtime_agents` — a
/// change notification carries no agent data, only word that a re-fetch is
/// due, and clobbering still-valid data with `Loading` on every
/// notification would flash the panel for no reason.
///
/// Fix round 1: this is a `bool` on `AppState`, not a returned `Action` —
/// see `AppState::runtime_agents_refetch_due`'s doc for why a returned
/// `Action` here was a defect (the main loop's burst-coalescing drain keeps
/// only the LAST non-`None` action, so an `Action` naming this re-fetch
/// could be silently overwritten and lost).
#[test]
fn a_runtime_agents_changed_topic_sets_the_refetch_flag_without_touching_state() {
    let mut state = AppState::new("s".into(), "m".into());
    state.runtime_agents = AgentPanelData::Ready(vec![]);

    state.handle_topic_event(RUNTIME_AGENTS_CHANGED_TOPIC, serde_json::json!({}));

    assert!(
        state.runtime_agents_refetch_due,
        "the one topic this phase understands must set the re-fetch flag"
    );
    assert!(
        matches!(state.runtime_agents, AgentPanelData::Ready(ref v) if v.is_empty()),
        "a change notification must not overwrite still-valid data before the \
         re-fetch answers"
    );
}

/// A topic this client did not subscribe to (or does not yet understand)
/// must be a no-op, not a wildcard trigger — proves this is a recognised
/// topic, not a catch-all that sets the re-fetch flag for anything.
#[test]
fn an_unrelated_topic_is_a_no_op() {
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_topic_event("connection.warning", serde_json::json!({}));

    assert!(
        !state.runtime_agents_refetch_due,
        "an unrelated topic must not set the agent-panel re-fetch flag"
    );
    assert!(
        matches!(state.runtime_agents, AgentPanelData::Loading),
        "an unrelated topic must not touch runtime_agents at all"
    );
}

/// The live plan projection against the PRODUCTION shape of a tool result:
/// the scratchpad's JSON re-encoded as a `Value::String`, which is what both
/// `agent_trace.tool_call_completed` and `tool_end` carry. A reader keyed on
/// `output.get("snapshot")` is `None` on that shape — this projection never
/// moved on a live frame until qa/agents_viz measured it (2026-09-02).
#[test]
fn a_live_scratchpad_result_in_the_wire_string_shape_updates_the_plan() {
    let mut state = AppState::new("agent:main:main:s1".into(), "m".into());
    let output = serde_json::json!({
        "success": true,
        "message": "Plan set with 2 item(s)",
        "snapshot": {
            "objective": "Ship",
            "complete": false,
            "items": [
                {"text": "Design", "status": "completed"},
                {"text": "Build", "status": "in_progress"},
            ]
        }
    });
    let wire = serde_json::Value::String(output.to_string());

    state.maybe_apply_plan_from_tool("scratchpad", &wire);

    let plan = state
        .plan
        .as_ref()
        .expect("the live frame updates the plan");
    assert_eq!(plan.total(), 2);
    assert_eq!(plan.current_step(), Some("Build"));

    // A later call with no snapshot (a `read`, or prose) leaves it alone:
    // absence is "this call carried none", never "clear".
    state.maybe_apply_plan_from_tool("scratchpad", &serde_json::json!("ok"));
    assert_eq!(state.plan.as_ref().map(PlanSnapshot::total), Some(2));
}

// ---------------------------------------------------------------------------
// B6: what a turn costs, and what it leaves behind when it closes
// ---------------------------------------------------------------------------

fn tool_item(id: &str, name: &str, ms: u64) -> aleph_protocol::events::ToolSummaryItem {
    aleph_protocol::events::ToolSummaryItem {
        tool_id: id.into(),
        tool_name: name.into(),
        emoji: String::new(),
        duration_ms: ms,
        success: true,
    }
}

fn finished_row(id: &str, name: &str, args: serde_json::Value) -> TranscriptEntry {
    let mut row = ToolRow::new(id, name, &args);
    row.start(0);
    row.finish(&aleph_protocol::ToolResult::success("ok"), 100, 100);
    TranscriptEntry::Tool(row)
}

/// The whole cost wire, from the two carriers to the string the status bar
/// renders: attach sets the base, a completed run adds to it.
#[test]
fn a_completed_run_adds_its_price_to_what_the_snapshot_reported() {
    let mut state = AppState::new("s".into(), "m".into());
    assert_eq!(
        state.cost_view(),
        CostView::Unknown,
        "before the server has said anything, the cost is unknown — not zero"
    );

    state.apply_session_snapshot(SessionSnapshot {
        session_key: "s".into(),
        estimated_cost_usd: 0.100,
        ..Default::default()
    });
    assert_eq!(state.cost_view().label(), "$0.100");

    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 1,
        summary: RunSummary {
            estimated_cost_usd: Some(0.020),
            ..Default::default()
        },
        total_duration_ms: 1_000,
    });
    assert_eq!(state.cost_view().label(), "$0.120");

    // And the next attach REBASES: the server's number already contains that
    // run, so adding again would bill it twice.
    state.apply_session_snapshot(SessionSnapshot {
        session_key: "s".into(),
        estimated_cost_usd: 0.120,
        ..Default::default()
    });
    assert_eq!(state.cost_view().label(), "$0.120");
}

/// A provider with no price list does not make the conversation free.
#[test]
fn an_unpriced_run_leaves_the_total_a_floor() {
    let mut state = AppState::new("s".into(), "m".into());
    state.apply_session_snapshot(SessionSnapshot {
        session_key: "s".into(),
        estimated_cost_usd: 0.050,
        ..Default::default()
    });
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 1,
        summary: RunSummary {
            estimated_cost_usd: None,
            ..Default::default()
        },
        total_duration_ms: 1_000,
    });
    assert_eq!(state.cost_view().label(), "$0.050+?");
}

/// Switching conversations must not carry the previous one's spend across.
#[test]
fn a_session_switch_drops_the_previous_conversations_cost() {
    let mut state = AppState::new("s1".into(), "m".into());
    state.apply_session_snapshot(SessionSnapshot {
        session_key: "s1".into(),
        estimated_cost_usd: 9.990,
        ..Default::default()
    });
    state.switch_session("s2");
    assert_eq!(
        state.cost_view(),
        CostView::Unknown,
        "the incoming conversation's spend is not known until its own snapshot arrives"
    );
}

/// **The turn summary gets a producer.** `TranscriptEntry::TurnSummary` had a
/// renderer in `chat_area` since B3 and nothing anywhere in the crate built
/// one (判据 §7 — two ends, no wire).
///
/// The counts come from the rows the AUTHORITATIVE record names, so they are
/// this run's work rather than everything still on screen.
#[test]
fn a_multi_tool_run_closes_with_a_summary_of_what_it_did() {
    let mut state = AppState::new("s".into(), "m".into());
    // A tool row from an EARLIER turn, still on the transcript. It must not
    // be counted into this run's summary.
    state
        .messages
        .push(finished_row("old", "bash", json!({"command": "true"})));
    state
        .messages
        .push(finished_row("c1", "bash", json!({"command": "ls"})));
    state.messages.push(finished_row(
        "c2",
        "file_read",
        json!({"file_path": "a.rs"}),
    ));

    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 1,
        summary: RunSummary {
            tool_summaries: vec![
                tool_item("c1", "bash", 100),
                tool_item("c2", "file_read", 100),
            ],
            ..Default::default()
        },
        total_duration_ms: 12_000,
    });

    let summary = state
        .messages
        .iter()
        .find_map(|m| match m {
            TranscriptEntry::TurnSummary(e) => Some(e),
            _ => None,
        })
        .expect("a two-tool run earns a summary row");
    assert_eq!(summary.commands, 1, "one Bash, not the earlier turn's too");
    assert_eq!(summary.reads, 1);

    // And the wall clock closes the turn, as its own row: the summary's
    // duration is the tools', this one is the run's.
    assert!(
        matches!(
            state.messages.last(),
            Some(TranscriptEntry::SystemNotice { text, .. }) if text.starts_with("\u{273b} Worked for 12s ·")
        ),
        "got: {:?}",
        state.messages.last()
    );
}

/// The shared gate, honoured rather than re-implemented: one tool is not a
/// turn worth summarising, and a run with no tools at all still gets its
/// wall-clock trailer.
#[test]
fn a_single_tool_run_gets_no_summary_row_but_still_closes() {
    let mut state = AppState::new("s".into(), "m".into());
    state
        .messages
        .push(finished_row("c1", "bash", json!({"command": "ls"})));
    state.handle_gateway_event(StreamEvent::RunComplete {
        run_id: "run-1".into(),
        seq: 1,
        summary: RunSummary {
            tool_summaries: vec![tool_item("c1", "bash", 100)],
            ..Default::default()
        },
        total_duration_ms: 800,
    });
    assert!(
        !state
            .messages
            .iter()
            .any(|m| matches!(m, TranscriptEntry::TurnSummary(_))),
        "MIN_TOOLS_FOR_SUMMARY is the shared rule; this surface does not get its own"
    );
    assert!(
        matches!(
            state.messages.last(),
            Some(TranscriptEntry::SystemNotice { text, .. }) if text.starts_with("\u{273b} Worked for 0.8s ·")
        ),
        "got: {:?}",
        state.messages.last()
    );
}

// ---- browser-live resource catalog wiring -------------------------------

fn browser_resource_json(id: &str, revision: u64) -> serde_json::Value {
    use aleph_protocol::browser_live::*;
    let resource = PreviewResource {
        resource_id: id.into(),
        revision,
        binding: ResourceBinding::Browser {
            viewer: ViewerBinding {
                principal: IssuerIdentity::User {
                    user_id: "u1".into(),
                },
                task: ConversationBinding {
                    session_key: "agent:main:main".into(),
                    run_id: "run-1".into(),
                },
                target: BrowserTargetBinding {
                    profile: "default".into(),
                    browser_session_id: "bs-1".into(),
                    target_id: "t1".into(),
                },
            },
        },
        kind: PreviewKind::Page,
        display: DisplayPolicy::ExplicitOnly,
        source: PreviewSource::BrowserTool,
        provenance: PreviewProvenance::NotManaged,
        expires_at_ms: 2_000,
        redaction: RedactionStatus::Pending,
        companion_candidates: Vec::new(),
    };
    serde_json::json!({"type": "browser_live_resource", "resource": resource})
}

#[test]
fn browser_resource_topic_populates_catalog_and_stale_revision_is_ignored() {
    use aleph_protocol::browser_live::RESOURCE_TOPIC;
    let mut state = AppState::new("s".into(), "m".into());

    state.handle_topic_event(RESOURCE_TOPIC, browser_resource_json("res_a", 2));
    assert_eq!(state.browser_resources.get("res_a").unwrap().revision, 2);

    state.handle_topic_event(RESOURCE_TOPIC, browser_resource_json("res_a", 1));
    assert_eq!(
        state.browser_resources.get("res_a").unwrap().revision,
        2,
        "an older revision must not replace the stored one"
    );
}

#[test]
fn browser_closed_topic_removes_resource_and_malformed_frames_are_no_ops() {
    use aleph_protocol::browser_live::{CLOSED_TOPIC, RESOURCE_TOPIC};
    let mut state = AppState::new("s".into(), "m".into());
    let data = browser_resource_json("res_a", 1);
    let binding = data["resource"]["binding"].clone();

    state.handle_topic_event(RESOURCE_TOPIC, serde_json::json!({"resource": 7}));
    state.handle_topic_event(CLOSED_TOPIC, serde_json::json!({}));
    assert!(state.browser_resources.is_empty());

    state.handle_topic_event(RESOURCE_TOPIC, data);
    state.handle_topic_event(RESOURCE_TOPIC, serde_json::json!({"resource": "garbage"}));
    assert_eq!(state.browser_resources.len(), 1);

    state.handle_topic_event(
        CLOSED_TOPIC,
        serde_json::json!({
            "type": "browser_live_closed",
            "closed": {
                "resource_id": "res_a",
                "binding": binding,
                "reason": "target_closed",
                "at_ms": 1000
            }
        }),
    );
    assert!(state.browser_resources.get("res_a").is_none());
    assert!(state.browser_resources.is_closed("res_a"));
}
