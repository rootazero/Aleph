// Core application state management for the TUI.
//
// Contains all state types (AppState, ChatMessage, Action, Focus, etc.)
// and the gateway event handler that maps StreamEvent -> state mutations.
// The two projection paths live in sibling modules: `events` (StreamEvent ->
// state) and `trace` (AgentTraceEvent -> state).

mod browser_catalog;
mod context_view;
mod cost;
pub(super) mod detail_setting;
mod events;
mod hydration;
mod trace;

pub use hydration::{build_completed_history, HydrationResult, RecoveryState};

#[cfg(test)]
mod tests;

pub use browser_catalog::BrowserResourceCatalog;
pub use context_view::ContextView;
pub use cost::{CostTally, CostView};

use std::collections::HashSet;
use std::time::Instant;

use aleph_protocol::plan::PlanSnapshot;
use aleph_protocol::providers::{rank_entries, CatalogEntry, RosterModel};
use aleph_protocol::runtime::RuntimeAgentEntry;
use aleph_protocol::subagent_tree::{self, NodeLifecycle, SubagentNode};
use aleph_protocol::{RunSummary, SessionSnapshot};
use chrono::{DateTime, Utc};
use ratatui::layout::Rect;
use shared_ui_logic::state::{scroll_action, ListCursor, ScrollAction};
use shared_ui_logic::transcript::{Change, DetailLevel, Modality, Transcript};

use super::btw_overlay::BtwOverlay;
use super::command_tree::{CommandEntry, DisplayEntry};
use super::interaction::{InteractionController, ModalOwner};
use super::regions::JumpTarget;
use super::slash::{LocalCommand, SessionKnob, ToolProgressMode};
use super::tool_output::ToolOutputView;
use super::widgets::sticky_user::StickyUserState;

// ---------------------------------------------------------------------------
// Action
// ---------------------------------------------------------------------------

/// All possible actions that can result from user input or system events.
/// Actions are dispatched from the input handler and gateway event handler,
/// then consumed by the main loop to mutate state and trigger side effects.
#[derive(Debug)]
pub enum Action {
    /// No-op, nothing to do
    None,
    /// Quit the application
    Quit,
    /// Tick event (drives spinner animation, etc.)
    Tick,

    // -- Chat --
    /// Send a message to the agent
    SendMessage(String),
    /// Execute a local slash command (handled in TUI)
    LocalCommand(LocalCommand),
    /// Send a gateway command (slash command forwarded as chat message)
    GatewayCommand(String),
    /// Cancel a running agent run
    CancelRun(String),

    // -- Scrolling --
    /// Scroll the chat view up by N lines
    ScrollUp(usize),
    /// Scroll the chat view down by N lines
    ScrollDown(usize),
    /// Jump to the bottom of the chat
    ScrollToBottom,
    JumpToUser(JumpTarget),

    // -- Folding --
    /// Fold or unfold one tool row, by tool call id.
    ToggleRow(String),
    /// Unfold every tool row, or fold them all if none is folded.
    ToggleExpandAll,

    // -- Focus --
    /// Focus the input textarea
    FocusInput,
    /// Focus the input textarea AND insert `ch` at the cursor. Used when the
    /// user pressed a printable character while the chat panel had it — the
    /// prior `FocusInput` alone silently dropped the keystroke that triggered
    /// the focus switch (the cursor moved into the textarea but no character
    /// appeared). The character is buffered into the action so the dispatch
    /// loop can insert it after `Focus::Input` is set.
    FocusInputWithChar(char),
    /// Focus the chat panel (for scrolling)
    FocusChat,

    // -- Overlays --
    /// Open the command palette
    OpenCommandPalette,
    /// Close any open overlay (palette, dialog)
    CloseOverlay,
    /// Move palette selection up
    PaletteUp,
    /// Move palette selection down
    PaletteDown,
    /// Confirm current palette selection
    PaletteConfirm,

    // -- Dialog response --
    /// Answer an `AskUser` dialog. Routed to `clarification.resolve` keyed by
    /// `session_key` (the reply routes by session, not by run).
    RespondToDialog {
        session_key: String,
        reply: String,
    },

    // -- Tool approval (Ask exec tier) --
    /// Resolve the pending tool-approval overlay by option index into
    /// `APPROVAL_DECISIONS` (0 = allow once, 1 = allow session, 2 = deny).
    ResolveApproval {
        index: usize,
    },
    LoadToolOutput {
        tool_call_id: String,
    },

    // -- Side question (`/btw`) --
    /// Esc in the side-question overlay: abort the side run when one is still
    /// answering, close the overlay when none is. Aborting names the
    /// **overlay's own** run id — the screen's `current_run` is the main run,
    /// or nothing, so `/stop`'s helper would stop the wrong thing (or refuse).
    BtwAbortOrClose,
    /// Copy the shown side answer as raw markdown.
    BtwCopy,

    // -- Session picker --
    /// Move session-picker selection up
    SessionPickerUp,
    /// Move session-picker selection down
    SessionPickerDown,
    /// Confirm the selected session and switch to it
    SessionPickerConfirm,

    // -- Agents overlay (`/agents`) --
    /// Move the agents-overlay selection up
    AgentsUp,
    /// Move the agents-overlay selection down
    AgentsDown,
    /// Open the highlighted agent's run view (fetches its child transcript)
    AgentsConfirm,
    /// Back out one level: detail → list, list → closed
    AgentsBack,

    // -- Provider / model picker --
    /// Move provider-picker selection up
    ProviderPickerUp,
    /// Move provider-picker selection down
    ProviderPickerDown,
    /// Confirm the highlighted row: descend into a provider, or pin a model
    ProviderPickerConfirm,
    /// Ask the highlighted provider's vendor what it serves now, then re-read
    /// the catalogue so the discovered ids appear in its roster.
    ProviderPickerRefresh,
}

// ---------------------------------------------------------------------------
// Focus
// ---------------------------------------------------------------------------

/// Which UI panel currently has keyboard focus.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Focus {
    Input,
    Chat,
    CommandPalette,
    Dialog,
    SessionPicker,
    ProviderPicker,
    ThemePicker,
    Approval,
    /// The `/btw` side-question overlay.
    Btw,
    /// The `/agents` overlay (sub-agent list + per-agent run view).
    Agents,
    /// The `/context` overlay (measured prompt layout of the last turn).
    Context,
    ToolOutput,
}

// ---------------------------------------------------------------------------
// Transcript
// ---------------------------------------------------------------------------

#[cfg(test)]
use shared_ui_logic::transcript::RowBody;
/// The transcript is a flat, chronological list of
/// [`shared_ui_logic::transcript::TranscriptEntry`].
///
/// # What replaced what, and why the shape had to change
///
/// This crate used to hold `ChatMessage::{User, Assistant, System}` with the
/// turn's tool calls nested inside `Assistant { tools: Vec<ToolExecution> }`.
/// Nesting is what made interleaving impossible: a tool could only ever be
/// drawn with its assistant message, so every tool call in a turn rendered
/// above all of that turn's text no matter when it actually ran. Tool rows are
/// peers here, appended when they happen.
///
/// `ToolExecution` / `ToolStatus` are gone with it, replaced by the shared
/// `ToolRow` / `RowStatus` the Panel will paint from too. The one piece of
/// `ToolStatus` worth restating is its `Unknown`: live tool frames ride
/// `agent_trace`, which is best-effort (a lagging server-side receiver drops
/// frames), so a busy run can drop a `ToolCallCompleted`; `RunComplete` reconciles against
/// the authoritative `summary.tool_summaries`, and anything still `Running`
/// after that had no authoritative record either. That is now
/// `RowStatus::Pending` by way of [`ToolRow::settle_resumed`], which carries
/// the same rule — never a spinner that turns forever, never a fabricated
/// success.
///
/// `ToolExecution::progress` has no separate home: a progress line IS the body
/// of a running row, and the result replaces it on `finish`.
///
/// `RowStatus` is deliberately NOT re-exported here: nothing outside the tests
/// names it through this module, and a facade that lists a type no caller
/// reaches is the kind of always-true claim this repo pays for later. The
/// tests import it from `shared_ui_logic` like every other consumer does.
pub use shared_ui_logic::transcript::{ToolRow, TranscriptEntry, TuiAttachment};

/// Unix ms, for the entry timestamps the shared model carries as `Option<u64>`.
fn as_ms(t: DateTime<Utc>) -> Option<u64> {
    u64::try_from(t.timestamp_millis()).ok()
}

// ---------------------------------------------------------------------------
// Overlay state
// ---------------------------------------------------------------------------

/// State for the `AskUser` confirmation dialog.
///
/// # Why there is a text buffer here
///
/// The overlay used to render a menu and nothing else. A question with no
/// choices — `ask_user` accepts one, and free text is *always* a legal answer
/// even when choices are offered — arrived as an options list of length zero,
/// so `Enter` resolved `options.get(selected)` to `None` and did nothing, every
/// digit key fell through, and `Esc` is deliberately swallowed for this overlay
/// (the run is parked on a oneshot). The result was an unanswerable modal
/// holding the whole TUI: the ways out were Ctrl+C (cancel the run) and
/// Ctrl+C twice / Ctrl+D (quit) — abandoning the work was possible, answering
/// the question was not. A parking tool's client must be able to produce every
/// answer the server accepts.
#[derive(Debug, Clone)]
pub struct DialogState {
    /// Clarification registry key — the answer is posted back to
    /// `clarification.resolve` against this, NOT the run id (replies route by
    /// session). Carried on the `AskUser` frame.
    pub session_key: String,
    pub question: String,
    pub options: Vec<String>,
    pub selected: usize,
    /// Several picks are accepted, comma-separated.
    pub multi_select: bool,
    /// The answer is a credential: the buffer is rendered masked and never
    /// echoed. Purely a display property here — the transport rule that makes
    /// `secret` load-bearing is enforced server-side in `clarification::ask`,
    /// which is why a secret question can only ever reach this overlay.
    pub secret: bool,
    /// The typed answer, sent verbatim. Core's `interpret_reply` is the only
    /// interpreter, so a typed `2` and a pressed `2` are the same bytes.
    pub input: String,
    /// Keys go to [`Self::input`] rather than the menu.
    ///
    /// Structural at open time (see [`DialogState::has_quick_pick`]) and
    /// toggled by Tab afterwards, so it cannot be derived from
    /// `input.is_empty()`: clearing the buffer would silently drop a free-text
    /// question back into a menu it does not have.
    pub typing: bool,
}

impl DialogState {
    /// Whether one keypress can answer the question outright.
    ///
    /// Mirrors the server's own rule for suppressing an inline keyboard
    /// (`clarification::render::keyboard_for`): a single index cannot express a
    /// multi-select answer, so offering one would render a control that
    /// silently answers less than the question asks. Same predicate, so the
    /// terminal and a messaging channel cannot disagree about it.
    #[must_use]
    pub const fn has_quick_pick(&self) -> bool {
        !self.options.is_empty() && !self.multi_select
    }

    /// The reply `Enter` would send right now, if any.
    ///
    /// Driven by the mode, not by whether the buffer happens to be empty: a
    /// user who typed something and then tabbed back to the menu means the
    /// menu, and a blank buffer in text mode means "nothing to send yet"
    /// rather than "send the highlight".
    ///
    /// A pick sends the **1-based index**, not the label. Labels carry their
    /// `— description` suffix, and core's `interpret_reply` matches labels
    /// exactly, so a described choice sent by label arrives as free text with
    /// no selected index — the answer looks right to a human and is `custom`
    /// to the model. The index is also byte-identical to what the Panel and a
    /// channel's `clarify:<n>` button send, which keeps `interpret_reply` the
    /// single interpreter for all three surfaces.
    #[must_use]
    pub fn pending_reply(&self) -> Option<String> {
        if self.typing {
            let typed = self.input.trim();
            return (!typed.is_empty()).then(|| typed.to_string());
        }
        (self.selected < self.options.len()).then(|| (self.selected + 1).to_string())
    }
}

/// The question an `AskUser` frame is asking, flattened for the overlay.
///
/// A struct rather than four positional arguments because two of them are
/// adjacent bools: `show_dialog(key, q, opts, true, false)` reads identically
/// whichever way round the last two go, and one of them decides whether the
/// answer is masked.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AskDialogView {
    /// Prompt as rendered — position marker, header chip, and hint included.
    pub question: String,
    /// Choice labels, already carrying their `— description` suffix. Empty for
    /// a free-text question.
    pub options: Vec<String>,
    /// Several picks accepted.
    pub multi_select: bool,
    /// Mask the typed answer.
    pub secret: bool,
}

/// Every decision the overlay knows how to render, in display order. Each is
/// `(label, wire_decision)`; the wire value is exactly what
/// `exec.approval.resolve` expects (kebab-case, server-validated).
///
/// This is the vocabulary, **not** the offer: which of these a given card may
/// use is the server's call (`exec::allowed_decisions::for_confirm_gate`),
/// carried on the pending record and enforced when the answer comes back. See
/// [`ApprovalState::decisions`].
pub const APPROVAL_DECISIONS: [(&str, &str); 4] = [
    ("Allow once", "allow-once"),
    ("Allow for session", "allow-session"),
    ("Always allow", "allow-always"),
    ("Deny", "deny"),
];

/// What a card offers when the server did not say (a core older than
/// 2026-08-11). The historical three, and never `allow-always`: a missing
/// field may narrow what a client offers, never widen it.
pub const DEFAULT_APPROVAL_DECISIONS: [(&str, &str); 3] = [
    ("Allow once", "allow-once"),
    ("Allow for session", "allow-session"),
    ("Deny", "deny"),
];

/// The renderable decisions for a card, given the wire values the server said
/// it may offer. Unknown wire values are dropped (a client cannot render a
/// decision it has no label for), and an empty result falls back to
/// [`DEFAULT_APPROVAL_DECISIONS`] — a card with no buttons is unanswerable,
/// which is worse than a card with the historical ones.
#[must_use]
pub fn offered_decisions(allowed: &[String]) -> Vec<(&'static str, &'static str)> {
    let offered: Vec<(&'static str, &'static str)> = APPROVAL_DECISIONS
        .iter()
        .filter(|(_, wire)| allowed.iter().any(|a| a == wire))
        .copied()
        .collect();
    if offered.is_empty() {
        DEFAULT_APPROVAL_DECISIONS.to_vec()
    } else {
        offered
    }
}

/// State for the tool-execution approval overlay (Ask exec tier). A parked
/// server run is waiting on `exec.approval.resolve` for this `id`. Kept
/// deliberately separate from [`DialogState`] (AskUser) so a security decision
/// can never be routed to `clarification.resolve` (the AskUser answer path) by
/// mistake — approvals resolve through `exec.approval.resolve` alone.
#[derive(Debug, Clone)]
pub struct ApprovalState {
    /// Approval id — the resolve key. Never shown to the user.
    pub id: String,
    /// Human-readable action being gated (the tool/command summary).
    pub command: String,
    /// Why the gate fired, when the server supplied a reason.
    pub reason: Option<String>,
    /// Highlighted decision index into [`Self::decisions`].
    pub selected: usize,
    /// The decisions THIS card offers, in display order — from the record's
    /// `allowed_decisions`, not from a fixed list. A card raised on a tool that
    /// declares its own confirmation floor does not offer "always"; a member's
    /// card does not either. Rendering a fixed set would put a button in front
    /// of the user that the server narrows on arrival.
    pub decisions: Vec<(&'static str, &'static str)>,
}

/// State for the command palette overlay.
#[derive(Debug, Clone)]
pub struct PaletteState {
    pub input: String,
    /// The argument tail of `input` — everything after the first whitespace,
    /// when the part before it was enough to narrow the list on its own (see
    /// [`super::command_tree::split_palette_input`]).
    ///
    /// Resolved by `recompute_palette_filter` at the same moment as
    /// `filtered`, and read by the confirm path, so the two cannot disagree
    /// about whether a word was a search term or an argument.
    pub args: String,
    pub filtered: Vec<DisplayEntry>,
    pub selected: usize,
    /// Stack of namespace names we have browsed into (e.g. `["session"]`)
    pub namespace_stack: Vec<String>,
}

impl PaletteState {
    /// The command line to run for the current selection: the selected
    /// entry's `full_command`, plus whatever arguments the input carried.
    ///
    /// `None` when the filter matched nothing — confirming an empty list is a
    /// no-op, not a guess.
    #[must_use]
    pub fn selected_command(&self) -> Option<String> {
        let entry = self.filtered.get(self.selected)?;
        let command = entry.full_command.trim();
        Some(if self.args.is_empty() {
            command.to_string()
        } else {
            format!("{command} {}", self.args)
        })
    }
}

/// A single browsable session in the resume/switch picker.
#[derive(Debug, Clone)]
pub struct SessionEntry {
    /// The session key used by `chat.history` / to re-point the session.
    pub key: String,
    /// Human-facing label: the row's `topic` (or its `label`, or the key when
    /// it has neither), its message count, and — when the server says this
    /// conversation's newest run needs attention — a `[interrupted]` /
    /// `[log inconsistent]` mark. Built in one place,
    /// `commands::session_entry_from_json`, from the shared `SessionListRow`.
    pub label: String,
}

/// State for the session resume/switch picker overlay. Populated from
/// `sessions.list`; confirming an entry loads `chat.history` and switches.
#[derive(Debug, Clone)]
pub struct SessionPickerState {
    pub input: String,
    pub entries: Vec<SessionEntry>,
    /// Indices into `entries` surviving the current input filter.
    pub filtered: Vec<usize>,
    pub selected: usize,
}

/// State for the `/agents` overlay: a selectable list of this session's
/// sub-agents (pi-style "↑↓ select · enter view · esc back"), with an optional
/// drill-in detail showing one agent's own transcript.
#[derive(Debug, Clone)]
pub struct AgentsOverlayState {
    /// Index into [`agent_display_order`]'s row order.
    pub selected: usize,
    /// `Some` while showing one agent's run view; Esc drops back to the list.
    pub detail: Option<AgentDetailState>,
}

/// One agent's run view, loaded on Enter. (The child session key it was
/// fetched from is deliberately not retained — nothing re-reads it, and a
/// stored copy would be a zero-consumer field.)
#[derive(Debug, Clone)]
pub struct AgentDetailState {
    /// Header: the task the agent was spawned with.
    pub title: String,
    /// Pre-formatted transcript/metadata lines (the widget wraps them).
    pub lines: Vec<String>,
    /// Scroll offset in lines from the top.
    pub scroll: usize,
}

/// Display order for agent rows — running first (spawn order within each
/// group, id tiebreak). ONE derivation shared by the pinned panel, the overlay
/// list, and Enter's index resolution: selecting in one order and applying the
/// index in another names a different agent.
#[must_use]
pub fn agent_display_order(agents: &[SubagentNode]) -> Vec<&SubagentNode> {
    let mut rows: Vec<&SubagentNode> = agents.iter().collect();
    rows.sort_by(|a, b| {
        let rank = |n: &SubagentNode| u8::from(n.lifecycle != NodeLifecycle::Running);
        rank(a)
            .cmp(&rank(b))
            .then_with(|| a.started_at_ms.cmp(&b.started_at_ms))
            .then_with(|| a.node_id.cmp(&b.node_id))
    });
    rows
}

/// One row on screen in the provider picker.
///
/// Two levels share one list, the way the palette's namespace stack does: the
/// provider level offers rows to descend into, the model level offers ids to
/// pin.
///
/// `PartialEq` without `Eq`: a model row carries a [`RateCard`], and a price is
/// a float. Nothing here is a map key.
///
/// [`RateCard`]: aleph_protocol::providers::RateCard
#[derive(Debug, Clone, PartialEq)]
pub enum PickerRow {
    Provider {
        /// Index into [`ProviderPickerState::entries`].
        index: usize,
        /// How many of that provider's models the current filter matched. Equal
        /// to the roster length unless the row surfaced *because* a model id
        /// matched — the shared ranker narrows the roster in that case, and a
        /// provider found through one of its models should not then hide which.
        matched: usize,
    },
    Model {
        model: RosterModel,
    },
}

/// What confirming the highlighted row means.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ProviderPick {
    /// Descend into this provider's roster.
    Provider(usize),
    /// Pin this model id.
    Model(String),
}

/// Local theme choices and feedback kept outside the transcript.
#[derive(Debug, Clone)]
pub struct ThemePickerState {
    pub names: Vec<String>,
    pub selected: usize,
    pub diagnostics: Vec<String>,
    pub feedback: Option<String>,
}

/// State for the provider/model picker overlay (`/providers`).
///
/// Holds the rows `providers.catalog` returned, verbatim. This client never
/// re-derives a roster, re-ranks by cost or capability, or keeps a provider
/// table of its own (R4) — the merge behind `roster` includes an "operator
/// moved `base_url` ⇒ drop the curated rungs" rule a frontend has no way to
/// evaluate. Filtering goes through `aleph_protocol::providers::search`, the
/// same matcher the Panel's picker uses, so a bare Enter selects the same row
/// in both.
#[derive(Debug, Clone)]
pub struct ProviderPickerState {
    /// Filter text. Carried across a descent on purpose: the ranker searches
    /// provider ids, aliases, display names **and** model ids at both levels,
    /// so `gpt-5` → Enter lands on the gpt-5 rows rather than on a roster the
    /// user then has to re-narrow.
    pub input: String,
    /// The catalogue as the server sent it.
    pub entries: Vec<CatalogEntry>,
    /// Which provider we have descended into (index into `entries`), or `None`
    /// at the provider level.
    pub provider: Option<usize>,
    /// The rows on screen for `input` at the current level.
    pub rows: Vec<PickerRow>,
    pub selected: usize,
}

impl ProviderPickerState {
    /// The catalogue row Ctrl+R would act on, or `None` when there is none.
    ///
    /// Lives on the picker state, not on [`AppState`], so the footer that
    /// *advertises* the key and the handler that *performs* it resolve the row
    /// through one function. Two independent index walks — one in the widget,
    /// one in the command — would agree today and diverge the first time either
    /// level's row list changes shape.
    #[must_use]
    pub fn refresh_target(&self) -> Option<&CatalogEntry> {
        let index = match self.provider {
            Some(index) => index,
            None => match self.rows.get(self.selected)? {
                PickerRow::Provider { index, .. } => *index,
                // A model row at the provider level cannot happen (that level
                // only emits provider rows), but answering `None` is the
                // honest reading rather than an unwrap.
                PickerRow::Model { .. } => return None,
            },
        };
        self.entries.get(index)
    }
}

/// A catalogue row for tests, built from the contract type so a field rename
/// on the wire breaks every picker test at once rather than none of them.
///
/// Shared by the state tests here and the widget tests in
/// `widgets::provider_picker`; both need a whole `CatalogEntry` and neither
/// should be hand-writing twenty fields to get one.
#[cfg(test)]
#[must_use]
pub(crate) fn sample_catalog_entry(id: &str, models: &[&str]) -> CatalogEntry {
    use aleph_protocol::providers::{AuthKind, ModelSource};

    CatalogEntry {
        id: id.to_string(),
        display_name: id.to_uppercase(),
        default_model: models.first().copied().unwrap_or_default().to_string(),
        base_url: String::new(),
        protocol: "openai".to_string(),
        color: String::new(),
        homepage: None,
        notes: None,
        signup_url: None,
        aliases: Vec::new(),
        modalities: Vec::new(),
        models: Vec::new(),
        has_api_key: false,
        verified: false,
        enabled: false,
        is_default: false,
        auth_kind: AuthKind::ApiKey,
        endpoint: "cloud".to_string(),
        requires_explicit_model: false,
        discoverable: true,
        roster: models
            .iter()
            .map(|m| RosterModel::new(*m, ModelSource::PresetFallback))
            .collect(),
    }
}

/// Rank the catalogue for one level of the picker.
///
/// A free function so it is testable on its own, and so the two levels
/// provably share one matcher: the model level ranks a one-element slice, which
/// gives it the same rule the level above has — a query naming the provider
/// keeps the whole roster, a query naming a model narrows to it.
#[must_use]
pub fn provider_picker_rows(
    entries: &[CatalogEntry],
    provider: Option<usize>,
    query: &str,
) -> Vec<PickerRow> {
    match provider {
        None => rank_entries(entries, query)
            .into_iter()
            .map(|m| PickerRow::Provider {
                index: m.index,
                matched: m.models.len(),
            })
            .collect(),
        Some(index) => entries.get(index).map_or_else(Vec::new, |entry| {
            rank_entries(std::slice::from_ref(entry), query)
                .into_iter()
                .flat_map(|m| m.models)
                .map(|model| PickerRow::Model { model })
                .collect()
        }),
    }
}

// ---------------------------------------------------------------------------
// AppState
// ---------------------------------------------------------------------------

// There used to be a second `SessionKnob` enum here, naming the same four
// knobs the parser's `slash::SessionKnob` names, plus a four-arm identity
// mapping in `commands.rs` to get between them. Its doc argued that the status
// bar enumerates *this* list — it does not, and never did: it enumerates
// `slash::SessionKnob::ALL`. So the second enum had one producer (the
// mapping), one consumer (`record_local_knob`), and a comment that was the
// only place the split was justified (判据 §1 — the copy in the comment is the
// expensive one). Adding a fifth knob meant editing two closed sets, and
// forgetting one of them is silent in exactly one direction.
//
// It also stole `AppState`'s doc comment: the enum was inserted under the
// banner and the `///` lines above it came along, so the struct they describe
// has been undocumented ever since. They are back on it below.

/// The five session knobs as the status bar reads them. Borrowed from the
/// snapshot so the renderer cannot hold a stale copy across an attach.
///
/// The fifth (`model_pin`) is the model `select_model` pinned, if any —
/// NOT one of the four `slash::SessionKnob` variants (whose author is the
/// slash command), and intentionally so: a slash command patching the row
/// alone would be honored after a restart and silently ignored before one —
/// a second writer that wins by accident. The status bar reads it directly
/// from here rather than via `SessionKnob::ALL`, which is why the count on
/// that constant stays at four.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct SessionKnobs<'a> {
    pub mode: Option<&'a str>,
    pub exec_tier: Option<&'a str>,
    pub think_level: Option<&'a str>,
    pub memory_mode: Option<&'a str>,
    pub model_pin: Option<&'a str>,
}

/// The run `chat.history` reports in flight on the session being attached,
/// and how old the server says it is.
///
/// The age is `Option` inside a run that is `Some` because those are two
/// different questions with two different answers: "is a turn running here"
/// is answered by the session registry, "how long has it been running" by the
/// engine's run table, and a run can leave the second between the two reads —
/// or be executing in another process entirely. `None` there means "the
/// server did not tell me", which the join reads as *count from now*, never
/// as *it started now*.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ActiveRunJoin {
    pub run_id: String,
    /// Milliseconds the run had been going when the server answered, on the
    /// server's monotonic clock. A duration rather than a start stamp so no
    /// client has to reconcile its clock with the server's — see
    /// `ExecutionAdapter::run_elapsed_ms`.
    pub elapsed_ms: Option<u64>,
}

/// The agent panel's data, as [`AppState::runtime_agents`] holds it.
///
/// Deliberately not a bare `Vec<RuntimeAgentEntry>` and not a
/// `Result<Vec<_>, String>` either: the latter conflates "no answer yet"
/// with "an empty list", and a `runtime.agents.list` refusal is not an
/// absence — [`AgentPanelData::Refused`] and [`AgentPanelData::Ready`]
/// holding an empty `Vec` must render differently, or a non-operator's
/// screen looks identical to an operator's install with nothing running
/// (判据 §8: a refusal must not be read as "there is nothing").
#[derive(Debug, Clone)]
pub enum AgentPanelData {
    /// Asked (or about to be asked), no answer yet. NOT "no agents" — the
    /// initial state before the first `runtime.agents.list` reply, and
    /// while a re-fetch triggered by [`AppState::runtime_agents_refetch_due`]
    /// is in flight the field keeps its PREVIOUS value rather than reverting
    /// to this, so a change notification does not flash the panel to
    /// "loading" over data that is still valid.
    Loading,
    /// A `runtime.agents.list` reply. An empty `Vec` here really does mean
    /// "no agents running" — nothing upstream needs to guess.
    Ready(Vec<RuntimeAgentEntry>),
    /// The operator gate said no (`runtime.agents.list` returned
    /// [`aleph_protocol::jsonrpc::AUTH_REQUIRED`]) — distinguished from
    /// [`Self::Unavailable`] by the JSON-RPC error CODE, never by matching
    /// words in the message (P8).
    Refused(String),
    /// Every other failure: transport, timeout, decode. Not the operator
    /// gate specifically — see [`Self::Refused`].
    Unavailable(String),
}

/// Read a transcript row's RFC3339 stamp, falling back to now.
///
/// One parser for both producers of that stamp, and they are the same value:
/// `chat.history` serves `MessageRecord::rfc3339` and
/// `StreamEvent::SessionUserMessage` carries the stamp taken from the very same
/// record. A second reader here would be a second answer to "when did this row
/// happen" for one row.
///
/// Falling back to now rather than refusing the row: an unreadable stamp is a
/// cosmetic loss, and dropping a peer's message to protect a timestamp would
/// trade the thing being rendered for the caption under it.
pub(super) fn row_timestamp(raw: Option<&str>) -> DateTime<Utc> {
    raw.and_then(|s| DateTime::parse_from_rfc3339(s).ok())
        .map_or_else(Utc::now, |dt| dt.with_timezone(&Utc))
}

/// Central application state. Owned by the main loop, mutated through
/// methods that enforce invariants (e.g. the scroll/fold decisions).
#[derive(Debug)]
pub struct AppState {
    // -- Chat --
    pub messages: Transcript,
    /// Recovery is deferred while a run has no replay/live watermark.
    pub transcript_needs_resync: bool,
    /// Incremented on a session replacement to reject late hydration.
    pub transcript_generation: u64,
    /// Rows the viewport is above the bottom of the transcript. `0` is
    /// "parked at the bottom, following the stream".
    ///
    /// There is no companion `auto_scroll` flag: it used to exist and the
    /// window arithmetic proved it redundant — its `true` branch computed
    /// exactly what the offset branch computes at `0` (判据 §1, the weakened
    /// second copy). "Am I following?" is `scroll_offset == 0`, and
    /// `shared_ui_logic::state::chat_scroll` decides what may override it.
    pub scroll_offset: usize,
    /// Whether mouse capture is on, i.e. whether a click can reach this
    /// screen at all.
    ///
    /// Written once in `tui::run` before the first draw and never again: the
    /// rendered-line cache bakes the hint wording in, and a value that
    /// changed mid-session would leave every already-cached row advertising
    /// the affordance the terminal no longer has.
    pub mouse: bool,
    /// The clickable regions of the last painted frame — see
    /// `crate::tui::regions`.
    pub regions: crate::tui::regions::RegionTable,
    /// Rows landed below the reader while they were scrolled up.
    ///
    /// Set by `chat_scroll`'s `MarkUnseen`, cleared the moment the viewport
    /// returns to the bottom. Its only consumer is the docked back-to-bottom
    /// control's wording — a flag nothing renders would be a fact with no
    /// reader (判据 §17).
    pub unseen_below: bool,
    /// The previous observation of the transcript, for `chat_scroll`.
    prev_cursor: ListCursor,
    /// How many messages **this viewer** has sent in this conversation.
    ///
    /// Counted rather than derived from the transcript: in a shared project
    /// room a peer's message is a user row too, and "the number of user rows
    /// grew" would read their send as mine and yank my viewport to the bottom
    /// while I am reading back. `chat_scroll`'s module doc is the long form of
    /// this; the counter is the predicate it asks for, stated directly.
    sends: u64,

    // -- Input history --
    pub send_history: Vec<String>,
    pub history_index: Option<usize>,

    // -- Session / model --
    pub session_key: String,
    /// The model name to display. Seeded from the gateway's default provider at
    /// launch and replaced by the conversation's own model the moment a
    /// [`SessionSnapshot`] arrives — a thread pinned with `select_model` must
    /// not be captioned with the install-wide default it overrode.
    pub model_name: String,
    /// Fallback model caption: the gateway's default-provider model, kept so a
    /// snapshot that names no model (a conversation that has not run yet) can
    /// restore the caption instead of leaving whatever the previous session had.
    default_model_name: String,
    pub total_tokens: u64,
    /// The conversation's durable settings as the server last reported them
    /// (`chat.history`'s `session` object). `None` until the first attach — and
    /// `None` is read as "the server has not told me", never as "nothing is
    /// set": an unset knob and an unknown knob look identical to a user, but
    /// only one of them is safe to render as a concrete value.
    ///
    /// Stored whole rather than fanned out into sibling fields: the snapshot is
    /// one fact with one producer, and six copies of it are six chances for a
    /// `switch_session` to reset five of them.
    pub session_snapshot: Option<SessionSnapshot>,
    /// Priced spend on this conversation: the server's number at the last
    /// attach plus the runs watched since. See [`CostTally`] for why the base
    /// and the accumulator are one type.
    pub cost: CostTally,
    /// The git branch of [`Self::project_root`], as read from THIS machine's
    /// filesystem when that path resolves here — see
    /// `widgets::header::git_branch_of` for when it can be wrong and how it
    /// fails when it cannot answer.
    ///
    /// Computed once per attach rather than per frame: the header is painted
    /// twenty times a second and a `.git/HEAD` read per frame would be twenty
    /// syscalls a second for a string that changes when someone runs
    /// `git switch`.
    pub project_branch: Option<String>,
    /// Live context-window occupancy `(used_tokens, window_tokens)` from the
    /// latest `ContextGauge` event. `None` until the session's first gauge
    /// arrives. The pair always travels together (one event), so a single
    /// `Option` keeps the half-known state unrepresentable; the denominator is
    /// server-authoritative per model.
    pub context_gauge: Option<(u32, u32)>,
    /// Last-call prompt-cache hit rate as a rounded percentage (0–100), from
    /// the latest `ProviderUsage` trace event that reported cache activity,
    /// computed via `aleph_protocol::cache_hit_ratio` (`read / (input + read)`,
    /// the single canonical formula shared with core and the Panel Usage
    /// view). `None` until a call reports cache tokens — providers without
    /// prompt caching never surface a misleading 0%. Last-call (not
    /// cumulative) on purpose: a sudden drop is what tells you a prefix bust
    /// just happened.
    pub cache_stat: Option<u64>,
    /// Agent id behind `cache_stat` when it did *not* come from the session's
    /// root agent — sub-agents and MoA advisors are metered on the same trace
    /// stream, so a delegated cold start would otherwise silently overwrite
    /// the root agent's healthy reading with someone else's number. Rendered
    /// as a suffix so a mixed reading is labelled rather than misattributed.
    pub cache_stat_agent: Option<String>,
    /// First agent id observed since the session was (re)set. The root agent
    /// necessarily makes the first LLM call — it cannot delegate before it has
    /// taken a turn — so this identifies it without the TUI needing to know
    /// the run topology.
    cache_root_agent: Option<String>,
    pub is_connected: bool,
    /// This client's own principal id, fetched once at startup (`users.me`).
    ///
    /// Sole consumer is the `SessionUserMessage` arm: a room peer's message
    /// becomes a bubble here, the viewer's own does not. `None` means the
    /// question cannot be answered — an older gateway, a transport error, or a
    /// caller with no principal record — and disables the echo rather than
    /// guessing, because the only wrong guess renders the user's own message
    /// twice with nothing to clean it up.
    ///
    /// Deliberately NOT derived from `current_run`: the frame races the
    /// `chat.send` response that would teach this screen its own run id, so
    /// run ownership is unknown at exactly the moment it would be needed.
    /// Author identity is known before the send, not after it.
    pub my_user_id: Option<String>,

    /// `(run_id, session_key)` pairs learned from every `RunAccepted` this
    /// screen has observed, own or foreign. Every other run-scoped frame is
    /// checked against this before it is applied (see
    /// `events::run_scoped_id` and `frame_belongs_here`), which compares the
    /// recorded session against [`Self::session_key`] *at check time* — not
    /// baked in at learn time — so a run correctly resumes appearing here if
    /// a `/session` switch leaves and later returns to its actual session. A
    /// run id never recorded here is treated as "unknown", which counts as
    /// "kept", not "foreign": proof is required to drop, absence of proof is
    /// not.
    ///
    /// FIFO-bounded (`events::RUN_SESSION_CAP`) so a long-lived screen next
    /// to a busy install does not grow this without limit.
    run_sessions: std::collections::VecDeque<(String, String)>,

    /// Whether the server has told this screen which run (if any) is in flight
    /// on [`Self::session_key`].
    ///
    /// Set by `commands::attach_session` from `chat.history`'s `active_run`
    /// field; cleared by [`Self::switch_session`], whose caller re-attaches
    /// immediately after.
    ///
    /// It exists to make [`Self::frame_belongs_here`] able to say "not mine"
    /// about a run id it has never heard of. That answer used to be
    /// unavailable, so an unknown id was kept — and a client that STARTS while
    /// another terminal is mid-turn on a different session never sees that
    /// run's `RunAccepted` and therefore never learns it is foreign, so its
    /// reasoning, tool rows and answer stream into whatever conversation this
    /// screen is showing. Once the server has answered, the picture is
    /// complete: this session's in-flight run (if any) is known by name, and
    /// every run started on it afterwards announces itself with a
    /// `RunAccepted` this connection receives. Anything else is somebody
    /// else's.
    ///
    /// `false` until then, which reproduces the previous fail-open exactly —
    /// including against a core too old to send the field at all.
    session_reconciled: bool,

    // -- Run tracking --
    pub current_run: Option<String>,
    /// Start of the active run, on the monotonic clock. Set to now on
    /// `RunAccepted`; on [`AppState::adopt_active_run`] it is BACK-DATED by the
    /// age the server reported, so joining a turn already minutes deep reports
    /// that turn's age and not this screen's attachment. Cleared on any
    /// run-end. Drives the status-bar working indicator's elapsed timer.
    pub run_started_at: Option<Instant>,
    pub current_run_uses_agent_trace: bool,
    pub current_run_trace_summary_applied: bool,
    /// True while [`Self::load_trace_replay`] is projecting a persisted trace
    /// onto the live state. The summary-side arms of `apply_agent_trace_event`
    /// (`SessionCompleted` / `ProviderUsage`) check this so the replay's
    /// finished-run accounting does not bleed into the current session's
    /// status-bar counters — a passive replay must not move the tokens/cache
    /// numbers the user is looking at.
    pub replaying_trace: bool,
    /// Bytes of the current turn's assistant text already appended by
    /// `ResponseChunk` deltas.
    ///
    /// A streaming turn produces the same text TWICE on the wire: as
    /// `ResponseChunk` deltas and again, in full, as
    /// `AgentTrace{TextEmitted{Final}}` (`harness/agent/think.rs` emits the
    /// latter unconditionally — its `response_was_streamed` guard only
    /// suppresses a second in-process `on_delta`). The TUI subscribes to no
    /// topics, so the gateway's `should_receive` gives it both. Appending both
    /// doubled the answer inside one bubble.
    ///
    /// Reset per turn (`TurnStarted`) and per run (`RunAccepted`); the final
    /// text appends only its un-streamed suffix, so a non-streamed turn (mock
    /// provider, output guardrail) still lands in full.
    pub turn_streamed_len: usize,

    /// Has THIS run put any assistant text on screen yet?
    ///
    /// Set by [`AppState::append_assistant_content`] — the one place either
    /// carrier (`ResponseChunk` deltas, `AgentTrace{TextEmitted{Final}}`)
    /// reaches the transcript — and cleared on `RunAccepted`.
    ///
    /// It exists because `RunComplete` carries `summary.final_response`, which
    /// `reply_emitter/extract.rs` calls the run's authoritative terminal
    /// answer, and for an ordinary streamed turn that field is a duplicate of
    /// what is already rendered. For a run that produced no text at all it is
    /// the ONLY copy, and the TUI used to drop it: a `/btw promote` — served
    /// by the gateway without a model, so no chunk and no trace ever
    /// arrives — showed a spinner and then nothing, for the success receipt
    /// and the "nothing to promote" receipt alike, while the failure receipt
    /// (`RunError`) spoke. This is the general repair rather than a promote
    /// special case: any served-not-run branch added later inherits it.
    ///
    /// A per-run flag rather than "is the last assistant bubble empty":
    /// a run that appended nothing leaves the previous turn's bubble as the
    /// last one, so that question answers about the wrong turn.
    pub run_rendered_assistant_text: bool,

    // -- Settings --
    pub detail: DetailLevel,
    pub step_overrides: HashSet<String>,
    pub verbose: bool,
    pub tool_progress_mode: ToolProgressMode,

    // -- Gateway commands (fetched at startup, tree-structured) --
    pub gateway_commands: Vec<CommandEntry>,

    // -- Tasks + agents visualization --
    /// The conversation's live execution list (pi-style tasks block). Fed by
    /// three carriers, all pre-existing: cold `chat.history.plan`, live
    /// `scratchpad` tool results (`ScratchpadOutput.snapshot`), and the
    /// authoritative `RunSummary.plan` at run end.
    pub plan: Option<PlanSnapshot>,
    /// `/todo` toggle for the pinned tasks panel. Defaults on; the panel only
    /// occupies rows while a plan with content exists.
    pub tasks_panel_visible: bool,
    /// Flat sub-agent nodes for THIS session — cold `subagent.tree` snapshot
    /// merged with live `run.subagent_tree` deltas via the shared protocol
    /// `apply_event` (the same algorithm the Panel runs).
    pub agents: Vec<SubagentNode>,
    /// The `/agents` overlay, when open.
    pub agents_overlay: Option<AgentsOverlayState>,
    /// The `/context` overlay, when open: one `context.breakdown` snapshot
    /// reconciled against the gauge. Not refreshed while it is up — see
    /// [`ContextView`].
    pub context_overlay: Option<ContextView>,

    // -- UI state --
    pub focus: Focus,
    /// Live transcript pane geometry, written by render.rs as the single
    /// source of selection coordinates.
    pub text_selection_area: Rect,
    pub dialog: Option<DialogState>,
    pub palette: Option<PaletteState>,
    pub session_picker: Option<SessionPickerState>,
    /// Provider/model picker overlay (`/providers`), populated from
    /// `providers.catalog`.
    pub provider_picker: Option<ProviderPickerState>,
    pub theme_picker: Option<ThemePickerState>,
    /// Pending tool-approval overlay (Ask exec tier), if one is being shown.
    /// Surfaced by the `exec.approvals.pending` poll, resolved via
    /// `exec.approval.resolve`.
    pub approval: Option<ApprovalState>,
    pub interaction: InteractionController,
    pub tool_output: Option<ToolOutputView>,
    pub sticky_user: StickyUserState,
    /// The `/btw` side-question overlay.
    ///
    /// Not an `Option` like its siblings: its history outlives any one
    /// showing (closing it hides it, the next `/btw` reopens onto what was
    /// already asked), and its run claims have to answer `accepts_frame` for
    /// frames that arrive after the user closed it. `BtwOverlay::open` says
    /// whether it is on screen.
    pub btw: BtwOverlay,

    // -- Control --
    pub ctrl_c_count: u8,
    pub spinner_frame: usize,
    pub should_quit: bool,

    /// Per-message rendered-line cache for the chat area — see
    /// `widgets::chat_area::LineCache`. Not part of any serialized/exported
    /// state; purely a render-time optimization.
    pub chat_line_cache: crate::tui::widgets::chat_area::LineCache,

    /// The agent panel's data (Task 8b renders it; Task 8a wires it).
    /// Populated by a startup fetch and re-fetched on every
    /// `runtime.agents.changed` topic event — see [`AgentPanelData`].
    pub runtime_agents: AgentPanelData,
    /// Whether the agent-panel column is shown in the sidebar.
    ///
    /// Starts `false`: this is a new, opt-in surface, not a replacement for
    /// any existing screen real estate — `/agentpanel`
    /// (`LocalCommand::AgentPanel`) flips it. The SOLE visibility gate `render.rs`'s layout reads; when
    /// `false` the layout takes the exact path it took before this column
    /// existed (R8-9 — no horizontal split, not even one with a nominally
    /// zero-width chunk).
    ///
    /// Deliberately NOT `shared_ui_logic::state::agent_panel::AgentPanelState`
    /// (or its `collapsed` field): that struct's `split_ratio` is the
    /// Panel's draggable-divider ratio (R7-2 names Task 9's drag handle as
    /// its driver), and R8-0 scopes drag-to-resize to the Panel only this
    /// phase — the TUI has no divider to drive it, so holding that struct
    /// here would be a field with no writer. A plain `bool` is the whole of
    /// what this screen's toggle needs.
    pub agent_panel_visible: bool,
    /// Set by [`AppState::handle_topic_event`], cleared by the main loop once
    /// it has performed the re-fetch.
    ///
    /// STATE, not an `Action` — the main loop's gateway-event branch keeps
    /// only the LAST non-`None` action out of a drained burst (see its own
    /// comment at `mod.rs`'s `select!` arm), so an `Action` that named "go
    /// re-fetch the agent table" could be silently overwritten by a later
    /// frame in the same burst and never happen — and `runtime.agents.changed`
    /// fires exactly when `stream.*` chunks are also flying, so that burst is
    /// not a rare shape. A `bool` on `AppState` cannot be coalesced away by a
    /// later frame the way a returned `Action` could: the main loop checks and
    /// clears it itself, once per iteration, after the `select!` — see
    /// `mod.rs::main_loop`.
    pub runtime_agents_refetch_due: bool,
    /// Browser-live resources the Gateway has published to this screen
    /// (`browser.live.resource` / `browser.live.closed`). A mirror of wire
    /// facts only - see [`BrowserResourceCatalog`]. Nothing here opens a
    /// viewer; that needs an explicit `issue_browser_viewer_launch` call.
    pub browser_resources: BrowserResourceCatalog,
    /// How `/browser` may launch a viewer. Disabled by default; `tui::run`
    /// fills it once from the explicit `ALEPH_VIEWER_*` environment opt-in.
    /// Plain data (no URL, no secret) - the launch URL only ever lives inside
    /// the one `/browser` handler call that received it from the Gateway.
    pub viewer_launcher_config: crate::viewer_launcher::ViewerLauncherConfig,
}

impl AppState {
    /// Create an `AppState` on an empty transcript.
    ///
    /// There is no welcome entry any more. It used to open every session with
    /// `Welcome to Aleph CLI. Session: … | Model: … Type /help for commands.`,
    /// and B6 took all three of its facts away from it: the model and the
    /// folder are the header line (`widgets::header`, derived per frame from
    /// this state, so a `/session` switch moves them), the session key is on
    /// the status bar, and `/help` is on the hint line. Keeping the entry
    /// would have made it the stale second copy of each (判据 §1) — it is a
    /// frozen string, and the model it names is only correct until the first
    /// snapshot arrives.
    pub fn new(session_key: String, model_name: String) -> Self {
        Self {
            messages: Transcript::new(),
            transcript_needs_resync: false,
            transcript_generation: 0,
            scroll_offset: 0,
            mouse: false,
            regions: crate::tui::regions::RegionTable::default(),
            unseen_below: false,
            prev_cursor: ListCursor::default(),
            sends: 0,

            send_history: Vec::new(),
            history_index: None,

            interaction: InteractionController::new(session_key.clone()),
            tool_output: None,
            sticky_user: StickyUserState::default(),
            session_key,
            default_model_name: model_name.clone(),
            model_name,
            total_tokens: 0,
            session_snapshot: None,
            cost: CostTally::default(),
            project_branch: None,
            context_gauge: None,
            cache_stat: None,
            cache_stat_agent: None,
            cache_root_agent: None,
            is_connected: true,
            my_user_id: None,
            run_sessions: std::collections::VecDeque::new(),
            session_reconciled: false,

            current_run: None,
            run_started_at: None,
            current_run_uses_agent_trace: false,
            replaying_trace: false,
            turn_streamed_len: 0,
            run_rendered_assistant_text: false,
            current_run_trace_summary_applied: false,

            detail: detail_setting::boot(),
            step_overrides: HashSet::new(),
            verbose: false,
            tool_progress_mode: ToolProgressMode::default(),
            gateway_commands: Vec::new(),

            plan: None,
            tasks_panel_visible: true,
            agents: Vec::new(),
            agents_overlay: None,
            context_overlay: None,

            focus: Focus::Input,
            text_selection_area: Rect::default(),
            dialog: None,
            palette: None,
            session_picker: None,
            provider_picker: None,
            theme_picker: None,
            approval: None,
            btw: BtwOverlay::default(),

            ctrl_c_count: 0,
            spinner_frame: 0,
            should_quit: false,

            chat_line_cache: crate::tui::widgets::chat_area::LineCache::default(),

            runtime_agents: AgentPanelData::Loading,
            agent_panel_visible: false,
            runtime_agents_refetch_due: false,
            browser_resources: BrowserResourceCatalog::new(),
            viewer_launcher_config: crate::viewer_launcher::ViewerLauncherConfig::default(),
        }
    }

    // -- Message helpers ------------------------------------------------

    /// Wall clock in unix ms, the unit every shared transcript stamp uses.
    ///
    /// `ToolRow` timestamps are durations-in-waiting: `start` records one and
    /// `finish` is handed the pair, so the two must come from the same clock.
    /// A pre-1970 clock (or one far enough forward to overflow) yields 0
    /// rather than a panic — a zero duration is wrong, a crashed TUI is worse,
    /// and `fmt_duration_ms` renders it as `0.0s` rather than inventing one.
    pub(super) fn now_ms(&self) -> u64 {
        u64::try_from(Utc::now().timestamp_millis()).unwrap_or(0)
    }

    /// A fresh id for a text entry. Tool rows use their `tool_call_id`
    /// instead, which is what [`Self::find_tool_mut`] addresses them by.
    pub(super) fn next_entry_id(&mut self) -> String {
        self.messages.local_id()
    }

    /// Add a message **this viewer** just sent to the chat history.
    ///
    /// Bumps `sends`, which is the whole reason this is not the same function
    /// as the peer path: a room peer's message is a user row too, and only
    /// one of the two means "I am done reading back".
    ///
    /// `attachments` is the list of files the user dropped onto this send.
    /// Every existing caller passes `vec![]` — the TUI's composer pipeline
    /// does not yet ship attachments — but the slot is wired in so the chip
    /// render is already correct on the moment a real attachment pipeline
    /// lands.
    pub fn add_user_message(&mut self, content: String, attachments: Vec<TuiAttachment>) {
        self.messages
            .push_user(&content, as_ms(Utc::now()), attachments);
        self.transcript_generation = self.transcript_generation.wrapping_add(1);
        self.sends = self.sends.saturating_add(1);
    }

    /// Add a system message to the chat history.
    pub fn add_system_message(&mut self, content: String) {
        let id = self.next_entry_id();
        self.messages
            .import_legacy(TranscriptEntry::SystemNotice { id, text: content });
        self.transcript_generation = self.transcript_generation.wrapping_add(1);
    }

    /// Ensure the **last** entry is assistant text, appending an empty one if
    /// it is not.
    ///
    /// "Last", not "last assistant entry anywhere": that distinction is the
    /// whole interleaving change. Text, then a tool, then more text has to
    /// become three entries in that order — resuming the pre-tool block would
    /// put the second half of the turn above the tool that produced it.
    #[cfg(test)]
    pub fn ensure_assistant_message(&mut self) {
        if !matches!(
            self.messages.last(),
            Some(TranscriptEntry::AssistantText { .. })
        ) {
            let id = self.next_entry_id();
            self.messages.push(TranscriptEntry::AssistantText {
                id,
                markdown: String::new(),
                streaming: true,
            });
        }
    }

    /// The trailing assistant-text entry, created if the tail is something
    /// else.
    #[cfg(test)]
    pub fn current_assistant_mut(&mut self) -> &mut TranscriptEntry {
        self.ensure_assistant_message();
        let idx = self.messages.len().saturating_sub(1);
        &mut self.messages[idx]
    }

    #[cfg(test)]
    pub fn append_assistant_content(&mut self, content: &str) {
        if let TranscriptEntry::AssistantText { markdown, .. } = self.current_assistant_mut() {
            markdown.push_str(content);
        }
    }

    #[cfg(test)]
    pub fn start_tool_execution(&mut self, id: String, tool: String, args: &serde_json::Value) {
        let mut row = ToolRow::new(id, tool, args);
        row.start(self.now_ms());
        self.messages.import_legacy(TranscriptEntry::Tool(row));
    }

    /// The name a tool row learned at its start frame, when the row exists.
    /// Read-only sibling of [`Self::find_tool_mut`], for consumers that need
    /// to identify a tool from a frame that carries only its id (`ToolEnd`).
    pub(super) fn tool_name_of(&self, tool_id: &str) -> Option<String> {
        self.messages.iter().rev().find_map(|m| match m {
            TranscriptEntry::Tool(row) if row.id == tool_id => Some(row.tool.clone()),
            TranscriptEntry::Step(step) => step
                .tools
                .iter()
                .find(|row| row.id == tool_id)
                .map(|row| row.tool.clone()),
            _ => None,
        })
    }

    /// Find a tool row by `tool_call_id`, newest first.
    ///
    /// Scans the whole transcript rather than one message's tool list: rows are
    /// peers now, and a late `ToolEnd` for a call from an earlier turn still
    /// has to land on its own row instead of silently no-opping.
    pub fn find_tool_mut(&mut self, tool_id: &str) -> Option<&mut ToolRow> {
        self.messages.iter_mut().rev().find_map(|m| match m {
            TranscriptEntry::Tool(row) if row.id == tool_id => Some(row),
            TranscriptEntry::Step(step) => step.find_tool_mut(tool_id),
            _ => None,
        })
    }

    /// Invalidate only changed reducer entries. A missing live frame is a
    /// recovery request, not permission to splice persisted data into it.
    pub(super) fn observe_transcript_changes(&mut self, changes: &[Change]) {
        if changes.iter().any(|c| matches!(c, Change::NeedsResync)) {
            self.transcript_needs_resync = true;
        }
        self.chat_line_cache
            .invalidate_changes(changes, &self.messages);
    }

    /// Apply an off-screen completed-history build only to its originating
    /// session and generation. Callers fetch history and trace in background.
    pub fn apply_completed_hydration(&mut self, result: HydrationResult) -> bool {
        if !result.matches(&self.session_key, self.transcript_generation)
            || self.current_run.is_some()
        {
            return false;
        }
        self.sticky_user.clear();
        self.messages = result.transcript;
        self.transcript_needs_resync = false;
        if result.recovery != RecoveryState::Complete {
            self.add_system_message("Showing available history; some recorded steps are unavailable. Reconnect to refresh.".into());
        }
        self.step_overrides.clear();
        self.invalidate_rendered_lines();
        true
    }

    // -- Scrolling ------------------------------------------------------

    /// Scroll up by `n` lines, which by definition stops following the bottom.
    ///
    /// The offset is not clamped here: this function does not know the
    /// transcript's height, which depends on the width it will be painted at.
    /// `render_chat_area` clamps it against the real total every frame, so a
    /// `Home` (`usize::MAX / 2`) becomes a reachable offset before anything
    /// reads it again.
    pub fn scroll_up(&mut self, n: usize) {
        self.sticky_user.clear();
        self.scroll_offset = self.scroll_offset.saturating_add(n);
    }

    /// Scroll down by `n` lines; reaching `0` resumes following the bottom.
    pub fn scroll_down(&mut self, n: usize) {
        self.sticky_user.clear();
        self.scroll_offset = self.scroll_offset.saturating_sub(n);
    }

    /// Jump to the bottom of the chat and resume following it.
    pub fn scroll_to_bottom(&mut self) {
        self.sticky_user.clear();
        self.scroll_offset = 0;
        self.unseen_below = false;
    }

    /// Is the reader parked at the bottom, following the stream?
    #[must_use]
    pub const fn stuck_to_bottom(&self) -> bool {
        self.scroll_offset == 0
    }

    /// This observation of the transcript, as `chat_scroll` reads it.
    ///
    /// `conv` is a hash of the session key rather than a counter bumped at
    /// every switch site, because a counter would be one more thing to
    /// remember at each of them and the failure would be silent (判据 §6:
    /// the direction you miscount in is always "one fewer"). Only equality is
    /// ever asked of it. The empty key a fresh client starts with hashes to
    /// its own value and is replaced once the gateway names the conversation,
    /// which reads as a switch — correct, and in any case simultaneous with
    /// the send that caused it.
    fn list_cursor(&self) -> ListCursor {
        use std::hash::{Hash, Hasher};
        let mut h = std::collections::hash_map::DefaultHasher::new();
        self.session_key.hash(&mut h);
        ListCursor {
            conv: Some(h.finish()),
            sends: self.sends,
            rows: self.messages.len(),
        }
    }

    /// Apply the shared scroll decision for whatever changed since the last
    /// call.
    ///
    /// Called once per main-loop iteration rather than at each of the
    /// eighteen places that used to return `ScrollToBottomIfAutoScroll`: the
    /// rule is one fact about the transcript, and eighteen call sites is
    /// eighteen chances for a new event to forget it (判据 §12). It also
    /// buys the case the old shape could not express — the viewer sending
    /// while scrolled up, whose answer used to stream in off-screen.
    pub fn settle_scroll(&mut self) {
        let next = self.list_cursor();
        match scroll_action(self.prev_cursor, next, self.stuck_to_bottom()) {
            ScrollAction::PinToBottom => self.scroll_to_bottom(),
            ScrollAction::MarkUnseen => self.unseen_below = true,
            ScrollAction::Leave => {}
        }
        self.prev_cursor = next;
    }

    // -- Folding --------------------------------------------------------

    /// Fold or unfold one tool row.
    ///
    /// Nested tool rows share a Step cache entry: invalidate it explicitly
    /// after a toggle rather than waiting for a full-body fingerprint.
    pub fn toggle_tool_expanded(&mut self, tool_id: &str) {
        if self
            .messages
            .iter()
            .any(|m| matches!(m, TranscriptEntry::Step(s) if s.id == tool_id))
        {
            if !self.step_overrides.insert(tool_id.to_owned()) {
                self.step_overrides.remove(tool_id);
            }
            self.chat_line_cache = crate::tui::widgets::chat_area::LineCache::default();
            return;
        }
        if let Some(row) = self.find_tool_mut(tool_id) {
            row.expanded = !row.expanded;
            self.invalidate_rendered_lines();
        }
    }

    /// Unfold every tool row, or fold every one if none is left folded.
    ///
    /// A bulk edit of the per-row flags rather than a second, sticky
    /// "expand everything" flag. Two holders of "is this row expanded" would
    /// be two answers to one question (判据 §1), and the row's own flag is
    /// the one the renderer and the click path already read. The visible
    /// consequence of choosing this way: a tool row that arrives *after* the
    /// keystroke arrives folded, wearing a hint that says `ctrl+o to expand`
    /// — which is true of it.
    pub fn toggle_expand_all(&mut self) {
        let any_folded = self.messages.iter().any(|m| match m {
            TranscriptEntry::Tool(row) => !row.expanded,
            TranscriptEntry::Step(step) => step.tools.iter().any(|row| !row.expanded),
            _ => false,
        });
        for message in self.messages.iter_mut() {
            match message {
                TranscriptEntry::Tool(row) => row.expanded = any_folded,
                TranscriptEntry::Step(step) => {
                    for row in &mut step.tools {
                        row.expanded = any_folded;
                    }
                }
                _ => {}
            }
        }
        self.invalidate_rendered_lines();
    }

    /// How a fold hint should word itself on this terminal.
    ///
    /// `Mouse` only once capture is actually on: a hint that says "click" on
    /// a terminal where nothing is listening for a click is a label for an
    /// affordance that does not exist (spec §8, 判据 §17).
    #[must_use]
    pub const fn modality(&self) -> Modality {
        if self.mouse {
            Modality::Mouse
        } else {
            crate::tui::widgets::tool_row::KEY_MODALITY
        }
    }

    // -- Overlays -------------------------------------------------------

    /// Return display entries for the current palette browse level.
    /// At root: local commands + gateway root entries.
    /// Inside a namespace: that namespace's children.
    pub fn palette_display_entries(&self, namespace_stack: &[String]) -> Vec<DisplayEntry> {
        if namespace_stack.is_empty() {
            // Root level: local commands + gateway root entries
            let mut entries: Vec<DisplayEntry> = super::slash::local_commands()
                .into_iter()
                .map(|(n, d)| DisplayEntry {
                    label: n.to_string(),
                    hint: d.to_string(),
                    is_namespace: false,
                    full_command: format!("{n} "),
                })
                .collect();
            entries.extend(CommandEntry::root_display_entries(&self.gateway_commands));
            entries
        } else {
            // Inside a namespace: drill down through the stack
            let mut current_entries = &self.gateway_commands;
            let mut found_ns: Option<&CommandEntry> = None;
            let empty: Vec<DisplayEntry> = Vec::new();

            for ns_name in namespace_stack {
                found_ns = current_entries
                    .iter()
                    .find(|e| e.is_namespace && e.name.eq_ignore_ascii_case(ns_name));
                if let Some(ns) = found_ns {
                    current_entries = &ns.children;
                } else {
                    return empty;
                }
            }

            found_ns.map_or_else(Vec::new, |ns| {
                let path = namespace_stack.join(" ");
                CommandEntry::namespace_display_entries(ns, &path)
            })
        }
    }

    /// Filter display entries by a prefix string (the palette input text).
    pub fn filter_display_entries(
        &self,
        namespace_stack: &[String],
        filter: &str,
    ) -> Vec<DisplayEntry> {
        let all = self.palette_display_entries(namespace_stack);
        if filter.is_empty() {
            return all;
        }
        let filter_lower = filter.to_lowercase();
        let mut matched: Vec<DisplayEntry> = all
            .into_iter()
            .filter(|e| {
                e.label.to_lowercase().contains(&filter_lower)
                    || e.hint.to_lowercase().contains(&filter_lower)
            })
            .collect();
        // Stable sort, so catalog order survives inside each rank — see
        // `command_tree::filter_rank` for why an exact name has to win.
        matched.sort_by_key(|e| super::command_tree::filter_rank(&e.label, filter));
        matched
    }

    /// Open the command palette, pre-populated with root-level commands.
    pub fn open_command_palette(&mut self) {
        let all = self.palette_display_entries(&[]);
        self.palette = Some(PaletteState {
            input: String::new(),
            args: String::new(),
            filtered: all,
            selected: 0,
            namespace_stack: Vec::new(),
        });
        self.focus = Focus::CommandPalette;
    }

    /// Enter a namespace in the palette, showing its children.
    pub fn palette_enter_namespace(&mut self, ns_name: &str) {
        // Build the new stack, then compute entries without holding a mutable borrow
        let new_stack = {
            let Some(palette) = &self.palette else {
                return;
            };
            let mut stack = palette.namespace_stack.clone();
            stack.push(ns_name.to_string());
            stack
        };
        let entries = self.palette_display_entries(&new_stack);
        if let Some(palette) = &mut self.palette {
            palette.namespace_stack = new_stack;
            palette.input.clear();
            // The args belong to the input that was just cleared; carrying
            // them into the namespace would attach a word the user typed at
            // one level to a command chosen at another.
            palette.args.clear();
            palette.selected = 0;
            palette.filtered = entries;
        }
    }

    /// Go back one level in the palette namespace stack.
    /// Returns true if we went back, false if already at root.
    pub fn palette_go_back(&mut self) -> bool {
        // Build the new stack, then compute entries without holding a mutable borrow
        let new_stack = {
            let Some(palette) = &self.palette else {
                return false;
            };
            if palette.namespace_stack.is_empty() {
                return false;
            }
            let mut stack = palette.namespace_stack.clone();
            stack.pop();
            stack
        };
        let entries = self.palette_display_entries(&new_stack);
        if let Some(palette) = &mut self.palette {
            palette.namespace_stack = new_stack;
            palette.input.clear();
            palette.selected = 0;
            palette.filtered = entries;
        }
        true
    }

    /// Where focus lands when a modal that was covering the screen goes away.
    ///
    /// Not unconditionally `Input`. The `/btw` overlay is the one surface that
    /// can still be **on screen** when another modal closes: a clarification
    /// or an approval card can open over it (both are raised by frames, not by
    /// keys, so neither needs the user to have left the overlay first), and
    /// answering one used to hand focus to the composer while the side
    /// question stayed painted over the transcript — visible, unreachable, and
    /// unclosable, because `Esc` at `Focus::Input` is a no-op and every key
    /// went to a textarea the user could not see.
    const fn focus_after_modal(&self) -> Focus {
        if self.btw.open {
            Focus::Btw
        } else {
            Focus::Input
        }
    }

    /// Close any open overlay (palette, dialog, session picker, provider
    /// picker, agents overlay, context overlay) and return focus to whatever
    /// is still on screen.
    pub fn close_overlay(&mut self) {
        match self.focus {
            Focus::Dialog => {
                self.interaction.hide_active();
                self.dialog = None;
            }
            Focus::Approval => return,
            Focus::ToolOutput => self.tool_output = None,
            Focus::CommandPalette => self.palette = None,
            Focus::SessionPicker => self.session_picker = None,
            Focus::ProviderPicker => self.provider_picker = None,
            Focus::ThemePicker => self.theme_picker = None,
            Focus::Agents => self.agents_overlay = None,
            Focus::Context => self.context_overlay = None,
            _ => {}
        }
        self.interaction.pause_for_picker(false);
        self.focus = self.focus_after_modal();
        self.sync_modal_focus();
    }

    pub fn displayed_interaction(&self) -> Option<ModalOwner> {
        if matches!(
            self.focus,
            Focus::CommandPalette
                | Focus::SessionPicker
                | Focus::ProviderPicker
                | Focus::ThemePicker
                | Focus::Agents
                | Focus::Context
                | Focus::ToolOutput
        ) {
            return None;
        }
        self.interaction
            .displayed_owner(self.approval.as_ref())
            .cloned()
    }

    pub fn sync_modal_focus(&mut self) {
        if matches!(
            self.focus,
            Focus::CommandPalette
                | Focus::SessionPicker
                | Focus::ProviderPicker
                | Focus::ThemePicker
                | Focus::Agents
                | Focus::Context
                | Focus::ToolOutput
        ) {
            return;
        }
        self.dialog = self.interaction.active_dialog().cloned();
        match self.interaction.displayed_owner(self.approval.as_ref()) {
            Some(ModalOwner::Clarification { .. }) => self.focus = Focus::Dialog,
            Some(ModalOwner::Approval { .. }) => self.focus = Focus::Approval,
            None if matches!(self.focus, Focus::Dialog | Focus::Approval) => {
                self.focus = self.focus_after_modal()
            }
            None => {}
        }
    }

    pub fn request_sticky_jump(&mut self, target: JumpTarget) {
        if self
            .messages
            .iter()
            .any(|e| matches!(e, TranscriptEntry::UserText { id, .. } if id == &target.entry_id))
        {
            self.sticky_user
                .jump(&target, &self.session_key, self.transcript_generation);
        }
    }

    pub fn jump_to_last_user(&mut self) {
        if let Some(id) = self.messages.iter().rev().find_map(|e| match e {
            TranscriptEntry::UserText { id, .. } => Some(id.clone()),
            _ => None,
        }) {
            self.sticky_user.jump_to_entry(&self.session_key, id);
        }
    }

    pub fn open_tool_output(&mut self, tool_call_id: String) {
        self.tool_output = Some(ToolOutputView::new(
            self.session_key.clone(),
            tool_call_id,
            self.transcript_generation,
        ));
        self.focus = Focus::ToolOutput;
    }

    // -- Tasks + agents -------------------------------------------------

    /// Apply one gateway topic notification. Unknown topics are ignored —
    /// this client consumes exactly the planes it renders.
    ///
    /// Two planes are understood today: `run.subagent_tree` (the agents
    /// panel/overlay) and `runtime.agents.changed` (the agent-panel sidebar).
    /// The latter records a re-fetch as STATE
    /// (`AppState::runtime_agents_refetch_due`), not an `Action` — see that
    /// field's own doc for why an `Action` here would be unsafe to coalesce
    /// away in the main loop's burst-drain.
    pub fn handle_topic_event(&mut self, topic: &str, data: serde_json::Value) {
        if topic == subagent_tree::TOPIC {
            if let Ok(ev) = serde_json::from_value::<subagent_tree::SubagentTreeEvent>(data) {
                self.apply_subagent_tree_event(ev);
            }
        } else if topic == aleph_protocol::runtime::RUNTIME_AGENTS_CHANGED_TOPIC {
            // Deliberately does NOT reset `self.runtime_agents` to `Loading`
            // here: the notification carries no agent data, only word that
            // the table changed, and clobbering still-valid data on every
            // notification would flash the panel to "loading" over data
            // that has not actually gone stale from the viewer's
            // perspective. The re-fetch this triggers replaces it once the
            // answer is in hand.
            self.runtime_agents_refetch_due = true;
        } else if topic == aleph_protocol::browser_live::RESOURCE_TOPIC
            || topic == aleph_protocol::browser_live::CLOSED_TOPIC
        {
            // Fail-closed inside the catalog: a malformed, stale or
            // post-close frame changes nothing. The outcome is not surfaced -
            // nothing renders this yet.
            let _ = self.browser_resources.apply_topic(topic, &data);
        }
    }

    /// Merge one `run.subagent_tree` event into this screen's flat node list.
    ///
    /// Events for OTHER sessions' trees are dropped here: the gateway scopes
    /// delivery by what this caller may see, not by which conversation this
    /// screen currently shows, so an operator with two busy sessions receives
    /// both trees on one socket.
    pub fn apply_subagent_tree_event(&mut self, ev: subagent_tree::SubagentTreeEvent) {
        let root = match &ev {
            subagent_tree::SubagentTreeEvent::Spawned { node } => node.root_session.as_str(),
            subagent_tree::SubagentTreeEvent::Progress { root_session, .. }
            | subagent_tree::SubagentTreeEvent::Settled { root_session, .. } => {
                root_session.as_str()
            }
        };
        if root != self.session_key {
            return;
        }
        subagent_tree::apply_event(&mut self.agents, ev);
    }

    /// How many of this session's sub-agents are still running (status bar).
    #[must_use]
    pub fn running_agent_count(&self) -> usize {
        self.agents
            .iter()
            .filter(|n| n.lifecycle == NodeLifecycle::Running)
            .count()
    }

    /// Live plan projection — a mutating `scratchpad` call attaches the full
    /// snapshot to its result (`ScratchpadOutput.snapshot`); mirror it the way
    /// the Panel's TodoPanel does. Only a parseable snapshot object updates
    /// state: absence means "this call carried none", never "clear" — the
    /// authoritative clear arrives as an EMPTY snapshot in `RunSummary.plan`
    /// at run end.
    pub(super) fn maybe_apply_plan_from_tool(
        &mut self,
        tool_name: &str,
        output: &serde_json::Value,
    ) {
        if tool_name != "scratchpad" || self.replaying_trace {
            return;
        }
        // The shared reader: on the real wire `output` is the tool's JSON as
        // a `Value::String`, so an `output.get("snapshot")` here was `None`
        // on every live frame and this projection only ever moved on a cold
        // `chat.history` attach (qa/agents_viz, 2026-09-02). Same reader as
        // the gateway's run-end latch and the Panel's Todo strip.
        if let Ok(Some(plan)) = aleph_protocol::plan::snapshot_from_tool_output(output) {
            self.plan = Some(plan);
        }
    }

    /// Open the `/context` overlay on a freshly fetched breakdown, reconciled
    /// against this session's live gauge.
    pub fn open_context_overlay(&mut self, breakdown: &aleph_protocol::ContextBreakdown) {
        self.context_overlay = Some(ContextView::new(breakdown, self.context_gauge));
        self.focus = Focus::Context;
    }

    /// Scroll the `/context` layer list. `delta` is in rows; the clamp is
    /// against the row count rather than the screen, because the widget is the
    /// only thing that knows how tall it got to be.
    pub fn context_scroll(&mut self, delta: isize) {
        let Some(view) = &mut self.context_overlay else {
            return;
        };
        let max = view.rows.rows.len().saturating_sub(1);
        view.scroll = view.scroll.saturating_add_signed(delta).min(max);
    }

    /// Open the `/agents` overlay in list mode.
    pub fn open_agents_overlay(&mut self) {
        self.agents_overlay = Some(AgentsOverlayState {
            selected: 0,
            detail: None,
        });
        self.focus = Focus::Agents;
    }

    /// The node currently highlighted in the agents overlay, resolved through
    /// the same [`agent_display_order`] the widget renders with.
    #[must_use]
    pub fn selected_agent(&self) -> Option<&SubagentNode> {
        let overlay = self.agents_overlay.as_ref()?;
        agent_display_order(&self.agents)
            .get(overlay.selected)
            .copied()
    }

    /// Esc in the agents overlay: detail → list, list → closed.
    pub fn agents_overlay_back(&mut self) {
        match self.agents_overlay.as_mut() {
            Some(overlay) if overlay.detail.is_some() => overlay.detail = None,
            _ => {
                self.agents_overlay = None;
                self.focus = self.focus_after_modal();
            }
        }
    }

    /// Scroll the agent detail view. Positive = down.
    pub fn agents_detail_scroll(&mut self, delta: isize) {
        if let Some(detail) = self.agents_overlay.as_mut().and_then(|o| o.detail.as_mut()) {
            let max = detail.lines.len().saturating_sub(1);
            let next = if delta.is_negative() {
                detail.scroll.saturating_sub(delta.unsigned_abs())
            } else {
                detail.scroll.saturating_add(delta.unsigned_abs())
            };
            detail.scroll = next.min(max);
        }
    }

    // -- Session picker -------------------------------------------------

    /// Open the session picker with entries fetched from `sessions.list`.
    pub fn open_session_picker(&mut self, entries: Vec<SessionEntry>) {
        let filtered = (0..entries.len()).collect();
        self.session_picker = Some(SessionPickerState {
            input: String::new(),
            entries,
            filtered,
            selected: 0,
        });
        self.focus = Focus::SessionPicker;
    }

    /// Recompute the session picker's filtered index list from its input text.
    pub fn recompute_session_filter(&mut self) {
        if let Some(picker) = &mut self.session_picker {
            let filter = picker.input.to_lowercase();
            picker.filtered = picker
                .entries
                .iter()
                .enumerate()
                .filter(|(_, e)| {
                    filter.is_empty()
                        || e.label.to_lowercase().contains(&filter)
                        || e.key.to_lowercase().contains(&filter)
                })
                .map(|(i, _)| i)
                .collect();
            picker.selected = 0;
        }
    }

    /// The session key currently highlighted in the picker, if any.
    pub fn selected_session_key(&self) -> Option<String> {
        let picker = self.session_picker.as_ref()?;
        let idx = *picker.filtered.get(picker.selected)?;
        picker.entries.get(idx).map(|e| e.key.clone())
    }

    // -- Provider / model picker ----------------------------------------

    /// Open the provider picker over the rows `providers.catalog` returned,
    /// pre-filtered by `query` (`/providers <query>`).
    /// Theme choices and feedback are local UI state, never transcript entries.
    pub fn open_theme_picker(&mut self, names: Vec<String>, diagnostics: Vec<String>) {
        let current = crate::tui::theme::current_theme_name();
        let selected = names.iter().position(|name| name == &current).unwrap_or(0);
        self.theme_picker = Some(ThemePickerState {
            names,
            selected,
            diagnostics,
            feedback: None,
        });
        self.interaction.pause_for_picker(true);
        self.focus = Focus::ThemePicker;
    }

    pub fn open_provider_picker(&mut self, entries: Vec<CatalogEntry>, query: String) {
        self.provider_picker = Some(ProviderPickerState {
            input: query,
            entries,
            provider: None,
            rows: Vec::new(),
            selected: 0,
        });
        self.recompute_provider_filter();
        self.focus = Focus::ProviderPicker;
    }

    /// Recompute the rows on screen from the current filter and level.
    pub fn recompute_provider_filter(&mut self) {
        let Some(picker) = &mut self.provider_picker else {
            return;
        };
        picker.rows = provider_picker_rows(&picker.entries, picker.provider, &picker.input);
        picker.selected = 0;
    }

    /// Descend into a provider's roster.
    pub fn enter_provider(&mut self, index: usize) {
        if let Some(picker) = &mut self.provider_picker {
            picker.provider = Some(index);
        }
        self.recompute_provider_filter();
    }

    /// Go back to the provider level. `false` when already there, so the caller
    /// can fall through to closing the overlay.
    pub fn provider_picker_go_back(&mut self) -> bool {
        let Some(picker) = &mut self.provider_picker else {
            return false;
        };
        if picker.provider.is_none() {
            return false;
        }
        picker.provider = None;
        self.recompute_provider_filter();
        true
    }

    /// The provider id a refresh would ask about, if any.
    ///
    /// At the model level that is the provider we descended into; at the
    /// provider level it is the highlighted row. `None` when nothing is
    /// highlighted — refreshing "whatever" is a guess, and this key dials a
    /// vendor.
    #[must_use]
    pub fn provider_picker_refresh_target(&self) -> Option<String> {
        Some(self.provider_picker.as_ref()?.refresh_target()?.id.clone())
    }

    /// Replace the catalogue behind the picker after a refetch.
    ///
    /// Re-resolves the descended-into provider **by id**, not by index: the
    /// server sorts and filters the catalogue, so a row's position is not a
    /// stable handle across two calls. Keeping the index would silently move
    /// the open roster to a different vendor. The filter text is preserved
    /// because the user is mid-search.
    pub fn replace_provider_catalog(&mut self, entries: Vec<CatalogEntry>) {
        let Some(picker) = &mut self.provider_picker else {
            return;
        };
        let open_id = picker
            .provider
            .and_then(|i| picker.entries.get(i))
            .map(|e| e.id.clone());
        // Also by id: the row under the cursor is the one the user just asked
        // about, and `recompute_provider_filter` resets the cursor to the top.
        // Refreshing a provider and then finding yourself looking at a
        // different one is the same class of surprise as the open roster
        // moving — just one level up.
        let cursor_id = match picker.rows.get(picker.selected) {
            Some(PickerRow::Provider { index, .. }) => {
                picker.entries.get(*index).map(|e| e.id.clone())
            }
            _ => None,
        };

        picker.provider = open_id.and_then(|id| entries.iter().position(|e| e.id == id));
        picker.entries = entries;
        self.recompute_provider_filter();

        let Some(picker) = &mut self.provider_picker else {
            return;
        };
        if let Some(id) = cursor_id {
            if let Some(row) = picker.rows.iter().position(|r| match r {
                PickerRow::Provider { index, .. } => {
                    picker.entries.get(*index).is_some_and(|e| e.id == id)
                }
                PickerRow::Model { .. } => false,
            }) {
                picker.selected = row;
            }
        }
    }

    /// What confirming the highlighted row means, if anything.
    ///
    /// `None` when the filter matched nothing — confirming an empty list is a
    /// no-op, not a guess about which provider was meant.
    #[must_use]
    pub fn selected_provider_pick(&self) -> Option<ProviderPick> {
        let picker = self.provider_picker.as_ref()?;
        match picker.rows.get(picker.selected)? {
            PickerRow::Provider { index, .. } => Some(ProviderPick::Provider(*index)),
            PickerRow::Model { model } => Some(ProviderPick::Model(model.id.clone())),
        }
    }

    /// Show an `AskUser` dialog. `session_key` is the clarification key the
    /// answer resolves against (`clarification.resolve`).
    ///
    /// The overlay opens in text mode whenever there is nothing to quick-pick,
    /// so the first keystroke on a free-text (or multi-select) question already
    /// goes where the user means it to.
    pub fn show_dialog(&mut self, session_key: String, view: AskDialogView) {
        self.interaction
            .offer_question(aleph_protocol::PendingClarification {
                session_key,
                request_id: String::new(),
                run_id: String::new(),
                question: view.question.clone(),
                options: view.options.clone(),
                answered: 0,
                questions: vec![aleph_protocol::AskUserQuestion {
                    id: "legacy".into(),
                    header: None,
                    prompt: view.question,
                    options: view
                        .options
                        .into_iter()
                        .map(|label| aleph_protocol::AskUserOption {
                            label,
                            description: None,
                        })
                        .collect(),
                    multi_select: view.multi_select,
                    secret: view.secret,
                }],
            });
        self.sync_modal_focus();
    }

    /// Surface the tool-approval overlay for a pending, session-owned approval
    /// and steal focus so the parked run gets a decision. The caller
    /// (`commands::poll_approvals`) has already confirmed the `id` belongs to
    /// this session.
    pub fn open_approval(
        &mut self,
        id: String,
        command: String,
        reason: Option<String>,
        decisions: Vec<(&'static str, &'static str)>,
    ) {
        self.interaction
            .offer_approval(self.session_key.clone(), id.clone());
        self.approval = Some(ApprovalState {
            id,
            command,
            reason,
            selected: 0,
            decisions,
        });
        self.sync_modal_focus();
    }

    /// Show the side-question overlay for a `/btw` just sent, and give it
    /// focus.
    ///
    /// The purely local overlays are dismissed first — nothing on the server
    /// is parked on any of them. The two that ARE parked on something
    /// (`AskUser`, tool approval) are deliberately not touched, and cannot be
    /// showing anyway: both hold focus, so no `/btw` can have been typed
    /// while one was up.
    pub fn open_btw(&mut self, question: String) {
        self.palette = None;
        self.session_picker = None;
        self.provider_picker = None;
        self.theme_picker = None;
        self.btw.begin(question);
        self.focus = Focus::Btw;
    }

    /// Hide the side-question overlay and return focus to input. The history
    /// and the run claims survive — see [`BtwOverlay`]'s docs for why the
    /// claims must.
    pub fn close_btw(&mut self) {
        self.btw.close();
        self.focus = Focus::Input;
    }

    /// Retract the approval overlay (resolved here, resolved elsewhere, or the
    /// server-side approval expired) and return focus to input.
    pub fn close_approval(&mut self) {
        if let Some(card) = &self.approval {
            self.interaction
                .retire_approval(&self.session_key, &card.id);
        }
        self.approval = None;
        self.focus = self.focus_after_modal();
        self.sync_modal_focus();
    }

    /// Drop a showing approval overlay when its run ends by any path (complete,
    /// error, cancel, session-complete). No-op when none is showing, so focus is
    /// reset only in the case where the modal was actually up (and thus held
    /// focus). Needed because the pending-approval poll runs only while a run is
    /// active — once the run ends it can no longer retract a stale overlay.
    pub(crate) fn dismiss_pending_approval(&mut self) {
        if self.approval.is_some() {
            self.close_approval();
        }
    }

    /// Adopt the canonical session key the gateway reports on the `agent.run`
    /// result.
    ///
    /// The gateway is the only authority on what key a run was routed to: an
    /// explicit key that fails `SessionKey::parse` does not fail the call, it
    /// makes `AgentRouter::route` mint a fresh epoch instead. A client that
    /// keeps its own guess afterwards addresses a session that does not exist,
    /// and every keyed RPC it makes (`chat.history`, `session.usage`,
    /// `sessions.patch`, `session.compact`) answers about nothing.
    ///
    /// A no-op when the key is unchanged or empty, so the common path costs
    /// nothing and a server that omits the field cannot blank the key.
    pub fn adopt_canonical_session_key(&mut self, canonical: &str) {
        if canonical.is_empty() || canonical == self.session_key {
            return;
        }
        self.session_key = canonical.to_string();
        // The settings we hold describe the key we just replaced. Dropping them
        // makes the status bar say "unknown" until the next attach, which is
        // true; keeping them would make it confidently describe someone else's
        // conversation.
        self.session_snapshot = None;
        self.cost.rebase(None);
        self.project_branch = None;
    }

    /// Restore this conversation's durable settings from the server's snapshot.
    ///
    /// Called on attach (`chat.history`) and after a session switch. Everything
    /// here is read back, never invented: the cumulative token count comes from
    /// the `sessions` row rather than from this process's own tally, which is
    /// why reopening a terminal mid-task no longer restarts the counter at 0.
    pub fn apply_session_snapshot(&mut self, snapshot: SessionSnapshot) {
        self.session_key = snapshot.session_key.clone();
        self.total_tokens = u64::try_from(snapshot.total_tokens).unwrap_or(0);
        self.model_name = snapshot
            .effective_model()
            .map_or_else(|| self.default_model_name.clone(), str::to_string);
        // The snapshot already contains every run before it, including the
        // ones this screen watched — so this is a rebase, never an add.
        self.cost.rebase(Some(snapshot.estimated_cost_usd));
        // One filesystem read per attach, at the only point the folder can
        // change.
        self.project_branch = snapshot
            .project_root
            .as_deref()
            .and_then(crate::tui::widgets::header::git_branch_of);
        self.session_snapshot = Some(snapshot);
    }

    /// The folder this conversation is scoped to, as the SERVER reports it.
    ///
    /// `None` means the conversation is scoped to no folder — the agent runs
    /// in its own `~/.aleph/workspaces/{agent_id}`, a path this client is not
    /// told. It does NOT mean "use the terminal's own working directory":
    /// with a remote gateway that is a different machine's filesystem, and
    /// the header has no way to say which one it meant.
    #[must_use]
    pub fn project_root(&self) -> Option<&str> {
        self.session_snapshot
            .as_ref()
            .and_then(|s| s.project_root.as_deref())
    }

    /// What this conversation has cost, and how sure this screen is.
    #[must_use]
    pub fn cost_view(&self) -> CostView {
        self.cost.view()
    }

    /// The language the working verb is drawn in.
    ///
    /// Derived from the same environment reading `aleph_protocol::terminate`
    /// uses for halt notices, so one terminal does not get an English verb
    /// over a Chinese notice. The two enums naming En/Zh are a duplication in
    /// the shared crates, not something this screen can fix from here.
    #[must_use]
    pub fn locale(&self) -> shared_ui_logic::transcript::Locale {
        match aleph_protocol::terminate::UiLocale::from_env() {
            aleph_protocol::terminate::UiLocale::Zh => shared_ui_logic::transcript::Locale::Zh,
            aleph_protocol::terminate::UiLocale::En => shared_ui_logic::transcript::Locale::En,
        }
    }

    /// The conversation's usage mode, exec tier, thinking depth, memory mode,
    /// and pinned model as the status bar renders them.
    ///
    /// `None` in the tuple means the session follows the global default — the
    /// renderer prints nothing rather than guessing which default is live,
    /// because the TUI does not read the server's config and a guess would be
    /// indistinguishable from a fact. Same for `model_pin: None`: the
    /// conversation is not pinned, not "the pin got lost".
    #[must_use]
    pub fn session_knobs(&self) -> SessionKnobs<'_> {
        let snap = self.session_snapshot.as_ref();
        SessionKnobs {
            mode: snap.and_then(|s| s.mode.as_deref()),
            exec_tier: snap.and_then(|s| s.exec_tier.as_deref()),
            think_level: snap.and_then(|s| s.think_level.as_deref()),
            memory_mode: snap.and_then(|s| s.memory_mode.as_deref()),
            model_pin: snap.and_then(|s| s.model_pin.as_deref()),
        }
    }

    /// Locally record a knob the user just changed, so the status bar reflects
    /// it before the next attach re-reads it from the server.
    ///
    /// Only ever called after the write RPC returned `Ok` — an optimistic
    /// update on a refused write is exactly the "confident false answer" the
    /// snapshot exists to prevent. `field` selects which knob; the value is
    /// `None` for "follow global".
    pub fn record_local_knob(&mut self, field: SessionKnob, value: Option<String>) {
        let snap = self
            .session_snapshot
            .get_or_insert_with(|| SessionSnapshot {
                session_key: self.session_key.clone(),
                ..SessionSnapshot::default()
            });
        match field {
            SessionKnob::Mode => snap.mode = value,
            SessionKnob::ExecTier => snap.exec_tier = value,
            SessionKnob::Think => snap.think_level = value,
            SessionKnob::Memory => snap.memory_mode = value,
        }
    }

    /// The socket died: stop believing what this screen learned from it.
    ///
    /// Only [`Self::session_reconciled`] is dropped, and dropping it is the
    /// whole point. That bit means "the server has told THIS screen which run
    /// is in flight here" — and the server that told it is gone. Left set, it
    /// leaves [`Self::frame_belongs_here`] answering "not mine" about unknown
    /// run ids on the strength of a baseline taken from a connection that no
    /// longer exists, including about a run that STARTED while this client was
    /// offline and whose `RunAccepted` it therefore never saw. Cleared, the
    /// fallback returns to keeping what it cannot prove foreign, which is the
    /// honest posture for a screen that has been out of the room.
    ///
    /// `current_run` is deliberately NOT cleared. That turn is very likely
    /// still running; this client simply cannot hear it. Clearing it switches
    /// off the working indicator and reports the turn as over, which is the one
    /// thing this screen does not know.
    pub fn on_disconnected(&mut self) {
        self.is_connected = false;
        self.session_reconciled = false;
    }

    /// Reset what a reconnect makes uncertain, before re-attaching.
    ///
    /// The transcript is deliberately NOT touched here. It is replaced by
    /// `attach_session(.., AttachMode::Replace)`, inside that call's success
    /// branch and only once the server's copy has arrived — clearing first
    /// turns a `chat.history` that fails on a freshly-restored connection into
    /// a blank screen, which is worse than the stale transcript it replaced.
    ///
    /// What IS reset: the run this screen believed was in flight (the attach
    /// re-answers it from the server, and a stale id would otherwise survive a
    /// turn that ended while this client was away) and the reconciliation bit,
    /// so unknown run ids are kept until the server has spoken again.
    ///
    /// Unlike [`Self::switch_session`] this leaves the `/btw` overlay alone.
    /// The side thread belongs to the SAME conversation, which has not changed,
    /// and its derived key is still addressable server-side.
    pub fn begin_reattach(&mut self) {
        self.sticky_user.clear();
        self.tool_output = None;
        self.transcript_generation = self.transcript_generation.wrapping_add(1);
        self.transcript_needs_resync = true;
        self.current_run = None;
        self.run_started_at = None;
        self.current_run_uses_agent_trace = false;
        self.current_run_trace_summary_applied = false;
        self.turn_streamed_len = 0;
        self.run_rendered_assistant_text = false;
        self.session_reconciled = false;
    }

    /// Switch to a different session and reset transient chat/run UI state.
    /// The caller then appends the fetched `chat.history` transcript.
    pub fn switch_session(&mut self, session_key: &str) {
        self.sticky_user.clear();
        self.tool_output = None;
        self.session_key = session_key.to_string();
        self.interaction.set_context(
            self.session_key.clone(),
            self.transcript_generation.wrapping_add(1),
        );
        // Per-conversation facts, and this component is a singleton: a counter
        // that survives the switch reports the previous conversation's spend
        // under the new one's name. The caller restores the real figures from
        // the incoming snapshot immediately after.
        self.total_tokens = 0;
        self.session_snapshot = None;
        // Same argument, same sentence, for the money: an unrebased tally
        // would bill the outgoing conversation's spend to the incoming one.
        self.cost.rebase(None);
        self.project_branch = None;
        self.model_name.clone_from(&self.default_model_name);
        self.messages.reset();
        self.transcript_generation = self.transcript_generation.wrapping_add(1);
        self.transcript_needs_resync = false;
        self.step_overrides.clear();
        self.invalidate_rendered_lines();
        // The run left behind (if any) still belongs to the OLD session, and
        // nothing extra needs to be recorded for that here: its own
        // `RunAccepted` already taught `run_sessions` which session it is
        // home to (see that field's doc), so `frame_belongs_here` now
        // answers "no" for it against the new `self.session_key` above — and
        // "yes" again if a later switch returns to its actual session.
        self.current_run = None;
        self.run_started_at = None;
        self.current_run_uses_agent_trace = false;
        self.current_run_trace_summary_applied = false;
        // Nothing has been asked about the INCOMING session yet. The caller
        // attaches immediately after and sets this again; until it does,
        // `frame_belongs_here` falls back to keeping unknown run ids, which is
        // the safe direction while this screen genuinely cannot tell.
        self.session_reconciled = false;

        // Per-conversation surfaces: the outgoing conversation's execution
        // list and sub-agent tree must not caption the incoming one. The
        // attach that follows restores both (`chat.history.plan` +
        // `subagent.tree`).
        self.plan = None;
        self.agents.clear();
        self.agents_overlay = None;

        // The side thread belongs to the conversation we just left, and it is
        // cleared rather than kept per-conversation. Two reasons, and the
        // second is the decisive one:
        //
        // 1. This client has no per-conversation container to key it into.
        //    `AppState` holds exactly one of everything and `messages` is
        //    wiped outright above — the Panel's `SessionMap<ConvId, ChatState>`
        //    has no counterpart here. A map with one live entry, in a
        //    singleton, is an abstraction with no consumer (R10); it would
        //    also be the only per-conversation field in the struct, which is
        //    how the next reader gets it wrong.
        // 2. The side key is derived from the main key **including its
        //    epoch** (`gateway::btw::side_key_for`). A `/session` switch —
        //    and `/new` — therefore leaves the old side session unaddressable
        //    server-side. Keeping its exchanges pageable would display a
        //    thread that no longer exists anywhere but in this process, and
        //    offer `p`/follow-up keys that address the wrong conversation.
        //
        // The run CLAIMS are kept, and that is not an oversight — see
        // `BtwOverlay::clear_for_session_switch`. A side run whose
        // `RunAccepted` has not landed yet is unknown to `run_sessions`, and
        // an unknown run id is deliberately kept by `frame_belongs_here`, so
        // forgetting the claim would render that run's answer into the
        // conversation we just switched TO. (The run itself keeps going
        // server-side, exactly as the main run left behind does a few lines
        // up: this client does not cancel on switch, and making the side
        // question the one exception would be a surprise, not a fix.)
        self.btw.clear_for_session_switch();
        // The send-history belongs to the outgoing conversation: recalling
        // its lines after `/session` would surface prompts from a different
        // context. Clear both the buffer and the up/down cursor together —
        // a stale `history_index` left pointing into a freshly emptied vec
        // is read by `keys.rs` via `send_history.get(idx)`, which returns
        // None and the textarea silently loses the keystroke. Wiping the
        // index keeps the next Up arrow safe.
        self.send_history.clear();
        self.history_index = None;
        // New session = different context window; drop the stale gauge until
        // the next run's first `ContextGauge` refreshes it.
        self.context_gauge = None;
        // Same for the cache stat: the old session's hit% is meaningless for
        // a different prefix, and a cache-less provider would otherwise show
        // it indefinitely (the stat only updates on real cache activity).
        self.cache_stat = None;
        self.cache_stat_agent = None;
        // The next session's first reporting agent becomes its new root.
        self.cache_root_agent = None;
        self.dialog = None;
        self.palette = None;
        // The picker's rows describe the install, not the conversation, but the
        // pick it is mid-way through would land on the session we just left.
        self.provider_picker = None;
        self.theme_picker = None;
        // Any approval prompt belonged to the old session's run; drop it.
        self.approval = None;
        self.focus = Focus::Input;
        self.scroll_to_bottom();
        self.add_system_message(format!("Switched to session {session_key}"));
    }

    // -- Settings -------------------------------------------------------

    /// Toggle verbose/debug output mode.
    pub const fn toggle_verbose(&mut self) {
        self.verbose = !self.verbose;
    }

    /// Toggle the agent-panel column's visibility (`/agents`).
    pub const fn toggle_agent_panel(&mut self) {
        self.agent_panel_visible = !self.agent_panel_visible;
    }

    /// Throw away every rendered line, keeping the messages.
    ///
    /// Rendered `Line`s carry their `Style` — the colour is baked in at build
    /// time — so anything that changes what a colour MEANS has to drop the
    /// cache or the transcript keeps the old palette above the switch point
    /// and the new one below it. `/theme` is the only event that calls this;
    /// a width change already invalidates through the entry's own `width`,
    /// and the syntax highlighter finishing its background load through
    /// `highlight_generation`.
    pub fn invalidate_rendered_lines(&mut self) {
        self.chat_line_cache = crate::tui::widgets::chat_area::LineCache::default();
    }

    /// Restore the startup view without replacing the session or ending work.
    pub fn clear_screen(&mut self) {
        // Keep the reducer's active run and de-duplication cursors: a display
        // reset is neither a cancellation nor proof that a run has finished.
        self.messages.clear_display();
        self.transcript_generation = self.transcript_generation.wrapping_add(1);
        self.invalidate_rendered_lines();
        self.step_overrides.clear();
        self.scroll_to_bottom();
        self.prev_cursor = ListCursor::default();
        self.sends = 0;
        self.regions = crate::tui::regions::RegionTable::default();
        self.send_history.clear();
        self.history_index = None;
        self.ctrl_c_count = 0;
        self.palette = None;
        self.session_picker = None;
        self.provider_picker = None;
        self.theme_picker = None;
        self.agents_overlay = None;
        self.context_overlay = None;
        self.tool_output = None;
        self.agent_panel_visible = false;
        if self.current_run.is_none() {
            self.plan = None;
            self.agents.clear();
        }
        if self.btw.active.is_none() {
            // Retain side-run claims so late frames cannot leak into chat.
            self.btw.clear_for_session_switch();
        } else {
            // Keep a live side question addressable, including its abort path.
            self.btw.close();
            self.btw.composer.clear();
            self.btw.scroll = 0;
        }
        // Pending questions/approvals belong to real waiters. Do not retire
        // them to make the screen look idle; restore their existing focus.
        self.interaction.pause_for_picker(false);
        self.dialog = None;
        self.focus = Focus::Input;
        self.sync_modal_focus();
        // Welcome/header is derived from the empty transcript, not a notice.
    }

    /// Update token usage from a `RunSummary`.
    pub const fn update_token_usage(&mut self, summary: &RunSummary) {
        self.total_tokens = self.total_tokens.saturating_add(summary.total_tokens);
    }

    /// Append a sent message to the input history, capping the list so a long
    /// session cannot grow it without bound.
    pub fn push_send_history(&mut self, text: String) {
        const CAP: usize = 1_000;
        if self.send_history.len() >= CAP {
            self.send_history.remove(0);
            if let Some(idx) = self.history_index.as_mut() {
                *idx = idx.saturating_sub(1);
            }
        }
        self.send_history.push(text);
        self.history_index = None;
    }
}
