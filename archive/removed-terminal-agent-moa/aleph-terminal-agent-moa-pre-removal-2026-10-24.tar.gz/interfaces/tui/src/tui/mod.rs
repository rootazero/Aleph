// TUI module: full-screen terminal UI for interactive chat.
//
// Provides the main event loop that integrates terminal events (keyboard, resize),
// gateway events (streaming responses, tool updates), and a 50ms tick for spinner
// animation. Terminal-event routing lives in `keys.rs`, local slash-command
// execution in `commands.rs`, and all rendering in `render.rs`, which splits the
// layout into chat area, input area, status bar, and overlays.

mod app;
mod approval;
mod btw_overlay;
mod clipboard;
mod command_tree;
mod commands;
mod event;
mod gateway_error;
mod highlight;
mod interaction;
mod keys;
mod markdown;
mod regions;
mod render;
mod rpc_jobs;
mod slash;
mod text_selection;
pub mod theme;
mod tool_output;
mod widgets;

use std::future::Future;
use std::io;
#[cfg(windows)]
use std::io::Write;
use std::pin::Pin;
use std::time::Duration;

use crossterm::{
    event::{DisableBracketedPaste, DisableMouseCapture, EnableBracketedPaste, EnableMouseCapture},
    execute,
    terminal::{
        disable_raw_mode, enable_raw_mode, DisableLineWrap, EnableLineWrap, EnterAlternateScreen,
        LeaveAlternateScreen,
    },
};
use ratatui::{backend::CrosstermBackend, Terminal};
use serde_json::{json, Value};
use tokio::sync::mpsc;
use tokio::task::JoinHandle;
use tui_textarea::TextArea;

use aleph_protocol::browser_live::{
    CLOSED_TOPIC as BROWSER_LIVE_CLOSED_TOPIC, RESOURCE_TOPIC as BROWSER_LIVE_RESOURCE_TOPIC,
};
use aleph_protocol::providers::ProviderListResult;
use aleph_protocol::runtime::{
    RuntimeAgentsListResponse, RUNTIME_AGENTS_CHANGED_TOPIC, RUNTIME_AGENTS_LIST_METHOD,
};
use aleph_protocol::{ClarificationResolveResponse, PendingListResponse, StreamEvent};

use aleph_client::{AlephClient, CliConfig, CliError, CliResult};

use app::{Action, AgentPanelData, AppState, Focus};
use commands::{
    btw_abort_or_close, confirm_provider_pick, dispatch_gateway_text, execute_local_command,
    fetch_gateway_commands, fetch_my_user_id, open_agent_detail, refresh_picker_provider,
    send_to_agent, shadowed_gateway_commands, AttachMode,
};
use slash::ParsedInput;

/// The status bar's launch model caption, plus what to say in the transcript
/// when that caption is not a model name.
struct ModelCaption {
    caption: String,
    note: Option<String>,
}

/// Resolve the launch caption from a `providers.list` reply.
///
/// Three outcomes, and they used to be one word. `Err(_) => "unknown"` folded
/// "the gateway refused to tell me" into "the gateway has nothing to tell" —
/// and `providers.*` is operator-only, so a member connection takes the refusal
/// branch every single launch and reads a claim about their install that the
/// server never made. Only the `Ok` arm may say anything about what is
/// configured; the other two say what happened to us instead.
fn model_caption(reply: Result<Value, CliError>) -> ModelCaption {
    match reply {
        Ok(result) => default_provider_model(&result).map_or_else(
            || ModelCaption {
                caption: "none".to_string(),
                note: Some(
                    "The gateway reports no default provider model; name one with /providers."
                        .to_string(),
                ),
            },
            |model| ModelCaption {
                caption: model,
                note: None,
            },
        ),
        Err(e) => ModelCaption {
            caption: gateway_error::classify(&e).caption().to_string(),
            note: Some(gateway_error::explain(&e, "the gateway's default model")),
        },
    }
}

/// The default provider's model, read through the shared [`ProviderInfo`].
///
/// The keys used to be poked out of the JSON by hand here (`is_default`,
/// `model`) — the same shape that shipped `aleph providers list` rendering two
/// columns the server has never emitted. Deserialising the contract type makes
/// a rename a compile error on both sides at once.
fn default_provider_model(result: &Value) -> Option<String> {
    let providers = serde_json::from_value::<ProviderListResult>(result.clone())
        .ok()?
        .providers;
    providers
        .iter()
        .find(|p| p.is_default)
        .or_else(|| providers.first())
        .map(|p| p.model.clone())
        .filter(|model| !model.is_empty())
}

/// Map a `runtime.agents.list` outcome into [`AgentPanelData`].
///
/// Same shape as [`model_caption`]: a pure function over a `CliResult`, so
/// it is testable with a canned `Ok`/`Err` and needs no live socket —
/// `client.call`'s own correctness is `shared/client`'s test suite's job,
/// not this crate's. `CliError::Rpc { code, .. }` is how an operator-gate
/// refusal actually reaches this layer (`AUTH_REQUIRED`, per
/// `gateway::server::connection::dispatch::process_request`'s admin gate) — distinguished
/// by that CODE, never by matching words in the message (P8).
fn agent_panel_data(result: CliResult<RuntimeAgentsListResponse>) -> AgentPanelData {
    match result {
        Ok(resp) => AgentPanelData::Ready(resp.agents),
        Err(CliError::Rpc { code, message }) if code == aleph_protocol::jsonrpc::AUTH_REQUIRED => {
            AgentPanelData::Refused(message)
        }
        Err(e) => AgentPanelData::Unavailable(e.to_string()),
    }
}

/// Subscribe to the agent panel's topic and mark a re-fetch as due.
///
/// Startup uses this helper; runtime refresh uses the bounded RPC queue.
///
/// One derivation, two callers (判据 §9/§1) — `run()` at startup, and the
/// reconnect-success arm in `main_loop`, beside `reconcile_side_question`.
/// Both need it: `events.subscribe` registers PER-CONNECTION server state
/// (`subscription_manager.remove_connection` drops it on close), so
/// `AlephClient::reconnect`'s new socket starts subscribed to nothing.
/// Without re-subscribing there, the first reconnect silently and
/// permanently kills this screen's agent-panel data path — R8-5 waives only
/// *unsubscribe* for the process's life, not *re-subscribe* after a socket
/// the gateway itself dropped.
///
/// Sets the flag rather than awaiting [`refresh_runtime_agents`] directly:
/// the subscribe must complete before this screen can miss a notification
/// (so it stays awaited), but the fetch itself does not need to block the
/// caller — `main_loop`'s existing flag-check performs it on its next
/// iteration, and doing it this way is also what makes
/// [`app::AgentPanelData::Loading`] observable at all (awaiting the fetch
/// here left it permanently unreachable before the first frame ever drew).
async fn subscribe_runtime_agents(state: &mut AppState, client: &AlephClient) -> CliResult<()> {
    // A non-operator's subscribe still "succeeds" as an RPC — the operator
    // gate lives on the event's publish side (`EventScopeGuard`), not on
    // `events.subscribe` itself — so its result is not worth failing on;
    // the eventual `runtime.agents.list` fetch this triggers is what
    // actually reports the gate's answer.
    //
    // The result is still surfaced (T1.8): the previous `let _ =` swallowed
    // transport errors silently, and a failed subscribe on a freshly
    // re-opened socket was the path that froze the panel after the first
    // reconnect — no warn, no retry, the gateway had already dropped the
    // subscription and there was no log line to look at. A failed call now
    // warns AND still arms the re-fetch flag, so the next `main_loop` tick
    // picks it up the same way a `runtime.agents.changed` topic event does.
    let result = client
        .call::<_, Value>("events.subscribe", Some(tui_event_subscribe_params()))
        .await;
    if let Err(e) = &result {
        tracing::warn!(
            error = %e,
            "events.subscribe for runtime.agents.changed failed; \
             the next main_loop tick will retry the subscribe and \
             the re-fetch"
        );
        // Arm the re-fetch flag ONLY on failure. On a successful
        // subscribe, the call sites that wanted a refresh anyway
        // (`run()` at startup, the reconnect-success arm in
        // `main_loop`) set it themselves — and `main_loop`'s flag-check
        // block now ALSO calls this helper, so setting the flag on
        // success here would create a feedback loop (clear → refresh
        // → subscribe → set → clear → refresh → …).
        state.runtime_agents_refetch_due = true;
    }
    result.map(|_| ())
}

/// Every subscription preserves the chat stream as well as both topic planes.
/// The first explicit filter replaces the Gateway's receive-all default, so
/// even a runtime-only retry must retain `stream.*` on a fresh connection.
fn tui_event_subscribe_params() -> Value {
    json!({ "topics": [
        "stream.*",
        RUNTIME_AGENTS_CHANGED_TOPIC,
        BROWSER_LIVE_RESOURCE_TOPIC,
        BROWSER_LIVE_CLOSED_TOPIC,
    ] })
}

/// Subscribe this connection to `browser.live.resource` / `browser.live.closed`
/// so `AppState::handle_topic_event` can feed the browser resource catalog.
///
/// `events.subscribe` is PER-CONNECTION server state, so this is called once
/// after startup and once after each reconnect success — never from the
/// runtime-agents refetch tick. Fail-soft: the TUI works without browser
/// topics, so a failure only emits a fixed warn line (no error text or
/// payload, which could carry secrets) and is returned for the caller to drop.
async fn subscribe_browser_live_topics(client: &AlephClient) -> CliResult<()> {
    let result = client
        .call::<_, Value>("events.subscribe", Some(tui_event_subscribe_params()))
        .await;
    if result.is_err() {
        tracing::warn!(
            "events.subscribe for browser.live topics failed; \
             browser resources unavailable on this connection"
        );
    }
    result.map(|_| ())
}

/// Entry point: run the TUI application.
///
/// Sets up the terminal, spawns the event collector, and runs the main loop
/// until the user quits. Terminal is always restored on exit (including panics).
///
/// # Errors
///
/// Returns an error if terminal setup, the gateway handshake, or the main loop fails.
pub async fn run(
    client: AlephClient,
    mut gateway_events: mpsc::Receiver<StreamEvent>,
    config: &CliConfig,
    session_key: Option<String>,
    verbose: bool,
) -> CliResult<()> {
    // 1. Setup terminal
    let mut stdout = io::stdout();
    // Mouse capture must be enabled before raw mode. On Windows, crossterm
    // saves the console-mode snapshot when capture is enabled. Capture is
    // optional: a refused capture only removes
    // mouse affordances, whose keyboard equivalents remain available.
    let mouse = match execute!(stdout, EnableMouseCapture) {
        Ok(()) => true,
        Err(error) => {
            tracing::warn!("Terminal mouse capture unavailable: {error}");
            false
        }
    };
    enable_raw_mode().inspect_err(|_| {
        let _ = execute!(stdout, DisableMouseCapture);
    })?;
    // Bracketed paste lets the terminal deliver a multi-line paste as one
    // `Event::Paste` instead of a stream of key events (each newline a bare
    // Enter), which would otherwise auto-send the first pasted line. Unix/macOS
    // only — crossterm's Windows console source does not emit paste events, so
    // this is inert (but harmless) there.
    if let Err(error) = execute!(stdout, EnterAlternateScreen) {
        let _ = execute!(stdout, DisableMouseCapture);
        let _ = disable_raw_mode();
        return Err(error.into());
    }
    // Full-width drawing must not wrap at the bottom-right cell and scroll
    // the physical screen. Change output mode only after entering alternate
    // screen: Windows' native fallback then targets its separate buffer.
    // ANSI hosts may share wrap state across buffers; this restores enabled
    // wrap on exit, not an arbitrary pre-existing disabled-wrap setting.
    let terminal_setup = (|| {
        execute!(stdout, DisableLineWrap, EnableBracketedPaste)?;
        #[cfg(windows)]
        {
            // ConPTY translates SGR mouse reports to MouseRecords.
            stdout.write_all(b"\x1b[?1006h")?;
            stdout.flush()?;
        }
        let backend = CrosstermBackend::new(stdout);
        Terminal::new(backend)
    })();
    let mut terminal = terminal_setup.inspect_err(|_| {
        // Attempt each restoration even if a preceding output command fails.
        #[cfg(windows)]
        {
            let mut stdout = io::stdout();
            let _ = stdout.write_all(b"\x1b[?1006l");
            let _ = stdout.flush();
        }
        let _ = execute!(io::stdout(), EnableLineWrap);
        let _ = execute!(io::stdout(), LeaveAlternateScreen, DisableBracketedPaste);
        let _ = execute!(io::stdout(), DisableMouseCapture);
        let _ = disable_raw_mode();
    })?;

    // 2. Set panic hook to restore terminal on panic
    let original_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        // Disable capture while crossterm's pre-raw console-mode snapshot is
        // still valid; disabling raw mode first can restore the wrong mode on
        // Windows. Disabling capture that was never enabled is harmless.
        let _ = execute!(io::stdout(), DisableMouseCapture);
        let _ = disable_raw_mode();
        #[cfg(windows)]
        {
            let mut stdout = io::stdout();
            let _ = stdout.write_all(b"\x1b[?1006l");
            let _ = stdout.flush();
        }
        let _ = execute!(io::stdout(), EnableLineWrap);
        let _ = execute!(io::stdout(), LeaveAlternateScreen, DisableBracketedPaste);
        let _ = execute!(io::stdout(), crossterm::cursor::Show);
        original_hook(info);
    }));

    // 3. Fetch model name from gateway, then create AppState and TextArea
    let ModelCaption {
        caption: model_name,
        note: model_caption_note,
    } = model_caption(client.call::<_, Value>("providers.list", None::<()>).await);

    // 3b. Fetch gateway commands for command palette
    let gateway_commands = fetch_gateway_commands(&client).await;

    // 3b-ii. This client's own principal id. One call, at startup, because the
    // answer cannot change for the life of a connection — the role and the
    // principal are both fixed by the `connect` handshake. It exists to answer
    // one question: on a shared room session, did somebody ELSE type the
    // message the server just echoed. `None` (older gateway, transport error,
    // or a caller with no principal record) turns the echo off rather than
    // guessing, which is the behaviour this screen had before it existed.
    let my_user_id = fetch_my_user_id(&client).await;

    // An empty key means "not routed yet": the first `agent.run` omits
    // `session_key` entirely and adopts whatever canonical key the gateway
    // reports back. Inventing a key here is what used to strand every keyed RPC
    // this client made.
    let mut state = AppState::new(session_key.clone().unwrap_or_default(), model_name);
    crate::tui::theme::initialize();
    for warning in crate::tui::theme::take_boot_warnings() {
        state.add_system_message(format!("Theme: {warning}"));
    }
    // Before the first draw, and never again: the rendered-line cache bakes
    // the hint wording in (see `AppState::mouse`).
    state.mouse = mouse;
    // Honor the CLI `--verbose` flag from launch, not only the /verbose command.
    state.verbose = verbose;
    // A one-word caption cannot explain itself. When it is not a model name,
    // say once why — the status bar goes on showing the short form.
    if let Some(note) = model_caption_note {
        state.add_system_message(note);
    }
    state.gateway_commands = gateway_commands;
    state.my_user_id = my_user_id;
    // `/browser` can only open a viewer when the user opted in explicitly
    // (ALEPH_VIEWER_ENABLED=1 plus trusted origins). A malformed opt-in stays
    // disabled and says so once; the message never echoes the offending value.
    match crate::viewer_launcher::config_from_env() {
        Ok(cfg) => state.viewer_launcher_config = cfg,
        Err(e) => state.add_system_message(format!("Viewer launcher disabled: {e}")),
    }
    // A local command that matches a gateway one makes the gateway one
    // unreachable — this client resolves local first and never falls through.
    // Recorded in the log, not the transcript: the clash is a developer-facing
    // fact and a startup banner about it read as noise to users
    // (see `shadowed_gateway_commands`).
    let shadowed = shadowed_gateway_commands(&state.gateway_commands);
    if !shadowed.is_empty() {
        tracing::info!(
            commands = %shadowed.join(", "),
            "local commands shadow gateway commands"
        );
    }

    // 3b-iii. Agent panel (Task 8a): subscribe once for the life of this
    // process, then mark a fetch as due — main_loop's first iteration
    // performs it, so this does not block startup on a second round trip
    // and AgentPanelData::Loading is briefly observable, as R8-6 intended.
    // The reconnect arm calls this same helper again — see its own doc.
    //
    // The result is deliberately not surfaced (T1.8): a failed subscribe on
    // startup already logs a warn inside the helper AND arms the re-fetch
    // flag, and `run()` is the wrong place to bubble the failure — the rest
    // of the launch (status bar, transcript attach) is still wanted.
    //
    // The helper now arms the re-fetch flag ONLY on failure. On a
    // successful subscribe, set it ourselves so `main_loop`'s first
    // iteration actually does the re-fetch (the previous "always-arm"
    // helper behavior was masking this need, and was the reason adding
    // a subscribe call to `main_loop`'s flag-check would otherwise
    // create an infinite loop).
    let _ = subscribe_runtime_agents(&mut state, &client).await;
    state.runtime_agents_refetch_due = true;
    // Browser live topics: per-connection, fail-soft, once at startup.
    let _ = subscribe_browser_live_topics(&client).await;

    // 3c. Attach to the named conversation: transcript + the settings that
    // govern it (mode / tier / thinking depth / model / cumulative tokens /
    // memory mode). Reopening a terminal mid-task lands you back where you
    // were; before this, `--session <key>` opened a blank screen and the status
    // bar reported the install defaults over a conversation that had its own.
    if let Some(key) = session_key.as_deref().filter(|k| !k.is_empty()) {
        state.session_key = key.to_owned();
        state.transcript_needs_resync = true;
    }
    let mut textarea = TextArea::default();
    textarea.set_placeholder_text("Type a message... (/ for commands)");

    // 4. Spawn event collector
    let mut term_events = event::spawn_event_collector();

    // 5. Main loop
    let result = main_loop(
        &mut terminal,
        &mut state,
        &mut textarea,
        &client,
        config,
        &mut gateway_events,
        &mut term_events,
    )
    .await;

    // 6. Restore terminal (always, even on error). Release capture before
    // raw mode so Windows crossterm can restore its pre-raw console snapshot.
    // Restore wrap while still on the alternate buffer, not the host buffer.
    let line_wrap_cleanup = execute!(terminal.backend_mut(), EnableLineWrap);
    let capture_and_screen_cleanup = execute!(
        terminal.backend_mut(),
        LeaveAlternateScreen,
        DisableBracketedPaste,
        DisableMouseCapture
    );
    let raw_mode_cleanup = disable_raw_mode();
    line_wrap_cleanup?;
    capture_and_screen_cleanup?;
    raw_mode_cleanup?;
    terminal.show_cursor()?;

    result
}

/// A reconnect attempt in flight, borrowing the client it will rebuild.
type ReconnectAttempt<'a> = Pin<Box<dyn Future<Output = CliResult<()>> + 'a>>;

/// One reconnect attempt, `delay` from now.
///
/// The wait lives INSIDE the future rather than in a second timer beside it, so
/// one object answers both "is an attempt outstanding" and "when does it
/// happen". Two pieces of state would be two things to get out of step, and the
/// failure would be a client that either never retries or retries continuously.
fn reconnect_after<'a>(
    client: &'a AlephClient,
    config: &'a CliConfig,
    delay: Duration,
) -> ReconnectAttempt<'a> {
    Box::pin(async move {
        tokio::time::sleep(delay).await;
        client.reconnect(config).await
    })
}

/// Await the attempt in flight, or never.
///
/// `None` has to be a branch that NEVER fires. A branch that resolved
/// immediately would spin the select at full speed and burn a core for as long
/// as the client is merely connected, which is almost always.
///
/// `select!` drops this wrapper every time another branch wins, and that is
/// safe: the attempt itself lives in `pending` and is only borrowed here, so
/// cancelling loses no progress — including none of the sleep.
async fn awaiting_reconnect<'a>(pending: &mut Option<ReconnectAttempt<'a>>) -> CliResult<()> {
    match pending {
        Some(attempt) => attempt.await,
        None => std::future::pending().await,
    }
}

/// How long to wait before the attempt after a failed one.
///
/// Starts at zero: the first try after a drop goes out immediately, because the
/// common case is a gateway that restarted and is already listening again. The
/// ceiling keeps a long outage from becoming a busy loop while staying short
/// enough that a user who fixes the network does not sit and wait for it.
fn next_backoff(current: Duration) -> Duration {
    const CEILING: Duration = Duration::from_secs(15);
    if current.is_zero() {
        Duration::from_secs(1)
    } else {
        (current * 2).min(CEILING)
    }
}

/// Await the next topic notification, or never when the plane was already
/// claimed elsewhere (`take_topic_events` is one-shot per client). The `None`
/// branch must never resolve — same rule as [`awaiting_reconnect`].
async fn next_topic_event(
    rx: &mut Option<mpsc::Receiver<aleph_client::TopicEvent>>,
) -> Option<aleph_client::TopicEvent> {
    match rx {
        Some(rx) => rx.recv().await,
        None => std::future::pending().await,
    }
}

/// Whether a pure `Action::Tick` (no gateway/terminal event) needs a redraw.
///
/// A tick that only bumped the spinner counter with nothing on screen
/// depending on it (`has_active_run == false`) changes nothing visible and
/// can skip the draw entirely — the per-message line cache (see
/// `widgets::chat_area::LineCache`) already makes an idle draw cheap, but
/// cheap is not free, and a genuinely idle terminal has no reason to redraw
/// 20 times a second. `connection_state_changed` covers the one other thing
/// a pure tick can affect: the status dot flips on the disconnect/reconnect
/// edge (see the tick handler's own comment on why the edge, not the level,
/// matters).
fn should_redraw_after_tick(has_active_run: bool, connection_state_changed: bool) -> bool {
    has_active_run || connection_state_changed
}

/// The main event loop. Separated from `run()` so terminal restoration
/// happens even if this function returns an error.
/// A lost terminal notification must not leave a run permanently blocking
/// history recovery. The server's identity and phase are the only verdict.
fn recover_missing_terminal(
    state: &mut AppState,
    run: &str,
    report: &aleph_protocol::AgentRunStatusReport,
) {
    if state.current_run.as_deref() != Some(run) || report.run_id != run {
        return;
    }
    if matches!(
        report.phase(),
        aleph_protocol::RunPhase::Completed
            | aleph_protocol::RunPhase::Failed
            | aleph_protocol::RunPhase::Cancelled
    ) {
        state.begin_reattach();
        state.transcript_needs_resync = true;
    }
}

fn enqueue_command_rpc<'a>(
    state: &mut AppState,
    client: &'a AlephClient,
    jobs: &mut rpc_jobs::RpcJobs<'a>,
    scope: &rpc_jobs::RpcScope,
    request: Option<(&'static str, Value)>,
    replay_sequence: &mut u64,
) {
    let Some((method, params)) = request else {
        return;
    };
    let identity = if method == "trace.get" {
        state.transcript_generation = state.transcript_generation.wrapping_add(1);
        *replay_sequence = replay_sequence.wrapping_add(1);
        replay_sequence.to_string()
    } else {
        "list".to_owned()
    };
    let tag = rpc_jobs::RpcTag {
        scope: scope.clone(),
        method,
        identity,
    };
    if !jobs.enqueue(client, tag, Some(params)) {
        state.add_system_message("Request queue is busy; retry the replay command shortly.".into());
    }
}

async fn main_loop<'c>(
    terminal: &mut Terminal<CrosstermBackend<io::Stdout>>,
    state: &mut AppState,
    textarea: &mut TextArea<'_>,
    client: &'c AlephClient,
    config: &'c CliConfig,
    gateway_events: &mut mpsc::Receiver<StreamEvent>,
    term_events: &mut mpsc::Receiver<event::TermEvent>,
) -> CliResult<()> {
    // Owned here rather than passed in: nothing outside this loop reads it, and
    // a parameter that only one caller can supply is a parameter that only
    // spends the argument budget.
    let mut tick_interval = tokio::time::interval(Duration::from_millis(50));
    // The topic plane (`{"method":"event"}` frames — `run.subagent_tree` and
    // friends), claimed once. `shared/client` used to drop these frames with a
    // `debug!` line; now they drive the agents panel/overlay live.
    let mut topic_events = client.take_topic_events();
    // At most one reconnect attempt is ever outstanding, and the loop owns the
    // policy: `shared/client` supplies only the mechanism, deliberately, so
    // that a socket cannot come back without this screen learning of it and
    // re-asking the server what is true (see `AlephClient::reconnect`).
    let mut reconnecting: Option<ReconnectAttempt<'c>> = None;
    let mut backoff = Duration::ZERO;
    let mut reported_reconnect_failure = false;
    let mut selection = text_selection::TextSelection::default();
    let mut selection_scope: Option<(String, u64, Focus, ratatui::layout::Rect)> = None;
    let mut copy_task: Option<JoinHandle<Result<(), String>>> = None;
    // Starts `true` so the first frame always draws — never delayed behind a
    // wait for the first event. Cleared right after each draw; only actions
    // that changed something visible set it back to `true` (see
    // `should_redraw_after_tick` for the one arm, `Action::Tick`, that
    // decides for itself instead of redrawing unconditionally).
    let mut needs_redraw = true;
    let mut last_welcome_layout = None;
    let mut rpc_jobs = rpc_jobs::RpcJobs::default();
    let mut runtime_refresh_after = std::time::Instant::now();
    let mut continuity = client.stream_continuity();
    let mut recovery_after = std::time::Instant::now();
    let mut run_probe_after = std::time::Instant::now();
    let mut pending_refresh_due = true;
    let mut pending_revision = 0_u64;
    let mut approval_revision = 0_u64;
    let mut observed_run = state.current_run.clone();
    let mut replay_sequence = 0_u64;
    let mut pending_refresh_after = std::time::Instant::now();
    let mut submissions = std::collections::HashMap::<String, interaction::Submission>::new();
    let mut modal_scope: Option<rpc_jobs::RpcScope> = None;
    let mut browser_subscribe_due = false;
    let mut side_recovery_due = false;
    let mut rpc_scope = rpc_jobs::RpcScope {
        session_key: state.session_key.clone(),
        generation: 0,
    };
    loop {
        if observed_run != state.current_run {
            observed_run = state.current_run.clone();
            approval_revision = approval_revision.wrapping_add(1);
            replay_sequence = replay_sequence.wrapping_add(1);
        }
        if rpc_scope.session_key != state.session_key {
            rpc_scope.session_key.clone_from(&state.session_key);
            rpc_scope.generation = rpc_scope.generation.wrapping_add(1);
            pending_refresh_due = true;
            pending_refresh_after = std::time::Instant::now();
        }
        if modal_scope.as_ref() != Some(&rpc_scope) {
            state
                .interaction
                .set_context(state.session_key.clone(), rpc_scope.generation);
            modal_scope = Some(rpc_scope.clone());
        }
        state.sync_modal_focus();
        let current_scope = (
            state.session_key.clone(),
            state.transcript_generation,
            state.focus,
            ratatui::layout::Rect::new(0, 0, terminal.size()?.width, terminal.size()?.height),
        );
        if selection_scope.as_ref() != Some(&current_scope) {
            selection.clear();
            selection_scope = Some(current_scope);
        }
        submissions.retain(|_, ticket| ticket.generation == rpc_scope.generation);
        // Settled by the reconnect branch below; read after the select, where
        // `reconnecting` is no longer borrowed.
        let mut reconnect_outcome: Option<CliResult<()>> = None;
        // Draw only when something visible changed since the last frame.
        if needs_redraw {
            // Re-sync on the empty/history boundary, not on every streamed
            // frame. Actual hero geometry remains owned by the renderer; this
            // conservative invalidation also covers terminals too short for it.
            let welcome_layout = !state
                .messages
                .iter()
                .any(|entry| !matches!(entry, app::TranscriptEntry::SystemNotice { .. }));
            if cfg!(windows)
                && last_welcome_layout.is_some_and(|previous| previous != welcome_layout)
            {
                // Native consoles can retain physical cells across this layout
                // change even after widget Clear. Re-sync both sides of the diff
                // once, as on overlay close; never clear ordinary streaming ticks.
                terminal.clear()?;
                terminal.swap_buffers();
            }
            terminal.draw(|f| {
                render::render(f, state, textarea);
                selection.observe(f.buffer_mut(), state.text_selection_area);
                selection.paint(f.buffer_mut());
            })?;
            last_welcome_layout = Some(welcome_layout);
            needs_redraw = false;
        }

        // Wait for next event
        let action = tokio::select! {
            Some(te) = term_events.recv() => {
                let action = match &te {
                    event::TermEvent::Mouse(mouse) => {
                        use crossterm::event::{MouseButton, MouseEventKind};
                        if matches!(mouse.kind, MouseEventKind::ScrollUp | MouseEventKind::ScrollDown) {
                            selection.clear();
                            keys::handle_terminal_event(state, textarea, &te)
                        } else {
                            match selection.mouse(*mouse) {
                                text_selection::MouseOutcome::Ignored => keys::handle_terminal_event(state, textarea, &te),
                                text_selection::MouseOutcome::Consumed => Action::None,
                                text_selection::MouseOutcome::Click { column, row } => keys::handle_terminal_event(
                                    state,
                                    textarea,
                                    &event::TermEvent::Mouse(crossterm::event::MouseEvent {
                                        kind: MouseEventKind::Down(MouseButton::Left),
                                        column,
                                        row,
                                        modifiers: mouse.modifiers,
                                    }),
                                ),
                                text_selection::MouseOutcome::Copy(text) => {
                                    if copy_task.is_none() {
                                        copy_task = Some(tokio::spawn(clipboard::copy_text(text)));
                                    }
                                    Action::None
                                }
                            }
                        }
                    }
                    event::TermEvent::Key(key) => {
                        let copy_key = (key.code == crossterm::event::KeyCode::Insert
                            && key.modifiers.contains(crossterm::event::KeyModifiers::CONTROL))
                            || (key.code == crossterm::event::KeyCode::Char('c')
                                && (key.modifiers.contains(crossterm::event::KeyModifiers::CONTROL)
                                    || key.modifiers.contains(crossterm::event::KeyModifiers::SUPER)));
                        if copy_key && selection.is_selected() {
                            if copy_task.is_none() {
                                if let Some(text) = selection.text() {
                                    copy_task = Some(tokio::spawn(clipboard::copy_text(text)));
                                }
                            }
                            Action::None
                        } else if key.code == crossterm::event::KeyCode::Esc && selection.is_selected() {
                            selection.clear();
                            Action::None
                        } else {
                            selection.clear();
                            keys::handle_terminal_event(state, textarea, &te)
                        }
                    }
                    event::TermEvent::Paste(_) | event::TermEvent::Resize => {
                        selection.clear();
                        keys::handle_terminal_event(state, textarea, &te)
                    }
                };
                needs_redraw = true;
                action
            }
            Some(ge) = gateway_events.recv() => {
                // Same reasoning as the terminal branch above: a gateway
                // frame can mutate visible state (e.g. the /btw overlay,
                // the AskUser dialog, a streamed chunk) while returning
                // Action::None.
                needs_redraw = true;
                if matches!(&ge, StreamEvent::AskUser { .. } | StreamEvent::ClarificationEnded { .. }) {
                    pending_revision = pending_revision.wrapping_add(1);
                    pending_refresh_due = true;
                }
                let mut action = state.handle_gateway_event(ge);
                // Coalesce a burst: chunks already queued behind this one
                // are state mutations that need ONE draw, not one draw
                // each. Draining costs zero added latency (these events
                // already arrived — nothing is waited for) and collapses a
                // high-rate token stream into far fewer terminal draws. The
                // first frame of a run is unaffected: the loop-top draw
                // fires immediately after this branch either way.
                for _ in 1..rpc_jobs::EVENT_BATCH {
                    let Ok(queued) = gateway_events.try_recv() else { break };
                    if matches!(&queued, StreamEvent::AskUser { .. } | StreamEvent::ClarificationEnded { .. }) {
                        pending_revision = pending_revision.wrapping_add(1);
                        pending_refresh_due = true;
                    }
                    let next = state.handle_gateway_event(queued);
                    if !matches!(next, Action::None) {
                        action = next;
                    }
                }
                action
            }
            Some(topic) = next_topic_event(&mut topic_events) => {
                needs_redraw = true;
                state.handle_topic_event(&topic.topic, topic.data);
                // Coalesce a burst the same way the gateway-event arm does.
                for _ in 1..rpc_jobs::EVENT_BATCH {
                    let Some(rx) = topic_events.as_mut() else { break };
                    match rx.try_recv() {
                        Ok(queued) => state.handle_topic_event(&queued.topic, queued.data),
                        Err(_) => break,
                    }
                }
                Action::None
            }
            _ = tick_interval.tick() => {
                Action::Tick
            }
            copy_result = async {
                match copy_task.as_mut() {
                    Some(task) => Some(task.await),
                    None => std::future::pending().await,
                }
            } => {
                copy_task = None;
                if matches!(copy_result, Some(Err(_)) | Some(Ok(Err(_)))) {
                    state.add_system_message("Clipboard copy failed; no text was reported as copied.".into());
                    needs_redraw = true;
                }
                Action::None
            }
            completed = rpc_jobs.next() => {
                if completed.tag.scope == rpc_scope {
                    match completed.tag.method {
                        RUNTIME_AGENTS_LIST_METHOD => {
                            state.runtime_agents = agent_panel_data(completed.result.and_then(|value| {
                                serde_json::from_value(value).map_err(CliError::from)
                            }));
                        }
                        "session.snapshot" => {
                            recovery_after = std::time::Instant::now() + Duration::from_secs(5);
                            match completed.result.and_then(|v| serde_json::from_value(v).map_err(CliError::from)) {
                                Ok(snapshot) => {
                                    commands::apply_acquired_session(state, snapshot, AttachMode::Replace);
                                }
                                Err(_) => state.add_system_message("Conversation recovery failed; keeping the current view and retrying.".into()),
                            }
                        }
                        "events.subscribe" => {
                            if completed.result.is_err() {
                                state.runtime_agents_refetch_due = true;
                            }
                        }
                        "agent.status" => {
                            if let Some(run) = completed.tag.identity.strip_prefix("main:") {
                                if let Ok(value) = completed.result {
                                    if let Ok(report) = serde_json::from_value::<aleph_protocol::AgentRunStatusReport>(value) {
                                        recover_missing_terminal(state, run, &report);
                                    }
                                }
                            } else {
                                let answer = completed.result.and_then(|v| serde_json::from_value(v).map_err(CliError::from));
                                commands::apply_side_question_status(state, &completed.tag.identity, answer);
                            }
                        }
                        "agent.cancel" => {
                            state.add_system_message(if completed.result.is_ok() {
                                "Cancellation requested; waiting for the run to settle.".into()
                            } else {
                                "Cancellation request failed; retry when connected.".into()
                            });
                        }
                        "clarification.resolve" => {
                            if let Some(ticket) = submissions.remove(&completed.tag.identity) {
                                let response = completed.result.ok().and_then(|v| serde_json::from_value::<ClarificationResolveResponse>(v).ok());
                                let effect = state.interaction.acknowledge(&ticket, response.as_ref());
                                if effect != interaction::AckEffect::Ignored {
                                    pending_revision = pending_revision.wrapping_add(1);
                                    pending_refresh_due = true;
                                    pending_refresh_after = std::time::Instant::now();
                                }
                                state.sync_modal_focus();
                            }
                        }
                        "clarification.pending" => {
                            pending_refresh_after = std::time::Instant::now() + Duration::from_secs(5);
                            if completed.tag.identity != pending_revision.to_string() {
                                pending_refresh_due = true;
                                pending_refresh_after = std::time::Instant::now();
                            } else {
                            match completed.result.and_then(|v| serde_json::from_value::<PendingListResponse>(v).map_err(CliError::from)) {
                                Ok(snapshot) => {
                                    let mut keys: std::collections::BTreeSet<String> = state.interaction.question_sessions().into_iter().collect();
                                    keys.insert(state.session_key.clone());
                                    keys.extend(snapshot.pending.iter().map(|p| p.session_key.clone()));
                                    for key in keys {
                                        let pending = snapshot.pending.iter().find(|p| p.session_key == key).cloned();
                                        state.interaction.reconcile_pending(&key, pending);
                                    }
                                    state.sync_modal_focus();
                                }
                                Err(_) => pending_refresh_due = true,
                            }
                            }
                        }
                        "trace.tool_output" => {
                            if let Some(view) = &mut state.tool_output {
                                if completed.tag.identity == format!("{}:{}:{}", view.generation, view.tool_call_id, view.next_offset) {
                                    match completed.result.ok().and_then(|v| serde_json::from_value::<aleph_protocol::ToolOutputPage>(v).ok()) {
                                        Some(page) => view.apply(view.next_offset, page),
                                        None => view.fail(),
                                    }
                                }
                            }
                        }
                        "exec.approval.resolve" => {
                            if state.approval.as_ref().is_some_and(|a| a.id == completed.tag.identity) {
                                if completed.result.is_ok() {
                                    approval_revision = approval_revision.wrapping_add(1);
                                    let key = state.session_key.clone();
                                    state.interaction.retire_approval(&key, &completed.tag.identity);
                                    state.close_approval();
                                } else {
                                    state.add_system_message("Approval submission failed; the pending card is retained for retry.".into());
                                }
                                state.sync_modal_focus();
                            }
                        }
                        "trace.list" => {
                            match completed.result.and_then(|value| serde_json::from_value::<aleph_protocol::AgentTraceListPage>(value).map_err(CliError::from)) {
                                Ok(page) => state.add_system_message(commands::format_replay_list(&page)),
                                Err(_) => state.add_system_message("Replay list could not be loaded. Retry /replay list.".into()),
                            }
                        }
                        "trace.get" => {
                            if completed.tag.identity == replay_sequence.to_string() && state.current_run.is_none() {
                                match completed.result.and_then(|value| serde_json::from_value::<aleph_protocol::AgentTraceReplay>(value).map_err(CliError::from)) {
                                    Ok(replay) => state.load_trace_replay(&replay),
                                    Err(_) => state.add_system_message("Replay could not be loaded; the conversation is retained.".into()),
                                }
                            }
                        }
                        "exec.approvals.pending"
                            if completed.tag.identity == format!("{}:{}", approval_revision, state.current_run.as_deref().unwrap_or_default()) => {
                            if let Ok(snapshot) = completed.result {
                                approval::reconcile_approvals(state, &snapshot);
                            }
                        }
                        _ => {}
                    }
                    needs_redraw = true;
                }
                Action::None
            }
            outcome = awaiting_reconnect(&mut reconnecting) => {
                reconnect_outcome = Some(outcome);
                Action::None
            }
        };

        // A reconnect attempt settled. Handled here rather than inside the
        // select branch because both outcomes need to touch `reconnecting`,
        // which that branch still has borrowed.
        if let Some(outcome) = reconnect_outcome {
            reconnecting = None;
            // A reconnect completing or failing always changes visible
            // state: the status dot flips and/or a system message is
            // appended below.
            needs_redraw = true;
            match outcome {
                Ok(()) => {
                    rpc_scope.generation = rpc_scope.generation.wrapping_add(1);
                    continuity = client.stream_continuity();
                    backoff = Duration::ZERO;
                    state.is_connected = true;
                    // Everything on this screen came from a connection that no
                    // longer exists, and it stopped moving at a point nobody
                    // recorded. Rebuild from the server rather than trusting a
                    // transcript with an unknown hole in it — turns can have
                    // completed, and a peer can have spoken, while this client
                    // was away.
                    state.begin_reattach();
                    state.runtime_agents_refetch_due = true;
                    state.browser_resources.clear_for_reconnect();
                    browser_subscribe_due = true;
                    side_recovery_due = true;
                    pending_refresh_due = true;
                }
                Err(e) => {
                    backoff = next_backoff(backoff);
                    // Said once. A long outage retries every 15 s, and a line
                    // per attempt would bury the transcript the user is still
                    // reading — the status dot already reports the level.
                    if !reported_reconnect_failure {
                        reported_reconnect_failure = true;
                        state.add_system_message(format!(
                            "Reconnect failed ({e}). Still trying; the status dot \
                             turns green when it succeeds."
                        ));
                    }
                    reconnecting = Some(reconnect_after(client, config, backoff));
                }
            }
        }

        // A pending agent-panel re-fetch is STATE
        // (`state.runtime_agents_refetch_due`), checked and cleared once per
        // iteration here — not an `Action`, and not folded into the match
        // below. See the field's own doc: the burst-coalescing drain in the
        // `gateway_events` branch above keeps only the LAST non-`None`
        // action from a drained burst, so an `Action` that meant "go
        // re-fetch the agent table" could be silently overwritten by a later
        // frame in the same burst and never happen — and `runtime.agents.changed`
        // fires exactly when `stream.*` chunks are also flying, which is not
        // a rare shape for this loop to see. A `bool` on `AppState` cannot be
        // coalesced away by a later frame the way a returned `Action` could.
        if state.runtime_agents_refetch_due && std::time::Instant::now() >= runtime_refresh_after {
            let fetch = rpc_jobs.enqueue(
                client,
                rpc_jobs::RpcTag {
                    scope: rpc_scope.clone(),
                    method: RUNTIME_AGENTS_LIST_METHOD,
                    identity: String::new(),
                },
                None,
            );
            let subscribe = rpc_jobs.enqueue(
                client,
                rpc_jobs::RpcTag {
                    scope: rpc_scope.clone(),
                    method: "events.subscribe",
                    identity: "runtime-agents".into(),
                },
                Some(tui_event_subscribe_params()),
            );
            if fetch && subscribe {
                state.runtime_agents_refetch_due = false;
            }
            runtime_refresh_after = std::time::Instant::now() + Duration::from_secs(1);
        }

        // Recovery is a durable due flag: a full worker queue cannot discard
        // it, and an active run is never spliced with an unwatermarked replay.
        if state.transcript_needs_resync
            && !state.replaying_trace
            && state.current_run.is_none()
            && !state.session_key.is_empty()
            && state.is_connected
            && std::time::Instant::now() >= recovery_after
        {
            let key = state.session_key.clone();
            let generation = state.transcript_generation;
            rpc_jobs.enqueue_work(
                rpc_jobs::RpcTag {
                    scope: rpc_scope.clone(),
                    method: "session.snapshot",
                    identity: generation.to_string(),
                },
                Box::pin(async move {
                    commands::acquire_session_snapshot(client, key, generation)
                        .await
                        .map_err(CliError::Config)
                        .and_then(|s| serde_json::to_value(s).map_err(CliError::from))
                }),
            );
        }
        if (pending_refresh_due || state.spinner_frame.is_multiple_of(100))
            && state.is_connected
            && !state.session_key.is_empty()
            && std::time::Instant::now() >= pending_refresh_after
            && rpc_jobs.enqueue(
                client,
                rpc_jobs::RpcTag {
                    scope: rpc_scope.clone(),
                    method: "clarification.pending",
                    identity: pending_revision.to_string(),
                },
                None,
            )
        {
            pending_refresh_due = false;
            pending_refresh_after = std::time::Instant::now() + Duration::from_secs(5);
        }
        if side_recovery_due && state.is_connected {
            if let Some(run) = state.btw.active_run_id() {
                if rpc_jobs.enqueue(
                    client,
                    rpc_jobs::RpcTag {
                        scope: rpc_scope.clone(),
                        method: "agent.status",
                        identity: run.into(),
                    },
                    Some(json!({"run_id":run})),
                ) {
                    side_recovery_due = false;
                }
            } else {
                side_recovery_due = false;
            }
        }
        if state.transcript_needs_resync && std::time::Instant::now() >= run_probe_after {
            if let Some(run) = state.current_run.as_deref() {
                if rpc_jobs.enqueue(
                    client,
                    rpc_jobs::RpcTag {
                        scope: rpc_scope.clone(),
                        method: "agent.status",
                        identity: format!("main:{run}"),
                    },
                    Some(json!({"run_id":run})),
                ) {
                    run_probe_after = std::time::Instant::now() + Duration::from_secs(5);
                }
            }
        }
        if browser_subscribe_due
            && rpc_jobs.enqueue(
                client,
                rpc_jobs::RpcTag {
                    scope: rpc_scope.clone(),
                    method: "events.subscribe",
                    identity: "browser-live".into(),
                },
                Some(json!({"topics": [BROWSER_LIVE_RESOURCE_TOPIC, BROWSER_LIVE_CLOSED_TOPIC]})),
            )
        {
            browser_subscribe_due = false;
        }

        // Execute action
        if let Some(view) = &mut state.tool_output {
            if view.load_due && view.can_load() {
                let tag = rpc_jobs::RpcTag {
                    scope: rpc_scope.clone(),
                    method: "trace.tool_output",
                    identity: format!(
                        "{}:{}:{}",
                        view.generation, view.tool_call_id, view.next_offset
                    ),
                };
                let params = json!({ "session_key": view.session_key, "tool_call_id": view.tool_call_id, "offset": view.next_offset, "limit": tool_output::PAGE_BYTES });
                if rpc_jobs.enqueue(client, tag, Some(params)) {
                    view.load_due = false;
                    view.loading = true;
                }
            }
        }
        match action {
            Action::None => {}
            Action::Quit => {
                break;
            }
            Action::Tick => {
                state.spinner_frame = state.spinner_frame.wrapping_add(1);
                let was_connected = state.is_connected;
                // Reflect the live connection state in the status dot even while
                // idle (no in-flight call). The gateway-event channel never
                // yields None on a WS drop — the client keeps an ownership anchor
                // on the receiver — so the connection's own atomic is the only
                // reliable disconnect signal.
                //
                // The EDGE is what matters, not the level. The moment the
                // socket goes from up to down is the moment everything this
                // screen reconciled against it stops being true, and it is the
                // only moment worth starting a reconnect from — reading the
                // level alone would restart the attempt on every 50 ms tick.
                let live = client.is_connected();
                if live {
                    state.is_connected = true;
                } else if state.is_connected {
                    state.on_disconnected();
                    state.add_system_message(
                        "Connection lost — reconnecting in the background.".to_string(),
                    );
                    backoff = Duration::ZERO;
                    reported_reconnect_failure = false;
                    reconnecting = Some(reconnect_after(client, config, backoff));
                }
                // Poll for pending tool approvals while a run is active. Ask
                // exec tier can park a run waiting on a decision the thin client
                // receives no event for; ~1s cadence (every 20th 50ms tick)
                // keeps the 120s approval window responsive without chatter.
                if state.current_run.is_some() && state.spinner_frame.is_multiple_of(20) {
                    rpc_jobs.enqueue(
                        client,
                        rpc_jobs::RpcTag {
                            scope: rpc_scope.clone(),
                            method: "exec.approvals.pending",
                            identity: format!(
                                "{}:{}",
                                approval_revision,
                                state.current_run.as_deref().unwrap_or_default()
                            ),
                        },
                        None,
                    );
                }
                let latest_continuity = client.stream_continuity();
                if latest_continuity != continuity {
                    continuity = latest_continuity;
                    rpc_scope.generation = rpc_scope.generation.wrapping_add(1);
                    state.add_system_message(
                        "Stream continuity changed; recorded conversation and pending requests need recovery.".into()
                    );
                    state.transcript_needs_resync = true;
                    pending_refresh_due = true;
                    recovery_after = std::time::Instant::now();
                    state.runtime_agents_refetch_due = true;
                }
                needs_redraw |= should_redraw_after_tick(
                    // `state.dialog` (the AskUser overlay) is OR'd in for the
                    // same reason as `btw`: `StreamEvent::AskUser` is exempt
                    // from the cross-session run-id guard by design (see
                    // `events::run_scoped_id`) so a background/delegated
                    // run's clarification can reach an otherwise-idle screen
                    // — `an_ask_user_from_another_sessions_run_is_still_shown`
                    // exercises exactly this with `current_run` staying
                    // `None` throughout. Its `Action::None` return means the
                    // tick that shows it for the first time has to be the one
                    // that decides to redraw, not some later action.
                    state.current_run.is_some()
                        || state.btw.active_run_id().is_some()
                        || state.dialog.is_some(),
                    state.is_connected != was_connected,
                );
            }

            // -- Chat --
            Action::SendMessage(msg) => {
                state.add_user_message(msg.clone(), vec![]);
                state.ctrl_c_count = 0;

                // Save to input history
                if !msg.is_empty() {
                    state.push_send_history(msg.clone());
                }

                send_to_agent(state, client, &msg, "Send error").await;
            }
            Action::LocalCommand(cmd) => {
                let request = execute_local_command(state, textarea, client, cmd).await;
                enqueue_command_rpc(
                    state,
                    client,
                    &mut rpc_jobs,
                    &rpc_scope,
                    request,
                    &mut replay_sequence,
                );
            }
            Action::GatewayCommand(text) => {
                state.ctrl_c_count = 0;

                if !text.is_empty() {
                    state.push_send_history(text.clone());
                }

                // Not `send_to_agent` directly: a `/btw` must reach the
                // overlay instead of the transcript, and that decision has to
                // be made BEFORE anything is echoed into the conversation the
                // side question is supposed to stay out of.
                dispatch_gateway_text(state, client, &text, "Command error").await;
            }
            Action::CancelRun(run_id) => {
                if !rpc_jobs.enqueue(
                    client,
                    rpc_jobs::RpcTag {
                        scope: rpc_scope.clone(),
                        method: "agent.cancel",
                        identity: run_id.clone(),
                    },
                    Some(json!({ "run_id": run_id })),
                ) {
                    state.add_system_message(
                        "Cancellation already pending or requests busy; retry shortly.".into(),
                    );
                }
            }

            // -- Scrolling --
            Action::ScrollUp(n) => state.scroll_up(n),
            Action::ScrollDown(n) => state.scroll_down(n),
            Action::ScrollToBottom => state.scroll_to_bottom(),

            // -- Folding --
            Action::ToggleRow(id) => state.toggle_tool_expanded(&id),
            Action::ToggleExpandAll => state.toggle_expand_all(),

            // -- Focus --
            Action::FocusInput => {
                state.focus = Focus::Input;
            }
            Action::FocusInputWithChar(ch) => {
                state.focus = Focus::Input;
                // The chat panel handler returned this when a printable key
                // both switched focus AND typed a character; the focus switch
                // would otherwise silently swallow the keystroke. Inserting
                // here (after the focus flip) means the character lands at
                // the cursor in the input textarea instead of vanishing.
                textarea.insert_char(ch);
            }
            Action::FocusChat => {
                state.focus = Focus::Chat;
            }

            // -- Overlays --
            Action::OpenCommandPalette => {
                state.open_command_palette();
            }
            Action::CloseOverlay => {
                state.close_overlay();
                // A Windows native console can retain cells from a Unicode overlay
                // when the incremental diff crosses wide-character boundaries. A
                // close is the one transition where stale physical cells are
                // unacceptable, so reset the backend and force the next full frame.
                terminal.clear()?;
                terminal.swap_buffers();
                needs_redraw = true;
            }
            Action::PaletteUp => {
                if let Some(palette) = &mut state.palette {
                    if palette.selected > 0 {
                        palette.selected -= 1;
                    }
                }
            }
            Action::PaletteDown => {
                if let Some(palette) = &mut state.palette {
                    if palette.selected + 1 < palette.filtered.len() {
                        palette.selected += 1;
                    }
                }
            }
            Action::PaletteConfirm => {
                if let Some(palette) = state.palette.take() {
                    // The entry names the command; anything the user typed
                    // after it is its argument (`PaletteState::selected_command`).
                    // Without that, the palette could only ever run a command
                    // bare — and it is the only route to one, `/` on an empty
                    // composer opening the palette instead of typing a slash.
                    if let Some(cmd_str) = palette.selected_command() {
                        state.close_overlay();
                        // Parse through our unified parser
                        match slash::parse_input(&cmd_str) {
                            ParsedInput::Local(cmd) => {
                                let request =
                                    execute_local_command(state, textarea, client, cmd).await;
                                enqueue_command_rpc(
                                    state,
                                    client,
                                    &mut rpc_jobs,
                                    &rpc_scope,
                                    request,
                                    &mut replay_sequence,
                                );
                            }
                            ParsedInput::Gateway(text) => {
                                // Same single dispatcher as the typed path —
                                // the palette is a second way to type a
                                // command, not a second set of rules for what
                                // one means.
                                dispatch_gateway_text(state, client, &text, "Command error").await;
                            }
                            ParsedInput::NotSlashCommand => {
                                // Shouldn't happen from palette, but handle gracefully
                            }
                        }
                    } else {
                        state.close_overlay();
                    }
                }
            }

            // -- Dialog --
            // `DialogSelect` is gone: its only producer was the out-of-range
            // branch of the digit key, and an out-of-range digit is now the
            // first character of a typed answer. Moving the highlight is what
            // the arrow keys do, and they mutate `DialogState` in place.
            Action::RespondToDialog { session_key, reply } => {
                if !state.interaction.active_dialog().is_some_and(|dialog| {
                    dialog.session_key == session_key
                        && dialog.pending_reply().as_deref() == Some(reply.as_str())
                }) {
                    continue;
                }
                if let Some(ticket) = state.interaction.submit() {
                    let identity = ticket.rpc_identity();
                    let params = serde_json::to_value(&ticket.params)?;
                    let tag = rpc_jobs::RpcTag {
                        scope: rpc_scope.clone(),
                        method: "clarification.resolve",
                        identity: identity.clone(),
                    };
                    if rpc_jobs.enqueue(client, tag, Some(params)) {
                        submissions.insert(identity, ticket);
                    } else {
                        state.interaction.acknowledge(&ticket, None);
                        state.add_system_message(
                            "Request queue is busy; the answer is retained. Retry shortly.".into(),
                        );
                    }
                    state.sync_modal_focus();
                }
            }

            // -- Tool approval --
            Action::JumpToUser(target) => state.request_sticky_jump(target),
            Action::LoadToolOutput { tool_call_id } => {
                if let Some(view) = &mut state.tool_output {
                    if view.tool_call_id == tool_call_id && view.can_load() {
                        view.load_due = true;
                    }
                }
            }
            Action::ResolveApproval { index } => {
                if let Some(card) = state.approval.as_ref() {
                    if let Some((_, decision)) = card.decisions.get(index) {
                        let tag = rpc_jobs::RpcTag {
                            scope: rpc_scope.clone(),
                            method: "exec.approval.resolve",
                            identity: card.id.clone(),
                        };
                        let params =
                            json!({ "id": card.id, "decision": decision, "resolved_by": "TUI" });
                        if !rpc_jobs.enqueue(client, tag, Some(params)) {
                            state.add_system_message("Approval is already submitting or the request queue is busy; the card is retained.".into());
                        }
                    }
                }
            }

            // -- Side question (`/btw`) --
            Action::BtwAbortOrClose => {
                btw_abort_or_close(state, client).await;
            }
            Action::BtwCopy => {
                // Fire-and-forget: OSC 52 has no reply, so the notice says
                // what was actually done rather than claiming success. Written
                // straight to the terminal rather than into ratatui's buffer —
                // it is a control sequence, not content, and the next frame
                // repaints over nothing.
                let notice = match state.btw.copyable() {
                    Some(answer) => {
                        let sequence = btw_overlay::osc52_clipboard_sequence(answer);
                        use std::io::Write as _;
                        let mut out = io::stdout();
                        if write!(out, "{sequence}").and_then(|()| out.flush()).is_ok() {
                            "Side answer sent to the terminal's clipboard (OSC 52)."
                        } else {
                            "Could not write to the terminal to copy the side answer."
                        }
                    }
                    None => "Nothing to copy yet.",
                };
                state.add_system_message(notice.to_string());
            }

            // -- Session picker --
            Action::SessionPickerUp => {
                if let Some(picker) = &mut state.session_picker {
                    if picker.selected > 0 {
                        picker.selected -= 1;
                    }
                }
            }
            Action::SessionPickerDown => {
                if let Some(picker) = &mut state.session_picker {
                    if picker.selected + 1 < picker.filtered.len() {
                        picker.selected += 1;
                    }
                }
            }
            Action::SessionPickerConfirm => {
                if let Some(key) = state.selected_session_key() {
                    state.close_overlay();
                    state.switch_session(&key);
                    state.transcript_needs_resync = true;
                    pending_refresh_due = true;
                    recovery_after = std::time::Instant::now();
                }
            }

            // -- Agents overlay --
            Action::AgentsUp => {
                if let Some(overlay) = &mut state.agents_overlay {
                    if overlay.selected > 0 {
                        overlay.selected -= 1;
                    }
                }
            }
            Action::AgentsDown => {
                let count = state.agents.len();
                if let Some(overlay) = &mut state.agents_overlay {
                    if overlay.selected + 1 < count {
                        overlay.selected += 1;
                    }
                }
            }
            Action::AgentsConfirm => {
                open_agent_detail(state, client).await;
            }
            Action::AgentsBack => {
                state.agents_overlay_back();
            }

            // -- Provider picker --
            Action::ProviderPickerUp => {
                if let Some(picker) = &mut state.provider_picker {
                    if picker.selected > 0 {
                        picker.selected -= 1;
                    }
                }
            }
            Action::ProviderPickerDown => {
                if let Some(picker) = &mut state.provider_picker {
                    if picker.selected + 1 < picker.rows.len() {
                        picker.selected += 1;
                    }
                }
            }
            Action::ProviderPickerConfirm => {
                confirm_provider_pick(state, client).await;
            }
            Action::ProviderPickerRefresh => {
                refresh_picker_provider(state, client).await;
            }
        }

        // One scroll decision per iteration, after everything that could have
        // changed the transcript has run — the burst-drain loops above append
        // several rows before returning a single action, so asking per event
        // would ask about states no frame was ever drawn from. See
        // `AppState::settle_scroll` for why it is not eighteen call sites.
        state.settle_scroll();

        // Check quit flag
        if state.should_quit {
            break;
        }
    }

    Ok(())
}

#[cfg(test)]
mod live_acceptance_tests;

#[cfg(test)]
mod theme_picker_tests;
#[cfg(test)]
mod theme_render_tests;

#[cfg(test)]
mod tests {
    use super::{
        agent_panel_data, model_caption, should_redraw_after_tick, tui_event_subscribe_params,
        AgentPanelData, AppState, ModelCaption, RUNTIME_AGENTS_CHANGED_TOPIC,
    };
    use aleph_client::CliError;
    use aleph_protocol::jsonrpc::{ADMIN_REQUIRED_MESSAGE, AUTH_REQUIRED};
    use aleph_protocol::providers::ProviderInfo;
    use aleph_protocol::runtime::{
        RuntimeAgentEntry, RuntimeAgentState, RuntimeAgentsListResponse,
    };
    use serde_json::json;

    /// Keep output-mode changes inside the alternate-screen lifetime, including
    /// setup failures and panics. This contract needs no live terminal.
    #[test]
    fn line_wrap_is_scoped_to_the_alternate_screen() {
        let src = include_str!("mod.rs").replace('\r', "");
        let production = src.split("#[cfg(test)]").next().unwrap();
        let code: String = production
            .lines()
            .filter(|line| !line.trim_start().starts_with("//"))
            .collect::<Vec<_>>()
            .join("\n");
        let run = code.split("pub async fn run(").nth(1).unwrap();
        let run = run.split("type ReconnectAttempt").next().unwrap();
        let (setup, rest) = run.split_once("let original_hook").unwrap();
        let (panic_hook, rest) = rest.split_once("original_hook(info);").unwrap();
        let cleanup = rest.split("let line_wrap_cleanup").nth(1).unwrap();

        let enter = setup.find("EnterAlternateScreen").unwrap();
        let disable = setup.find("DisableLineWrap").unwrap();
        let terminal = setup.find("Terminal::new(backend)").unwrap();
        assert!(enter < disable && disable < terminal);
        assert!(!setup[..enter].contains("EnableLineWrap"));
        assert!(setup[enter..disable].contains("return Err(error.into());"));

        let failure = setup.split("terminal_setup.inspect_err").nth(1).unwrap();
        for path in [failure, panic_hook, cleanup] {
            assert!(
                path.find("EnableLineWrap").unwrap() < path.find("LeaveAlternateScreen").unwrap(),
                "restore wrap before returning to the host buffer: {path}",
            );
        }
        assert!(failure.contains("DisableMouseCapture"));
        assert!(failure.contains("disable_raw_mode()"));
        // The same failure handler must cover both mode setup and Terminal::new.
        let terminal_setup = setup.split("let terminal_setup =").nth(1).unwrap();
        assert!(terminal_setup.contains("DisableLineWrap"));
        assert!(terminal_setup.contains("EnableBracketedPaste)?;"));
        assert!(terminal_setup.contains("Terminal::new(backend)"));
    }

    /// Build a `providers.list` reply the way the server does — from
    /// `ProviderInfo`, not from a JSON literal written here. A literal would
    /// only prove serde round-trips its own bytes; serialising the contract
    /// type is what makes a wire rename break this test.
    fn reply(rows: Vec<ProviderInfo>) -> Result<serde_json::Value, CliError> {
        Ok(serde_json::json!({ "providers": rows }))
    }

    fn provider(name: &str, models: &[&str], is_default: bool) -> ProviderInfo {
        let info: ProviderInfo = serde_json::from_value(serde_json::json!({
            "name": name,
            "is_default": is_default,
        }))
        .expect("ProviderInfo defaults cover every unset field");
        info.with_models(models.iter().map(|m| (*m).to_string()).collect())
    }

    #[test]
    fn the_caption_is_the_default_provider_s_first_rung() {
        let ModelCaption { caption, note } = model_caption(reply(vec![
            provider("relay", &["fallback-model"], false),
            provider("openai", &["default-model", "second-rung"], true),
        ]));
        assert_eq!(caption, "default-model");
        assert!(note.is_none(), "a plain answer needs no explanation");
    }

    /// "I was refused" and "there is nothing" must not share a caption. The
    /// `providers.*` family is operator-only, so a member takes this branch on
    /// every launch — captioning it like an empty install states something the
    /// server never said.
    #[test]
    fn a_refusal_is_not_an_empty_install() {
        let refused = model_caption(Err(CliError::Rpc {
            code: AUTH_REQUIRED,
            message: ADMIN_REQUIRED_MESSAGE.to_string(),
        }));
        let empty = model_caption(reply(Vec::new()));
        let offline = model_caption(Err(CliError::Timeout("no response in 30s".into())));

        assert_eq!(refused.caption, "restricted");
        assert_eq!(empty.caption, "none");
        assert_eq!(offline.caption, "unavailable");
        // Each of the three non-answers explains itself once in the transcript;
        // the caption alone cannot.
        for outcome in [&refused, &empty, &offline] {
            assert!(outcome.note.is_some(), "{} says nothing", outcome.caption);
        }
        assert!(refused.note.as_ref().unwrap().contains("not an operator"));
        assert!(offline
            .note
            .as_ref()
            .unwrap()
            .contains("no response in 30s"));
    }

    #[test]
    fn tick_with_no_active_run_and_no_connection_change_does_not_redraw() {
        assert!(!should_redraw_after_tick(false, false));
    }

    #[test]
    fn tick_with_an_active_run_redraws_to_animate_the_spinner() {
        assert!(should_redraw_after_tick(true, false));
    }

    #[test]
    fn tick_with_a_connection_state_change_redraws_even_when_idle() {
        assert!(should_redraw_after_tick(false, true));
    }

    fn agent_entry(session_id: &str) -> RuntimeAgentEntry {
        RuntimeAgentEntry {
            session_id: session_id.to_string(),
            label: "claude".into(),
            cwd: "/tmp".into(),
            agent: Some("claude".into()),
            program: None,
            state: RuntimeAgentState::Working,
            updated_at: 1,
            quiet_since: None,
        }
    }

    /// `agent_panel_data`'s mapping, mirroring `a_refusal_is_not_an_empty_install`
    /// above for the exact same reason: a `runtime.agents.list` refusal and an
    /// install with nothing running must not collapse into the same shape.
    #[test]
    fn a_runtime_agents_refusal_is_distinguished_from_every_other_failure() {
        let ready = agent_panel_data(Ok(RuntimeAgentsListResponse {
            agents: vec![agent_entry("s1")],
        }));
        let refused = agent_panel_data(Err(CliError::Rpc {
            code: AUTH_REQUIRED,
            message: ADMIN_REQUIRED_MESSAGE.to_string(),
        }));
        let unavailable = agent_panel_data(Err(CliError::Timeout("no response in 30s".into())));

        assert!(matches!(ready, AgentPanelData::Ready(ref v) if v.len() == 1));
        match refused {
            // The mapping passes the message through untouched — assert
            // equality with the shared constant, not a substring of its
            // wording, so this test stays green if that wording ever
            // changes (another page keys off it too — see
            // `ADMIN_REQUIRED_MESSAGE`'s own doc) and only reddens if the
            // pass-through itself breaks.
            AgentPanelData::Refused(msg) => assert_eq!(msg, ADMIN_REQUIRED_MESSAGE),
            other => panic!("AUTH_REQUIRED must map to Refused, not {other:?}"),
        }
        match unavailable {
            AgentPanelData::Unavailable(msg) => assert!(msg.contains("no response in 30s")),
            other => panic!("a non-gate failure must map to Unavailable, not {other:?}"),
        }
    }

    /// The round trip R8-7 asks for: a `runtime.agents.changed` topic event
    /// arriving ends with `runtime_agents` holding entries it did not have
    /// before — not merely a flag having flipped (判据 §4). A flag DOES flip
    /// here (`runtime_agents_refetch_due` — see its doc for why the fix-round-1
    /// design deliberately makes the pending re-fetch state, not an `Action`
    /// that a burst-coalescing drain could silently lose), but this test does
    /// not stop at that: it drives the REAL functions production uses
    /// (`AppState::handle_topic_event`, `agent_panel_data` — the same mapping
    /// `refresh_runtime_agents` applies to a real RPC reply) in the sequence
    /// the main loop drives them, and asserts the state that comes out the
    /// other end. The one link this cannot exercise without a live socket is
    /// `client.call` itself, already covered by `shared/client`'s own test
    /// suite; `a_runtime_agents_refetch_flag_is_wired_to_the_refetch_call`
    /// below closes the remaining gap — that `main_loop` actually acts on the
    /// flag this test sets.
    #[test]
    fn a_runtime_agents_changed_topic_ends_with_new_entries_in_state() {
        let mut state = AppState::new("s".into(), "m".into());
        assert!(
            matches!(state.runtime_agents, AgentPanelData::Loading),
            "must start with no answer yet"
        );
        assert!(
            !state.runtime_agents_refetch_due,
            "must start with nothing pending"
        );

        state.handle_topic_event(RUNTIME_AGENTS_CHANGED_TOPIC, serde_json::json!({}));
        assert!(
            state.runtime_agents_refetch_due,
            "the one topic this phase understands must set the re-fetch flag"
        );

        let fixture = RuntimeAgentsListResponse {
            agents: vec![agent_entry("s1"), agent_entry("s2")],
        };
        // What `refresh_runtime_agents` does with a real RPC reply, called
        // directly here instead of over a socket — see this test's doc.
        state.runtime_agents = agent_panel_data(Ok(fixture.clone()));

        match &state.runtime_agents {
            AgentPanelData::Ready(entries) => assert_eq!(
                entries, &fixture.agents,
                "state must hold the NEW entries, not the Loading it started with"
            ),
            other => panic!("expected Ready(entries), got {other:?}"),
        }
    }

    /// Every subscription entry point keeps chat frames and both topic planes.
    #[test]
    fn subscriptions_keep_chat_stream_and_browser_runtime_topics() {
        use aleph_protocol::browser_live::{CLOSED_TOPIC, RESOURCE_TOPIC};
        assert_eq!(
            tui_event_subscribe_params(),
            json!({ "topics": ["stream.*", RUNTIME_AGENTS_CHANGED_TOPIC, RESOURCE_TOPIC, CLOSED_TOPIC] })
        );
        assert_eq!(RESOURCE_TOPIC, "browser.live.resource");
        assert_eq!(CLOSED_TOPIC, "browser.live.closed");
    }

    /// On T1.8's bug shape: a `subscribe_runtime_agents` whose `events.subscribe`
    /// RPC fails on a freshly re-opened socket must NOT silently freeze the
    /// panel — the next `main_loop` tick has to retry the re-fetch via the
    /// same flag the topic-event path already uses (`runtime_agents_refetch_due`).
    ///
    /// `AlephClient::connect` opens a real TCP socket and `events.subscribe`
    /// goes through `client.call`, so an in-process "connect, then break the
    /// socket" fixture exists in principle (`shared/client`'s tests do it for
    /// other arms) but spinning one up here would land a multi-hundred-line
    /// server in an L1 fix whose job is the failure-path shape, not the
    /// transport. Source-level, for the same reason the wiring tests above are:
    /// a runtime call cannot tell "subscribed successfully" from "subscribed
    /// and the result was discarded", and a `match` arm the source no longer
    /// contains cannot satisfy the assertion. Comment lines are stripped
    /// first so a comment naming `tracing::warn!` cannot satisfy the
    /// "emits a warn" check.
    #[test]
    fn subscribe_runtime_agents_failure_path_sets_refetch_due_and_warns() {
        let src = include_str!("mod.rs").replace('\r', "");
        let production = src.split("#[cfg(test)]").next().expect("split yields one");
        let code: String = production
            .lines()
            .filter(|l| !l.trim_start().starts_with("//"))
            .collect::<Vec<_>>()
            .join("\n");

        // Bounded to `subscribe_runtime_agents`'s body — a `Result`-returning
        // function named something else in this file would otherwise satisfy
        // the shape assertions below while the actual function still has the
        // pre-T1.8 `let _ =` swallow.
        let fn_start = code
            .find("async fn subscribe_runtime_agents")
            .expect("subscribe_runtime_agents must still exist");
        let fn_open_brace = code[fn_start..]
            .find('{')
            .map(|i| fn_start + i)
            .expect("subscribe_runtime_agents must have a body");
        let fn_close_brace = code[fn_open_brace..]
            .find("\n}")
            .map(|i| fn_open_brace + i)
            .expect("subscribe_runtime_agents must close");
        let body = &code[fn_open_brace..fn_close_brace];

        // 1. The signature must surface the failure, not swallow it the way
        //    the pre-T1.8 `let _ = client.call(...).await;` did. Either spelling
        //    counts — `-> Result<…>` directly or `-> CliResult<…>` (the type
        //    alias this crate imports) — but a bare `-> ()` or a missing
        //    return type does NOT.
        let signature_end = code[fn_start..]
            .find('{')
            .expect("signature must terminate");
        let signature = &code[fn_start..fn_start + signature_end];
        assert!(
            signature.contains("-> Result") || signature.contains("-> CliResult"),
            "subscribe_runtime_agents must return a Result so the reconnect arm \
             can observe a failed subscribe — got signature: `{}`",
            signature.trim(),
        );

        // 2. The failure branch must (a) log a warn so a frozen-looking panel
        //    leaves a breadcrumb in `RUST_LOG`, and (b) set the flag the
        //    existing `main_loop` retry hook already polls on.
        assert!(
            body.contains("tracing::warn"),
            "a failed subscribe must produce a warn-level log entry; without \
             one, the panel going dark on a re-opened socket is invisible. \
             Got body:\n{}",
            body,
        );
        assert!(
            body.contains("runtime_agents_refetch_due = true"),
            "a failed subscribe must mark a re-fetch as due so the next \
             `main_loop` tick retries — that is the existing retry hook the \
             topic-event path already rides. Got body:\n{}",
            body,
        );
    }
}

#[cfg(test)]
mod reconnect_tests {
    use super::next_backoff;
    use std::time::Duration;

    /// The first attempt after a drop goes out immediately. The common case is
    /// a gateway that restarted and is already listening again, and making that
    /// case wait is making every user wait for the rare one.
    #[test]
    fn the_first_attempt_is_not_delayed() {
        assert_eq!(next_backoff(Duration::ZERO), Duration::from_secs(1));
    }

    /// Doubling, so a long outage is not a busy loop.
    #[test]
    fn each_failure_waits_longer_than_the_last() {
        assert_eq!(next_backoff(Duration::from_secs(1)), Duration::from_secs(2));
        assert_eq!(next_backoff(Duration::from_secs(4)), Duration::from_secs(8));
    }

    /// …to a ceiling, so a user who fixes the network is not left waiting for
    /// an exponent. Unbounded doubling is how a client that "reconnects
    /// automatically" ends up taking ten minutes to notice a server that came
    /// back in ten seconds.
    #[test]
    fn the_wait_stops_growing_at_the_ceiling() {
        assert_eq!(
            next_backoff(Duration::from_secs(10)),
            Duration::from_secs(15)
        );
        assert_eq!(
            next_backoff(Duration::from_secs(15)),
            Duration::from_secs(15)
        );
    }
}

#[cfg(test)]
mod recovery_probe_tests {
    use super::*;
    #[test]
    fn only_a_matching_authoritative_terminal_unblocks_history_recovery() {
        let mut state = AppState::new("s".into(), "m".into());
        state.current_run = Some("r".into());
        let mut report = aleph_protocol::AgentRunStatusReport {
            run_id: "r".into(),
            status: "running".into(),
            ..Default::default()
        };
        recover_missing_terminal(&mut state, "r", &report);
        assert_eq!(state.current_run.as_deref(), Some("r"));
        report.status = "completed".into();
        recover_missing_terminal(&mut state, "other", &report);
        assert_eq!(state.current_run.as_deref(), Some("r"));
        recover_missing_terminal(&mut state, "r", &report);
        assert!(state.current_run.is_none());
        assert!(state.transcript_needs_resync);
    }
}
