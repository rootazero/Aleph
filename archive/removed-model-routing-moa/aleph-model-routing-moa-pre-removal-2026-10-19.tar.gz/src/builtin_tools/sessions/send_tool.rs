//! Sessions Send Tool
//!
//! Enables cross-session communication by sending messages to other sessions
//! (same or different agents). Supports both fire-and-forget and wait-for-reply modes.
//!
//! # Example
//!
//! ```rust,ignore
//! // Fire-and-forget mode
//! let args = SessionsSendArgs {
//!     session_key: Some("agent:translator:main".to_string()),
//!     message: "Translate this to French".to_string(),
//!     timeout_seconds: 0, // fire-and-forget
//! };
//!
//! // Wait mode (default 30s)
//! let args = SessionsSendArgs {
//!     session_key: None, // defaults to main session
//!     message: "Hello world".to_string(),
//!     timeout_seconds: 30,
//! };
//! ```

use crate::sync_primitives::Arc;
use std::collections::HashMap;

use async_trait::async_trait;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use tracing::{debug, info, warn};

use crate::error::Result;
use crate::gateway::context::GatewayContext;
use crate::gateway::event_emitter::NoOpEventEmitter;
use crate::gateway::execution_engine::RunRequest;
use crate::gateway::router::SessionKey;
use crate::tools::AlephTool;

use super::super::notify_tool_start;
use super::helpers::parse_session_key;

/// Arguments for `sessions_send` tool
#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
pub struct SessionsSendArgs {
    /// Target session key (defaults to main if not specified)
    ///
    /// Format: `agent:<agent_id>:<session_type>:<id>`
    /// Examples:
    /// - `agent:main:main` - main session
    /// - `agent:translator:main` - translator agent's main session
    /// - `agent:main:dm:user123` - DM session
    #[serde(default)]
    pub session_key: Option<String>,

    /// Message to send to the target session
    pub message: String,

    /// Timeout in seconds.
    /// - 0 = fire-and-forget (returns immediately with Accepted status)
    /// - >0 = wait for response (default: 30 seconds)
    #[serde(default = "default_timeout")]
    pub timeout_seconds: u32,
}

const fn default_timeout() -> u32 {
    30
}

/// Hard upper bound on the message body for `session_send`. The body is
/// forwarded into the receiving runner's prompt, persisted into that session's
/// history, and replayed on every subsequent read. 64 KiB is well past any
/// realistic cross-session prompt (the practical ceiling is single-digit KB)
/// while still leaving headroom for inline code attachments.
const MAX_CROSS_SESSION_MESSAGE_CHARS: usize = 64 * 1024;

/// Default fire-and-forget timeout when `args.timeout_seconds == 0` —
/// five minutes, matching the long-tail RPC ceiling. The literal
/// was inlined at the call site before; named here so a future
/// change to either the default or the max timeout lands in one
/// place.
const DEFAULT_FIRE_AND_FORGET_TIMEOUT_SECS: u64 = 300;

/// Status of the `sessions_send` operation
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum SessionsSendStatus {
    /// Successfully sent and received response
    Ok,
    /// Fire-and-forget accepted (`timeout_seconds` was 0)
    Accepted,
    /// Timed out waiting for response
    Timeout,
    /// A2A policy denied the communication
    Forbidden,
    /// Other error occurred
    Error,
}

/// Output from `sessions_send` tool
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionsSendOutput {
    /// Unique identifier for this run
    pub run_id: String,
    /// Status of the operation
    pub status: SessionsSendStatus,
    /// Response from target session (if waited and received)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub reply: Option<String>,
    /// Target session key that was used
    #[serde(skip_serializing_if = "Option::is_none")]
    pub session_key: Option<String>,
    /// Error message if status is Error
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

impl SessionsSendOutput {
    /// Create an Ok response with reply
    #[must_use]
    pub const fn ok(run_id: String, session_key: String, reply: String) -> Self {
        Self {
            run_id,
            status: SessionsSendStatus::Ok,
            reply: Some(reply),
            session_key: Some(session_key),
            error: None,
        }
    }

    /// Create an Accepted response (fire-and-forget)
    #[must_use]
    pub const fn accepted(run_id: String, session_key: String) -> Self {
        Self {
            run_id,
            status: SessionsSendStatus::Accepted,
            reply: None,
            session_key: Some(session_key),
            error: None,
        }
    }

    /// Create a Timeout response
    #[must_use]
    pub const fn timeout(run_id: String, session_key: String) -> Self {
        Self {
            run_id,
            status: SessionsSendStatus::Timeout,
            reply: None,
            session_key: Some(session_key),
            error: None,
        }
    }

    /// Create a Forbidden response
    #[must_use]
    pub const fn forbidden(run_id: String, error: String) -> Self {
        Self {
            run_id,
            status: SessionsSendStatus::Forbidden,
            reply: None,
            session_key: None,
            error: Some(error),
        }
    }

    /// Create an Error response
    #[must_use]
    pub const fn error(run_id: String, error: String) -> Self {
        Self {
            run_id,
            status: SessionsSendStatus::Error,
            reply: None,
            session_key: None,
            error: Some(error),
        }
    }
}

/// Sessions send tool for cross-session communication
///
/// Requires `GatewayContext` to access:
/// - `AgentRegistry`: to find the target agent
/// - `ExecutionAdapter`: to execute the run
/// - `AgentToAgentPolicy`: to check communication permissions
/// - `SessionManager`: to fetch the reply from history
#[derive(Clone)]
pub struct SessionsSendTool {
    /// Gateway context containing required components
    context: Option<GatewayContext>,
    /// Current agent ID (requester)
    current_agent_id: String,
}

impl SessionsSendTool {
    /// Tool identifier
    pub const NAME: &'static str = "session_send";

    /// Tool description for AI prompt
    pub const DESCRIPTION: &'static str =
        "Send a message to another session (same or different agent). \
        Supports fire-and-forget (timeout_seconds=0) or wait-for-reply modes. \
        Use this to delegate tasks to other agents or communicate across sessions.";

    /// Create a new `SessionsSendTool` without context (will fail on execute)
    #[must_use]
    pub fn new() -> Self {
        Self {
            context: None,
            current_agent_id: "main".to_string(),
        }
    }

    /// Create a new `SessionsSendTool` with gateway context
    pub fn with_context(context: GatewayContext, current_agent_id: impl Into<String>) -> Self {
        Self {
            context: Some(context),
            current_agent_id: current_agent_id.into(),
        }
    }

    /// Set the gateway context
    pub fn set_context(&mut self, context: GatewayContext) {
        self.context = Some(context);
    }

    // No `set_current_agent_id`: the dispatch arm builds this tool per call
    // with `caller_agent_id()` (the running turn's identity), so a mutator
    // would have had nothing left to correct. It had zero callers for exactly
    // that reason — CUT rather than reconnected (R10 YAGNI).

    /// Fetch the last assistant reply from a target agent's session
    async fn fetch_last_reply(
        agent: &crate::gateway::agent_instance::AgentInstance,
        session_key: &crate::routing::session_key::SessionKey,
    ) -> Option<String> {
        let history = agent
            .get_history(&session_key_to_gateway(session_key), Some(1))
            .await;
        history
            .last()
            .filter(|msg| {
                matches!(
                    msg.role,
                    crate::gateway::agent_instance::MessageRole::Assistant
                )
            })
            .map(|msg| msg.content.clone())
    }

    /// Execute the tool (internal implementation)
    async fn call_impl(&self, args: SessionsSendArgs) -> SessionsSendOutput {
        let run_id = uuid::Uuid::new_v4().to_string();

        // Bound the message body at the dispatcher: a multi-MB cross-session
        // message blocks the gateway and the receiving runner, and there is no
        // downstream reader that wants more than a few KB of prompt.
        if args.message.len() > MAX_CROSS_SESSION_MESSAGE_CHARS {
            return SessionsSendOutput::error(
                run_id,
                format!(
                    "session_send message is {} chars; the cap is {MAX_CROSS_SESSION_MESSAGE_CHARS} \
                     chars. Split the message or attach large payloads as artifacts.",
                    args.message.len()
                ),
            );
        }

        notify_tool_start(
            Self::NAME,
            &format!(
                "Sending to {:?}, timeout={}s",
                args.session_key, args.timeout_seconds
            ),
        );

        // Validate context is available
        let context = match &self.context {
            Some(ctx) => ctx,
            None => {
                return SessionsSendOutput::error(
                    run_id,
                    "GatewayContext not configured for sessions_send tool".to_string(),
                );
            }
        };

        // Parse target session key
        let target_session_key = match &args.session_key {
            Some(key_str) => match parse_session_key(key_str) {
                Ok(key) => key,
                Err(e) => {
                    return SessionsSendOutput::error(run_id, format!("Invalid session key: {e}"));
                }
            },
            None => {
                // Default to main session
                crate::routing::session_key::SessionKey::main("main")
            }
        };

        let target_key_str = target_session_key.to_key_string();
        let target_agent_id = target_session_key.agent_id().to_string();

        // `args.session_key` is MODEL-supplied, and this tool DISPATCHES A RUN
        // into whatever it names. Its deliberate siblings in this same
        // directory — `session_compact`, `set_topic`, `set_mode`,
        // `session_new` — all address the INJECTED `args.__session_key` the
        // model cannot choose; this one is the exception, and the only check
        // standing in front of it was `a2a_policy`, whose production default is
        // permissive (`allow_patterns: ["*"]`). An agent→agent policy is not an
        // ownership predicate: it answers "may main talk to coder", never
        // "whose conversation is this".
        //
        // A key that resolves to NO row stays allowed — that is
        // `existing_session_is_visible`'s asymmetry, and a brand-new
        // conversation is the normal case. Refusal reuses the tool's own
        // not-found text so a foreign key and an absent key read identically.
        match context
            .session_store()
            .get_metadata(&target_session_key)
            .await
        {
            Ok(Some(meta)) => {
                // `ambient_actor` is the resolver, NOT `visible_owner_filter`
                // (reads `CALLER_USER`, dead inside a spawned run, and a tool
                // call is always inside one) and NOT `ambient_owner` (answers
                // with the run's scope owner, which in a project room is the
                // room's CREATOR for every member — so a member's turn inside
                // someone else's room could dispatch a run into that person's
                // PERSONAL session). `None` (cron / A2A / internal) is
                // unrestricted, matching every sibling predicate.
                let admitted = crate::gateway::visibility::ambient_actor().is_none_or(|actor| {
                    crate::gateway::visibility::session_visible_to(&meta, &actor)
                });
                if !admitted {
                    return SessionsSendOutput::error(
                        run_id,
                        format!("No session found for key '{target_key_str}'"),
                    );
                }
            }
            Ok(None) => {}
            // Fail closed: we could not establish whose session this is, and
            // this call starts a run inside it.
            Err(_) => {
                return SessionsSendOutput::error(
                    run_id,
                    format!("No session found for key '{target_key_str}'"),
                );
            }
        }

        debug!(
            run_id = %run_id,
            from = %self.current_agent_id,
            to = %target_agent_id,
            session = %target_key_str,
            "sessions_send: checking A2A policy"
        );

        // Check A2A policy
        let a2a_policy = context.a2a_policy();
        if !a2a_policy.is_allowed(&self.current_agent_id, &target_agent_id) {
            warn!(
                run_id = %run_id,
                from = %self.current_agent_id,
                to = %target_agent_id,
                "sessions_send: A2A policy denied"
            );
            return SessionsSendOutput::forbidden(
                run_id,
                format!(
                    "A2A policy denies communication from '{}' to '{}'",
                    self.current_agent_id, target_agent_id
                ),
            );
        }

        let agent_registry = context.agent_registry();

        // The human axis, and the other half of the A2A check above: that one
        // asks "may THIS AGENT reach that agent", this one asks "may the
        // PERSON driving this run reach it" (`AgentDefinition::allowed_users`,
        // enforced at run start by `handlers::agent::build_run_request`).
        //
        // Without it `allowed_users` is a one-step gate with a two-step
        // bypass: a caller refused `ops` at run start names an agent they ARE
        // allowed and has it delegate — both steps legal, the pair equivalent.
        // It is the same argument that already makes this tool forward
        // `channel_tool_permissions` to the child run: a restriction the
        // parent turn ran under must not evaporate at a delegation boundary.
        //
        // Resolver is `ambient_actor()` — the one this file already uses for
        // the session check above, and the only one that survives the spawn a
        // tool call always runs inside. `None` (cron / A2A / internal) is
        // unrestricted, like every sibling predicate.
        if let Some(allowed) = agent_registry.get_allowed_users(&target_agent_id).await {
            let actor = crate::gateway::visibility::ambient_actor();
            if !crate::config::types::agent_admits_user(allowed.as_deref(), actor.as_deref()) {
                warn!(
                    run_id = %run_id,
                    from = %self.current_agent_id,
                    to = %target_agent_id,
                    "sessions_send: target agent's allowed_users denies this caller"
                );
                return SessionsSendOutput::forbidden(
                    run_id,
                    format!(
                        "not authorized to delegate to agent '{target_agent_id}' \
                         (its `allowed_users` list does not include you)"
                    ),
                );
            }
        }

        // Get target agent from registry
        let target_agent = match agent_registry.get(&target_agent_id).await {
            Some(agent) => agent,
            None => {
                return SessionsSendOutput::error(
                    run_id,
                    format!("Target agent '{target_agent_id}' not found in registry"),
                );
            }
        };

        // Convert routing::SessionKey to gateway::router::SessionKey
        let gateway_session_key = session_key_to_gateway(&target_session_key);

        // Inherit the parent run's project root so a sub-agent invoked
        // mid-flow (e.g. main → coder during a project-scoped chat) lands
        // inside the same user-picked folder rather than reverting to
        // `~/.aleph/workspaces/{agent_id}/`. Captured BEFORE any spawn
        // because tokio task-locals do not cross the `tokio::spawn`
        // boundary used by fire-and-forget below.
        let inherited_workspace = crate::projects::current_project_root();
        // Same capture-before-spawn rule, same reason, and the sibling that was
        // missing: a delegated run inherits WHOSE it is, not just where it runs.
        let inherited_scope = crate::scope::current_scope();
        // Same capture-before-spawn rule, same reason, and the sibling that was
        // still missing: WHO is speaking, not just whose scope this is. In a
        // project room the two differ, and `run_loop::with_request_scope` seeds
        // `ambient_actor()`'s room-speaker arm from this key alone — losing it
        // resolves every member's delegated child to the room's CREATOR
        // instead (`scope::room_author`'s fallback).
        let inherited_room_author = crate::scope::current_room_author();
        // Same capture-before-spawn rule once more: WHERE a public telecom run
        // came from. Read from the run-origin task-local (seeded only from the
        // parent request's own admitted `telecom_public`, never from a model
        // argument) and stored as the typed `RunRequest.telecom_public` field,
        // so the fire-and-forget `tokio::spawn` below — which drops task-locals
        // — and the auto-continuation request both carry the same value. An
        // ordinary / unseeded parent reads `None`: this path never upgrades a
        // run's origin, it only refuses to launder a public one into "ordinary".
        let inherited_telecom_public = crate::gateway::telecom::run_origin::current_run_origin();
        // `TURN_CONTEXT` is reliably in scope here (ScopedToolService scopes it
        // around every tool dispatch and reading it does not cross a
        // `tokio::spawn` boundary), so the dispatching turn's `caller_role` AND
        // its channel `tool_permissions` deny layer are captured before any spawn.
        let turn = crate::tools::turn_context::current_turn_context();
        // A wait-mode child of a HEADLESS parent (goal / loop continuation,
        // cron, heartbeat) is just as unattended as the parent: nobody can
        // answer its approval cards either. Without inheriting the flag it
        // would park on the 120 s approval timeout per gated tool instead of
        // failing closed instantly. Fire-and-forget stays stamped regardless.
        let parent_unattended = turn.as_ref().is_some_and(|t| t.unattended);
        let sub_metadata = build_sub_metadata(
            inherited_workspace.as_deref(),
            turn.as_ref().and_then(|t| t.caller_role.clone()),
            turn.as_ref()
                .and_then(|t| t.channel_tool_permissions.clone()),
            args.timeout_seconds == 0 || parent_unattended,
            inherited_scope.as_ref(),
            inherited_room_author,
        );

        // Tree budget (goal × session_send): when the CALLING session carries an
        // active budgeted goal, refuse a NEW delegation once the shared budget
        // is spent (an F9 compact refusal the model can act on), else enroll the
        // target under the GATEWAY key it accrues tokens under. Shared seam with
        // team_delegate / the autonomous dispatcher — see `goal_budget`.
        if let Some(caller_session) = crate::tools::turn_context::current_session_key() {
            if let crate::gateway::goal_budget::DelegationBudget::Refused(reason) =
                crate::gateway::goal_budget::check_and_enroll_delegation(
                    context.session_store(),
                    &caller_session,
                    &gateway_session_key,
                    true,
                )
                .await
            {
                return SessionsSendOutput::error(run_id, reason);
            }
        }

        // Create run request
        let request = RunRequest {
            run_id: run_id.clone(),
            input: args.message.clone(),
            session_key: gateway_session_key,
            timeout_secs: if args.timeout_seconds > 0 {
                Some(u64::from(args.timeout_seconds))
            } else {
                Some(DEFAULT_FIRE_AND_FORGET_TIMEOUT_SECS)
            },
            metadata: sub_metadata.clone(),
            attachments: Vec::new(),
            pending_media: Arc::new(tokio::sync::Mutex::new(Vec::new())),
            sandbox_override: None,
            workspace_override: inherited_workspace.clone(),
            max_iterations_override: None,
            model_override: None,
            telecom_public: inherited_telecom_public.clone(),
            telecom_authority: None,
        };

        // Get execution adapter
        let execution_adapter = context.execution_adapter();

        // Create a no-op emitter for this execution
        let emitter: Arc<dyn crate::gateway::event_emitter::EventEmitter + Send + Sync> =
            Arc::new(NoOpEventEmitter::new());

        // Fire-and-forget mode
        if args.timeout_seconds == 0 {
            info!(
                run_id = %run_id,
                target = %target_key_str,
                "sessions_send: fire-and-forget mode"
            );

            // Spawn execution in background
            let adapter = execution_adapter.clone();
            let agent = target_agent.clone();
            let emitter_clone = emitter.clone();
            let run_id_clone = run_id.clone();

            tokio::spawn(async move {
                if let Err(e) = adapter.execute(request, agent, emitter_clone).await {
                    warn!(
                        run_id = %run_id_clone,
                        error = %e,
                        "sessions_send: background execution failed"
                    );
                }
            });

            return SessionsSendOutput::accepted(run_id, target_key_str);
        }

        // Wait mode: execute and wait for completion
        info!(
            run_id = %run_id,
            target = %target_key_str,
            timeout = args.timeout_seconds,
            "sessions_send: wait mode"
        );

        let timeout_duration = std::time::Duration::from_secs(u64::from(args.timeout_seconds));

        // Execute with timeout
        let execution_result = tokio::time::timeout(
            timeout_duration,
            execution_adapter.execute(request, target_agent.clone(), emitter),
        )
        .await;

        match execution_result {
            Ok(Ok(())) => {
                // Execution completed successfully, fetch the last assistant message
                let reply = Self::fetch_last_reply(&target_agent, &target_session_key).await;

                match reply {
                    Some(content) => {
                        // Check if the sub-agent's response was truncated (contains truncation marker)
                        // If so, automatically send a continuation request once
                        let content = if content.contains("[output truncated") {
                            info!(
                                run_id = %run_id,
                                target = %target_key_str,
                                "sessions_send: sub-agent response truncated, auto-continuing"
                            );
                            // Send a continuation request to the sub-agent
                            let continue_request = RunRequest {
                                run_id: format!("{run_id}-continue"),
                                input: "Please continue from where you left off".to_string(),
                                session_key: session_key_to_gateway(&target_session_key),
                                timeout_secs: Some(u64::from(args.timeout_seconds)),
                                metadata: sub_metadata.clone(),
                                attachments: Vec::new(),
                                pending_media: Arc::new(tokio::sync::Mutex::new(Vec::new())),
                                sandbox_override: None,
                                workspace_override: inherited_workspace.clone(),
                                max_iterations_override: None,
                                model_override: None,
                                telecom_public: inherited_telecom_public.clone(),
                                telecom_authority: None,
                            };
                            let continue_emitter: Arc<
                                dyn crate::gateway::event_emitter::EventEmitter + Send + Sync,
                            > = Arc::new(NoOpEventEmitter::new());
                            let continue_result = tokio::time::timeout(
                                timeout_duration,
                                execution_adapter.execute(
                                    continue_request,
                                    target_agent.clone(),
                                    continue_emitter,
                                ),
                            )
                            .await;

                            match continue_result {
                                Ok(Ok(())) => {
                                    // Fetch the continuation reply
                                    let continuation =
                                        Self::fetch_last_reply(&target_agent, &target_session_key)
                                            .await;
                                    match continuation {
                                        Some(cont_text) => {
                                            format!("{content}{cont_text}")
                                        }
                                        None => content,
                                    }
                                }
                                _ => {
                                    warn!(
                                        run_id = %run_id,
                                        "sessions_send: auto-continuation failed, returning truncated response"
                                    );
                                    content
                                }
                            }
                        } else {
                            content
                        };

                        info!(
                            run_id = %run_id,
                            target = %target_key_str,
                            reply_len = content.len(),
                            "sessions_send: got reply"
                        );
                        SessionsSendOutput::ok(run_id, target_key_str, content)
                    }
                    None => {
                        warn!(
                            run_id = %run_id,
                            target = %target_key_str,
                            "sessions_send: execution completed but no assistant reply found"
                        );
                        SessionsSendOutput::ok(
                            run_id,
                            target_key_str,
                            "(No reply content)".to_string(),
                        )
                    }
                }
            }
            Ok(Err(e)) => {
                warn!(
                    run_id = %run_id,
                    error = %e,
                    "sessions_send: execution failed"
                );
                SessionsSendOutput::error(run_id, format!("Execution failed: {e}"))
            }
            Err(_) => {
                warn!(
                    run_id = %run_id,
                    timeout = args.timeout_seconds,
                    "sessions_send: timed out"
                );
                // BT-D-R4-21: dropping the timeout future leaves the engine's
                // internal run state alive (channels, locks, emitters).
                // Call the adapter's cancel hook to let the engine transition
                // the run to Cancelled and emit RunError. Without this, the
                // target agent stays "busy" until the run eventually completes
                // on its own and any side-effect in-flight (file writes,
                // partial tool calls) is never reconciled. cancel() is
                // fallible (run may have already completed in the gap);
                // any error is logged at info — the timeout is the primary
                // signal to the caller.
                if let Err(e) = execution_adapter.cancel(&run_id).await {
                    info!(
                        run_id = %run_id,
                        error = %e,
                        "sessions_send: post-timeout cancel attempt returned; \
                         run may have already completed in the timeout gap"
                    );
                }
                SessionsSendOutput::timeout(run_id, target_key_str)
            }
        }
    }
}

impl Default for SessionsSendTool {
    fn default() -> Self {
        Self::new()
    }
}

/// Canonical concurrency-claim key for a `session_send` target: the SAME
/// gateway session key the send actually executes under
/// (`session_key_to_gateway`), rendered to its stable string.
///
/// The claim MUST key on the gateway form rather than the raw spelling,
/// because *that* is the key the send executes on: two raw spellings that
/// normalise to one execution session must claim the same thing, or two
/// fan-out arms race into one session.
///
/// **The dm/group example this doc used to give is no longer one.** It said
/// `dm` and `group` keys with the same agent + peer "both collapse to `peer`"
/// and used that as the whole justification — but PR-6 / BT-D-R4-20 removed
/// that collapse deliberately (see `session_key_to_gateway`): it made a
/// delegated send fork a seam-private `peer:` thread instead of continuing the
/// visible conversation. The reasoning above survives the example's removal;
/// the example did not, and the test that pinned it was asserting a rule the
/// codebase had retired.
///
/// `None` = unresolvable here (empty / invalid / defaulted target); the claim
/// producer degrades to whole-world exclusive.
#[must_use]
pub fn claim_session_key(raw: &str) -> Option<String> {
    let parsed = super::helpers::parse_session_key(raw).ok()?;
    Some(session_key_to_gateway(&parsed).to_key_string())
}

/// Convert `routing::SessionKey` to `gateway::router::SessionKey`.
///
/// PR-6 / BT-D-R4-20: the previous shape collapsed `DirectMessage` and
/// `Group` arms to the legacy `peer` form (`SessionKey::peer` =
/// `dm(agent, "", peer, PerPeer)` -> renders `agent:{a}:peer:{pid}`),
/// discarding the channel + `dm_scope` the inbound path stores under.
/// The seam therefore executed AND claimed on a key no inbound
/// conversation ever wrote -- the claim key was consistent with where
/// the seam executed (both collapsed), but inconsistent with the
/// storage key of the DM/group conversation it targeted: a delegated
/// send spawned a seam-private `peer:` thread instead of continuing
/// the visible conversation. Group collapsed identically.
///
/// Preserve the dm/group form: forward the channel and `dm_scope`
/// fields verbatim into `SessionKey::dm` / `SessionKey::group`. The
/// storage key is now what the seam executes on, so a delegated send
/// continues the visible conversation instead of forking.
fn session_key_to_gateway(key: &crate::routing::session_key::SessionKey) -> SessionKey {
    match key {
        crate::routing::session_key::SessionKey::Main { agent_id, .. } => {
            SessionKey::main(agent_id.clone())
        }
        crate::routing::session_key::SessionKey::DirectMessage {
            agent_id,
            channel,
            peer_id,
            dm_scope,
            ..
        } => SessionKey::dm(
            agent_id.clone(),
            channel.clone(),
            peer_id.clone(),
            *dm_scope,
        ),
        crate::routing::session_key::SessionKey::Group {
            agent_id,
            channel,
            peer_kind,
            peer_id,
        } => SessionKey::group(
            agent_id.clone(),
            channel.clone(),
            *peer_kind,
            peer_id.clone(),
        ),
        crate::routing::session_key::SessionKey::Task {
            agent_id,
            task_type,
            task_id,
        } => SessionKey::task(agent_id.clone(), task_type.clone(), task_id.clone()),
        crate::routing::session_key::SessionKey::Subagent { parent_key, .. } => {
            session_key_to_gateway(parent_key)
        }
        crate::routing::session_key::SessionKey::Ephemeral { agent_id, .. } => {
            SessionKey::ephemeral(agent_id.clone())
        }
    }
}

/// Build the delegated run's metadata. Extracted as a pure function so the two
/// security invariants are unit-testable without a full execution harness:
///
/// 1. The dispatching turn's `caller_role` AND its channel `tool_permissions`
///    deny layer are forwarded — the same two restrictive keys
///    [`carry_policy_metadata`](crate::gateway::execution_engine) carries for
///    goal/loop/cron continuations — so a delegated run is never MORE privileged
///    than the turn that spawned it. Dropping `caller_role` would let
///    `role_is_operator(None) = true` promote a guest channel to operator +
///    unclamped tier; dropping the channel layer would let a guest bypass its own
///    `deny` override (e.g. `web_fetch = deny`) simply by delegating.
/// 2. An unattended run is stamped
///    [`UNATTENDED_KEY`](crate::gateway::execution_engine::UNATTENDED_KEY)
///    so confirm-gated tools fail closed immediately instead of parking on an
///    approval card nobody can answer. `unattended` here means fire-and-forget
///    (no human attached to the child) OR a headless PARENT
///    (`TurnContext::unattended`) — a wait-mode child of a goal/loop/cron run
///    has nobody to answer its cards either, and used to hang the full 120 s
///    approval timeout per gated tool instead of failing closed.
///
/// 3. This turn's SPEAKER (`AUTHOR_USER_KEY`) rides beside the scope pair,
///    not derived from it. `run_loop::with_request_scope` seeds the room
///    author from this key alone and `scope::room_author` falls back to
///    `attr.owner_user_id` — the room's CREATOR — when it is absent. In a
///    project room the creator and the speaker are different people, so
///    dropping this key does not make the child anonymous, it makes it the
///    creator: `visibility::ambient_actor()`'s first arm resolves to them for
///    every member's delegated run, and `memory_search` /
///    `sessions/list_tool` both gate on that resolver. Mirrors
///    `teams::dispatcher::runner::task_run_metadata` exactly, including its
///    `None => write nothing` arm — a background dispatch does not invent an
///    author.
///
/// `channel_id` / `conversation_id` are deliberately NOT forwarded — they are
/// what make an approval look deliverable, and a delegated run must keep failing
/// closed on approval-gated tools.
fn build_sub_metadata(
    inherited_workspace: Option<&std::path::Path>,
    caller_role: Option<String>,
    channel_tool_permissions: Option<String>,
    unattended: bool,
    scope: Option<&crate::scope::ScopeAttribution>,
    room_author: Option<String>,
) -> HashMap<String, String> {
    let mut m = HashMap::new();
    // The scope pair, which this function's doc claimed parity on and did not
    // carry. `carry_policy_metadata` forwards FOUR keys — `caller_role`,
    // `CHANNEL_TOOL_PERMISSIONS_KEY`, `OWNER_META_KEY` and `SCOPE_META_KEY` —
    // and explains at its own site why the scope pair must be inherited
    // unchanged. Without it the delegated run was created with no attribution:
    // `ensure_session_under_request_scope` stamped nothing, the session row was
    // written NULL/NULL and adopted by `owner_or_legacy`, and the child's
    // memory writes fell into the base partition while the parent sat on
    // `main__u-alice`.
    if let Some(attr) = scope {
        crate::scope::stamp_metadata(&mut m, attr);
    }
    // The room's speaker, captured before the spawn for the same reason as
    // `inherited_scope` above it at the call site. `None` (no ambient author:
    // background dispatch, tests) writes nothing — see this function's doc,
    // point 3.
    if let Some(author) = room_author {
        m.insert(
            crate::gateway::execution_engine::AUTHOR_USER_KEY.to_string(),
            author,
        );
    }
    if let Some(p) = inherited_workspace {
        m.insert("project_root".to_string(), p.display().to_string());
    }
    if let Some(role) = caller_role {
        m.insert("caller_role".to_string(), role);
    }
    if let Some(perms) = channel_tool_permissions {
        m.insert(
            crate::gateway::execution_engine::CHANNEL_TOOL_PERMISSIONS_KEY.to_string(),
            perms,
        );
    }
    if unattended {
        m.insert(
            crate::gateway::execution_engine::UNATTENDED_KEY.to_string(),
            "true".to_string(),
        );
    }
    m
}

/// Implementation of `AlephTool` trait for `SessionsSendTool`
#[async_trait]
impl AlephTool for SessionsSendTool {
    const NAME: &'static str = Self::NAME;
    const DESCRIPTION: &'static str = Self::DESCRIPTION;

    type Args = SessionsSendArgs;
    type Output = SessionsSendOutput;

    async fn call(&self, args: Self::Args) -> Result<Self::Output> {
        Ok(self.call_impl(args).await)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // ============================================================================
    // SessionsSendArgs tests
    // ============================================================================

    #[test]
    fn test_args_default_timeout() {
        let args: SessionsSendArgs = serde_json::from_str(r#"{"message": "hello"}"#).unwrap();
        assert_eq!(args.timeout_seconds, 30);
        assert!(args.session_key.is_none());
    }

    #[test]
    fn test_args_with_all_fields() {
        let args: SessionsSendArgs = serde_json::from_str(
            r#"{"session_key": "agent:translator:main", "message": "translate this", "timeout_seconds": 60}"#,
        )
        .unwrap();
        assert_eq!(args.session_key, Some("agent:translator:main".to_string()));
        assert_eq!(args.message, "translate this");
        assert_eq!(args.timeout_seconds, 60);
    }

    #[test]
    fn test_args_fire_and_forget() {
        let args: SessionsSendArgs =
            serde_json::from_str(r#"{"message": "async task", "timeout_seconds": 0}"#).unwrap();
        assert_eq!(args.timeout_seconds, 0);
    }

    // ============================================================================
    // SessionsSendStatus tests
    // ============================================================================

    #[test]
    fn test_status_serialization() {
        assert_eq!(
            serde_json::to_string(&SessionsSendStatus::Ok).unwrap(),
            r#""ok""#
        );
        assert_eq!(
            serde_json::to_string(&SessionsSendStatus::Accepted).unwrap(),
            r#""accepted""#
        );
        assert_eq!(
            serde_json::to_string(&SessionsSendStatus::Timeout).unwrap(),
            r#""timeout""#
        );
        assert_eq!(
            serde_json::to_string(&SessionsSendStatus::Forbidden).unwrap(),
            r#""forbidden""#
        );
        assert_eq!(
            serde_json::to_string(&SessionsSendStatus::Error).unwrap(),
            r#""error""#
        );
    }

    // ============================================================================
    // SessionsSendOutput tests
    // ============================================================================

    #[test]
    fn test_output_ok() {
        let output = SessionsSendOutput::ok(
            "run-1".to_string(),
            "agent:main:main".to_string(),
            "Hello!".to_string(),
        );
        assert_eq!(output.status, SessionsSendStatus::Ok);
        assert_eq!(output.reply, Some("Hello!".to_string()));
        assert_eq!(output.session_key, Some("agent:main:main".to_string()));
        assert!(output.error.is_none());
    }

    #[test]
    fn test_output_accepted() {
        let output =
            SessionsSendOutput::accepted("run-2".to_string(), "agent:main:main".to_string());
        assert_eq!(output.status, SessionsSendStatus::Accepted);
        assert!(output.reply.is_none());
    }

    #[test]
    fn test_output_timeout() {
        let output =
            SessionsSendOutput::timeout("run-3".to_string(), "agent:main:main".to_string());
        assert_eq!(output.status, SessionsSendStatus::Timeout);
    }

    #[test]
    fn test_output_forbidden() {
        let output =
            SessionsSendOutput::forbidden("run-4".to_string(), "Policy denied".to_string());
        assert_eq!(output.status, SessionsSendStatus::Forbidden);
        assert_eq!(output.error, Some("Policy denied".to_string()));
    }

    #[test]
    fn test_output_error() {
        let output =
            SessionsSendOutput::error("run-5".to_string(), "Something went wrong".to_string());
        assert_eq!(output.status, SessionsSendStatus::Error);
        assert_eq!(output.error, Some("Something went wrong".to_string()));
    }

    // ============================================================================
    // SessionsSendTool tests
    // ============================================================================

    #[test]
    fn test_tool_creation() {
        let tool = SessionsSendTool::new();
        assert!(tool.context.is_none());
        assert_eq!(tool.current_agent_id, "main");
    }

    #[test]
    fn test_tool_name_and_description() {
        assert_eq!(SessionsSendTool::NAME, "session_send");
        assert!(!SessionsSendTool::DESCRIPTION.is_empty());
    }

    #[tokio::test]
    async fn test_tool_without_context_returns_error() {
        let tool = SessionsSendTool::new();
        let args = SessionsSendArgs {
            session_key: None,
            message: "test".to_string(),
            timeout_seconds: 30,
        };

        let output = AlephTool::call(&tool, args).await.unwrap();
        assert_eq!(output.status, SessionsSendStatus::Error);
        assert!(output.error.is_some());
        assert!(output
            .error
            .unwrap()
            .contains("GatewayContext not configured"));
    }

    // ============================================================================
    // Telecom provenance (Task 4): a delegated child of a public telecom run
    // ============================================================================

    /// Records `(run_id, request.telecom_public)` for every `execute`, as the
    /// typed field — NOT the task-local — and answers the first (non-`-continue`)
    /// run with a truncated assistant reply so wait mode auto-continues.
    struct ProvenanceAdapter {
        seen: tokio::sync::mpsc::UnboundedSender<(
            String,
            Option<crate::gateway::telecom::TelecomPublicContext>,
        )>,
    }

    #[async_trait::async_trait]
    impl crate::gateway::execution_adapter::ExecutionAdapter for ProvenanceAdapter {
        async fn execute(
            &self,
            request: RunRequest,
            agent: Arc<crate::gateway::agent_instance::AgentInstance>,
            _emitter: Arc<dyn crate::gateway::event_emitter::EventEmitter + Send + Sync>,
        ) -> std::result::Result<(), crate::gateway::execution_engine::ExecutionError> {
            let reply = if request.run_id.ends_with("-continue") {
                "tail"
            } else {
                "head [output truncated"
            };
            let store = agent.session_store();
            store.get_or_create(&request.session_key).await.unwrap();
            store
                .append_message(
                    &request.session_key,
                    crate::gateway::session_store::types::MessageRecord {
                        id: request.run_id.clone(),
                        role: "assistant".to_string(),
                        content: reply.to_string(),
                        timestamp: chrono::Utc::now().timestamp(),
                        metadata: None,
                        input_tokens: 0,
                        output_tokens: 0,
                        tool_call_id: None,
                        tool_name: None,
                    },
                )
                .await
                .unwrap();
            let _ = self
                .seen
                .send((request.run_id.clone(), request.telecom_public.clone()));
            Ok(())
        }
        async fn cancel(
            &self,
            _run_id: &str,
        ) -> std::result::Result<(), crate::gateway::execution_engine::ExecutionError> {
            Ok(())
        }
        async fn get_status(
            &self,
            _run_id: &str,
        ) -> Option<crate::gateway::execution_engine::RunStatus> {
            None
        }
        async fn active_run_count(&self) -> usize {
            0
        }
    }

    type Seen = tokio::sync::mpsc::UnboundedReceiver<(
        String,
        Option<crate::gateway::telecom::TelecomPublicContext>,
    )>;

    async fn provenance_tool() -> (SessionsSendTool, Seen, tempfile::TempDir) {
        use crate::gateway::agent_instance::{AgentInstance, AgentInstanceConfig, AgentRegistry};
        use crate::gateway::session_store::file_backend::{
            FileSessionStore, FileSessionStoreConfig,
        };
        use crate::gateway::session_store::SessionStore;

        let tmp = tempfile::tempdir().unwrap();
        let store: Arc<dyn SessionStore> = Arc::new(
            FileSessionStore::new(FileSessionStoreConfig {
                base_dir: tmp.path().join("agent-sessions"),
                ..FileSessionStoreConfig::default()
            })
            .unwrap(),
        );
        let registry = Arc::new(AgentRegistry::new());
        registry
            .register(
                AgentInstance::new(
                    AgentInstanceConfig {
                        agent_id: "main".into(),
                        workspace: tmp.path().join("workspace"),
                        agent_dir: tmp.path().join("agent"),
                        ..AgentInstanceConfig::default()
                    },
                    store,
                )
                .unwrap(),
            )
            .await;
        let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
        let manager = Arc::new(
            crate::gateway::SessionManager::new(
                crate::gateway::session_manager::SessionManagerConfig {
                    db_path: tmp.path().join("sessions.db"),
                    ..Default::default()
                },
            )
            .unwrap(),
        );
        let context = GatewayContext::new(
            manager,
            registry,
            Arc::new(ProvenanceAdapter { seen: tx }),
            Arc::new(crate::gateway::inter_agent_policy::AgentToAgentPolicy::permissive()),
        );
        (SessionsSendTool::with_context(context, "main"), rx, tmp)
    }

    async fn drain(
        rx: &mut Seen,
        n: usize,
    ) -> Vec<(
        String,
        Option<crate::gateway::telecom::TelecomPublicContext>,
    )> {
        let mut out = Vec::new();
        for _ in 0..n {
            out.push(
                tokio::time::timeout(std::time::Duration::from_secs(5), rx.recv())
                    .await
                    .expect("adapter must observe the run")
                    .expect("channel open"),
            );
        }
        out
    }

    fn send_args(timeout_seconds: u32) -> SessionsSendArgs {
        SessionsSendArgs {
            session_key: None,
            message: "delegate".to_string(),
            timeout_seconds,
        }
    }

    #[tokio::test]
    async fn a_public_parents_wait_send_and_auto_continuation_carry_its_origin() {
        let (tool, mut rx, _tmp) = provenance_tool().await;
        let ctx = crate::gateway::telecom::run_origin::sample_public_context("b-send-wait");
        let out = crate::gateway::telecom::run_origin::seed_run_origin(
            Some(ctx.clone()),
            AlephTool::call(&tool, send_args(30)),
        )
        .await
        .unwrap();
        assert_eq!(out.status, SessionsSendStatus::Ok, "{:?}", out.error);
        assert_eq!(out.reply.as_deref(), Some("head [output truncatedtail"));
        let seen = drain(&mut rx, 2).await;
        assert!(!seen[0].0.ends_with("-continue"));
        assert!(seen[1].0.ends_with("-continue"), "{seen:?}");
        assert_eq!(seen[0].1, Some(ctx.clone()), "initial child request");
        assert_eq!(seen[1].1, Some(ctx), "automatic continuation request");
    }

    #[tokio::test]
    async fn a_public_parents_fire_and_forget_send_carries_its_origin_across_the_spawn() {
        let (tool, mut rx, _tmp) = provenance_tool().await;
        let ctx = crate::gateway::telecom::run_origin::sample_public_context("b-send-ff");
        let out = crate::gateway::telecom::run_origin::seed_run_origin(
            Some(ctx.clone()),
            AlephTool::call(&tool, send_args(0)),
        )
        .await
        .unwrap();
        assert_eq!(out.status, SessionsSendStatus::Accepted);
        let seen = drain(&mut rx, 1).await;
        assert_eq!(seen[0].1, Some(ctx), "bare-spawned child request");
    }

    #[tokio::test]
    async fn an_ordinary_or_unseeded_parent_send_stays_none() {
        for timeout in [0u32, 30] {
            let (tool, mut rx, _tmp) = provenance_tool().await;
            let out = crate::gateway::telecom::run_origin::seed_run_origin(
                None,
                AlephTool::call(&tool, send_args(timeout)),
            )
            .await
            .unwrap();
            assert!(matches!(
                out.status,
                SessionsSendStatus::Ok | SessionsSendStatus::Accepted
            ));
            let want = if timeout == 30 { 2 } else { 1 };
            for (id, origin) in drain(&mut rx, want).await {
                assert_eq!(origin, None, "ordinary parent, run {id}");
            }
            // Unseeded (no run scope at all) is also ordinary.
            let (tool, mut rx, _tmp) = provenance_tool().await;
            AlephTool::call(&tool, send_args(timeout)).await.unwrap();
            for (id, origin) in drain(&mut rx, want).await {
                assert_eq!(origin, None, "unseeded parent, run {id}");
            }
        }
    }

    /// A real `HarnessRunner` whose `run` executes the real `SessionsSendTool`
    /// -- i.e. the tool runs inside the task `Orchestrator::dispatch` spawns,
    /// where the gateway's run-origin task-local no longer exists unless the
    /// spawn re-seeds it.
    struct SendingHarness {
        tool: Arc<SessionsSendTool>,
    }

    #[async_trait::async_trait]
    impl crate::orchestrator::dispatch::HarnessRunner for SendingHarness {
        async fn run(
            &self,
            _session_key: String,
            _spec: Arc<crate::orchestrator::flow_spec::FlowSpec>,
            _input: crate::orchestrator::flow_spec::FlowInput,
            _sandbox: Arc<dyn crate::sandbox::Sandbox>,
            _events: tokio::sync::broadcast::Sender<crate::orchestrator::dispatch::FlowStreamEvent>,
            _cancel: tokio_util::sync::CancellationToken,
            _tool_service_override: Option<Arc<dyn crate::tools::service::ToolService>>,
            _trace_sink: Option<Arc<dyn crate::harness::TraceSink>>,
            _interaction_manifest: Option<crate::thinker::InteractionManifest>,
            _workspace_override: Option<std::path::PathBuf>,
            _max_iterations_override: Option<u32>,
            _transient_context: Option<String>,
            _think_level: Option<crate::agents::thinking::ThinkLevel>,
            _envelope: crate::thinker::TurnEnvelope,
            _turn_model: Option<crate::providers::session_model_handle::SessionModelPref>,
            _run_id: String,
            _telecom_public: Option<crate::gateway::telecom::TelecomPublicContext>,
        ) -> std::result::Result<
            crate::orchestrator::dispatch::FlowOutcome,
            crate::orchestrator::errors::FlowError,
        > {
            let out = AlephTool::call(&*self.tool, send_args(30)).await.unwrap();
            assert_eq!(out.status, SessionsSendStatus::Ok, "{:?}", out.error);
            Ok(crate::orchestrator::dispatch::FlowOutcome::default())
        }
    }

    /// End to end through the real harness spawn: the delegated child's typed
    /// `RunRequest.telecom_public` is `Some` for a public parent request and
    /// `None` for an ordinary one (no origin is invented).
    #[tokio::test]
    async fn sessions_send_inside_the_harness_spawn_carries_the_requests_origin() {
        use crate::orchestrator::dispatch::{FlowRequest, Orchestrator};
        use crate::orchestrator::flow_registry::{FlowRegistry, FlowSet};
        use crate::orchestrator::flow_spec::{
            BrainRef, FlowInput, FlowOverrides, FlowSpec, SessionStrategy,
        };

        let ctx = crate::gateway::telecom::run_origin::sample_public_context("b-harness");
        for parent in [Some(ctx.clone()), None] {
            let (tool, mut rx, _tmp) = provenance_tool().await;
            let mut specs = FlowSet::new();
            specs.insert(
                "default-agent".into(),
                Arc::new(FlowSpec {
                    id: "default-agent".into(),
                    description: "t".into(),
                    agent: "main".into(),
                    brain: BrainRef::Default,
                    session_strategy: SessionStrategy::Fresh,
                    overrides: FlowOverrides::default(),
                }),
            );
            let mut defaults = std::collections::HashMap::new();
            defaults.insert("main".to_string(), "default-agent".to_string());
            let conn = rusqlite::Connection::open_in_memory().unwrap();
            crate::session::store::migrate_add_session_events(&conn).unwrap();
            let store: Arc<dyn crate::session::store::SessionEventStore> =
                Arc::new(crate::session::store::SqliteEventStore::new(conn));
            let orch = Orchestrator::new(
                Arc::new(FlowRegistry::new(specs)),
                Arc::new(defaults),
                Arc::new(crate::session::in_process::InProcessActorSessionService::new(store)),
                crate::orchestrator::sandbox_factory::build_sandbox_factory(Arc::new(|_| {
                    Ok(Arc::new(crate::sandbox::NoopSandbox) as Arc<dyn crate::sandbox::Sandbox>)
                })),
                Arc::new(SendingHarness {
                    tool: Arc::new(tool),
                }),
            );
            let handle = orch
                .dispatch(FlowRequest {
                    flow_id: None,
                    agent_id: "main".into(),
                    run_id: "parent-run".into(),
                    input: FlowInput::Prompt("go".into()),
                    channel: None,
                    session_hint: None,
                    scope: crate::scope::FlowScope::unscoped(),
                    parent_session: None,
                    depth: 0,
                    tool_service: None,
                    trace_sink: None,
                    event_tx: None,
                    interaction_manifest: None,
                    sandbox_override: None,
                    workspace_override: None,
                    max_iterations_override: None,
                    transient_context: None,
                    think_level: None,
                    envelope: crate::thinker::TurnEnvelope::none(),
                    model_directive: None,
                    telecom_public: parent.clone(),
                })
                .await
                .expect("dispatch ok");
            handle.completion.await.unwrap().expect("harness ok");
            for (id, origin) in drain(&mut rx, 2).await {
                assert_eq!(origin, parent, "child run {id}");
            }
        }
    }

    // ============================================================================
    // session_key_to_gateway conversion tests
    // ============================================================================

    #[test]
    fn test_convert_main_key() {
        use crate::routing::session_key::SessionKey as RoutingKey;

        let routing_key = RoutingKey::main("test-agent");
        let gateway_key = session_key_to_gateway(&routing_key);

        assert!(
            matches!(gateway_key, SessionKey::Main { agent_id, .. } if agent_id == "test-agent")
        );
    }

    #[test]
    fn test_convert_dm_key() {
        use crate::routing::session_key::{DmScope, SessionKey as RoutingKey};

        let routing_key = RoutingKey::dm("main", "telegram", "user123", DmScope::PerPeer);
        let gateway_key = session_key_to_gateway(&routing_key);

        assert!(
            matches!(gateway_key, SessionKey::DirectMessage { agent_id, peer_id, .. } if agent_id == "main" && peer_id == "user123")
        );
    }

    #[test]
    fn test_convert_task_key() {
        use crate::routing::session_key::SessionKey as RoutingKey;

        let routing_key = RoutingKey::task("main", "cron", "daily");
        let gateway_key = session_key_to_gateway(&routing_key);

        assert!(
            matches!(gateway_key, SessionKey::Task { agent_id, task_type, task_id } if agent_id == "main" && task_type == "cron" && task_id == "daily")
        );
    }

    #[test]
    fn sub_metadata_forwards_caller_role() {
        // A guest channel delegating must carry its role forward, or the child
        // run passes the operator gate (role_is_operator(None) = true).
        let m = build_sub_metadata(None, Some("guest".to_string()), None, false, None, None);
        assert_eq!(m.get("caller_role").map(String::as_str), Some("guest"));
        // Wait-mode under an ATTENDED parent must NOT be stamped unattended: a
        // human is attached to the awaiting parent turn. (The call site passes
        // `fire_and_forget || parent.unattended`, so a headless parent's
        // wait-mode child IS stamped — see the test below.)
        assert!(!m.contains_key(crate::gateway::execution_engine::UNATTENDED_KEY));
    }

    #[test]
    fn sub_metadata_forwards_channel_tool_permissions() {
        // A guest channel with a deny override (e.g. web_fetch = deny) must carry
        // that deny layer to the delegate, or it bypasses its own deny by
        // delegating to another session.
        let perms = r#"{"web_fetch":"deny"}"#.to_string();
        let m = build_sub_metadata(
            None,
            Some("guest".to_string()),
            Some(perms.clone()),
            false,
            None,
            None,
        );
        assert_eq!(
            m.get(crate::gateway::execution_engine::CHANNEL_TOOL_PERMISSIONS_KEY)
                .map(String::as_str),
            Some(perms.as_str())
        );
    }

    #[test]
    fn sub_metadata_omits_caller_role_when_absent() {
        // A trusted local/internal run (no role) forwards nothing — the child
        // stays at the same absent-role trust level, not a fabricated "guest".
        let m = build_sub_metadata(None, None, None, false, None, None);
        assert!(!m.contains_key("caller_role"));
        assert!(!m.contains_key(crate::gateway::execution_engine::CHANNEL_TOOL_PERMISSIONS_KEY));
    }

    #[test]
    fn sub_metadata_stamps_unattended_on_fire_and_forget() {
        let m = build_sub_metadata(None, Some("operator".to_string()), None, true, None, None);
        assert_eq!(
            m.get(crate::gateway::execution_engine::UNATTENDED_KEY)
                .map(String::as_str),
            Some("true")
        );
        // caller_role still rides along even for fire-and-forget.
        assert_eq!(m.get("caller_role").map(String::as_str), Some("operator"));
    }

    /// A wait-mode child of a headless parent inherits `unattended` through the
    /// call-site OR (`fire_and_forget || turn.unattended`): the flag reaching
    /// the child's metadata is what makes its confirm-gated tools fail closed
    /// instantly instead of hanging the 120 s approval timeout — and, being
    /// read back by `continuation_metadata`, it stays transitive to N+1.
    #[test]
    fn sub_metadata_stamps_unattended_for_headless_parent_wait_mode() {
        // fire_and_forget = false, parent_unattended = true → OR = true.
        let m = build_sub_metadata(None, None, None, true, None, None);
        assert_eq!(
            m.get(crate::gateway::execution_engine::UNATTENDED_KEY)
                .map(String::as_str),
            Some("true")
        );
    }

    // ============================================================================
    // T06: the delegated child must carry the room's speaker, not its creator
    // ============================================================================

    /// Behavioural, not source-level (criterion #4: throw the metadata map's
    /// return value away). Builds the metadata a delegated `send_tool` child
    /// actually gets, then re-derives the ambient actor the SAME way
    /// `run_loop::with_request_scope` does — `scope_from_metadata` for the
    /// scope pair, a raw `AUTHOR_USER_KEY` read for the speaker — and drives
    /// the real resolver [`crate::gateway::visibility::ambient_actor`]. Then
    /// asserts the effect that resolver gates: `memory_search`'s
    /// `partition_visible_to` and `sessions/list_tool`'s
    /// `owner_and_scope_visible_to`, both fed the resolved actor, not the map.
    #[tokio::test]
    async fn a_delegated_child_carries_the_rooms_speaker_not_its_creator() {
        // Alice created the room; Bob is the one actually typing this turn.
        let room_scope = crate::scope::ScopeAttribution {
            owner_user_id: "u-alice".to_string(),
            scope: crate::scope::ScopeId::Project("p-room".to_string()),
        };
        let sub_metadata = build_sub_metadata(
            None,
            None,
            None,
            false,
            Some(&room_scope),
            Some("u-bob".to_string()),
        );

        // Mirrors `run_loop::request_scope` / `with_request_scope` exactly:
        // scope from the stamped pair, author from a raw key read — not from
        // any helper that could paper over a dropped key with a fallback.
        let scope = crate::scope::scope_from_metadata(&sub_metadata);
        let author = sub_metadata
            .get(crate::gateway::execution_engine::AUTHOR_USER_KEY)
            .cloned();
        let actor = crate::scope::with_scope(
            scope,
            crate::scope::with_room_author(author, async {
                crate::gateway::visibility::ambient_actor()
            }),
        )
        .await;
        assert_eq!(
            actor.as_deref(),
            Some("u-bob"),
            "a delegated child's ambient actor must be the room's speaker, not its creator"
        );

        // The effect the actor gates: `memory_search`'s exact predicate.
        assert!(
            !crate::gateway::visibility::partition_visible_to("main__u-alice", actor.as_deref()),
            "the room creator's personal memory partition must stay refused to a delegated child"
        );
        assert!(
            crate::gateway::visibility::partition_visible_to("main__u-bob", actor.as_deref()),
            "the speaker's own memory partition must stay visible to their delegated child"
        );

        // `sessions/list_tool`'s exact predicate: the creator's personal
        // session must not enumerate for the speaker.
        assert!(
            !crate::gateway::visibility::owner_and_scope_visible_to(
                Some("u-alice"),
                None,
                actor.as_deref().expect("resolved above")
            ),
            "the room creator's personal sessions must not enumerate for the delegated child"
        );
    }

    /// A background dispatch (no ambient speaker — cron, A2A, tests) must not
    /// invent an author: `AUTHOR_USER_KEY` is absent entirely, byte-identical
    /// to `teams::dispatcher::runner::task_run_metadata`'s `None` arm.
    #[test]
    fn a_background_dispatch_with_no_room_author_writes_no_author_key() {
        let m = build_sub_metadata(None, None, None, false, None, None);
        assert!(!m.contains_key(crate::gateway::execution_engine::AUTHOR_USER_KEY));
    }
}
