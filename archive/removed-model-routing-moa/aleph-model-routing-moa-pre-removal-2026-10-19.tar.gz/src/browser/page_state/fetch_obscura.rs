//! **INTERIM.** obscura's `DOMSnapshot.captureSnapshot` fabricates its
//! geometry — `domsnapshot.rs:231-236` (**verified at `v0.2.2`**) is literally
//! `let y = (i as f64) * 18.0; bounds.push(json!([0.0, y, 1280.0, 18.0]))`,
//! with a constant style vector claiming `visibility:visible` for every node
//! and no marker on the wire — so the Chromium fetcher's one-call path cannot
//! be used on this engine. This module is the stand-in: `DOM.getDocument` for
//! the tree, bounded-concurrent `DOM.getBoxModel` for rectangles, and one
//! `Runtime.evaluate` for the computed flags and the caret.
//!
//! **DELETE IT** when the obscura ledger tag (`runtimes::specs::OBSCURA_TAG`)
//! reaches the release carrying the upstream `DOMSnapshot` layout fix. At that
//! point `fetch_chromium` serves both engines, and **Task 10's census — "at
//! most one `PageState::build` call site" — plus the engine-arm census in
//! `cdp_backend/snapshot.rs` must be revisited**, or they go red on the
//! deletion and look like a regression.
//!
//! # What this fetcher knows that the Chromium one does not
//!
//! Every item below was measured on the real v0.2.2 binary (2026-09-06), not
//! inferred from the source survey. The probe outputs are T0's `U2`, `U3`,
//! `U5` and `U9` in `docs/superpowers/specs/…-evidence/t0-results.md`.
//!
//! * **`pierce: true` is accepted and ignored** — unimplemented, not merely
//!   unhonoured: obscura's `DOM.getDocument` handler reads only `depth` (U3,
//!   confirmed at source). An `<iframe>` arrives as an ordinary element with no
//!   children, and an iframe is never its own CDP target either, because every
//!   frame shares one V8 isolate. So this fetcher produces **exactly one**
//!   `RawFrame`, always, and **every frame element goes into
//!   [`RawDom::unreached_frames`]** — the absence has to be stated, or a page
//!   whose iframe was never read is indistinguishable from one whose iframe is
//!   genuinely empty (判据 §17).
//! * **A zero box is not a visibility signal on this engine.** U2 measured
//!   `display:none` on obscura returning a box **successfully** with the quad
//!   `[0,0,0,0,0,0,0,0]` — where Chromium fails the call honestly. U9 measured
//!   the converse: obscura lays out `a-in-p`, `a-in-td` and `span-in-block`
//!   fine (and HN's title link gets a real `{x:130,y:11,w:83,h:15}`), and
//!   misses only an inline element that is a **direct child of `<body>`**. So
//!   the earlier claim that "inline elements have no box on obscura" was true
//!   of one fixture page and false in general — a conclusion's scope is its
//!   method (判据 §18).
//!
//!   What this fetcher does, and it is the same either way: a zero quad becomes
//!   `rect: None`, and **`rect: None` is never spent as hidden on this engine**
//!   — [`super::build::visibility_of`] reads [`Computed`] first and falls back
//!   to the box only when the style read is absent. Visibility comes from
//!   [`COMPUTED_FLAGS_JS`].
//!
//!   ⚠️ The fallback arm is therefore live exactly when the cross-check below
//!   fails twice, and **what that costs is now the whole text of the page, not
//!   a few boxless elements.** With every `computed` at `None`,
//!   `cascade_effective_styles` finds no parent flags to hand down; only
//!   elements are asked for a box, so every TEXT node falls to
//!   `rect.is_some()` = false and `render_text` drops each one
//!   (`render.rs:114`), alongside the boxless-but-visible elements. The honest
//!   word for a degraded page is therefore **textless**, not "less visible":
//!   the good path and the degraded path differ by every string on the page
//!   (判据 §17 — a wrong label costs more than a missing one, and
//!   "conservative" was the wrong label for this). Reachable: one open shadow
//!   root makes the element counts disagree (see `walk`'s shadow branch),
//!   which is a disagreement no retry can fix. obscura returns none today, so
//!   this is a live path on a future build rather than on this one — which is
//!   why it is written down. It is still the direction to fail in, and it is
//!   why the cross-check retries before giving up.
//! * **`Page.getFrameTree` carries a real, changing `loaderId` for the main
//!   frame** (`loader-blank-page-1` → `loader-010b239d-…` across a navigate),
//!   which is what makes ref generations work here at all. A CHILD frame's
//!   `loaderId` is derived from its frame id and never changes, so it must not
//!   be used as a document identity — and cannot be, since
//!   `PageState::build` resets on `frames[0]` and this fetcher emits one frame.
//! * **`Page.getLayoutMetrics.cssContentSize` is the viewport, not the
//!   document** (1280×720 for a 208 px page). Recorded as measured; nothing
//!   may compute a scroll extent from it.
//! * **`backendNodeId: 0` is the document.** It is a real id, not a sentinel —
//!   the captured `DOM.getDocument` this module's tests read has `#document` at
//!   `backendNodeId: 0`, with the `<html>` element at 2.
//!
//! # What this fetcher does NOT supply, and why that is a declaration
//!
//! [`RawFrame::live_properties_observed`] is **`false`**. This fetcher does not
//! read the live `checked` / `selected` / `value` DOM properties, so `build`
//! falls back to the page's content attributes — which are the *initial* state
//! and go stale the moment anyone, including the agent itself, clicks or types.
//! That is a stated gap, not a silent one: `false` is the honest declaration
//! the field exists to carry, and the fallback it selects is correct for a page
//! nobody has interacted with yet.
//!
//! [`RawNode::focused`] is the opposite case and is therefore **supplied here**.
//! It has no attribute fallback — no markup can express where the caret is — so
//! a fetcher that left it `None` would make `NodeStates::focused` a predicate
//! that is constant across every capture on every engine (判据 §2), which is
//! the condition `RawNode::focused`'s own doc names for cutting the field. One
//! JS call already crosses the V8 lock; the caret rides along on it.

use std::collections::HashMap;

use aleph_cdp::methods::{dom, page, runtime};
use aleph_cdp::{CdpConnection, SessionId};
use futures::stream::StreamExt;

use super::fetch_chromium::FRAME_ELEMENTS;
use super::{Computed, RawDom, RawFrame, RawNode, RawNodeKind, Rect, UnreachedFrame, Viewport};
use crate::browser::engine::Engine;
use crate::browser::error::BrowserError;

/// How many `DOM.getBoxModel` calls may be in flight at once.
///
/// Bounded because obscura serialises every `DOM.*` call behind one
/// per-connection V8 lock: unbounded concurrency does not go faster, it just
/// queues N commands against a per-command watchdog, so one slow page turns
/// into N timeouts instead of one.
pub const DEFAULT_BOX_CONCURRENCY: usize = 16;

/// The single expression that carries every per-element flag, the caret, and
/// the cross-check anchors, in `document.querySelectorAll('*')` order.
///
/// One expression rather than one per element: on obscura each `evaluate` is a
/// separate trip through the V8 lock, and the flags are cheap next to the trip.
/// The three anchors (`n`, `first`, `last`) are what make zipping the rows onto
/// the `getDocument` walk falsifiable rather than hopeful — a count alone
/// cannot see "34 elements both times, a different 34".
///
/// `focus` has **three** states on the wire and they are not interchangeable:
/// `null` is "this engine could not say", `-1` is "I looked and nothing on this
/// page has the caret", and an index names the element. The `null` arm is not
/// defensive decoration — an `activeElement` that is outside
/// `querySelectorAll('*')` (inside a shadow root) would otherwise come back as
/// `indexOf` → `-1` and be read as "nothing is focused", which is a denial
/// manufactured out of an unknown (判据 §8).
///
/// **`-1` is produced by exactly ONE condition — `ae === document.body` — and
/// "cannot say" is the INITIAL value rather than a branch.** That shape is the
/// fix, not a style choice. This expression first read
/// `if (!ae || ae === document.body) { focus = -1; }`, which answers *"I looked
/// and nothing has it"* for a **stub `activeElement`** that returns
/// `undefined` — collapsing the two states at the point of production and
/// making the whole three-state distinction downstream decorative. With the
/// falsy case reaching no branch at all, there is no path by which not-knowing
/// can become a denial. Pinned by
/// `the_caret_sentinel_is_reachable_only_through_document_body`.
///
/// **Residual, written down rather than left silent: a genuinely focused
/// `<body tabindex="0">` is still spent as `-1`.** The caret really is on
/// `<body>`, and this reports "I looked and nothing has it", plus
/// `focused: Some(false)` on `<body>` itself. In a real browser the
/// discriminator is `document.body.matches(':focus')` — and **that does not
/// work on the engine this fetcher serves. Read on the installed `v0.2.2`
/// binary, defaults only:** after `el.focus()`, `matches(':focus')`,
/// `:hover`, `:active`, `:focus-visible` and `:focus-within` are all `false`,
/// `document.querySelector(':focus')` is `null`, and
/// `querySelectorAll(':hover').length` is `0`. **Control, so this is about the
/// dynamic pseudo-classes and not a broken selector engine:** on the same
/// element in the same run, `matches(':enabled')` and `matches('div')` are
/// both `true`.
///
/// **The half that makes this expression's SHAPE a reading rather than an
/// inference: `document.activeElement` DOES track the caret on that same
/// run.** After `el.focus()` it reads back as the focused element while
/// `:focus` stays false — two faces of one fact that disagree (判据 §9). So
/// the engine knows where focus is and the selector cannot see it, which is
/// why the expression above reads `activeElement` and never `:focus`: a
/// selector-based focus check on this engine is constant-false and would never
/// go red.
///
/// Corroborated at source, at the tag: obscura's selector engine answers
/// `PseudoClass::Focus` with an unconditional `false`, grouped with the other
/// four under the comment *"Dynamic user-interaction pseudo-classes have no
/// meaning against a static DOM snapshot with no live user input"*
/// (`crates/obscura-dom/src/selector.rs:507-511` — the arm's own span; this
/// read `506-510`, a pre-existing tail off-by-one rather than tag drift, since
/// the file is byte-identical at `v0.2.2` and at the tree the claim was first
/// read on), reached from `bootstrap.js:3556`'s `matches` via
/// `matches_selector` (**verified unmoved at `v0.2.2`**). Conjoining it here
/// would put a 恒假 term in front of the `-1` branch: `!matches(':focus')` is
/// always true, so the branch would behave exactly as it does now, wearing a
/// guard that cannot fire (判据 §2). So this is documented, not repaired. The
/// bound on the cost: it takes a page whose only focusable thing is `<body>`
/// itself, and every element still reports `focused: Some(false)`, which is
/// true of every one of them.
///
/// **`cursor` is not an answer about the cascade on this engine, and the doc on
/// `cascade_effective_styles` says what it is instead** — read that before
/// spending `cursor_pointer` for anything beyond the one OR arm that reads it.
///
/// `pub` so a prober runs the same string the fetcher runs; two copies would
/// let a QA fixture agree with a fetcher that had changed (判据 §1).
pub const COMPUTED_FLAGS_JS: &str = "(() => { \
    const es = [...document.querySelectorAll('*')]; \
    const rows = es.map(e => { const c = getComputedStyle(e); return [ \
        c.display === 'none', \
        c.visibility === 'hidden', \
        parseFloat(c.opacity) === 0, \
        c.cursor === 'pointer' ]; }); \
    let focus = null; \
    if ('activeElement' in document) { \
        const ae = document.activeElement; \
        if (ae === document.body) { focus = -1; } \
        else if (ae) { const i = es.indexOf(ae); focus = i >= 0 ? i : null; } \
    } \
    return { n: es.length, first: es[0] ? es[0].tagName : '', \
             last: es.length ? es[es.length - 1].tagName : '', rows, focus }; })()";

/// Where the caret is, as the engine answered.
///
/// Three states, because the wire has three and collapsing any two of them
/// spends an unknown as a value. [`Self::Unknown`] leaves every
/// `RawNode::focused` at `None`; [`Self::Observed`] licenses a `Some(false)` on
/// every element the engine did not name, which is a real observation rather
/// than a default.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Focus {
    /// The engine did not say. Nothing may be concluded about any node.
    Unknown,
    /// The engine looked. `Some(i)` names the element in document order;
    /// `None` is "nothing on this page has the caret".
    Observed(Option<usize>),
}

/// Parse the evaluate payload's flag rows, refusing anything whose shape
/// disagrees with the tree we walked.
///
/// `None` means "these flags cannot be trusted for THIS tree" and the caller
/// spends it as `computed: None` on every node — never as a partial zip, which
/// would attribute one element's visibility to another (判据 §8).
#[must_use]
pub fn parse_computed_rows(
    value: &serde_json::Value,
    element_count: usize,
    first_tag: &str,
    last_tag: &str,
) -> Option<Vec<Computed>> {
    let n = usize::try_from(value.get("n")?.as_u64()?).ok()?;
    if n != element_count {
        return None;
    }
    if !value
        .get("first")?
        .as_str()?
        .eq_ignore_ascii_case(first_tag)
    {
        return None;
    }
    if !value.get("last")?.as_str()?.eq_ignore_ascii_case(last_tag) {
        return None;
    }
    let rows = value.get("rows")?.as_array()?;
    if rows.len() != element_count {
        return None;
    }
    let mut out = Vec::with_capacity(rows.len());
    for row in rows {
        let cols = row.as_array()?;
        // Four, and the number is `Computed`'s field count, not a wire
        // convention: R34 cut `overflow_clip`, and a row that still carried it
        // would be a column nothing reads (判据 §1).
        if cols.len() != 4 {
            return None;
        }
        out.push(Computed {
            display_none: cols[0].as_bool()?,
            visibility_hidden: cols[1].as_bool()?,
            opacity_zero: cols[2].as_bool()?,
            cursor_pointer: cols[3].as_bool()?,
        });
    }
    Some(out)
}

/// Read the caret out of the same payload. Only ever called once
/// [`parse_computed_rows`] has agreed the payload describes THIS tree, so the
/// index below indexes the walk we are about to zip onto.
///
/// Every disagreement lands on [`Focus::Unknown`], including an index that
/// falls outside the tree: such an index is a payload about a different page,
/// and the one thing it may not become is "nothing is focused". Only `-1` —
/// the engine saying it looked and found none — licenses that reading.
fn parse_focus(value: &serde_json::Value, element_count: usize) -> Focus {
    let Some(raw) = value.get("focus") else {
        return Focus::Unknown;
    };
    if raw.is_null() {
        return Focus::Unknown;
    }
    let Some(i) = raw.as_i64() else {
        return Focus::Unknown;
    };
    if i == -1 {
        return Focus::Observed(None);
    }
    match usize::try_from(i) {
        Ok(i) if i < element_count => Focus::Observed(Some(i)),
        _ => Focus::Unknown,
    }
}

/// A flattened node plus where it sits in `querySelectorAll('*')` order.
struct Walked {
    node: RawNode,
    /// `Some` for element nodes: the position of this node in
    /// `querySelectorAll('*')` order, which is also the row to zip onto it.
    element_index: Option<usize>,
}

/// Flatten `DOM.getDocument`'s nested tree into document order.
///
/// Order matters twice over: it is the order `render_text` prints, and it is
/// the order the computed rows are zipped in. `querySelectorAll('*')` is
/// document order too, which is why the zip is sound — and the first/last tag
/// anchors are what prove it on each fetch rather than once in a comment.
fn walk(
    node: &dom::Node,
    parent: Option<usize>,
    out: &mut Vec<Walked>,
    element_seq: &mut usize,
) -> Result<(), BrowserError> {
    let kind = match node.node_type {
        1 => RawNodeKind::Element,
        3 => RawNodeKind::Text,
        9 => RawNodeKind::Document,
        _ => RawNodeKind::Other,
    };
    let element_index = if matches!(kind, RawNodeKind::Element) {
        let i = *element_seq;
        *element_seq += 1;
        Some(i)
    } else {
        None
    };
    // `backendNodeId: 0` is the DOCUMENT on obscura — a real id, so it is cast
    // and never filtered. A NEGATIVE id is the case that must not be cast: the
    // only in-range answer is `0`, which would hand this node the document's
    // identity and let a ref resolve to the wrong element. An unknown is
    // allowed to say "I don't know", and here the place to say it is a refusal
    // (判据 §8) — the same ruling `fetch_chromium::unaccounted_frame_elements`
    // already applies to its own ids.
    let Ok(backend_node_id) = u64::try_from(node.backend_node_id) else {
        return Err(BrowserError::EngineFailure {
            engine: Engine::Obscura,
            reason: format!(
                "DOM.getDocument returned node {:?} with backendNodeId {}, which is not \
                 an id — and giving it one would address a different element. Re-run \
                 browser_snapshot.",
                node.node_name, node.backend_node_id
            ),
        });
    };
    // CDP ships attributes as a FLAT [name, value, name, value, …] array.
    let attrs: Vec<(String, String)> = node
        .attributes
        .as_chunks::<2>()
        .0
        .iter()
        .map(|pair| (pair[0].clone(), pair[1].clone()))
        .collect();
    let text = if matches!(kind, RawNodeKind::Text) && !node.node_value.is_empty() {
        Some(node.node_value.clone())
    } else {
        None
    };
    let me = out.len();
    out.push(Walked {
        node: RawNode {
            backend_node_id,
            parent,
            kind,
            tag: matches!(kind, RawNodeKind::Element).then(|| node.node_name.to_ascii_lowercase()),
            attrs,
            text,
            rect: None,
            computed: None,
            clickable_hint: None,
            focused: None,
            // Not read by this fetcher; `RawFrame::live_properties_observed`
            // is `false` to say so, and `build` then reads the page's content
            // attributes. See this module's doc.
            checked: None,
            selected: None,
            value: None,
        },
        element_index,
    });
    for child in &node.children {
        walk(child, Some(me), out, element_seq)?;
    }
    // Shadow roots are walked so their contents are visible — as ORDINARY
    // children. Part 1's `dom::Node` still carries `shadow_roots`, but R34 cut
    // `RawNode::shadow_root`, so nothing downstream distinguishes them and a
    // flag here would have no reader.
    //
    // ⚠️ They are NOT in `querySelectorAll('*')`, which does not pierce shadow
    // boundaries — so a page with an open shadow root makes the element counts
    // disagree and the cross-check drops every flag for the whole page. That is
    // the correct failure (a mis-zip would attribute one element's visibility
    // to another), and it is stated here because the branch that causes it is
    // this one. obscura returns no shadow roots today, so this costs nothing
    // on the engine this module serves.
    for root in &node.shadow_roots {
        walk(root, Some(me), out, element_seq)?;
    }
    // Present for symmetry with the CDP type. obscura never populates it
    // (measured: `pierce: true` is unimplemented), so on this engine the branch
    // is dead — and it is written rather than `unreachable!()` so that the day
    // obscura DOES populate it, the content appears instead of panicking.
    if let Some(doc) = &node.content_document {
        walk(doc, Some(me), out, element_seq)?;
    }
    Ok(())
}

/// A quad's bounding rect, or `None` when the engine reported nothing usable.
///
/// A zero-area box is `None`, not `Some(0x0)`. obscura returns exactly that
/// quad for a `display:none` element **successfully** (U2), and a zero rect
/// spent downstream is a click at (0, 0) — a wrong answer that looks like an
/// answer.
fn rect_from(model: &dom::BoxModel) -> Option<Rect> {
    let q = &model.border;
    let xs = [q[0], q[2], q[4], q[6]];
    let ys = [q[1], q[3], q[5], q[7]];
    let (min_x, max_x) = (
        xs.iter().copied().fold(f64::INFINITY, f64::min),
        xs.iter().copied().fold(f64::NEG_INFINITY, f64::max),
    );
    let (min_y, max_y) = (
        ys.iter().copied().fold(f64::INFINITY, f64::min),
        ys.iter().copied().fold(f64::NEG_INFINITY, f64::max),
    );
    if !min_x.is_finite() || !min_y.is_finite() {
        return None;
    }
    let w = (max_x - min_x).round();
    let h = (max_y - min_y).round();
    if w <= 0.0 || h <= 0.0 {
        return None;
    }
    Some(Rect {
        x: min_x.round() as i32,
        y: min_y.round() as i32,
        w: w as i32,
        h: h as i32,
    })
}

/// The interim obscura fetcher.
pub async fn fetch_obscura(
    conn: &CdpConnection,
    session: &SessionId,
    box_concurrency: usize,
) -> Result<RawDom, BrowserError> {
    let concurrency = box_concurrency.max(1);

    // 1. Viewport. `cssContentSize` is the VIEWPORT on obscura (measured), not
    //    the document; recorded as reported rather than corrected, because a
    //    correction here would be this module inventing a number.
    let metrics = page::get_layout_metrics(conn, Some(session))
        .await
        .map_err(|e| engine_failure("Page.getLayoutMetrics", &e))?;
    let viewport = Viewport {
        width: metrics.css_visual_viewport.client_width.round().max(0.0) as u32,
        height: metrics.css_visual_viewport.client_height.round().max(0.0) as u32,
        scroll_x: metrics.css_visual_viewport.page_x.round() as i32,
        scroll_y: metrics.css_visual_viewport.page_y.round() as i32,
        content_width: metrics.css_content_size.width.round().max(0.0) as u32,
        content_height: metrics.css_content_size.height.round().max(0.0) as u32,
        page_scale: metrics.css_visual_viewport.scale,
    };

    // 2. Document identity. The MAIN frame's loader id only: a child frame's is
    //    derived from its frame id and never changes (measured), so it would be
    //    a document identity that never expires.
    let tree = page::get_frame_tree(conn, Some(session))
        .await
        .map_err(|e| engine_failure("Page.getFrameTree", &e))?;
    let main = tree.frame;

    // 3. The tree.
    let root = dom::get_document(conn, Some(session), -1, true)
        .await
        .map_err(|e| engine_failure("DOM.getDocument", &e))?;
    let mut walked = Vec::new();
    let mut element_seq = 0usize;
    walk(&root, None, &mut walked, &mut element_seq)?;
    let element_count = element_seq;

    // 4. Boxes, bounded. `Ok(None)` (the engine's own "could not compute box
    //    model") and `Err` (any other protocol failure) both land on
    //    `rect: None` — different facts, but neither is a rectangle, and
    //    neither may lose the rest of the page.
    let ids: Vec<u64> = walked
        .iter()
        .filter(|w| w.element_index.is_some())
        .map(|w| w.node.backend_node_id)
        .collect();
    let boxes: HashMap<u64, Rect> = futures::stream::iter(ids.into_iter().map(|id| async move {
        // The cast cannot lose an id this walk produced: every one came out of
        // an `i64` on the wire and through `u64::try_from`, which refused the
        // only values that do not round-trip.
        let model = dom::get_box_model(conn, Some(session), id as i64).await;
        (id, model.ok().flatten().as_ref().and_then(rect_from))
    }))
    .buffer_unordered(concurrency)
    .filter_map(|(id, rect)| async move { rect.map(|r| (id, r)) })
    .collect()
    .await;

    // 5. Computed flags and the caret: one call, cross-checked against the walk.
    let first_tag = tag_at_element_index(&walked, 0);
    let last_tag = element_count
        .checked_sub(1)
        .map_or_else(String::new, |last| tag_at_element_index(&walked, last));

    let mut evaluated = fetch_computed(conn, session, element_count, &first_tag, &last_tag).await;
    if evaluated.is_none() && element_count > 0 {
        // One retry, and one only. A page that mutates between the two calls is
        // the case this cross-check exists for; a page that mutates
        // continuously is one we stop trying to describe geometrically rather
        // than describe wrongly.
        tracing::debug!("obscura computed-flag cross-check disagreed; re-running once");
        evaluated = fetch_computed(conn, session, element_count, &first_tag, &last_tag).await;
        if evaluated.is_none() {
            tracing::warn!(
                element_count,
                "obscura computed-flag cross-check disagreed twice; the snapshot will \
                 carry no visibility flags rather than mis-attributed ones"
            );
        }
    }
    let (rows, focus) = match evaluated {
        Some((rows, focus)) => (Some(rows), focus),
        None => (None, Focus::Unknown),
    };

    // 6. Assemble.
    let mut nodes = Vec::with_capacity(walked.len());
    let mut unreached_frames = Vec::new();
    for w in walked {
        let mut node = w.node;
        if let Some(i) = w.element_index {
            node.rect = boxes.get(&node.backend_node_id).cloned();
            node.computed = rows.as_ref().and_then(|r| r.get(i).copied());
            // `clickable_hint` stays `None`, deliberately. It names Chrome's
            // `DOMSnapshot.isClickable`, which obscura does not report at all,
            // and its doc says `None` is "the engine did not say" rather than
            // "no". Filling it from `cursor_pointer` — the obvious move, since
            // that flag is right here — would be wrong twice over: `roles::
            // is_interactive` already returns `true` on `computed.cursor_pointer`
            // BEFORE it ever reads this field, so a `Some(true)` changes no
            // outcome (判据 §1, one fact in two places); and the `Some(false)`
            // it would write on every other element turns "nobody looked" into
            // a denial about a signal that means something else entirely —
            // Chrome marks an element with a click handler and no pointer
            // cursor as clickable (判据 §17, the wrong label costing more than
            // the missing one).
            node.focused = match focus {
                // A `Some(false)` here is an OBSERVATION, not a default: the
                // engine reported where the caret is, so every other element
                // demonstrably does not have it.
                Focus::Observed(at) => Some(at == Some(i)),
                Focus::Unknown => None,
            };
            // obscura reaches no iframe content, ever (U3), so every frame
            // element in this capture owns a document this capture does not
            // have. Saying so is the whole job of `unreached_frames`: without
            // it, "the iframe was never read" and "the iframe is empty" are the
            // same observation.
            //
            // **`FRAME_ELEMENTS` is shared with `fetch_chromium`, and its
            // NARROWNESS is re-justified here rather than inherited.** That set
            // omits `OBJECT`/`EMBED` for a Chromium-specific reason — their
            // absence from `contentDocumentIndex` is evidence of nothing,
            // because they establish a browsing context only for some `type`s,
            // and over-flagging would refuse captures of complete pages. **That
            // reason does not transfer**: here nothing is reached, so there is
            // no evidence to be ambiguous about, and the same omission would
            // instead leave an `<object data="x.html">` document undeclared —
            // the §8 shape this list exists to prevent.
            //
            // Kept narrow anyway, on a MEASUREMENT taken for this decision
            // rather than on the inherited sentence — and the measurement is a
            // reading of the shipped binary, not a survey of its source:
            // obscura creates a browsing context for `<iframe>` and nothing
            // else. On the installed `v0.2.2` binary, defaults only, a
            // PARSE-TIME document carrying an `<iframe>`, an `<object data>`
            // and an `<embed src>` — all three parsed, `querySelectorAll`
            // counts 1/1/1 — answers `window.frames.length` = **1**, with
            // `contentWindow` and `contentDocument` **non-null on the
            // `<iframe>`** and **present and NULL on the `<object>` and the
            // `<embed>`**. Present-and-null is written down rather than
            // summarised because it is the shape most likely to be misread as
            // "not loaded yet" instead of "never creates one".
            //
            // **The CDP frame surfaces cannot settle this and were not used.**
            // `Page.getFrameTree` reports **zero** child frames for that
            // working `<iframe>`, and `Target.getTargets` reports one target,
            // the page itself — the same answer both give for a page with no
            // iframe at all. An empty enumeration is not evidence of an empty
            // browser (判据 §8), and a frame count read off either surface
            // would be 恒 0 on this engine (判据 §2).
            //
            // Corroborated at source, at the tag: in
            // `obscura-browser/src/page.rs`, the file that owns frame
            // lifecycle, the quoted tag `"iframe"` occurs exactly once (a
            // `query_selector` gate at `:3526`, deciding whether there are any
            // frames at all), and `"object"` and `"embed"` occur **zero**
            // times in it; the whole frame registry is spelled `_iframeWin` /
            // `__obscura_frameElements`. `<object>` and `<embed>` appear only in
            // `obscura-render`'s replaced-element layout list and in a URL
            // attribute table.
            //
            // ⚠️ This paragraph used to open that survey with "9044 lines", and
            // `:3587` for the gate. **Both are `main`'s numbers**: at the
            // `v0.2.2` tag the file is 8026 lines and the gate is at `:3526`.
            // The line count carried the whole weight of "someone went and
            // measured", so it is not quietly renumbered — it is REMOVED. A
            // file's length was never the evidence for what creates a browsing
            // context, and a number that moves every release is the wrong thing
            // to lean on when the engine itself can be asked. The grep counts
            // above are re-verified at the tag; the line count is gone.
            //
            // So on this engine an `<object>` has no document for anyone to
            // have missed, and declaring one unreached would be a claim about a
            // document that does not exist — 判据 §17, the wrong label costing
            // more than the missing one.
            //
            // `FRAME` (a `<frameset>` child) is the one entry that is wider
            // than obscura needs. It is kept rather than filtered: sharing one
            // spelling of "which elements own a browsing context" is worth more
            // than trimming a tag that requires `<frameset>` to appear at all
            // (判据 §12), and over-declaring there costs a confession nobody
            // will read on a page nobody serves.
            if FRAME_ELEMENTS.contains(&node.tag_lower().to_ascii_uppercase().as_str()) {
                unreached_frames.push(UnreachedFrame::NotCaptured(node.backend_node_id));
            }
        }
        nodes.push(node);
    }
    cascade_effective_styles(&mut nodes);

    Ok(RawDom {
        engine: Engine::Obscura,
        viewport,
        unreached_frames,
        // Exactly one frame, always: obscura ignores `pierce` and an iframe is
        // never its own target (measured).
        frames: vec![RawFrame {
            frame_id: main.id,
            loader_id: main.loader_id,
            offset: (0, 0),
            // This IS the page's renderer — obscura has exactly one, by
            // construction (every frame shares one V8 isolate), so no
            // `backendNodeId` in this capture is from anywhere else.
            separate_renderer: false,
            // This fetcher does not read the live DOM properties. See the
            // module doc: `false` selects the content-attribute fallback, which
            // is the honest reading when nobody looked.
            live_properties_observed: false,
            nodes,
        }],
    })
}

/// Turn each node's OWN reported style into its EFFECTIVE one.
///
/// [`Computed`]'s doc states this as an obligation on the fetcher, in its own
/// words: *"a fetcher must report the **effective** style of each node: a child
/// of a `display: none` subtree must itself carry `display_none: true`"* —
/// because [`super::build::visibility_of`] judges each node by its own
/// `Computed` and never walks ancestors.
///
/// # TWO questions decide this, not one — for BOTH fetchers, derived once
///
/// An earlier version of this paragraph put the whole thing on one question and
/// was therefore false for `opacity`. Which flags a fetcher must re-derive is
/// settled by these two, asked of its own engine:
///
/// **Q1 — does the engine resolve INHERITED properties before it answers?**
/// This settles `visibility` and `cursor`, the two CSS inherits. Chromium: YES.
/// obscura: NO, and that is read in obscura's own source below, never inferred
/// from CSS — CSS is exactly what the first version of this paragraph reasoned
/// from, and it was right about the CSSOM and wrong about the only engine this
/// file serves.
///
/// **Q2 — does the engine's answer for a DESCENDANT already account for the
/// ancestor?** This settles `display` and `opacity`, which CSS does not inherit
/// and which therefore resolve to the descendant's own value on every engine —
/// so the only thing that can save a fetcher is the engine omitting or marking
/// the descendant some other way. The answers are per flag, not per engine:
///
/// | | Q1 `visibility` | Q1 `cursor` | Q2 `display` | Q2 `opacity` |
/// |---|---|---|---|---|
/// | Chromium | resolved ⇒ nothing to do | resolved ⇒ nothing to do | **yes**: a `display:none` subtree gets no `DOMSnapshot` layout entry at all, so `computed` is `None` and `rect: None` carries it (`fetch_chromium::computed_from`'s own doc) | **NO** — see below |
/// | obscura | own value ⇒ **this function** | own value, and not even that (see the `cursor` section) | no ⇒ **this function** | no ⇒ **this function** |
///
/// **So: `fetch_chromium` must not copy the `visibility` arm** — Chrome answers
/// Q1 yes, and OR-ing there would hide elements Chrome correctly called visible.
/// That is 判据 §16 inverted, and it is the only arm the inversion covers.
///
/// ⚠️ **`fetch_chromium` answers Q2 NO for `opacity`, and it now compensates —
/// in its own function, [`super::fetch_chromium::cascade_opacity`], for that
/// one flag only.** This paragraph used to say the gap was open and unfixed;
/// it was, until Task 17b closed it, and leaving the old wording here would be
/// this file telling the next reader that the twin still has a defect it does
/// not (判据 §1). The Q2 answer itself is unchanged and still **NO**, which is
/// exactly why that function has to exist.
///
/// Its predictions were then checked against a running browser rather than
/// left source-level: Chrome 153.0.8010.36 reports `opacity: "1"` for an
/// ELEMENT two levels inside an `opacity: 0` container and lays it out, while
/// the `display: none` subtree gets no layout entry and a
/// `visibility: hidden` descendant already reads `hidden`. The capture is
/// `fetch_chromium`'s `fixtures/local-hidden-containers.domsnapshot.json`; the
/// per-arm readings are in that function's doc, not restated here.
///
/// **Measured first, on the installed `v0.2.2` binary with default flags; the
/// source lines below are corroboration, not the evidence.**
/// `<div style="visibility:hidden"><span>x</span></div>` answers
/// `getComputedStyle(span).visibility` = **`"visible"`** while the div itself
/// answers `"hidden"` — and the same pair comes back when the rule is written
/// in a stylesheet (`#ss-vis{visibility:hidden}`) instead of inline. Chrome
/// answers `"hidden"` on both children. **Control, so this is a statement
/// about `visibility` and not about inheritance generally:** on the same
/// engine in the same run, `color: rgb(1,2,3)` on a parent reads back as
/// `rgb(1, 2, 3)` on a dynamically appended child. Inheritance works;
/// `visibility` specifically does not. That one reading is the only thing that
/// distinguishes `None` → `"visible"` from a real inherited `"hidden"`, which
/// is the entire subject of the three bullets below.
///
/// * `LayoutStyle::visibility_hidden` is the element's **own** value. obscura's
///   words: *"`visibility: hidden|visible`, own value. `None` means 'inherit
///   the ancestor's computed value' (visibility, unlike most box properties, is
///   a real inherited CSS property). Resolved into `effectively_invisible`
///   during `dom::layout_dom`'s inheritance pass"*
///   (`crates/obscura-render/src/lib.rs:1409-1413` — **verified unmoved at
///   `v0.2.2`**; the file is byte-identical between the tag and the tree this
///   claim was first read on).
/// * The resolution is real and it **never reaches JS**.
///   `refresh_effective_visibility` computes
///   `style.visibility_hidden.unwrap_or(parent_state.0)` and writes the answer
///   to `effectively_invisible` (`crates/obscura-render/src/dom.rs:1043-1049`
///   — **verified unmoved at `v0.2.2`**, file byte-identical);
///
///   **This is the one claim in this file whose primary evidence is still a
///   source line, and the reason no reading replaces it is worth stating.**
///   How the field is COMPUTED — the `||` between `visibility_hidden` and
///   `opacity_zero` inside the inheritance pass — is an internal layout value
///   on no CDP surface. Its only external consequence is paint, and reading a
///   rendered pixel and calling it a `getComputedStyle` fact would be a chain
///   rather than a capture: the conclusion's scope would be the method, and
///   the method would be "something in the paint path made this dark", which
///   does not name the operator between the two terms (判据 §18). No probe was
///   invented for it. What IS measured is the next bullet's half — that the
///   field never crosses the wire — and those are different claims.
///   and it stays inside the renderer: at `v0.2.2`, `effectively_invisible` has
///   **zero** occurrences outside `obscura-render` — **none in the
///   computed-style map, none in `obscura-cdp`, none in `obscura-js`** — which
///   is the whole of the claim. **16 occurrences on 14 LINES** — `dom.rs:1051`
///   and `:1054` each carry two — which is the number with its instrument
///   attached (判据 §18). The sentence here used to say "14 occurrences", and
///   fix round 1 established what that was: **not `main`'s number, a UNIT
///   error.** `grep -c` counts lines and `grep -o | wc -l` counts occurrences,
///   and they differ here by exactly the amount of the original mistake — so
///   the round that "corrected" it to 16 got the number right and the reason
///   wrong, and wrote the wrong reason down. The total was never the evidence
///   either way: the ZERO outside is.
///
///   **And the wire says the same thing, which is stronger than the grep.**
///   Read on the installed `v0.2.2` binary: neither computed-style key set
///   carries anything matching `/invisib|effective|occlud|obscur/i` — zero hits
///   among the native map's 74 entries and zero among the JS wrapper's 309 —
///   and `'effectivelyInvisible' in getComputedStyle(el)` is `false`. *(Method
///   note: `getPropertyValue('effectively-invisible')` returns `""`, but so
///   does `getPropertyValue('totally-made-up-prop')`. `""` can only say "I do
///   not know" (判据 §8), so the verdict rests on the key enumeration and not
///   on that.)*
/// * What the map inserts for `"visibility"` is
///   `if style.visibility_hidden.unwrap_or(false) { "hidden" } else { "visible" }`
///   (`crates/obscura-render/src/paint.rs:1379-1387` at `v0.2.2`) — **the own
///   value, with `None` collapsed into `Some(false)`**. The JS shim serves that
///   key straight out of the native snapshot and does no ancestor walk
///   (`crates/obscura-js/js/bootstrap.js:8472` at `v0.2.2`).
///
///   Both addresses were repaired: they read `paint.rs:1444-1452` and
///   `bootstrap.js:8479`, which are `main`'s. At `a1e09de6` those resolve —
///   which is the failure mode that reads like fact — to the tail of the
///   `white-space` insert running into the head of the `text-overflow` one,
///   and to `if (Number.isFinite(value)) return String(…)`, the opacity clamp
///   inside `lookup`'s inline tier. The CONTENT at the two correct addresses is
///   byte-identical to what was read, so the conclusion never moved; only the
///   evidence pointing at it did.
///
///   *(Those two landing readings are at a FIXED commit, so unlike a citation
///   into a moving file they cannot rot. They were nonetheless wrong when first
///   written here: the `8479` one said "a blank line", inherited from the
///   citation map's `bootstrap.js` rows, which are permuted. Fix round 1
///   re-measured all seven landing readings in this file at the tag; three were
///   wrong and all three were the map's `bootstrap.js` trio. The round that
///   wrote them had verified every repaired ADDRESS itself and then reported
///   that as having checked every number the map gave — 判据 §18, a
///   conclusion's scope is its method.)*
///
/// ## 连线优先: the resolved answer was looked for before it was re-derived
///
/// It is on no obscura CDP surface. All four readings below were re-taken at
/// `v0.2.2` for this round. There is **no `CSS` domain** —
/// `crates/obscura-cdp/src/domains/` has no `css.rs` (verified: fifteen
/// domain modules beside `mod.rs`, none of them CSS), `CSS.getComputedStyleForNode` has zero
/// occurrences in that crate (verified), and `CSS.enable` is a fast-path `{}`
/// in `server.rs:1615` — **this read `:1719`, which is `main`'s and at the tag
/// is the `Message::Close` arm of the socket loop**.
/// `DOMSnapshot.captureSnapshot` writes the literal `"visible"` into a constant
/// style vector for every node (`domains/domsnapshot.rs:215-226`, **verified
/// unmoved at `v0.2.2`** — the vector is exactly those twelve lines) — the
/// fabrication this module's head doc already refuses to read.
/// `Accessibility.getFullAXTree` hard-codes `"ignored": false`
/// (`domains/accessibility.rs:131`, **verified unmoved**). `DOM.*` reports no
/// visibility at all. One `Runtime.evaluate` on `getComputedStyle` is the only
/// surface there is, so the inheritance obscura already computed has to be
/// re-derived here.
///
/// ⚠️ **Those four citations were missed by the audit that repaired the rest of
/// this file, and the reason is worth more than the fix (判据 §6 — 数错的方向
/// 永远是少一个).** That audit enumerated citations by grepping for the
/// `crates/obscura-…:NNN` form. These four are written WITHOUT the prefix, so
/// the census reported seventeen citations and nine repairs when the true
/// numbers were twenty-one and ten — and the one extra repair is in this
/// paragraph. A citation that does not name the crate it points into is
/// invisible to the next person auditing them; when you add one here, spell the
/// path in full.
///
/// # What is cascaded
///
/// * `display` — not inherited: the resolved value for an element inside a
///   `display: none` subtree is **that element's own** `display` (`block`,
///   say). CSS does not rewrite it to `none`; the subtree simply generates no
///   boxes. OR is exact.
/// * `opacity` — not inherited, and it group-composites, so a child at
///   `opacity: 1` inside `opacity: 0` is still invisible and cannot re-show
///   itself by DECLARING anything. **The OR ALONE is exact on THIS engine, and
///   the qualifier is not pedantry — it is false on the twin.** On Chromium a
///   descendant leaves the ancestor's paint group without declaring anything,
///   by entering the top layer (`<dialog>.showModal()`, `showPopover()`,
///   `requestFullscreen()`), so the twin's OR has a second arm: a node the
///   engine names in `DOM.getTopLayerElements` is a cascade ROOT and its parent
///   edge is skipped. That arm is measured, and owned, in
///   [`super::fetch_chromium::cascade_opacity`]'s doc — not restated here. This
///   cascade has no such arm, and the next bullet is why that is a measurement
///   rather than an omission.
///
///   obscura has no top layer **in layout at all**, which is why the exactness
///   survives here with no second arm — and that is a reading of the shipped
///   binary on four independent surfaces, not a grep. On the installed
///   `v0.2.2` binary, defaults only, with a `<dialog>` and a `[popover]`
///   inside an `opacity: 0` ancestor:
///
///   | probe | Chrome would say | obscura `v0.2.2` says |
///   |---|---|---|
///   | `DOM.getTopLayerElements` | the top-layer element list | **`-32601 "Unknown DOM method: getTopLayerElements"`** |
///   | `getComputedStyle(dialog).display`, dialog CLOSED | `"none"` (UA `dialog:not([open])`) | **`"block"`** |
///   | `getBoundingClientRect()` before → after `showModal()` | re-centred, `width:fit-content` | **byte-identical: `{x:8,y:80,width:1264,height:18}`** |
///   | `DOM.getBoxModel(dialog)` after promotion | — | `[8,80,1272,80,1272,98,8,98]` — a normal-flow box CONTAINED IN the `opacity:0` div's own box |
///   | `showPopover()` then `getComputedStyle(pop).display` | `"none"` → `"block"` | **`"block"` both before and after** |
///
///   The full-width `1264px` box and the unchanged rect say it never receives
///   modal UA styling at all: the dialog is an ordinary block child of its
///   faded ancestor and stays there when promoted.
///
///   **Two controls, because a CONFIRMING reading is exactly when to check the
///   instrument.** `:modal` is not 恒真 — `true` on the open modal, `false` on
///   a closed dialog, `false` on a plain `<div>`, `false` again after
///   `close()`; same for `:popover-open`. And the prober's own `DOMSnapshot`
///   needle search produced a **false positive** they caught: `modal` and
///   `popover` both hit until the fixture's TEXT was changed to neutral
///   strings, at which point `modal` went false — the first hit had been their
///   own input, not a structural field (判据 §3). `topLayer` / `top_layer` /
///   `isModal` were false throughout. That format carries property *indices*
///   rather than names, so it is one surface of four and deliberately not the
///   load-bearing one; the load-bearing evidence is the unchanged geometry and
///   the absent CDP method.
///
///   **What obscura implements is the STATE, not the rendering**, which is
///   this bullet's other half: `showModal()` sets the `open` attribute and a
///   `_dialogModal` flag and nothing else, under the comment *"Modal
///   top-layer/focus/render is layout (out of scope)"*
///   (`crates/obscura-js/js/bootstrap.js:3904-3905`, `showModal` at `:3925` —
///   **both verified unmoved at `v0.2.2`**). `:modal` and `:popover-open` ARE
///   answerable in JS (`bootstrap.js:3560-3573`, **verified unmoved**, off
///   `_dialogModal` / `_popoverState`) — so the state is observable while
///   having no rendering consequence, which is exactly the shape that would
///   let someone "fix" this arm here and change nothing but the output.
///
///   `top_layer` having **zero** occurrences in `obscura-render` (**re-measured
///   at `v0.2.2` for this round**, where the earlier reading was taken on
///   `main`) is kept as a source note and DEMOTED on purpose: a string's
///   absence from a source tree
///   is not a fact an artefact can testify to, and the table above decides the
///   same question on the binary Aleph actually installs. The claim expires
///   with the stamp below, which NAMES it, because obscura is the default
///   engine and the way this one rots is a user finding their modal has gone
///   missing, not a reader noticing a stale sentence.
/// * `visibility` — cascaded, **and this OR is an APPROXIMATION.** See below.
///
/// ## The residual on `visibility`, named as a residual
///
/// `unwrap_or(false)` collapses two different answers into one wire value:
/// `None` ("inherit — ask my ancestor") and `Some(false)` ("I declare
/// `visibility: visible`") both arrive as `"visible"`. An OR down these edges
/// therefore cannot tell a descendant that RE-SHOWS itself inside a hidden
/// container from one that said nothing at all, and **it will mark a genuinely
/// visible `visibility: visible` descendant hidden**. That is a real error, not
/// a hypothetical one, and no argument in this file makes it go away: the bound
/// is approximate, which is why the backstop below is about the OR and not
/// about exactness.
///
/// It is taken deliberately, in the cheaper direction (判据 §17). Over-reporting
/// hands the model a ref it will click — and worse here than in the
/// `display: none` case, because a `visibility: hidden` subtree still generates
/// boxes, so the wrong answer arrives wearing a plausible rect and the click
/// lands on a real coordinate where nothing is. Under-reporting omits an
/// element. Every other decision in this module already takes omission.
///
/// Note what the approximation degenerates to: obscura's own rule is
/// `visibility_hidden.unwrap_or(parent)`, which IS this OR for every element
/// that does not declare the property — i.e. for all but the re-showing
/// descendant, which is precisely the residual.
///
/// # `cursor` is left alone, and not for the reason CSS would give
///
/// On obscura `c.cursor === 'pointer'` is **the element's own INLINE
/// `style="cursor:pointer"`, or nothing** — read on the installed `v0.2.2`
/// binary, defaults only, as a DIFFERENTIAL, which is the only instrument that
/// settles it:
///
/// | | `getComputedStyle(el).cursor` |
/// |---|---|
/// | no author rule | `"auto"` |
/// | **inline** `style="cursor:pointer"` | **`"pointer"`** |
/// | **stylesheet** `#ss-cursor{cursor:pointer}` | **`"auto"`** |
///
/// ⚠️ **Do not settle this by enumerating keys. There are TWO key sets and they
/// disagree.** `Object.keys(getComputedStyle(el))` is the JS wrapper's accessor
/// list — **309** entries, and `cursor` IS one of them (`'cursor' in
/// getComputedStyle(el)` is likewise `true`). The **native** indexed map behind
/// it, `s.item(i)` for `i < s.length`, is **74** entries and `cursor` is NOT
/// one of them (neither are `pointer-events` or `user-select`; `display`,
/// `opacity`, `visibility` and `color` are). And the clincher: **with
/// `cursor:pointer` set inline the native set is still exactly 74 and still has
/// no `cursor`** — the delta against a plain element is empty, so the inline
/// value is served by the shim reading the `style` attribute and never by the
/// map. A reader who ran the obvious `Object.keys` probe would have found
/// `cursor` present and concluded this section was wrong: the surface a key
/// enumeration reaches is the one that disagrees with the claim (判据 §9).
///
/// The observable tier ORDER was read the same way — contrast a property the
/// native map carries against one it does not, each set inline and by
/// stylesheet: `display` answers `"none"` from both, `cursor` answers
/// `"pointer"` from inline and falls to the default `"auto"` from a stylesheet.
/// The literal four-branch shape of `lookup()` stays source-only: which tier
/// WINS is measurable, how many branches exist is not.
///
/// Corroborated at source, at the tag: the computed-style map has no `cursor`
/// key at all — `"cursor"` occurs exactly once in
/// `crates/obscura-render/src/paint.rs`, at `:10636`, inside
/// `svg_css_presentation_attribute`'s name list. The shim's `lookup` misses the
/// native snapshot, falls through to the element's **inline** CSSOM
/// (`bootstrap.js:8475`, where `target` is `el.style`, whose
/// `getPropertyValue` `_pull()`s the `style` attribute at `:1704`, **verified
/// unmoved at `v0.2.2`**), and only then to `defaultsKebab`, where
/// `cursor: 'auto'` (`:8454`). So no stylesheet rule reaches this flag and it
/// does not inherit.
///
/// Three of those four addresses were repaired — they read `paint.rs:10718`,
/// `bootstrap.js:8482` and `:8461`, which are `main`'s. At `a1e09de6` they land,
/// respectively, on `fn svg_presentation_substitution_is_guaranteed_invalid`
/// (a DIFFERENT function, adjacent to the right one, which starts at `:10623`),
/// on the closing `}` of the very tier that was cited — with the next tier,
/// `dimensionFor`, on the line after — and on a blank line, one past
/// `defaultsKebab`'s own `};`. Every one resolves; not one says what it was
/// cited for.
///
/// *(Re-measured in fix round 1. Two of those three were wrong as first
/// written: `8482` was called "one tier PAST the one cited" when it is that
/// tier's own closing brace, and `8461` was called "a bare `}`" when the bare
/// `}` is `8482` and `8461` is blank. Both came from the citation map's
/// `bootstrap.js` rows, which are a cyclic permutation of each other, and
/// neither was re-measured by the round that copied them.)*
///
/// **It is NOT 恒假** — the round that raised this said it was, and the inline
/// arm is the one step that claim went too far. It is false for very nearly
/// every element that really has a pointer cursor, which is a different and
/// smaller statement.
///
/// Not repaired, and the reason is a count (判据 §6). `cursor_pointer` has
/// exactly ONE consumer in this tree: `roles::is_interactive` (`roles.rs:227`),
/// the fifth of six OR-ed signals. It can only ADD interactivity, never deny
/// it, and no renderer prints the field, so nothing can spend the `false` as a
/// denial. What it costs is an under-report — an icon-only `<div class="btn">`
/// whose listener was attached by script earns no ref — which is this module's
/// preferred direction; and widening `Computed::cursor_pointer` to
/// `Option<bool>` would change the behaviour of nothing while moving a Task 10
/// wire type. **Cascading it would be strictly worse**: it would spread one
/// element's inline declaration over a subtree the engine never said anything
/// about, manufacturing interactivity instead of missing it.
///
/// The claim rots loudly rather than silently:
/// `the_obscura_source_claims_here_name_the_build_they_were_read_on`.
///
/// # A text node takes its parent's answer whole
///
/// `querySelectorAll('*')` names only elements, so a text node gets no row —
/// and with `computed: None`, `visibility_of` falls through to `rect.is_some()`,
/// which is `None` for every text node here because only elements are asked for
/// a box. **That made every text node on every obscura page read
/// `visible: false`**, and `render_text` drops a text node that is not visible
/// (`render.rs:114`). A text node has no style of its own: it renders exactly as
/// its parent element does, and all four flags are correct to take wholesale.
///
/// # ⚠️ This bites BECAUSE the visibility rule was fixed correctly
///
/// Task 10 changed `visibility_of` to consult `Computed` **first** precisely so
/// that obscura's missing boxes would not read as hidden. That fix is right.
/// It is also what makes `computed` authoritative and the `rect` fallback
/// unreachable — so a `Computed` that says `display_none: false` about a node
/// in a hidden subtree is now believed outright, and the model is shown, and
/// handed a ref to, a control that is not on the page. **A premise consumed by
/// the fix it justified.**
///
/// ⚠️ This paragraph used to end *"`fetch_chromium` cannot have this defect — a
/// hidden subtree gets no `DOMSnapshot` layout entry at all"*. Read strictly as
/// `display: none` that is true and it is why this arm is not copied there.
/// Read as this section reads it — as a claim about the whole class — it is
/// **false, and Task 17b disproved it for `opacity`**: that subtree IS laid
/// out, every descendant reports its own `1`, and the twin needed its own
/// cascade. The narrow reading is the only one that survives, so it is now
/// stated narrowly: **`display: none` specifically** gets no layout entry on
/// Chromium, which is why THIS function's `display_none` arm has no counterpart
/// there. Nothing here licenses a claim about the twin's other flags; those
/// live in `fetch_chromium::cascade_opacity` and are measured on that engine.
///
/// Whoever next reaches for a computed-style read on this engine meets this
/// paragraph first.
fn cascade_effective_styles(nodes: &mut [RawNode]) {
    for i in 0..nodes.len() {
        let Some(parent) = nodes[i].parent else {
            continue;
        };
        // `walk` emits document order, so a parent is always already effective
        // by the time its child is reached. A forward or self edge is not
        // trusted rather than assumed away (P7).
        if parent >= i {
            continue;
        }
        let Some(from_parent) = nodes[parent].computed else {
            continue;
        };
        let effective = match (nodes[i].kind, nodes[i].computed) {
            (RawNodeKind::Element, Some(mut own)) => {
                own.display_none |= from_parent.display_none;
                own.opacity_zero |= from_parent.opacity_zero;
                // `visibility` rides the SAME edge as the other two, and the
                // reason is obscura's, not CSS's: `getComputedStyle` answers
                // the element's OWN `visibility_hidden` with `None` collapsed
                // into `false`, so the inheritance obscura computed into
                // `effectively_invisible` never crosses the wire. Approximate
                // in one direction only — see this function's doc for the
                // residual and for why that direction is the cheap one.
                own.visibility_hidden |= from_parent.visibility_hidden;
                own
            }
            // An element with no row of its own means the cross-check dropped
            // the flags for the whole page. It stays unknown; borrowing the
            // parent's would manufacture a reading the engine never gave.
            (RawNodeKind::Element, None) => continue,
            // Text, and the document/doctype nodes that carry no style.
            _ => from_parent,
        };
        nodes[i].computed = Some(effective);
    }
}

/// The tag at a given `querySelectorAll('*')` position, or `""`.
///
/// One derivation for both anchors — two spellings of "the tag at position k"
/// are free to drift, and these two are compared against each other (判据 §12).
fn tag_at_element_index(walked: &[Walked], index: usize) -> String {
    walked
        .iter()
        .find(|w| w.element_index == Some(index))
        .and_then(|w| w.node.tag.clone())
        .unwrap_or_default()
}

fn engine_failure(method: &str, err: &aleph_cdp::CdpError) -> BrowserError {
    BrowserError::EngineFailure {
        engine: Engine::Obscura,
        reason: format!("{method}: {err}. Re-run browser_snapshot."),
    }
}

async fn fetch_computed(
    conn: &CdpConnection,
    session: &SessionId,
    element_count: usize,
    first_tag: &str,
    last_tag: &str,
) -> Option<(Vec<Computed>, Focus)> {
    let result = runtime::evaluate(conn, Some(session), COMPUTED_FLAGS_JS, false).await;
    let evaluated = match result {
        Ok(r) if r.exception.is_none() => r.value,
        // A JS exception and a transport failure are different, and neither is
        // a set of flags. Both land on `None`, which the caller renders as
        // "unknown visibility" rather than "visible".
        Ok(r) => {
            tracing::warn!(exception = ?r.exception, "obscura computed-flag evaluate threw");
            return None;
        }
        Err(e) => {
            tracing::warn!(error = %e, "obscura computed-flag evaluate failed");
            return None;
        }
    };
    let rows = parse_computed_rows(&evaluated, element_count, first_tag, last_tag)?;
    // Gated behind the row cross-check on purpose: the caret is an INDEX into
    // the very ordering that check validates, so a payload not trusted to be
    // about this tree is not trusted to say where its caret is either.
    let focus = parse_focus(&evaluated, element_count);
    Some((rows, focus))
}

#[cfg(test)]
mod tests {
    use super::*;
    use aleph_cdp::methods::dom::{NO_BOX_CODE, NO_BOX_MESSAGE};
    use aleph_cdp::testkit::{scripted, scripted_slow, FakeCdpServer, Responder};

    /// The reply obscura sends for a node it has no box for — spelled with
    /// `aleph-cdp`'s own constants, because that crate TRANSLATES exactly this
    /// `(code, message)` pair into `Ok(None)` and lets every other protocol
    /// error through as `Err` — the `Err(CdpError::Protocol { .. }) if code ==
    /// NO_BOX_CODE && message.starts_with(NO_BOX_MESSAGE) => Ok(None)` arm of
    /// `aleph_cdp::methods::dom::get_box_model`. **Named, not numbered: this
    /// cited `dom.rs:165-169` until fix round 1, by which time the arm had
    /// moved — that file was edited by the two commits immediately before the
    /// one that wrote this sentence, and `165-169` had become the tail of the
    /// `object.objectId` decode. Where it moved TO is deliberately not written
    /// down: the point of the sentence is that the number rotted, and naming
    /// the new one would start the same clock again. Same defect, found the same way, as the
    /// DOM-agent handshake the stamp below dates — which cited its own call by
    /// line number until that number rotted too. An arm identified by the
    /// constants it matches on cannot be moved by an edit above it.** Two
    /// facts, one wire shape
    /// apart; a literal here would let the two drift and this test module
    /// silently stop covering one of them.
    ///
    /// It cost a mutation to find that out. The `Err`-tolerance test below was
    /// first written with this same message and therefore never reached the
    /// `Err` arm at all — it was exercising the translated `Ok(None)` while its
    /// name said otherwise (判据 §18: a conclusion's scope is its method).
    fn no_box_model() -> Responder {
        Responder::Error {
            code: NO_BOX_CODE,
            message: NO_BOX_MESSAGE.into(),
        }
    }

    /// A protocol error that is NOT the no-box one, so `get_box_model` hands
    /// back a real `Err`. The code is deliberately different from
    /// [`NO_BOX_CODE`]: this is the arm where the engine failed to answer at
    /// all, which is a different fact from "this node has no box".
    fn box_model_transport_error() -> Responder {
        Responder::Error {
            code: -32603,
            message: "Internal error: the renderer went away".into(),
        }
    }

    /// **The engine's own bytes.** A frozen `DOM.getDocument` reply captured
    /// from the real obscura v0.2.2 binary on `probes/t0-page.html` during T0
    /// (2026-09-06), copied verbatim from
    /// `crates/aleph-cdp/tests/fixtures/obscura-DOM.getDocument.json` — Task 1's
    /// file, which this task may not edit (R20).
    ///
    /// Two copies of one capture, and that is deliberate rather than 判据 §1: a
    /// capture is a **frozen measurement**, not a maintained fact, so there is
    /// no pair of values here that can drift apart. The alternative — an
    /// `include_str!` reaching across into another crate's `tests/` directory —
    /// makes `alephcore`'s unit tests depend on `aleph-cdp`'s test layout, and
    /// the alternative the brief proposed (hand-writing 1.7 KB of nested CDP
    /// JSON for a page nobody ran) would have made this very doc comment a lie:
    /// hand-written bytes test serde against itself (判据 §10).
    ///
    /// 88 nodes, 34 elements, `#document` at `backendNodeId: 0` — the node count
    /// T0's U3 probe independently reported for this page.
    const GETDOCUMENT: &str = include_str!("fixtures/t0page-obscura.getdocument.json");

    /// Element positions in `document.querySelectorAll('*')` order, which is
    /// the walk order and the row order. Read off the fixture once, so a test
    /// that means "the hidden div" says so.
    const HTML: usize = 0;
    const HEAD: usize = 1;
    const META: usize = 2;
    const TITLE: usize = 3;
    const STYLE: usize = 4;
    const A_HOME: usize = 7;
    const A_EXTERNAL: usize = 8;
    const INPUT_Q: usize = 13;
    const HIDDEN_NONE: usize = 21;
    const HIDDEN_VIS: usize = 22;
    const OPACITY_ZERO: usize = 25;
    const SCRIPT: usize = 33;
    const ELEMENT_COUNT: usize = 34;
    const FIRST_TAG: &str = "HTML";
    const LAST_TAG: &str = "SCRIPT";

    /// `backendNodeId`s, for assertions that name a node rather than a position.
    const ID_DOCUMENT: u64 = 0;
    const ID_HTML: u64 = 2;
    const ID_A_HOME: u64 = 18;
    const ID_A_EXTERNAL: u64 = 21;
    const ID_H1: u64 = 27;
    const ID_H1_TEXT: u64 = 28;
    const ID_INPUT_Q: u64 = 36;
    const ID_HIDDEN_NONE: u64 = 53;
    const ID_HIDDEN_NONE_TEXT: u64 = 54;
    const ID_HIDDEN_VIS: u64 = 56;
    const ID_IFRAME: u64 = 83;
    /// `HEAD`'s element children — the fixture's only hidden container that
    /// holds ELEMENTS rather than just text, and therefore the only place the
    /// real capture can exercise the element half of the cascade.
    const ID_META: u64 = 5;
    const ID_TITLE: u64 = 7;
    const ID_STYLE: u64 = 10;
    /// **The depth-2 nodes**, one per cascaded flag — the shape that tells a
    /// transitive cascade from a one-edge one. Each is the TEXT inside an
    /// element that is itself inside the flagged container, so reaching it
    /// requires the loop to read the parent's ALREADY-EFFECTIVE value and not
    /// its original one. Read off the fixture: `HEAD(3) → TITLE(7) → text(8)`,
    /// `HEADER(16) → A#home(18) → text(19)`, `MAIN(25) → H1(27) → text(28)`.
    const ID_TITLE_TEXT: u64 = 8;
    const ID_A_HOME_TEXT: u64 = 19;
    /// `MAIN(25) → UL(71) → LI(72)`: the fixture's only chain of two ELEMENT
    /// edges below a container, and therefore the only place an intermediate
    /// ELEMENT carries no flag of its own. Element indices 9 → 27 → 28.
    const MAIN_EL: usize = 9;
    const ID_UL: u64 = 71;
    const ID_LI: u64 = 72;
    const ID_MAIN: u64 = 25;
    const ID_HEADER: u64 = 16;

    fn box_model(x: f64, y: f64, w: f64, h: f64) -> serde_json::Value {
        let quad = serde_json::json!([x, y, x + w, y, x + w, y + h, x, y + h]);
        serde_json::json!({"model": {
            "content": quad, "padding": quad, "border": quad, "margin": quad,
            "width": w as i64, "height": h as i64,
        }})
    }

    /// The `DOM.getBoxModel` answers, keyed by `backendNodeId`.
    ///
    /// **What is measured and what is scaffolding, stated rather than blurred.**
    /// The name says neither, on purpose: this table holds one real measurement,
    /// one stand-in, and ~14 scaffolding coordinates, so no single word over it
    /// can be true of its contents — provenance belongs per entry, below and in
    /// the comments on the rows. (It was `measured_boxes`. The sibling table was
    /// `measured_rows` and had NO measurement in it at all; asking the question
    /// of one and not the other would have left the second member of a two-member
    /// class wearing the word — 判据 §11.)
    ///
    /// The ZERO quad on `#hidden-none` (`display:none`) is U2's actual finding:
    /// obscura answers that call **successfully** with `[0,0,0,0,0,0,0,0]` where
    /// Chromium fails it honestly. The zero on `#external` stands in for U9's
    /// finding that obscura misses the layout of an inline element that is a
    /// direct child of `<body>` — this page's `<a>`s are inside a `<header>` and
    /// would really have boxes, so that placement is scaffolding chosen to
    /// exercise the path, and what the test asserts about it is the fetcher's
    /// MAPPING, never a claim about obscura's layout of a header link. Every
    /// other number here is scaffolding too: the shape of the reply is the
    /// engine's, the coordinates are this table's.
    ///
    /// Ids absent from this map get a protocol error from the dispatcher, which
    /// is a third real case (`rect: None`, page not lost).
    fn box_replies() -> std::collections::HashMap<i64, serde_json::Value> {
        [
            (2, box_model(0.0, 0.0, 1280.0, 3000.0)),   // HTML
            (3, box_model(0.0, 0.0, 0.0, 0.0)),         // HEAD
            (5, box_model(0.0, 0.0, 0.0, 0.0)),         // META
            (7, box_model(0.0, 0.0, 0.0, 0.0)),         // TITLE
            (10, box_model(0.0, 0.0, 0.0, 0.0)),        // STYLE
            (14, box_model(0.0, 0.0, 1280.0, 3000.0)),  // BODY
            (16, box_model(0.0, 0.0, 1280.0, 20.0)),    // HEADER
            (18, box_model(4.0, 2.0, 60.0, 16.0)),      // A#home — a real box
            (21, box_model(0.0, 0.0, 0.0, 0.0)),        // A#external — ZERO quad
            (25, box_model(0.0, 20.0, 1280.0, 2900.0)), // MAIN
            (27, box_model(0.0, 20.0, 1280.0, 37.0)),   // H1
            (53, box_model(0.0, 0.0, 0.0, 0.0)),        // DIV display:none — U2
            (56, box_model(0.0, 100.0, 1280.0, 18.0)),  // DIV visibility:hidden
            (59, box_model(0.0, 0.0, 0.0, 0.0)),        // DIV#zero-size
            (65, box_model(0.0, 140.0, 1280.0, 18.0)),  // DIV opacity:0
            (83, box_model(0.0, 300.0, 304.0, 154.0)),  // IFRAME
        ]
        .into_iter()
        .collect()
    }

    /// The computed rows in document order: four columns per element —
    /// `display_none`, `visibility_hidden`, `opacity_zero`, `cursor_pointer`.
    ///
    /// Built from named positions rather than typed out as 34 literal arrays,
    /// so a row means something to the next reader. R34 cut `overflow_clip`, so
    /// there are four columns and not the five the T0 probe captured; a fifth
    /// would fail `parse_computed_rows`' arity check, which is the right
    /// failure.
    ///
    /// # Not one of these four columns is a measurement, and the name used to say it was
    ///
    /// This was called `measured_rows`. **No obscura `getComputedStyle` capture
    /// exists** — not in `crates/aleph-cdp/tests/fixtures/`, not anywhere in
    /// `docs/superpowers/specs/…-evidence/`. T0's only computed-style capture is
    /// `DOMSnapshot.captureSnapshot` with `{ computedStyles: COMPUTED_STYLES }`
    /// (`probes/t0-capture.mjs:249-250`), written under `{ fixture: CHROME }`,
    /// i.e. **Chromium only**; and the one `Runtime.evaluate` T0 ever sent
    /// obscura was `1 + 1` (`t0-capture.mjs:201-202`, and
    /// `obscura-Runtime.evaluate.json` is `{"value": 2}`). So there was nothing
    /// for any column to be measured FROM, and the word sat over all four.
    ///
    /// Per column, since "constructed" is not one fact but four:
    ///
    /// | col | flag | provenance |
    /// |---|---|---|
    /// | 0 | `display_none` | **Constructed, corroborated indirectly.** U2 measured obscura answering `getBoxModel` on `#hidden-none` with a zero quad, which requires its layout to know the element is `display: none`; the map reads that same field (`obscura-render/src/paint.rs:1338` at `v0.2.2`; this read `:1400`, which is `main`'s and off by three even there). A BOX reading is not a `getComputedStyle` reading (判据 §18) — this is a chain, not a capture. |
    /// | 1 | `visibility_hidden` | **Constructed; the behaviour behind it is now MEASURED.** `#hidden-vis { visibility:hidden }` is a stylesheet rule, obscura's declaration applier writes `LayoutStyle::visibility_hidden`, and the map serves that own value — confirmed on the installed `v0.2.2` binary by the parent/child reading in [`cascade_effective_styles`]'s doc. True of the DECLARING element only, which is that function's whole subject. |
    /// | 2 | `opacity_zero` | **Constructed, source-derived.** `paint.rs:1388` at `v0.2.2` serves `css_number(opacity.unwrap_or(1.0))`, so the declaring element answers `"0"`. (This read `:1453`, `main`'s address, which at the tag is `crate::TextOverflow::Clip => "clip",`.) |
    /// | 3 | `cursor_pointer` | **Constructed, and CONTRADICTED by this file's own derivation — pure scaffolding.** See below. |
    ///
    /// ## Column 3 is scaffolding and must be read as scaffolding
    ///
    /// On `probes/t0-page.html` the pointer cursor comes from a **stylesheet
    /// rule**, `a, button { cursor:pointer; }`, and neither `<a>` carries a
    /// `style` attribute. By the `cursor` section of
    /// [`cascade_effective_styles`], obscura answers `'auto'` for both, so a
    /// real obscura capture would set this column **nowhere on this page**.
    ///
    /// Nor is it Chromium's answer. Measured on the committed capture
    /// `chrome-DOMSnapshot.captureSnapshot.json`: **8** nodes report
    /// `cursor: pointer` — `A#home`, `A#external`, `BUTTON#go`,
    /// `BUTTON#deep-target` and each of their text children. This table flags
    /// **two**. So the row set matches no engine at all: obscura would flag
    /// zero, Chromium four elements.
    ///
    /// It is kept because it is the ONLY thing exercising the column-3 →
    /// `cursor_pointer` mapping, and a mapping with no test is worse than a
    /// labelled fixture. What it may never be read as is evidence that obscura
    /// answers `cursor` — which is exactly what it looked like while it was
    /// called "measured", twenty lines from the paragraph proving the opposite
    /// (判据 §3: a guard that would be cited as evidence FOR the defect costs
    /// more than no guard).
    fn constructed_rows() -> serde_json::Value {
        let mut rows = vec![[false, false, false, false]; ELEMENT_COUNT];
        for i in [HEAD, META, TITLE, STYLE, SCRIPT, HIDDEN_NONE] {
            rows[i][0] = true;
        }
        rows[HIDDEN_VIS][1] = true;
        rows[OPACITY_ZERO][2] = true;
        for i in [A_HOME, A_EXTERNAL] {
            rows[i][3] = true;
        }
        serde_json::json!(rows)
    }

    fn eval_payload(
        rows: serde_json::Value,
        n: usize,
        first: &str,
        last: &str,
        focus: serde_json::Value,
    ) -> serde_json::Value {
        serde_json::json!({"result": {"type": "object", "value": {
            "n": n, "first": first, "last": last, "rows": rows, "focus": focus,
        }}})
    }

    /// The four fixed replies every scenario shares, in Part 1's
    /// `(method, Responder)` form. The frame tree and the layout metrics carry
    /// M-a's and M-e's measured values.
    fn base_entries(
        rows: serde_json::Value,
        n: usize,
        first: &str,
        last: &str,
        focus: serde_json::Value,
    ) -> Vec<(&'static str, Responder)> {
        vec![
            (
                "Page.getLayoutMetrics",
                Responder::Reply(serde_json::json!({
                    "cssVisualViewport": {"pageX": 0, "pageY": 0, "clientWidth": 1280,
                                          "clientHeight": 720, "scale": 1.0, "zoom": 1.0},
                    // M-e: contentSize is the VIEWPORT on obscura, not the document.
                    "cssContentSize": {"x": 0, "y": 0, "width": 1280, "height": 720}
                })),
            ),
            (
                "Page.getFrameTree",
                Responder::Reply(serde_json::json!({"frameTree": {"frame": {
                    "id": "page-1",
                    "loaderId": "loader-010b239d-4769-4df5-a089-5d312c451b51",
                    "url": "http://127.0.0.1:18999/t0-page.html"
                }, "childFrames": []}})),
            ),
            (
                "DOM.getDocument",
                Responder::Reply(serde_json::from_str(GETDOCUMENT).unwrap()),
            ),
            (
                "Runtime.evaluate",
                Responder::Reply(eval_payload(rows, n, first, last, focus)),
            ),
        ]
    }

    /// `DOM.getBoxModel` answers per `backendNodeId`, which the flat
    /// `(method, Responder)` table cannot express — so the base table is
    /// composed with a small dispatcher, which is exactly why Part 1's
    /// `scripted` returns a closure instead of a server.
    async fn server_with(
        rows: serde_json::Value,
        n: usize,
        first: &str,
        last: &str,
        focus: serde_json::Value,
    ) -> FakeCdpServer {
        let boxes = box_replies();
        let base = scripted(base_entries(rows, n, first, last, focus));
        FakeCdpServer::start(move |req| {
            if req["method"] == "DOM.getBoxModel" {
                let id = req["params"]["backendNodeId"].as_i64().unwrap_or(-1);
                return match boxes.get(&id) {
                    Some(v) => Responder::Reply(v.clone()),
                    // An id the table does not cover is a node the engine has
                    // no box for — the ordinary case on a real page, and the
                    // one `aleph-cdp` turns into `Ok(None)`.
                    None => no_box_model(),
                };
            }
            base(req)
        })
        .await
    }

    /// The agreeing server: measured rows, measured anchors, caret on `#q`.
    async fn agreeing_server() -> FakeCdpServer {
        server_with(
            constructed_rows(),
            ELEMENT_COUNT,
            FIRST_TAG,
            LAST_TAG,
            serde_json::json!(INPUT_Q),
        )
        .await
    }

    /// The whole fetcher against the engine's own captured bytes. Asserted on
    /// EFFECTS — the node the `<a>` became, the rect the `<h1>` got, the flag
    /// the hidden `<div>` carries — not on which CDP methods were called.
    #[tokio::test]
    async fn fetch_obscura_builds_one_frame_with_measured_rects_and_constructed_flags() {
        let server = agreeing_server().await;
        let (conn, session) = server.connect_and_attach().await;

        let raw = fetch_obscura(&conn, &session, 4)
            .await
            .expect("fetch must succeed");

        assert_eq!(raw.engine, Engine::Obscura);
        // U3: obscura's getDocument never descends into iframes and an iframe
        // is never its own target, so a page with one still yields ONE frame.
        assert_eq!(raw.frames.len(), 1, "obscura ignores pierce:true");
        let f = &raw.frames[0];
        assert_eq!(f.frame_id, "page-1");
        assert_eq!(f.loader_id, "loader-010b239d-4769-4df5-a089-5d312c451b51");
        assert_eq!(f.offset, (0, 0));
        // One renderer by construction, so every id here is the page session's.
        assert!(!f.separate_renderer);
        // This fetcher does not read the live DOM properties, and says so.
        assert!(!f.live_properties_observed);

        let by_id = |id: u64| f.nodes.iter().find(|n| n.backend_node_id == id).unwrap();

        // A real box survives as a real rect.
        let h1 = by_id(ID_H1);
        assert_eq!(h1.tag.as_deref(), Some("h1"), "tags are lowercased");
        assert_eq!(
            h1.rect,
            Some(Rect {
                x: 0,
                y: 20,
                w: 1280,
                h: 37
            })
        );
        assert!(!h1.computed.as_ref().unwrap().display_none);

        // A zero box becomes `None`, NOT `Some(0x0)`. A zero-sized rect would be
        // spent downstream as a real position and clicked at (0,0).
        let a = by_id(ID_A_EXTERNAL);
        assert_eq!(a.tag.as_deref(), Some("a"));
        assert_eq!(a.rect, None, "a zero quad is an absence, not a coordinate");
        // …and it is emphatically NOT hidden: the flags say so, which is why
        // `rect: None` may not be read as invisibility on this engine.
        let c = a
            .computed
            .as_ref()
            .expect("the evaluate covered every element");
        assert!(!c.display_none && !c.visibility_hidden && !c.opacity_zero);
        assert!(
            c.cursor_pointer,
            "column 3 must reach `cursor_pointer`. This row is SCAFFOLDING, not \
             a measurement: on this page the pointer cursor comes from a \
             stylesheet rule, and `cascade_effective_styles`' `cursor` section \
             shows obscura answers `'auto'` for it. What is under test is the \
             column-3 mapping, which nothing else exercises — never that \
             obscura reports `cursor`"
        );
        // …and it is NOT laundered into `clickable_hint`, which names a signal
        // obscura does not report. `roles::is_interactive` reads
        // `computed.cursor_pointer` before it reads this field, so a copy here
        // would change nothing when true and would deny a different signal on
        // every element when false.
        assert_eq!(
            a.clickable_hint, None,
            "cursor:pointer is not DOMSnapshot's isClickable"
        );
        assert!(
            f.nodes.iter().all(|n| n.clickable_hint.is_none()),
            "obscura reports no isClickable for any node"
        );
        assert!(
            crate::browser::page_state::build::visibility_of(a),
            "a boxless element whose styles say visible IS visible on obscura"
        );
        assert_eq!(
            a.attrs
                .iter()
                .find(|(k, _)| k == "href")
                .map(|(_, v)| v.as_str()),
            Some("https://example.invalid/docs"),
            "flat CDP attribute pairs are zipped into (name, value)"
        );
        // The sibling link kept its real box — the zero above is one node's
        // fact, not the fetcher flattening every link.
        assert_eq!(
            by_id(ID_A_HOME).rect,
            Some(Rect {
                x: 4,
                y: 2,
                w: 60,
                h: 16
            })
        );

        // U2: `display:none` returns a box SUCCESSFULLY on obscura, with a zero
        // quad. The flag, never the box, is what makes this hidden.
        let hidden = by_id(ID_HIDDEN_NONE);
        assert!(hidden.computed.as_ref().unwrap().display_none);
        assert_eq!(hidden.rect, None);
        assert!(!crate::browser::page_state::build::visibility_of(hidden));

        // visibility:hidden keeps its layout box — the flag is what hides it.
        let invis = by_id(ID_HIDDEN_VIS);
        assert_eq!(
            invis.rect,
            Some(Rect {
                x: 0,
                y: 100,
                w: 1280,
                h: 18
            })
        );
        assert!(invis.computed.as_ref().unwrap().visibility_hidden);

        // Text nodes come through with their value and their parent.
        let text = by_id(ID_H1_TEXT);
        assert_eq!(text.kind, RawNodeKind::Text);
        assert_eq!(text.text.as_deref(), Some("T0 probe page"));
        let parent = text.parent.expect("a text node has a parent");
        assert_eq!(f.nodes[parent].backend_node_id, ID_H1);

        // …and a text node is VISIBLE. `querySelectorAll('*')` names only
        // elements, so a text node gets no row; with `computed: None` it would
        // fall through to `rect.is_some()`, and only elements are asked for a
        // box here — which made **every text node on every obscura page** read
        // as invisible, and `render_text` drops a text node that is not visible.
        // It takes its parent element's styles wholesale.
        assert!(
            crate::browser::page_state::build::visibility_of(text),
            "a text node under a visible element is visible"
        );
        assert_eq!(text.computed, by_id(ID_H1).computed);
        // The same rule the other way: the text inside the display:none div is
        // hidden, because its parent is.
        let hidden_text = by_id(ID_HIDDEN_NONE_TEXT);
        assert_eq!(hidden_text.kind, RawNodeKind::Text);
        assert!(hidden_text.computed.expect("inherited").display_none);
        assert!(!crate::browser::page_state::build::visibility_of(
            hidden_text
        ));

        // M-e: contentSize is the VIEWPORT on obscura, recorded as measured.
        assert_eq!(raw.viewport.width, 1280);
        assert_eq!(raw.viewport.height, 720);
        assert_eq!(raw.viewport.content_height, 720);
    }

    /// **F3 — the three flags obscura answers per-element are cascaded by the
    /// fetcher, `visibility` among them.**
    ///
    /// `Computed`'s doc puts this obligation on the fetcher: a child of a
    /// `display: none` subtree must itself carry `display_none: true`, because
    /// `visibility_of` judges each node alone and never walks ancestors. The raw
    /// `getComputedStyle` answer does not provide that on this engine, and the
    /// reason is **obscura's, not CSS's**: `display` and `opacity` are not
    /// inherited properties at all, and `visibility` is — but obscura's
    /// computed-style map serves `style.visibility_hidden.unwrap_or(false)`,
    /// the element's OWN value, and the inheritance pass that resolves it
    /// writes `effectively_invisible`, which reaches no CDP surface
    /// (`crates/obscura-render/src/lib.rs:1409-1413`, `paint.rs:1379-1387`,
    /// `dom.rs:1043-1049`, all at `v0.2.2`). See [`cascade_effective_styles`]
    /// for the reading that settles it on the shipped binary, for the full
    /// derivation and for the residual the OR carries.
    ///
    /// **This assertion previously pinned the opposite answer**, on the CSS
    /// argument — which is true of the CSSOM and false of this engine — and a
    /// guard that would be cited as evidence for the defect costs more than no
    /// guard at all (判据 §3). What it pins now is the OR: delete
    /// `own.visibility_hidden |= from_parent.visibility_hidden` and `A#home`
    /// goes back to reporting itself visible inside a hidden `<header>`, and
    /// this test names it.
    ///
    /// **The corpus needed a shape the captured page does not otherwise give.**
    /// Every hidden container in the real fixture (`#hidden-none`,
    /// `#opacity-zero`) holds only a text node, so a per-element defect was
    /// invisible to a green suite — 判据 §3, a guard covering only the shapes
    /// its corpus contains. The shape here is `HEAD` → `META`/`TITLE`/`STYLE`,
    /// which the real bytes do contain; what this test supplies is the ROW set
    /// that distinguishes the cases, marking only the container. That is not a
    /// fiction: after the fix the expression reports raw per-element values by
    /// design, so "container none, children not" is exactly what a real engine
    /// sends for a container hidden by a stylesheet rather than by the UA sheet.
    #[tokio::test]
    async fn styles_that_do_not_inherit_are_cascaded_to_descendants() {
        // Raw rows: only the CONTAINERS carry a flag.
        let mut rows = vec![[false, false, false, false]; ELEMENT_COUNT];
        rows[HEAD][0] = true; // display:none on the container only
        rows[9][2] = true; // opacity:0 on MAIN only (element index 9)
        rows[6][1] = true; // visibility:hidden on HEADER only (element index 6)
        let server = server_with(
            serde_json::json!(rows),
            ELEMENT_COUNT,
            FIRST_TAG,
            LAST_TAG,
            serde_json::json!(-1),
        )
        .await;
        let (conn, session) = server.connect_and_attach().await;
        let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
        let f = &raw.frames[0];
        let by_id = |id: u64| f.nodes.iter().find(|n| n.backend_node_id == id).unwrap();

        // `display` does NOT reach descendants on its own. These three are
        // elements, not text, which is the half the fixture could not show.
        for id in [ID_META, ID_TITLE, ID_STYLE] {
            let n = by_id(id);
            assert_eq!(n.kind, RawNodeKind::Element, "id {id} must be an element");
            assert!(
                n.computed.expect("flags present").display_none,
                "element {id} is inside a display:none subtree and must say so — \
                 otherwise the model is shown, and handed a ref to, a control \
                 that is not on the page"
            );
            assert!(!crate::browser::page_state::build::visibility_of(n));
        }

        // `opacity` is not an inherited property either. H1 is MAIN's child.
        let h1 = by_id(ID_H1);
        assert!(
            h1.computed.expect("flags present").opacity_zero,
            "an element inside an opacity:0 subtree is not visible"
        );
        assert!(!crate::browser::page_state::build::visibility_of(h1));
        assert!(by_id(ID_MAIN).computed.unwrap().opacity_zero);

        // …and `visibility` IS propagated, because obscura answers the own
        // value. `A#home` is the `<header>`'s child; on the engine this fetcher
        // serves, `getComputedStyle(a).visibility` is `"visible"` here, and
        // believing it hands the model a ref carrying a PLAUSIBLE rect — a
        // `visibility: hidden` subtree still generates boxes — so the click
        // lands on a real coordinate where nothing is.
        assert!(by_id(ID_HEADER).computed.unwrap().visibility_hidden);
        let a_home = by_id(ID_A_HOME);
        assert!(
            a_home.computed.unwrap().visibility_hidden,
            "an element inside a visibility:hidden subtree must say so: obscura \
             reports each element's OWN `visibility`, never the inherited one \
             (obscura-render/src/paint.rs:1379-1387 at v0.2.2), so nothing \
             upstream of \
             this cascade has applied the inheritance"
        );
        assert!(!crate::browser::page_state::build::visibility_of(a_home));

        // A sibling subtree is untouched — the cascade follows edges, not the
        // document order it walks in.
        assert!(!by_id(ID_IFRAME).computed.unwrap().display_none);

        // **DEPTH 2 — the transitivity, which every assertion above is blind
        // to.** Each node named above is ONE edge from its flagged container,
        // so all of them stay green under a cascade that reads the parent's
        // ORIGINAL value instead of its already-effective one — the shape a
        // future author produces by "cleaning up" the aliasing read, or by
        // moving this loop to `split_at_mut`. That mutation was run against the
        // whole browser suite and scored 534 passed / 0 failed, identical to the
        // control, while every node at depth ≥ 2 in every hidden subtree went
        // back to reporting itself visible — the same defect this test exists
        // for, one level down, with nothing red (判据 §3: a green covers only
        // the shapes its corpus contains).
        //
        // **What these three catch, measured rather than claimed.** They catch
        // the TEXT arm reading a stale parent — `_ => from_parent` — which is
        // what the whole-value mutation above breaks. They do NOT catch a
        // single-flag break in the ELEMENT arm: replacing only
        // `own.display_none |= from_parent.display_none` with a read of the
        // parent's original value scores **534 passed / 0 failed** against
        // these, because every node named here has a flagged container as its
        // grandparent, so one stale hop still lands on the flag. An earlier
        // version of this comment claimed otherwise; the mutation said no.
        // `the_cascade_is_transitive_through_an_element_that_carries_no_flag`
        // below is the one that covers that arm, and it needs a DIFFERENT shape
        // — two ELEMENT edges — which this row set does not contain.
        let read: [(u64, fn(Computed) -> bool, &str); 3] = [
            (ID_TITLE_TEXT, |c| c.display_none, "display_none"),
            (ID_A_HOME_TEXT, |c| c.visibility_hidden, "visibility_hidden"),
            (ID_H1_TEXT, |c| c.opacity_zero, "opacity_zero"),
        ];
        for (id, flag, name) in read {
            let n = by_id(id);
            assert_eq!(n.kind, RawNodeKind::Text, "node {id} must be a text node");
            let c = n.computed.expect("flags present");
            assert!(
                flag(c),
                "node {id} is TWO edges below the container flagged `{name}` —                  its own parent carries no flag of its own, so this is only                  true if the cascade read the parent's ALREADY-EFFECTIVE value.                  A one-edge-deep corpus cannot tell that apart from a cascade                  that reads the parent's original value, and the whole suite is                  green on the broken one."
            );
            assert!(!crate::browser::page_state::build::visibility_of(n));
        }
    }

    /// **The ELEMENT arm is transitive too — through an intermediate element
    /// that declares nothing of its own.**
    ///
    /// The depth-2 assertions in the test above ride the TEXT arm. They are
    /// blind to a single-flag break in the element arm, and that is a
    /// measurement, not a worry: replacing only
    /// `own.display_none |= from_parent.display_none` with a read of the
    /// parent's ORIGINAL value scored **534 passed / 0 failed** — the whole
    /// browser suite green — because every node those assertions name has a
    /// flagged container as its GRANDparent, so one stale hop still lands on
    /// the flag.
    ///
    /// The shape that tells them apart needs **two ELEMENT edges** with the
    /// middle one unflagged, and the fixture contains exactly one:
    /// `MAIN(25) → UL(71) → LI(72)`. Under a non-transitive cascade `UL` still
    /// picks the flag up from `MAIN` and `LI` does not, so `LI` goes back to
    /// reporting itself visible while nothing else moves.
    ///
    /// Run over all three cascaded flags rather than one, because the three
    /// `|=` lines are separate statements and a break in one is invisible to an
    /// assertion about another — which is the thing the other test's comment
    /// once claimed for itself and does not have.
    #[tokio::test]
    async fn the_cascade_is_transitive_through_an_element_that_carries_no_flag() {
        let cases: [(usize, fn(Computed) -> bool, &str); 3] = [
            (0, |c| c.display_none, "display_none"),
            (1, |c| c.visibility_hidden, "visibility_hidden"),
            (2, |c| c.opacity_zero, "opacity_zero"),
        ];
        for (col, flag, name) in cases {
            // Only MAIN declares anything. UL and LI declare nothing, which is
            // what a real engine sends for a subtree hidden by one rule on the
            // container.
            let mut rows = vec![[false, false, false, false]; ELEMENT_COUNT];
            rows[MAIN_EL][col] = true;
            let server = server_with(
                serde_json::json!(rows),
                ELEMENT_COUNT,
                FIRST_TAG,
                LAST_TAG,
                serde_json::json!(-1),
            )
            .await;
            let (conn, session) = server.connect_and_attach().await;
            let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
            let f = &raw.frames[0];
            let by_id = |id: u64| f.nodes.iter().find(|n| n.backend_node_id == id).unwrap();

            // The intermediate first, so a failure says WHICH hop was lost.
            assert!(
                flag(by_id(ID_UL).computed.expect("flags present")),
                "the intermediate UL must carry `{name}` from MAIN — if this is \
                 the red one, the cascade is not running at all, not merely \
                 non-transitive"
            );
            let li = by_id(ID_LI);
            assert_eq!(li.kind, RawNodeKind::Element);
            assert!(
                flag(li.computed.expect("flags present")),
                "LI is two ELEMENT edges below the container flagged `{name}`, \
                 and its parent UL declares nothing of its own — so this is \
                 true only if the cascade read UL's ALREADY-EFFECTIVE value. A \
                 cascade that reads the parent's original value passes every \
                 other assertion in this file and hands the model a ref to a \
                 list item nobody can see"
            );
            assert!(!crate::browser::page_state::build::visibility_of(li));
        }
    }

    /// A parent edge that points FORWARD is refused, not followed.
    ///
    /// **Carried over from the twin, which is where it was found** (判据 §16).
    /// `fetch_chromium::cascade_opacity` has the identical `parent >= i` guard
    /// with the identical P7 comment, and its Task 17b review measured that the
    /// guard could be DELETED with the whole suite still green — this file had
    /// no forward-edge test at all, so the same hole was here and unmeasured.
    /// The cascade *semantics* differ per engine and deliberately must not be
    /// copied; the guard's falsifier is the same mechanism answering the same
    /// question, so it transfers.
    ///
    /// ⚠️ **And then the two engines parted company, which is why the twin's
    /// copy of this test is now about something else.** This cascade reads
    /// `nodes[parent].computed` IN PLACE, so a forward edge really does hand it
    /// the parent's own value and this test reddens when the guard is deleted —
    /// measured. `cascade_opacity` reads a side vector initialised to `false`,
    /// so an unvisited parent already answers "not transparent" there and
    /// deleting its guard changed nothing; its falsifier moved to the guard's
    /// other job, the bounds check. Same line, same comment, different
    /// remaining purpose — do not assume the twin's version asserts this one's
    /// claim.
    ///
    /// **In what situation does it go red?** `walk` emits document order, so no
    /// capture can produce a forward edge and this is synthetic on purpose
    /// rather than by omission (判据 §3). What it pins is a decision: on a
    /// forward edge the parent's entry still holds its OWN value, so following
    /// it would hand out a reading that is silently one-hop for that subtree.
    ///
    /// The fixture's design is load-bearing and must not be simplified. Node 0's
    /// forward parent must be transparent **by its own value**, or following the
    /// edge and refusing it give the same answer and the guard's removal is
    /// invisible — which is exactly how the twin's first version of this test
    /// passed with the guard deleted.
    #[test]
    fn a_forward_parent_edge_is_not_trusted_by_the_cascade() {
        let opaque = Computed::default();
        let transparent = Computed {
            opacity_zero: true,
            ..Computed::default()
        };
        let node = |parent: Option<usize>, computed: Computed| RawNode {
            backend_node_id: 1,
            parent,
            kind: RawNodeKind::Element,
            tag: Some("DIV".to_string()),
            attrs: Vec::new(),
            text: None,
            rect: None,
            computed: Some(computed),
            clickable_hint: None,
            focused: None,
            checked: None,
            selected: None,
            value: None,
        };
        let mut nodes = vec![
            node(Some(2), opaque),
            node(None, opaque),
            node(Some(1), transparent),
            node(Some(2), opaque),
        ];
        cascade_effective_styles(&mut nodes);

        assert!(
            !nodes[0].computed.expect("node 0").opacity_zero,
            "node 0's parent index points forward at a node that is transparent \
             by its OWN value, but this pass has not reached it yet. Following \
             that edge makes the cascade one-hop for the subtree and says \
             nothing true about it"
        );
        assert!(
            nodes[3].computed.expect("node 3").opacity_zero,
            "node 3 is an ordinary backward child of a transparent parent — if \
             this is false the guard is rejecting real edges too"
        );
    }

    /// The caret sentinel `-1` means "I looked and nothing has it", and it must
    /// be reachable through exactly one condition.
    ///
    /// The expression first read `if (!ae || ae === document.body)`, which
    /// answers `-1` for a **stub `activeElement`** returning `undefined` — the
    /// "cannot say" case — and `-1` is what licenses `focused: Some(false)` on
    /// every node downstream. That collapsed two of the three states at the
    /// point of production and made the distinction the rest of this module
    /// maintains decorative (判据 §8).
    ///
    /// Asserted as a **corpus count, not a `contains`**: the `contains` alone
    /// would pass with a second, wider path to `-1` sitting beside it. `-1`
    /// occurring exactly once in the whole constant is what makes the guarded
    /// spelling the ONLY way to produce it.
    #[test]
    fn the_caret_sentinel_is_reachable_only_through_document_body() {
        assert_eq!(
            COMPUTED_FLAGS_JS.matches("-1").count(),
            1,
            "`-1` must have exactly one producer in the expression, or the \
             guarded spelling below is not the only way to reach it: \
             {COMPUTED_FLAGS_JS}"
        );
        assert!(
            COMPUTED_FLAGS_JS.contains("if (ae === document.body) { focus = -1; }"),
            "the only path to the `nothing is focused` sentinel must be the \
             body check — a falsy activeElement is `cannot say`, which is the \
             initial `null` and reaches no branch: {COMPUTED_FLAGS_JS}"
        );
    }

    /// Every `.rs` file under `src/` whose text contains `needle` once
    /// backticks are removed from both sides, as repo-relative paths, sorted.
    ///
    /// Walked, never listed (判据 §5): a file added tomorrow is in the corpus
    /// without anyone remembering it. Raw text, NOT `code_text` — the claims
    /// this guards live in doc comments, which every source scan strips, so
    /// scanning code only would have made the guard 恒绿 in its own subject
    /// case (判据 §2). The walk asserts a floor on the file count, so a broken
    /// walk reads as broken rather than as "nothing found".
    ///
    /// # Why backticks come out, and what that did and did not buy
    ///
    /// A claim written ``obscura ignores `pierce` `` and one written "obscura
    /// ignores pierce" are the same claim by one character, and a plain
    /// `contains` sees only the second. That is not a hypothetical: `:640` of
    /// this file — the comment on the single-frame `RawFrame` — is the first
    /// spelling, and a review planted that exact sentence, verbatim, into
    /// `raw.rs` and measured **550 passed / 0 failed**. The census's own
    /// second author walked past it.
    ///
    /// Stripping is done in the EXECUTOR rather than by listing both spellings
    /// on the one row that was caught (判据 §11): every claim in
    /// [`DATED_CLAIMS`] is quotable, so every row had the same hole. Measured
    /// before the change and after: **no row's home set moves**, so this is
    /// pure widening and cost no migration.
    ///
    /// **It buys backticks and nothing else.** A hyphen still splits a needle —
    /// `fetch_chromium.rs` carries both `no top layer` and "no top-layer", and
    /// only the first is matched — and a genuine reword ("obscura never
    /// descends into an iframe") is matched by nothing here. Those are not
    /// closed, and are not legislated for either: there is no measured
    /// counter-example for them in a file that is not already a home, and a
    /// normalisation rule written for a case nobody has seen is 判据 §5.
    fn files_mentioning(needle: &str) -> Vec<String> {
        fn walk(dir: &std::path::Path, out: &mut Vec<std::path::PathBuf>) {
            let Ok(entries) = std::fs::read_dir(dir) else {
                return;
            };
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_dir() {
                    walk(&path, out);
                } else if path.extension().is_some_and(|e| e == "rs") {
                    out.push(path);
                }
            }
        }
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
        let mut files = Vec::new();
        walk(&root, &mut files);
        assert!(
            files.len() > 100,
            "the walk found {} sources under src/, which is the walk failing, \
             not the tree being small",
            files.len()
        );
        let mut hits: Vec<String> = files
            .into_iter()
            .filter_map(|file| {
                let text = std::fs::read_to_string(&file).ok()?;
                if !text.replace('`', "").contains(&needle.replace('`', "")) {
                    return None;
                }
                Some(
                    file.strip_prefix(env!("CARGO_MANIFEST_DIR"))
                        .unwrap_or(&file)
                        .to_string_lossy()
                        .replace('\\', "/"),
                )
            })
            .collect();
        hits.sort();
        hits
    }

    /// The obscura ARTEFACT this module's claims were read on — **two values,
    /// because a tag and a build are different facts and only one of them is
    /// copyable.**
    ///
    /// ## What the single literal could not do
    ///
    /// This was one constant, `OBSCURA_SOURCE_READ_AT = "v0.2.2"`, whose doc
    /// argued — correctly — that deriving it from `runtimes::OBSCURA_TAG` would
    /// make the comparison below 恒真 and guard nothing (判据 §2): the whole
    /// point is that the two are free to disagree, and the disagreement is the
    /// signal. It was then filled **from the pin** instead of from the checkout
    /// that was read, and the readings behind every `crates/obscura-…` citation
    /// in this file had in fact been taken in obscura's `main`, 49 commits and
    /// 7 days past the tag. The mechanism was built to let the two disagree and
    /// then initialised so they never could about the one thing it names —
    /// 判据 §2's fourth face: a real comparison against a real constant that
    /// cannot go red for the single drift it exists to catch.
    ///
    /// The repair is not a better sentence. It is a second value that **cannot
    /// be filled in from this repository or from the release page.**
    const OBSCURA_READ_ON_TAG: &str = "v0.2.2";

    /// sha256 of the EXTRACTED executable every behavioural reading in this
    /// file was taken on: `~/.aleph/runtimes/obscura/v0.2.2/obscura`,
    /// 94,864,016 bytes, Mach-O arm64, hashed on the measuring host.
    ///
    /// **Not the release ARCHIVE's digest — and that distinction is the whole
    /// reason this constant is a digest at all.**
    /// `obscura-aarch64-macos.tar.gz` is 76,038,298 bytes and hashes to
    /// something else entirely, and that number is *published on the release
    /// page* and recorded in this repository at
    /// `docs/superpowers/specs/2026-09-06-browser-dual-engine-evidence/README.md`
    /// — so it is writable by someone who never held the artefact, which is the
    /// same defect as copying the tag from the pin, wearing a longer number. A
    /// draft of this task's own brief made exactly that substitution, attaching
    /// an archive's digest to a binary's path (判据 §1, two facts linked as
    /// one). The binary's digest is published nowhere: the only way to write it
    /// down is to have hashed the file you measured on.
    /// [`the_artefact_stamp_records_the_binary_not_the_published_archive`]
    /// turns that substitution back into a red.
    ///
    /// **What this is NOT: a runtime check**, said plainly because a stamp
    /// reads like a warranty (判据 §17). Nothing hashes a file to compare
    /// against it, on purpose — obscura is absent on CI, and the bytes differ
    /// per platform and per release flavour, so a live comparison would be 恒绿
    /// wherever the artefact is missing and falsely RED on a host that
    /// installed a different platform's build, and a guard that misfires is
    /// dearer than one that stays quiet (判据 §3). It is a receipt, and its
    /// force is at AUTHORING time: re-stamping requires hashing a file, and
    /// there is nothing to copy instead. A determined author can still invent
    /// 64 hex characters — that is fabrication, not the accident this repairs,
    /// and no unit test in this crate can tell the two apart.
    const OBSCURA_READ_ON_SHA256: &str =
        "9e14e821fca149698b7dbf21c4e61a727b1032469660f2459792f18bbc2b2b4b";

    /// Every `(tag, digest)` this stamp has ever certified, oldest first. The
    /// LAST row is the live one, and appending is the only legal edit.
    ///
    /// ## Why a history and not just the pair above
    ///
    /// The pair alone guards the CONTENT of the receipt and never its AGE, and
    /// that hole was measured rather than argued: move the pin **and**
    /// `OBSCURA_READ_ON_TAG` to a new release, leave the digest at the retired
    /// artefact's, and **nothing in this repository reddens.** The tag
    /// comparison passes because the tags agree; the archive guard passes
    /// because a stale *binary* digest is still not an *archive* digest. That
    /// is the author who bumps the pin and dutifully re-stamps the half they
    /// can see — and the receipt they leave behind is the same lie the old
    /// one-literal stamp told, with more digits and therefore *less* legible:
    /// a tag that disagrees can be spotted at a glance, a 64-hex string that
    /// disagrees cannot be.
    ///
    /// The history closes it with two assertions and no new instrument
    /// (`the_obscura_source_claims_here_name_the_build_they_were_read_on`):
    /// the last row must equal the live pair, so bumping the tag half without
    /// appending is red; and no digest may appear in two rows, so a row
    /// appended with the previous release's digest is red, naming both tags.
    /// The only way out of the pair is to hash a file.
    ///
    /// ## Its limit, stated the same way the runtime-hash refusal is
    ///
    /// **A fabricated row still passes.** Nothing here can tell 64 invented hex
    /// characters from a digest, and no unit test in this crate could. What the
    /// history buys is the achievable property, not unforgeability: the value
    /// **cannot be filled in by COPYING** — not from the pin, not from the
    /// release page, and now not from the row above it either. Every path that
    /// produces a plausible value without holding the artefact is closed;
    /// inventing one is a different act, and this file does not claim to catch
    /// it.
    const RECEIPTS: &[(&str, &str)] = &[(
        "v0.2.2",
        "9e14e821fca149698b7dbf21c4e61a727b1032469660f2459792f18bbc2b2b4b",
    )];

    /// One claim class the stamp dates.
    struct DatedClaim {
        /// The claim, in the words the failure message prints.
        claim: &'static str,
        /// The spelling a second author of THIS claim has to use — a phrase the
        /// claim is hard to state without, never a topic word.
        ///
        /// **There is no free choice here, and the earlier wording asserted one
        /// instead of stating the trade.** An IDENTIFIER needle (`pierce`,
        /// `top_layer`) catches every restatement and also goes red when a
        /// refactor merely uses the symbol — a false red diagnosed as a real
        /// drift by someone with no reason to suspect the needle. A PHRASE
        /// needle cannot be planted by a refactor and is **green on a
        /// paraphrase**. Each way of being wrong is the other's strength; what
        /// a row can honestly claim is which failure it chose, not that it has
        /// neither.
        ///
        /// These rows choose the phrase, and pay the paraphrase. The size of
        /// that payment is measured rather than guessed: see
        /// [`files_mentioning`] for the one counter-example this tree actually
        /// contained, and for the backtick case, which was cheap enough to
        /// close and is closed.
        needle: &'static str,
        /// Every `src/` file whose text carries `needle` today — backticks
        /// removed from both sides — sorted as [`files_mentioning`] sorts.
        homes: &'static [&'static str],
    }

    /// The claim classes this stamp dates — **one list, two readers.**
    ///
    /// Before this round the failure message enumerated the classes in prose
    /// while the census knew a single needle, `getComputedStyle`, and nothing
    /// could notice the two disagreed. Counted on the committed bytes: **two of
    /// seven** classes sat inside the census half and five sat outside it,
    /// while the scope paragraph was read as though it covered the message
    /// (判据 §1 — two spellings of one fact, and the expensive copy is the one
    /// in the prose). The list is now the single author: the message is printed
    /// FROM it and the census walks it, so a class added to either is a class
    /// added to both.
    ///
    /// **`homes` is a COUNT, not a permission** (判据 §6 — 先数一遍). It says
    /// how many copies of one fact live in `src/` today; a second entry is
    /// 判据 §1 debt the row makes visible rather than hides, and each is named
    /// with why it is there.
    ///
    /// **In what situation does a row go red?** When a file outside its homes
    /// starts carrying the needle — exactly the drift that put an uncited
    /// engine claim in `raw.rs` the same hour the first stamp arrived, asked
    /// now once per class instead of once for the file. The test is
    /// [`every_dated_obscura_claim_has_exactly_the_homes_it_declares`], and it
    /// is deliberately NOT the one that dates the build: a pin bump and a
    /// second author demand opposite actions, and a reader of red NAMES cannot
    /// act on a name that covers both.
    ///
    /// **A green here does not mean the claim is still stated.** Every needle
    /// literal appears in a file the row declares as a home — this list is one
    /// of them — so that hit is self-satisfied and the row can only ever redden
    /// on a NEW file, never on the claim leaving its home. That is the intended
    /// direction (it is a drift census, not a liveness check), and it is
    /// written down because a reader could otherwise spend the green as
    /// "fetch_obscura.rs still says this."
    ///
    /// **What a row cannot see, stated rather than implied:** a second author
    /// who makes the same claim in different words. A needle census covers only
    /// the spellings it recognises (判据 §3). That is why every needle here is
    /// a phrase the claim is hard to state without — and why `top_layer`,
    /// `getBoxModel` and `visibility_hidden` are NOT used: those are code
    /// identifiers the twin and the shared types legitimately carry, so a
    /// census over them would go red for refactors rather than for claims.
    const DATED_CLAIMS: &[DatedClaim] = &[
        DatedClaim {
            claim: "the computed-style map has no `cursor` key — `cursor:pointer` \
                    reaches this fetcher from an element's INLINE style attribute \
                    or not at all, never from a stylesheet rule",
            needle: "getComputedStyle",
            homes: &["src/browser/page_state/fetch_obscura.rs"],
        },
        DatedClaim {
            claim: "`visibility` is served as the element's OWN value with `None` \
                    collapsed to false, which is the entire reason \
                    `cascade_effective_styles` exists",
            // obscura's own field name for the resolved answer. A second author
            // of "obscura resolves inheritance somewhere the wire cannot see"
            // has to name the place.
            needle: "effectively_invisible",
            homes: &["src/browser/page_state/fetch_obscura.rs"],
        },
        DatedClaim {
            claim: "`:focus` / `:hover` / `:active` / `:focus-visible` / \
                    `:focus-within` match an unconditional false, while \
                    `document.activeElement` DOES track the caret — two faces of \
                    one fact that disagree, which is why this fetcher reads the \
                    property and never the selector",
            needle: ":focus-within",
            homes: &["src/browser/page_state/fetch_obscura.rs"],
        },
        DatedClaim {
            claim: "obscura ignores pierce — `pierce: true` is accepted and \
                    unimplemented, so a capture is always exactly one frame and \
                    every frame element is declared unreached",
            // NOT the bare word `pierce`, which this row used until fix round 1
            // and which breaks the rule stated above: it is a `DOM.getDocument`
            // PARAMETER, so a refactor can plant it in a second file without
            // making any claim at all. Two concrete reasons, not a worry: the
            // cross-frame task that follows this one may legitimately send
            // `pierce: true` from `fetch_chromium.rs`, and the shadow-root
            // warning inside [`walk`] already uses the word in THIS file, in
            // the unrelated sense "does not pierce shadow boundaries" — named,
            // not numbered, because this file grew 891 lines over two rounds
            // and a line number written today is the next thing to rot. Widening `homes` to pre-admit the twin was the
            // other candidate and is wrong twice over — `fetch_chromium.rs`
            // carries zero occurrences today, so the row would go red
            // immediately, and a home list that admits a file for a spelling it
            // does not have is an allowlist written for a future that may not
            // arrive (判据 §5).
            //
            // ⚠️ This comment used to end "and still matches the sentence a
            // second author would actually write." **That was an assertion of
            // coverage, and it was false in this very file**: `:640` writes the
            // claim as ``obscura ignores `pierce` ``, one backtick away, and a
            // review planted that exact sentence into `raw.rs` to 550/0. The
            // backtick half is now closed in [`files_mentioning`], for every
            // row rather than this one. What is still green is a real reword —
            // the price of not using the identifier, named rather than claimed
            // away.
            needle: "ignores pierce",
            homes: &["src/browser/page_state/fetch_obscura.rs"],
        },
        DatedClaim {
            claim: "a `display:none` element answers `DOM.getBoxModel` \
                    SUCCESSFULLY with a zero quad, where Chromium fails the call \
                    honestly — so a zero quad is an absence here, never a verdict",
            needle: "zero quad",
            // `build.rs` quotes this obscura reading in the doc of the test that
            // depends on it (`a_boxless_but_styled_node_stays_visible…`). A real
            // second copy of one fact, recorded rather than discovered later.
            homes: &[
                "src/browser/page_state/build.rs",
                "src/browser/page_state/fetch_obscura.rs",
            ],
        },
        DatedClaim {
            claim: "NO TOP LAYER: `showModal()` sets an attribute and a flag, the \
                    promoted dialog's rect is byte-identical before and after, and \
                    `DOM.getTopLayerElements` does not exist on this engine",
            needle: "no top layer",
            // `fetch_chromium.rs` says the phrase about its OWN captures, not
            // about obscura. It is in the set because the needle cannot tell the
            // two subjects apart, and a needle narrowed until it could would be
            // one rewording away from matching nothing.
            homes: &[
                "src/browser/page_state/fetch_chromium.rs",
                "src/browser/page_state/fetch_obscura.rs",
            ],
        },
        DatedClaim {
            claim: "the DOM AGENT: the `dom::get_document(conn, Some(session), \
                    -1, true)` call in `fetch_obscura` turns on \
                    NO event stream (0 unsolicited `DOM.*` events, measured twice) \
                    and `DOM.disable` does not exist (`-32601 Unknown DOM method: \
                    disable`) — which is why this fetcher does not pair its \
                    handshake with a disable the way `fetch_chromium` does. If the \
                    new tag emits `DOM.*` events, that omission becomes Task 17d's \
                    D1 live on the DEFAULT engine; if it also implements \
                    `DOM.disable`, the fix is `top_layer_backend_ids`' shape",
            needle: "Unknown DOM method",
            // `fetch_chromium.rs` carries the obscura reading because its
            // enabler/disabler census is justified BY it: an engine-blind
            // "always disable after the tree read" refactor would break the
            // DEFAULT engine. A genuine second copy of one fact (判据 §1),
            // written down here instead of left to be found.
            homes: &[
                "src/browser/page_state/fetch_chromium.rs",
                "src/browser/page_state/fetch_obscura.rs",
            ],
        },
    ];

    /// The dated claims as the failure message prints them.
    fn dated_claim_list() -> String {
        DATED_CLAIMS
            .iter()
            .map(|c| format!("\n  * {}", c.claim))
            .collect()
    }

    /// **In what situation does this go red?** ONE situation, in two stages —
    /// a bump of the pinned build that was not carried all the way through.
    ///
    /// 1. **The pin moves and nobody re-reads.** Somebody edits `obscura_tag!()`
    ///    in `runtimes::specs`: every claim in [`DATED_CLAIMS`] becomes a
    ///    statement about a binary Aleph no longer installs, and
    ///    `OBSCURA_READ_ON_TAG` no longer matches it.
    /// 2. **The tag half is re-stamped and the receipt is not.** The tags agree
    ///    again, and [`RECEIPTS`] still ends at the retired artefact — so the
    ///    file certifies "I held this build" while naming a file nobody
    ///    installs. Measured to be green before fix round 1; it is stage 2 that
    ///    the receipt history exists for, and both stages ask the same thing of
    ///    the reader: go and read the new build.
    ///
    /// **What this test deliberately does NOT cover, and why it used to.** A
    /// second author appearing in another file is a different situation
    /// demanding the opposite action — *move the claim back or widen the row*,
    /// not *re-read everything against a new build* — and until fix round 1 the
    /// two printed this one name. A reader of red NAMES (a CI summary, the
    /// extractor the brief's addendum says broke a round) could not tell them
    /// apart, which is the defect the commit immediately before this work
    /// existed to remove: *"give the error-path cleanup its own test name, so
    /// the two defects stop sharing a label."* The census now lives in
    /// [`every_dated_obscura_claim_has_exactly_the_homes_it_declares`].
    ///
    /// ⚠️ **One reader outside this file followed the old arrangement.**
    /// `fetch_chromium.rs` says the CSSOM entry point may be named in exactly
    /// one file under `src/` and names THIS test as what enforces it. That
    /// enforcement moved one hop, to the census named above; the constraint
    /// itself is unchanged and still enforced. That sentence belongs to another
    /// task's file and was not edited here — this note is the forwarding
    /// pointer, and the sentence is worth correcting the next time that file is
    /// open.
    ///
    /// The remaining situation belongs to the sibling test: a receipt filled
    /// from the release page rather than from a file. See
    /// [`the_artefact_stamp_records_the_binary_not_the_published_archive`].
    ///
    /// # The DOM-agent reading, and why an ABSENCE has to be dated
    ///
    /// `fetch_chromium::top_layer_backend_ids` sends `DOM.disable` because on
    /// Chromium `DOM.getDocument` enables an event stream that outlives the
    /// call. This fetcher sends its `dom::get_document(conn, Some(session), -1,
    /// true)` — the one call in [`fetch_obscura`] — and does **not** disable,
    /// and the reason is a fact about the BUILD, which is
    /// exactly the kind of fact this stamp exists to expire. Measured twice,
    /// independently, on the installed v0.2.2 artefact with default flags, with
    /// a Chromium control in the third column:
    ///
    /// | | obscura v0.2.2 | Chromium |
    /// |---|---|---|
    /// | unsolicited `DOM.*` with no handshake | **0** | 0 |
    /// | unsolicited `DOM.*` after `DOM.getDocument(-1, true)` | **0** | many |
    /// | `DOM.disable` | **`-32601 Unknown DOM method: disable`** | `ok` |
    /// | `DOM.enable` | accepted, and still emits nothing | — |
    /// | `alert()` → `Page.javascriptDialogOpening` | **no frames** | fires |
    /// | `Runtime.evaluate` after `alert()` | **0 ms, value 2** | times out at 4000 ms |
    /// | `Page.handleJavaScriptDialog` | unknown method | `ok` |
    ///
    /// So there is nothing to disable, and nothing to disable it WITH — the two
    /// halves point the same way today and would come apart the moment either
    /// changes. Without this entry the absence reads as "we did not look over
    /// there".
    ///
    /// **The top-layer claim is the most expensive one on that list — which is
    /// why it, and not the newest, is the one to re-read FIRST.** obscura is the
    /// DEFAULT engine. If v0.3 implements a top layer and this stamp is bumped
    /// without re-reading, [`cascade_effective_styles`] goes on ORing
    /// `opacity_zero` down DOM parent edges into a modal dialog the engine now
    /// paints outside them — and the way anyone finds out is a user whose
    /// dialog is missing from the page state, with the agent told the page does
    /// not contain the thing the user is looking at. That is the same defect
    /// the twin's Task 17d arm closed on Chromium, arriving on the other engine
    /// by a version bump instead of by a code change (判据 §16).
    ///
    /// **What it does not buy — and there are TWO doors past it, not one.**
    /// `OBSCURA_TAG` names the build the ledger INSTALLS.
    /// `diagnostics::checks::engine_missing::run_obscura` reaches a binary by:
    ///
    /// 1. the **config pin** `[general.browser.obscura] binary_path` — resolved
    ///    FIRST (`engine_missing.rs:333-363`), returning found-or-missing
    ///    without ever consulting the ledger, and advertised to the operator in
    ///    the install hint itself. This is the nearer door;
    /// 2. then a `which` PATH walk (`:366`).
    ///
    /// Either one hands Aleph an operator-supplied build of any version with
    /// this stamp green. It covers the pinned path, which is the path Aleph
    /// controls, and it can cover no other — 判据 §5, and the list is the
    /// resolver's, not a remembered one.
    #[test]
    fn the_obscura_source_claims_here_name_the_build_they_were_read_on() {
        assert_eq!(
            OBSCURA_READ_ON_TAG,
            crate::runtimes::OBSCURA_TAG,
            "the pinned obscura release moved. Every claim in fetch_obscura.rs \
             was read on {OBSCURA_READ_ON_TAG} — the `crates/obscura-…` \
             citations against that tag, the behavioural readings against the \
             binary that hashes to {OBSCURA_READ_ON_SHA256} — and all of them \
             are now unverified. Re-read them on the new build and re-stamp \
             BOTH constants: the digest is the half you cannot fill in without \
             holding the artefact (`shasum -a 256` the extracted executable, \
             NOT the release archive — the archive's digest is published, which \
             is what makes it the wrong number). The classes that decide \
             behaviour:{claims}\n\
             Re-read the top layer FIRST — not because it is newest but because \
             it is the most expensive: if the new tag paints one, \
             cascade_effective_styles goes on ORing opacity_zero down DOM parent \
             edges into a modal the engine now paints outside them, and deletes \
             every open dialog inside a faded container from the page state on \
             the DEFAULT engine, silently. fetch_chromium::cascade_opacity's \
             top-layer arm is the shape the fix has to take here too (判据 §16).",
            claims = dated_claim_list(),
        );

        // Stage 2. Reached only once the tags agree again, which is exactly the
        // state the author is in after fixing the assertion above.
        assert_eq!(
            RECEIPTS.last().copied(),
            Some((OBSCURA_READ_ON_TAG, OBSCURA_READ_ON_SHA256)),
            "the stamp names {OBSCURA_READ_ON_TAG} and the receipt history does \
             not end there, so this file certifies holding a build it has no \
             receipt for. Append a row: (\"{OBSCURA_READ_ON_TAG}\", <sha256 of \
             the EXTRACTED executable you measured on>) — \
             `shasum -a 256 ~/.aleph/runtimes/obscura/{OBSCURA_READ_ON_TAG}/obscura`. \
             Carrying the previous row's digest forward is refused below, and \
             the release archive's digest is refused by \
             the_artefact_stamp_records_the_binary_not_the_published_archive, so \
             there is nothing to copy: hashing the file is the only way through. \
             History: {RECEIPTS:?}"
        );

        for (i, (tag, digest)) in RECEIPTS.iter().enumerate() {
            if let Some((earlier, _)) = RECEIPTS[..i].iter().find(|(_, d)| d == digest) {
                panic!(
                    "receipt row {i} says {tag} was read on the same bytes as \
                     {earlier}: {digest}. Two releases cannot hash alike, so one \
                     of those rows was carried forward rather than measured — \
                     which is the whole defect this history exists to refuse. \
                     Hash the artefact for {tag}."
                );
            }
        }
    }

    /// **In what situation does this go red?** When a file outside a
    /// [`DATED_CLAIMS`] row's `homes` starts carrying that row's needle: a
    /// second author of an engine fact whose claims nothing dates. That is the
    /// drift that left an uncited `getComputedStyle` claim in `raw.rs` the same
    /// hour the first stamp arrived, asked now once per claim class.
    ///
    /// **Its own name, and not the stamp's, on purpose.** This and a pin bump
    /// demand opposite actions — *move the claim back or widen the row* versus
    /// *re-read every claim against a new build* — and they shared one name
    /// until fix round 1. See
    /// [`the_obscura_source_claims_here_name_the_build_they_were_read_on`] for
    /// the other half and for the one cross-reference that still points at the
    /// old arrangement.
    ///
    /// **It collects rather than stops at the first mismatch**, which is not
    /// tidiness. A `for` loop around an `assert_eq!` reports two simultaneous
    /// drifts as one, and the second stays invisible until the first is fixed —
    /// measured: with two needles planted in `raw.rs` at once, only the earlier
    /// row was named. A second author copying a paragraph usually carries more
    /// than one of these phrases, which is precisely when that matters.
    #[test]
    fn every_dated_obscura_claim_has_exactly_the_homes_it_declares() {
        let mut drifted = Vec::new();
        for c in DATED_CLAIMS {
            let found = files_mentioning(c.needle);
            let expected: Vec<String> = c.homes.iter().map(|h| (*h).to_string()).collect();
            if found != expected {
                drifted.push(format!(
                    "\n  * needle `{needle}` — {claim}\n      declared: {expected:?}\n      found:    {found:?}",
                    needle = c.needle,
                    claim = c.claim,
                ));
            }
        }
        assert!(
            drifted.is_empty(),
            "the file set carrying a dated obscura claim moved, on {n} of the \
             {total} claim classes this stamp dates. Every file in a row is a \
             copy of one engine fact; a new one is a second author whose claims \
             nothing dates. Either move the claim into fetch_obscura.rs, or \
             widen the row — which widens the stamp's failure message with it, \
             because they are the same list.{rows}",
            n = drifted.len(),
            total = DATED_CLAIMS.len(),
            rows = drifted.concat(),
        );
    }

    /// Every 64-character lowercase-hex run in `line`, and nothing shorter or
    /// longer: a sha256 as it is written down, not any hex it is embedded in.
    fn sha256_runs(line: &str) -> Vec<&str> {
        let bytes = line.as_bytes();
        let mut out = Vec::new();
        let mut start: Option<usize> = None;
        for i in 0..=bytes.len() {
            let hex = i < bytes.len() && matches!(bytes[i], b'0'..=b'9' | b'a'..=b'f');
            match (hex, start) {
                (true, None) => start = Some(i),
                (false, Some(s)) => {
                    if i - s == 64 {
                        out.push(&line[s..i]);
                    }
                    start = None;
                }
                _ => {}
            }
        }
        out
    }

    /// **In what situation does this go red?** When [`OBSCURA_READ_ON_SHA256`]
    /// is filled with the release ARCHIVE's digest instead of the extracted
    /// binary's.
    ///
    /// That is not a hypothetical shape. The archive's digest is published on
    /// the release page and recorded in this repository, so it is **copyable by
    /// someone who never held the artefact** — the same defect as copying the
    /// tag from the pin, wearing a longer number — and a draft of the brief
    /// that commissioned this stamp attached exactly that number to the
    /// binary's path. The binary's own digest is published nowhere.
    ///
    /// The comparand is READ from the tree rather than restated here: a second
    /// literal spelling of the archive digest would be two copies of one fact
    /// free to drift, and an assertion between two literals written in the same
    /// breath tests nothing at all (判据 §10). If that file stops yielding an
    /// archive digest this goes RED naming it, rather than passing quietly — a
    /// missing comparand can only say "I don't know" (判据 §8).
    ///
    /// **Its limit, stated:** it knows the digests this repository records
    /// today. A future release's published archive digest is not among them, so
    /// this catches the confusion for the artefact in hand and not for the next
    /// one. It cannot fail falsely, though — an archive and the executable
    /// inside it are different bytes by construction.
    #[test]
    fn the_artefact_stamp_records_the_binary_not_the_published_archive() {
        // Every ROW, not just the live one. A history whose older rows go
        // unchecked would let an appended row be wrong the moment the next one
        // is appended past it, which is the same shape as the age hole the
        // history exists to close.
        for (tag, digest) in RECEIPTS {
            assert_eq!(
                digest.len(),
                64,
                "the receipt for {tag} must be a whole sha256. A digest elided \
                 to `9e14e821fc…` is a value nobody can check against a file, \
                 which is the one thing these rows exist to be."
            );
            assert!(
                digest
                    .bytes()
                    .all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f')),
                "the receipt for {tag} must be lowercase hex, as `shasum -a 256` \
                 prints it: {digest}"
            );
        }

        let readme = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("docs/superpowers/specs/2026-09-06-browser-dual-engine-evidence/README.md");
        let text = std::fs::read_to_string(&readme).unwrap_or_else(|e| {
            panic!(
                "this guard compares the artefact receipt against the release \
                 ARCHIVE digests this repo records, and {} could not be read \
                 ({e}). That is a red, not a skip: with no comparand the guard \
                 knows nothing, and a guard that answers \"I don't know\" as \
                 \"fine\" is the shape it exists to refuse (判据 §8). Point it \
                 at wherever the evidence README moved to.",
                readme.display()
            )
        });
        let published: Vec<&str> = text
            .lines()
            .filter(|l| l.contains(".tar.gz") || l.contains(".zip"))
            .flat_map(sha256_runs)
            .collect();
        assert!(
            !published.is_empty(),
            "no archive digest was found in {}, so this guard has nothing to \
             compare against and is certifying an absence. It recorded one when \
             it was written — the `obscura-aarch64-macos.tar.gz` sha256 on the \
             `Binary measured:` line.",
            readme.display()
        );
        for (tag, digest) in RECEIPTS {
            assert!(
                !published.contains(digest),
                "the receipt for {tag} is a release ARCHIVE's digest, not the \
                 extracted binary's. The archive digest is published on the \
                 release page and recorded in {}, so writing it here proves \
                 nothing about having held the artefact — which is the whole \
                 and only job of these rows. Hash the executable the readings \
                 were taken on: \
                 `shasum -a 256 ~/.aleph/runtimes/obscura/{tag}/obscura`. \
                 Archive digests found: {published:?}",
                readme.display()
            );
        }
    }

    /// obscura reaches no iframe content, ever (U3). The `<iframe>` element is
    /// in the tree with its box and its `src`, and its DOCUMENT is not — so the
    /// capture has to say so, or "never read" and "genuinely empty" are the same
    /// observation and nothing downstream can tell them apart.
    #[tokio::test]
    async fn every_frame_element_is_declared_unreached_because_obscura_never_descends() {
        let server = agreeing_server().await;
        let (conn, session) = server.connect_and_attach().await;
        let raw = fetch_obscura(&conn, &session, 4).await.unwrap();

        assert_eq!(
            raw.unreached_frames,
            vec![UnreachedFrame::NotCaptured(ID_IFRAME)],
            "the page's one <iframe> owns a document this capture does not have"
        );
        // Non-vacuity: the element itself IS in the capture, so the entry above
        // is about a frame that was seen and not descended into — not about a
        // node that went missing.
        let iframe = raw.frames[0]
            .nodes
            .iter()
            .find(|n| n.backend_node_id == ID_IFRAME)
            .expect("the <iframe> element is an ordinary element in the tree");
        assert_eq!(iframe.tag.as_deref(), Some("iframe"));
        assert_eq!(iframe.attr("src"), Some("about:blank"));
    }

    /// `backendNodeId: 0` is the document on obscura — a legitimate id, not a
    /// sentinel. Anything that treats 0 as "absent" drops the root.
    #[tokio::test]
    async fn backend_node_id_zero_is_the_document_not_a_missing_id() {
        let server = agreeing_server().await;
        let (conn, session) = server.connect_and_attach().await;
        let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
        let root = &raw.frames[0].nodes[0];
        assert_eq!(root.backend_node_id, ID_DOCUMENT);
        assert_eq!(root.kind, RawNodeKind::Document);
        assert_eq!(root.parent, None);
        // And the node after it is the DOCTYPE, which is neither element nor
        // document — a `RawNodeKind::Other` that must not consume an element
        // row, or every flag on the page would be off by one.
        let html = raw.frames[0]
            .nodes
            .iter()
            .find(|n| n.backend_node_id == ID_HTML)
            .unwrap();
        assert_eq!(html.kind, RawNodeKind::Element);
        assert_eq!(html.tag.as_deref(), Some("html"));
        assert_eq!(raw.frames[0].nodes[1].kind, RawNodeKind::Other);
    }

    /// The caret is an OBSERVATION when the engine answered, and every other
    /// element is observed NOT to have it — `Some(false)`, not `None`. `None`
    /// means "nobody looked", and conflating the two is what made
    /// `NodeStates::focused` a constant predicate before this fetcher existed.
    #[tokio::test]
    async fn the_caret_is_reported_and_the_other_elements_are_observed_not_unknown() {
        let server = agreeing_server().await;
        let (conn, session) = server.connect_and_attach().await;
        let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
        let f = &raw.frames[0];

        let q = f
            .nodes
            .iter()
            .find(|n| n.backend_node_id == ID_INPUT_Q)
            .unwrap();
        assert_eq!(q.focused, Some(true), "the engine named this element");
        let h1 = f.nodes.iter().find(|n| n.backend_node_id == ID_H1).unwrap();
        assert_eq!(
            h1.focused,
            Some(false),
            "an element the engine did not name is observed to lack the caret"
        );
        // Exactly one element carries it.
        assert_eq!(
            f.nodes.iter().filter(|n| n.focused == Some(true)).count(),
            1
        );
        // Non-elements are never claimed about: a text node has no caret to
        // have, and `querySelectorAll('*')` never named one.
        let text = f
            .nodes
            .iter()
            .find(|n| n.backend_node_id == ID_H1_TEXT)
            .unwrap();
        assert_eq!(text.focused, None);
    }

    /// An engine that cannot answer `activeElement`, and an `activeElement`
    /// outside `querySelectorAll('*')`, are both UNKNOWN — never "nothing is
    /// focused". A `-1` means the engine looked and found none, and only that
    /// licenses the `Some(false)`s above (判据 §8).
    #[tokio::test]
    async fn an_unanswerable_caret_is_unknown_while_minus_one_is_an_observed_none() {
        for unknown in [serde_json::Value::Null, serde_json::json!(ELEMENT_COUNT)] {
            let server = server_with(
                constructed_rows(),
                ELEMENT_COUNT,
                FIRST_TAG,
                LAST_TAG,
                unknown.clone(),
            )
            .await;
            let (conn, session) = server.connect_and_attach().await;
            let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
            assert!(
                raw.frames[0].nodes.iter().all(|n| n.focused.is_none()),
                "focus={unknown} is an unknown and must not become a denial"
            );
            // The flags are untouched — the caret failing does not cost the
            // page its visibility.
            assert!(raw.frames[0].nodes.iter().any(|n| n.computed.is_some()));
        }

        let server = server_with(
            constructed_rows(),
            ELEMENT_COUNT,
            FIRST_TAG,
            LAST_TAG,
            serde_json::json!(-1),
        )
        .await;
        let (conn, session) = server.connect_and_attach().await;
        let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
        assert!(
            raw.frames[0]
                .nodes
                .iter()
                .filter(|n| n.kind == RawNodeKind::Element)
                .all(|n| n.focused == Some(false)),
            "-1 is `I looked, nothing has it` and every element is then observed"
        );
    }

    /// The cross-check exists to catch a page that mutated between the two
    /// calls. When it fires twice, every `computed` is `None` — the flags are
    /// not attributed to the wrong nodes, and the loss is stated rather than
    /// silently mis-aligned (判据 §8: an unknown may not be spent as a value).
    #[tokio::test]
    async fn a_persistent_count_mismatch_drops_every_computed_flag() {
        // One row short of the tree, twice.
        let short = serde_json::Value::Array(
            constructed_rows().as_array().unwrap()[..ELEMENT_COUNT - 1].to_vec(),
        );
        let server = server_with(
            short,
            ELEMENT_COUNT - 1,
            FIRST_TAG,
            LAST_TAG,
            serde_json::json!(INPUT_Q),
        )
        .await;
        let (conn, session) = server.connect_and_attach().await;
        let raw = fetch_obscura(&conn, &session, 4).await.unwrap();
        assert!(
            raw.frames[0].nodes.iter().all(|n| n.computed.is_none()),
            "a mismatched evaluate must not be zipped onto the wrong nodes"
        );
        // The caret rode on the same payload and is dropped with it: an index
        // into an ordering we no longer trust is not a position.
        assert!(raw.frames[0].nodes.iter().all(|n| n.focused.is_none()));
        // The rects are unaffected: they came from a different call and are
        // still trustworthy.
        let h1 = raw.frames[0]
            .nodes
            .iter()
            .find(|n| n.backend_node_id == ID_H1)
            .unwrap();
        assert_eq!(
            h1.rect,
            Some(Rect {
                x: 0,
                y: 20,
                w: 1280,
                h: 37
            })
        );
    }

    /// A first/last tag disagreement is the same class of failure as a count
    /// disagreement, and it is the one a count alone cannot see: 34 elements
    /// both times, a different 34.
    #[test]
    fn parse_computed_rows_rejects_a_matching_count_with_a_different_first_tag() {
        let value = serde_json::json!({
            "n": ELEMENT_COUNT, "first": "BODY", "last": LAST_TAG, "rows": constructed_rows(),
        });
        assert!(parse_computed_rows(&value, ELEMENT_COUNT, FIRST_TAG, LAST_TAG).is_none());
        let value = serde_json::json!({
            "n": ELEMENT_COUNT, "first": FIRST_TAG, "last": "SPAN", "rows": constructed_rows(),
        });
        assert!(parse_computed_rows(&value, ELEMENT_COUNT, FIRST_TAG, LAST_TAG).is_none());
        let value = serde_json::json!({
            "n": ELEMENT_COUNT, "first": FIRST_TAG, "last": LAST_TAG, "rows": constructed_rows(),
        });
        let rows = parse_computed_rows(&value, ELEMENT_COUNT, FIRST_TAG, LAST_TAG)
            .expect("agreeing shapes parse");
        assert_eq!(rows.len(), ELEMENT_COUNT);
        assert!(rows[HIDDEN_NONE].display_none);
        // Column 3 → `cursor_pointer`, which is what this asserts. The row is
        // scaffolding — obscura answers `'auto'` for a stylesheet `cursor`, see
        // `constructed_rows`' doc — so this is a claim about the PARSER's column
        // order, never about the engine.
        assert!(rows[A_HOME].cursor_pointer);
        assert!(!rows[HTML].display_none);
    }

    /// A row that still carries R34's cut fifth column is refused whole, not
    /// truncated: a payload with a column this build does not model is a
    /// payload from a different contract.
    #[test]
    fn parse_computed_rows_refuses_a_row_whose_arity_is_not_computeds_field_count() {
        let five: Vec<Vec<bool>> = (0..ELEMENT_COUNT)
            .map(|_| vec![false, false, false, false, false])
            .collect();
        let value = serde_json::json!({
            "n": ELEMENT_COUNT, "first": FIRST_TAG, "last": LAST_TAG, "rows": five,
        });
        assert!(parse_computed_rows(&value, ELEMENT_COUNT, FIRST_TAG, LAST_TAG).is_none());
    }

    /// Drive a whole fetch where EVERY `DOM.getBoxModel` answers the same way,
    /// so the two arms below differ in exactly one thing: which reply.
    async fn fetch_with_every_box_answered(reply: Responder) -> RawDom {
        let base = scripted(base_entries(
            constructed_rows(),
            ELEMENT_COUNT,
            FIRST_TAG,
            LAST_TAG,
            serde_json::json!(INPUT_Q),
        ));
        let server = FakeCdpServer::start(move |req| {
            if req["method"] == "DOM.getBoxModel" {
                return reply.clone();
            }
            base(req)
        })
        .await;
        let (conn, session) = server.connect_and_attach().await;
        fetch_obscura(&conn, &session, 4)
            .await
            .expect("one node's missing geometry must not lose the page")
    }

    /// `Ok(None)` — the engine says this node has no box. Not a hidden element:
    /// one whose geometry there is none of. `rect: None`, page intact.
    #[tokio::test]
    async fn a_no_box_model_reply_yields_rect_none_and_does_not_fail_the_fetch() {
        let raw = fetch_with_every_box_answered(no_box_model()).await;
        assert!(raw.frames[0].nodes.iter().all(|n| n.rect.is_none()));
        // The flags are untouched, so the page is still describable.
        assert!(raw.frames[0].nodes.iter().any(|n| n.computed.is_some()));
    }

    /// `Err` — the engine failed to answer at all. A DIFFERENT fact from "no
    /// box model", and the one this module's step 4 comment claims to handle
    /// identically. Same `rect: None`, and (crucially) the fetch still
    /// succeeds: one node's unanswered call must not lose the whole page.
    ///
    /// **This is the arm the first version of this test never reached.** It
    /// sent `aleph-cdp`'s own no-box `(code, message)`, which that crate
    /// translates to `Ok(None)` before this module ever sees it — so the test
    /// passed, named a fact it did not cover, and the `Err` arm had no test at
    /// all. Found by mutating `model.ok()` to `model.unwrap()` and reading
    /// which names went red: this one stayed green.
    #[tokio::test]
    async fn a_box_model_protocol_error_yields_rect_none_and_does_not_fail_the_fetch() {
        let raw = fetch_with_every_box_answered(box_model_transport_error()).await;
        assert!(raw.frames[0].nodes.iter().all(|n| n.rect.is_none()));
        assert!(raw.frames[0].nodes.iter().any(|n| n.computed.is_some()));
    }

    /// The bound is real, measured as ELAPSED TIME.
    ///
    /// Part 1's `Responder` has no enter/leave hook, and inventing one here
    /// would be a second design for a type another part owns (判据 §1). A fixed
    /// per-reply delay says the same thing arithmetically: 34 element nodes at
    /// `box_concurrency = 2` is seventeen serialised batches, so the fetch
    /// cannot return in under `17 * delay`; unbounded, it is one batch on top of
    /// the four base calls.
    #[tokio::test]
    async fn box_model_concurrency_is_bounded_by_the_parameter() {
        const DELAY: std::time::Duration = std::time::Duration::from_millis(20);
        let boxes = box_replies();
        let base = scripted_slow(
            base_entries(
                constructed_rows(),
                ELEMENT_COUNT,
                FIRST_TAG,
                LAST_TAG,
                serde_json::json!(INPUT_Q),
            ),
            DELAY,
        );
        let server = FakeCdpServer::start(move |req| {
            if req["method"] == "DOM.getBoxModel" {
                let id = req["params"]["backendNodeId"].as_i64().unwrap_or(-1);
                // The no-box reply for an uncovered id, not an empty object:
                // this test is about elapsed time, and an empty object is a
                // decode failure — a third behaviour it has no business
                // depending on.
                let inner = boxes
                    .get(&id)
                    .map_or_else(no_box_model, |v| Responder::Reply(v.clone()));
                return Responder::Delay(DELAY, Box::new(inner));
            }
            base(req)
        })
        .await;
        let (conn, session) = server.connect_and_attach().await;

        let started = std::time::Instant::now();
        fetch_obscura(&conn, &session, 2).await.unwrap();
        let elapsed = started.elapsed();

        // Floor chosen at 12 batches, not 17: the assertion has to survive a
        // loaded CI box rounding a 20 ms sleep, while still being far above the
        // ~5 (four base calls plus one batch) an unbounded fetch would take.
        assert!(
            elapsed >= DELAY * 12,
            "34 box models at concurrency 2 finished in {elapsed:?} — that is fewer \
             batches than the bound allows, so the bound is not being applied"
        );
    }

    /// The module is interim, and the sentence that says so is the only thing
    /// that will make someone delete it. Pinned so an edit that removes the
    /// pointer to its own expiry condition goes red.
    #[test]
    fn the_module_doc_states_its_own_deletion_condition() {
        let src = include_str!("fetch_obscura.rs");
        let head: String = src.lines().take_while(|l| l.starts_with("//!")).collect();
        assert!(head.contains("INTERIM"), "{head}");
        assert!(head.contains("DOMSnapshot"), "{head}");
        assert!(
            head.contains("census"),
            "it must name what has to change when it goes: {head}"
        );
    }
}
