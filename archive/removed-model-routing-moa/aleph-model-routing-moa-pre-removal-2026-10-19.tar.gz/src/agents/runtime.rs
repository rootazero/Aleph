//! Sub-agent runtime — canonical home for `AgentRuntime` and the types it
//! exposes to `SubagentTool` and callers.
//!
//! Wraps the Harness-based spawner with lifecycle tracing and transcript
//! persistence.

use std::collections::HashMap;
use std::time::Instant;

use tokio_util::sync::CancellationToken;

use crate::agents::AgentDef;
use crate::harness::chain_context::ChainContext;
use crate::memory::extensions::MemoryExtensionRegistry;
use crate::memory::store::raw_memory::RawMemoryStore;
use crate::providers::AiProvider;
use crate::session::service::SessionService;
use crate::sync_primitives::Arc;
use crate::tools::service::ToolService;

// =============================================================================
// LoopRunResult
// =============================================================================

/// Outcome of a completed sub-agent run.
///
/// Cancellation is surfaced as an `Err("sub-agent failed: …")` from
/// `AgentRuntime::run`, not via a boolean on this struct — so there is no
/// dedicated `cancelled` field.
#[derive(Debug, Clone)]
pub struct LoopRunResult {
    pub final_text: Option<String>,
    pub iterations: usize,
    pub tool_calls_made: usize,
    pub total_tokens: usize,
    pub hit_limit: bool,
}

// =============================================================================
// AgentRuntimeConfig (decomposed into role-grouped sub-configs)
// =============================================================================

/// Configuration for launching a sub-agent — composed of role-grouped
/// sub-configs (identity / spawn-override / lifecycle) so each concern lives
/// in exactly one place. Sub-struct fields stay `pub` so callers and tests
/// build configs via plain struct literals.
#[derive(Debug)]
pub struct AgentRuntimeConfig {
    /// Who is being run and what they were told.
    pub identity: AgentIdentity,
    /// Caller-provided per-call overrides on how the child starts.
    pub spawn_override: SpawnOverride,
    /// Run-level lifecycle controls (timeout).
    pub lifecycle: Lifecycle,
}

/// Agent identity — role (`agent_def`), task string, optional parent context.
#[derive(Debug)]
pub struct AgentIdentity {
    /// The agent definition describing role, tools, and limits.
    pub agent_def: AgentDef,
    /// The task to execute.
    pub task: String,
    /// Optional context summary from the parent agent.
    pub context_summary: Option<String>,
}

/// Spawn overrides — caller-controlled knobs that take precedence over the
/// agent definition's own defaults.
#[derive(Debug)]
pub struct SpawnOverride {
    /// Per-call override of where the child's starting context comes from.
    /// `None` defers to `agent_def.context_mode`.
    pub spawn_context: Option<crate::agents::SpawnContext>,
    /// Parent transcript for a `context=fork` spawn, captured once per tool
    /// call so every child of one fan-out forks the same instant. See
    /// `crate::agents::subagent_spawner::fork::ForkSource`.
    pub fork_source: Option<crate::agents::subagent_spawner::fork::ForkSource>,
    /// Explicit model override (highest priority).
    pub model: Option<String>,
    /// The caller's stable handle for this child, forwarded to
    /// [`crate::agents::subagent_spawner::SpawnRequest::request_id`] so the
    /// child's session key — and therefore the durable `SubagentSpawned` /
    /// `SubagentReturned` pair — is addressable by it after a restart.
    ///
    /// `Some` only for the background `subagent` spawn, the one path whose id
    /// outlives the call. Foreground and batch spawns return inline and leave
    /// this `None`.
    pub request_id: Option<String>,
}

/// Run-level lifecycle controls. Currently a single timeout; future
/// wall-clock / deadline knobs land here.
#[derive(Debug)]
pub struct Lifecycle {
    /// Timeout in seconds for the entire run.
    pub timeout_secs: u64,
}

// =============================================================================
// Transcript types
// =============================================================================

/// Outcome classification for a sub-agent execution.
#[non_exhaustive]
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub enum TranscriptOutcome {
    /// The sub-agent completed successfully.
    Success,
    /// The sub-agent encountered an error.
    Error(String),
    /// The sub-agent was terminated due to timeout.
    Timeout,
}

/// Structured transcript of a sub-agent execution for observability.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct SubagentTranscript {
    /// Unique identifier for the agent instance.
    pub agent_id: String,
    /// Agent type name (from `agent_def`).
    pub agent_type: String,
    /// Summary of the task that was executed.
    pub task_summary: String,
    /// How the execution ended.
    pub outcome: TranscriptOutcome,
    /// Number of think-act iterations completed.
    pub iterations: usize,
    /// Wall-clock duration in milliseconds.
    pub duration_ms: u64,
    /// Total tokens consumed.
    pub tokens_used: usize,
    /// Key findings extracted from the agent's final response (first 200 chars).
    pub key_findings: String,
}

// =============================================================================
// AgentRuntime
// =============================================================================

/// Role-grouped sub-config carried by [`AgentRuntime`] — provider routing
/// (default provider + `provider_hint` override map).
pub(crate) struct ProviderRouting {
    pub(crate) provider: Arc<dyn AiProvider>,
    pub(crate) provider_overrides: HashMap<String, Arc<dyn AiProvider>>,
}

/// Role-grouped sub-config — Delegation hook emit (RawMemory + capture
/// filter) and parent identity stamped onto each emitted row.
pub(crate) struct MemoryCapture {
    pub(crate) raw_memory_writer: Option<Arc<dyn RawMemoryStore>>,
    pub(crate) capture_registry: Option<Arc<MemoryExtensionRegistry>>,
    pub(crate) parent_agent_id: Option<String>,
    pub(crate) parent_session_id: Option<String>,
}

/// Role-grouped sub-config — shared subagent concurrency cap and the
/// shared plugin-registry handle threaded into SpawnerBase.
pub(crate) struct BackgroundConfig {
    pub(crate) subagent_semaphore: Option<Arc<tokio::sync::Semaphore>>,
    pub(crate) plugin_registry:
        Option<Arc<tokio::sync::RwLock<crate::extension::registry::PluginRegistry>>>,
}

/// Role-grouped sub-config — guardrails, resilience knobs (stall /
/// consecutive-failure / per-turn timeout), and run-style inheritance
/// (strategy body, session mode).
pub(crate) struct PolicyInheritance {
    pub(crate) guardrails: Option<Arc<crate::guardrails::GuardrailRegistry>>,
    pub(crate) stall_config: Option<crate::harness::StallConfig>,
    pub(crate) consecutive_failure_cap: Option<usize>,
    pub(crate) turn_timeout: Option<std::time::Duration>,
    pub(crate) strategy: Option<String>,
    pub(crate) session_mode: Option<crate::config::types::policies::SessionMode>,
}

/// Role-grouped sub-config — iteration cap, parallel-tool cap,
/// `[context_budget]` config + per-run refiner + cheap-tier summarizer,
/// and verifier chain. One sub-config because the spawner reads them all
/// together when constructing `SpawnerBase` for the child.
pub(crate) struct BudgetInheritance {
    pub(crate) default_max_iterations: Option<usize>,
    pub(crate) parallel_tool_concurrency: Option<usize>,
    pub(crate) context_budget_config: Option<crate::context::budget::ContextBudgetConfig>,
    pub(crate) context_budget_refiner:
        Option<crate::orchestrator::deps_builder::ContextBudgetRefiner>,
    pub(crate) primary_context_window: Option<u32>,
    pub(crate) cheap_summary_provider: Option<Arc<dyn AiProvider>>,
    pub(crate) verifier_chain: Option<Arc<crate::verification::VerifierChain>>,
}

/// Role-grouped sub-config — routing-experience store threaded into
/// every `SpawnerBase`.
pub(crate) struct RoutingExperience {
    pub(crate) routing_store: Option<Arc<crate::routing::RoutingExperienceStore>>,
}

/// Role-grouped sub-config — the harness and accounting sinks threaded into
/// `SpawnerBase` (split by producer; see `SpawnerBase::accounting_sink`).
pub(crate) struct TraceContext {
    pub(crate) trace_sink: Option<Arc<dyn crate::harness::TraceSink>>,
    pub(crate) accounting_sink: Option<Arc<dyn crate::harness::TraceSink>>,
}

/// Middle layer that manages sub-agent lifecycle: setup, execution, and transcript.
///
/// Decomposed into role-grouped sub-configs so each concern lives in exactly
/// one place. The four "runtime identity" fields (`child_chain`, `cancel_token`,
/// `session`, `parent_tools`) stay as direct fields because they ARE the
/// runtime's identity — every spawn reads them directly. Everything else is
/// grouped:
///   * `provider_routing` — default provider + `provider_hint` overrides
///   * `memory` — Delegation hook emit + parent identity
///   * `background` — shared concurrency cap + plugin-registry handle
///   * `policy_inheritance` — guardrails + resilience + run-style
///   * `budget_inheritance` — iteration / parallel / context-budget / verifier
///   * `routing_experience` — routing store
///   * `trace` — trace sink
pub struct AgentRuntime {
    child_chain: ChainContext,
    cancel_token: CancellationToken,
    /// Shared session actor used by the Harness spawner for the child's
    /// ephemeral session.
    session: Arc<dyn SessionService>,
    /// Parent tool service — decorated with `AllowlistToolService` inside
    /// the spawner.
    parent_tools: Arc<dyn ToolService>,

    provider_routing: ProviderRouting,
    memory: MemoryCapture,
    background: BackgroundConfig,
    policy_inheritance: PolicyInheritance,
    budget_inheritance: BudgetInheritance,
    routing_experience: RoutingExperience,
    trace: TraceContext,
}

impl AgentRuntime {
    /// Create a new runtime with the shared infrastructure needed to spawn agents.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        provider: Arc<dyn AiProvider>,
        child_chain: ChainContext,
        cancel_token: CancellationToken,
        session: Arc<dyn SessionService>,
        parent_tools: Arc<dyn ToolService>,
    ) -> Self {
        Self {
            child_chain,
            cancel_token,
            session,
            parent_tools,
            provider_routing: ProviderRouting {
                provider,
                provider_overrides: HashMap::new(),
            },
            memory: MemoryCapture {
                raw_memory_writer: None,
                capture_registry: None,
                parent_agent_id: None,
                parent_session_id: None,
            },
            background: BackgroundConfig {
                subagent_semaphore: None,
                plugin_registry: None,
            },
            policy_inheritance: PolicyInheritance {
                guardrails: None,
                stall_config: None,
                consecutive_failure_cap: None,
                turn_timeout: None,
                strategy: None,
                session_mode: None,
            },
            budget_inheritance: BudgetInheritance {
                default_max_iterations: None,
                parallel_tool_concurrency: None,
                context_budget_config: None,
                context_budget_refiner: None,
                primary_context_window: None,
                cheap_summary_provider: None,
                verifier_chain: None,
            },
            routing_experience: RoutingExperience {
                routing_store: None,
            },
            trace: TraceContext {
                trace_sink: None,
                accounting_sink: None,
            },
        }
    }

    /// Wire the parent runner's cheap-tier summarizer so every spawned child's
    /// compactor routes its side-channel call to the same flash sibling.
    #[must_use]
    pub fn with_cheap_summary_provider(mut self, provider: Arc<dyn AiProvider>) -> Self {
        self.budget_inheritance.cheap_summary_provider = Some(provider);
        self
    }

    /// B15 — wire the parent runner's boot-time iteration cap, inherited by
    /// every spawned child that declares none of its own.
    #[must_use]
    pub const fn with_default_max_iterations(mut self, max_iterations: usize) -> Self {
        self.budget_inheritance.default_max_iterations = Some(max_iterations);
        self
    }

    /// Wire the parent runner's `[context_budget]` config so every spawned
    /// child gets its own budget / compactor / preflight pipeline.
    #[must_use]
    pub fn with_context_budget_config(
        mut self,
        cfg: crate::context::budget::ContextBudgetConfig,
    ) -> Self {
        self.budget_inheritance.context_budget_config = Some(cfg);
        self
    }

    /// Wire the parent runner's per-run budget refiner + window override so
    /// every spawned child's prompt budget is sized to the model IT will run
    /// on, exactly as the main loop sizes its own.
    #[must_use]
    pub fn with_context_budget_refinement(
        mut self,
        refiner: crate::orchestrator::deps_builder::ContextBudgetRefiner,
        primary_context_window: Option<u32>,
    ) -> Self {
        self.budget_inheritance.context_budget_refiner = Some(refiner);
        self.budget_inheritance.primary_context_window = primary_context_window;
        self
    }

    /// Wire the parent runner's `[tool_service] parallel_tool_concurrency`,
    /// inherited by every spawned child's Act phase.
    #[must_use]
    pub const fn with_parallel_tool_concurrency(mut self, cap: usize) -> Self {
        self.budget_inheritance.parallel_tool_concurrency = Some(cap);
        self
    }

    /// Wire the welded strategy `<strategy>` body inherited by every spawn.
    #[must_use]
    pub fn with_strategy(mut self, strategy: String) -> Self {
        self.policy_inheritance.strategy = Some(strategy);
        self
    }

    /// Wire the parent run's usage mode inherited by every spawn.
    #[must_use]
    pub const fn with_session_mode(
        mut self,
        mode: crate::config::types::policies::SessionMode,
    ) -> Self {
        self.policy_inheritance.session_mode = Some(mode);
        self
    }

    /// Phase 3 — wire the per-`provider_hint` override registry. Each spawn
    /// whose `agent_def.provider_hint` matches a key runs on that provider.
    #[must_use]
    pub fn with_provider_overrides(
        mut self,
        overrides: HashMap<String, Arc<dyn AiProvider>>,
    ) -> Self {
        self.provider_routing.provider_overrides = overrides;
        self
    }

    /// A2 — wire the shared subagent concurrency semaphore.
    pub fn with_subagent_semaphore(mut self, sem: Arc<tokio::sync::Semaphore>) -> Self {
        self.background.subagent_semaphore = Some(sem);
        self
    }

    /// B2 — wire the shared plugin-registry handle for per-agent MCP scope.
    #[must_use]
    pub fn with_plugin_registry(
        mut self,
        registry: Arc<tokio::sync::RwLock<crate::extension::registry::PluginRegistry>>,
    ) -> Self {
        self.background.plugin_registry = Some(registry);
        self
    }

    /// Stage 5a (#9) — wire a guardrail registry that subagents inherit.
    pub fn with_guardrails(mut self, registry: Arc<crate::guardrails::GuardrailRegistry>) -> Self {
        self.policy_inheritance.guardrails = Some(registry);
        self
    }

    // Stage A (P1) — resilience builders threaded into SpawnerBase →
    // HarnessDeps. `SubagentTool` applies them via `build_runtime`; the
    // `trace_sink` / `accounting_sink` pair is chosen in production by
    // `gateway/execution_engine/run_trace_sinks.rs` (`RunTraceSinks`).

    /// Stage A (P1) — wire the stall watchdog config.
    #[must_use]
    pub const fn with_stall_config(mut self, config: crate::harness::StallConfig) -> Self {
        self.policy_inheritance.stall_config = Some(config);
        self
    }

    /// Stage A (P1) — wire the consecutive-failure cap.
    #[must_use]
    pub const fn with_consecutive_failure_cap(mut self, cap: usize) -> Self {
        self.policy_inheritance.consecutive_failure_cap = Some(cap);
        self
    }

    /// Stage A (P1) — wire the per-turn wall-clock timeout.
    #[must_use]
    pub const fn with_turn_timeout(mut self, timeout: std::time::Duration) -> Self {
        self.policy_inheritance.turn_timeout = Some(timeout);
        self
    }

    /// Stage A (P1) — wire the sink the child's harness loop emits into.
    pub fn with_trace_sink(mut self, sink: Arc<dyn crate::harness::TraceSink>) -> Self {
        self.trace.trace_sink = Some(sink);
        self
    }

    /// Wire the sink the child's `MeteringProvider`s emit into.
    pub fn with_accounting_sink(mut self, sink: Arc<dyn crate::harness::TraceSink>) -> Self {
        self.trace.accounting_sink = Some(sink);
        self
    }

    /// VESR v1.1 (b) — wire the routing-experience store inherited by subagents.
    #[must_use]
    pub fn with_routing_store(
        mut self,
        store: Arc<crate::routing::RoutingExperienceStore>,
    ) -> Self {
        self.routing_experience.routing_store = Some(store);
        self
    }

    /// Wire the parent runner's verifier chain so spawned subagents run
    /// under the same structural watchdogs (ToolLoopVerifier,
    /// StopHookVerifier, …) as the parent. `None` keeps the legacy
    /// no-verifier path — the spawner's `verifier_chain: None` — in which
    /// case the iteration cap is the last line of defence.
    #[must_use]
    pub fn with_verifier_chain(mut self, chain: Arc<crate::verification::VerifierChain>) -> Self {
        self.budget_inheritance.verifier_chain = Some(chain);
        self
    }

    /// Wire a `RawMemoryStore` so the spawner emits the Delegation hook.
    pub fn with_raw_memory_writer(mut self, writer: Arc<dyn RawMemoryStore>) -> Self {
        self.memory.raw_memory_writer = Some(writer);
        self
    }

    /// Wire an optional capture-filter registry threaded into the emit.
    pub fn with_capture_registry(mut self, registry: Arc<MemoryExtensionRegistry>) -> Self {
        self.memory.capture_registry = Some(registry);
        self
    }

    /// Set the parent agent id stamped onto the emitted Delegation row.
    pub fn with_parent_agent_id(mut self, id: impl Into<String>) -> Self {
        self.memory.parent_agent_id = Some(id.into());
        self
    }

    /// Set the parent session id stamped onto the emitted Delegation row.
    pub fn with_parent_session_id(mut self, sid: impl Into<String>) -> Self {
        self.memory.parent_session_id = Some(sid.into());
        self
    }

    /// Execute a sub-agent to completion with lifecycle tracing.
    pub async fn run(&self, config: AgentRuntimeConfig) -> Result<LoopRunResult, String> {
        let start = Instant::now();
        let agent_id = format!("{}-{}", config.identity.agent_def.id, uuid::Uuid::new_v4());
        let agent_type = config.identity.agent_def.id.clone();
        let task_summary = crate::utils::text_format::truncate_text(&config.identity.task, 120);

        tracing::info!(
            agent_id = %agent_id,
            agent_type = %agent_type,
            task = %task_summary,
            "SubagentStart: launching sub-agent"
        );

        // SubagentStart lifecycle hook (observer-only — the child has already
        // launched). Reuses the process-global fire-and-forget helper; a silent
        // no-op when no hooks are registered, so it is safe on every spawn.
        crate::extension::hooks::fire_global_observer(
            crate::extension::HookEvent::SubagentStart,
            self.memory.parent_session_id.as_deref().unwrap_or_default(),
            vec![
                ("SUBAGENT_ID", agent_id.clone()),
                ("SUBAGENT_TYPE", agent_type.clone()),
                ("TASK", task_summary.clone()),
                (
                    "PARENT_AGENT_ID",
                    self.memory.parent_agent_id.clone().unwrap_or_default(),
                ),
                ("CHAIN_DEPTH", self.child_chain.depth.to_string()),
            ],
        )
        .await;

        let result = self.execute_via_harness(&config).await;

        let duration_ms = start.elapsed().as_millis().try_into().unwrap_or(u64::MAX);
        let key_findings = match &result {
            Ok(run_result) => run_result
                .final_text
                .as_deref()
                .unwrap_or("")
                .chars()
                .take(200)
                .collect::<String>(),
            Err(_) => String::new(),
        };
        let (outcome, iterations, tokens_used) = match &result {
            Ok(run_result) => (
                TranscriptOutcome::Success,
                run_result.iterations,
                run_result.total_tokens,
            ),
            Err(e) => {
                // Match the spawner's exact wall-clock-timeout prefix
                // ("Sub-agent timed out after Ns") rather than a loose substring —
                // an inner error merely *containing* "timed out" (e.g. a wrapped
                // "connection timed out") must not be misclassified as a hard timeout.
                let outcome = if e.starts_with("Sub-agent timed out") {
                    TranscriptOutcome::Timeout
                } else {
                    TranscriptOutcome::Error(e.clone())
                };
                (outcome, 0, 0)
            }
        };
        let transcript = SubagentTranscript {
            agent_id: agent_id.clone(),
            agent_type: agent_type.clone(),
            task_summary,
            outcome,
            iterations,
            duration_ms,
            tokens_used,
            key_findings,
        };

        tracing::info!(
            agent_id = %transcript.agent_id,
            agent_type = %transcript.agent_type,
            outcome = ?format_outcome(&transcript.outcome),
            iterations = transcript.iterations,
            duration_ms = transcript.duration_ms,
            tokens_used = transcript.tokens_used,
            "SubagentEnd: sub-agent completed"
        );

        // B1-05 (R10): CUT transcript persistence. The transcript file has zero
        // readers repo-wide (the only `data/transcripts` occurrence is this
        // write; nothing reads the directory, no RPC serves it, no tool
        // exposes it, SubagentTranscript is deserialized only in this file's
        // own round-trip tests). The durable subagent record consumers
        // actually use is the SubagentSpawned / SubagentReturned session
        // event pair. Detaching a spawn_blocking per completion to write a
        // dead store (and trigger its own fs::remove_dir_all via cleanup)
        // is exactly the 'zero existing consumer' R10 prescribes deleting.
        // If observability is wanted later, route through TraceSink
        // (already wired on this struct, runtime.rs:137) rather than a
        // second, unread store.

        // SubagentStop lifecycle hook (observer-only). Carries the completion
        // outcome so hooks can react to delegation results without re-reading
        // the transcript store.
        crate::extension::hooks::fire_global_observer(
            crate::extension::HookEvent::SubagentStop,
            self.memory.parent_session_id.as_deref().unwrap_or_default(),
            vec![
                ("SUBAGENT_ID", transcript.agent_id.clone()),
                ("SUBAGENT_TYPE", transcript.agent_type.clone()),
                ("OUTCOME", format_outcome(&transcript.outcome).to_string()),
                ("ITERATIONS", transcript.iterations.to_string()),
                ("DURATION_MS", transcript.duration_ms.to_string()),
                ("TOKENS_USED", transcript.tokens_used.to_string()),
                ("KEY_FINDINGS", transcript.key_findings.clone()),
            ],
        )
        .await;

        result
    }

    async fn execute_via_harness(
        &self,
        config: &AgentRuntimeConfig,
    ) -> Result<LoopRunResult, String> {
        use crate::agents::subagent_spawner::{spawn, SpawnRequest, SpawnerBase};
        // `self.child_chain` is the already-descended chain produced by the
        // caller (SubagentTool::execute calls `self.chain.child()`). The
        // spawner descends again via `base.chain.child()`, so synthesize the
        // logical parent here to keep depth accounting equivalent to the
        // retiring `run_subagent` path (which consumed the child_chain as-is).
        //
        // Invariant: `child_chain` came from `ChainContext::child()`, which
        // returns `Some` only after incrementing depth by 1. depth == 0 here
        // would indicate a caller constructed the runtime with an un-descended
        // chain — the assert catches that in debug builds; release uses
        // `saturating_sub` to avoid underflow.
        debug_assert!(
            self.child_chain.depth > 0,
            "AgentRuntime received an un-descended ChainContext; callers must pass `parent_chain.child()`"
        );
        let parent_chain = ChainContext {
            chain_id: self.child_chain.chain_id.clone(),
            depth: self.child_chain.depth.saturating_sub(1),
            max_depth: self.child_chain.max_depth,
        };
        // Phase 3 — resolve the per-agent provider: `provider_hint` pins a
        // registered override (pinned, then falling through the global chain);
        // a `provider/model` model id routes across vendors; otherwise the
        // shared default. See `resolve_spawn_route`.
        //
        // The effective model is `model` then `model_hint` — the same order the
        // spawner resolves — so a role whose frontmatter carries the qualified
        // form routes too.
        let effective_model = config.spawn_override.model.as_deref().or(config
            .identity
            .agent_def
            .model_hint
            .as_deref());
        let (provider, routed_model) = resolve_spawn_route(
            &self.provider_routing.provider,
            &self.provider_routing.provider_overrides,
            &config.identity.agent_def,
            effective_model,
        );
        let base = SpawnerBase {
            session: self.session.clone(),
            parent_tools: self.parent_tools.clone(),
            provider,
            chain: parent_chain,
            raw_memory_writer: self.memory.raw_memory_writer.clone(),
            capture_registry: self.memory.capture_registry.clone(),
            parent_agent_id: self.memory.parent_agent_id.clone(),
            parent_session_id: self.memory.parent_session_id.clone(),
            guardrails: self.policy_inheritance.guardrails.clone(),
            // Stage A (P1):
            stall_config: self.policy_inheritance.stall_config.clone(),
            consecutive_failure_cap: self.policy_inheritance.consecutive_failure_cap,
            turn_timeout: self.policy_inheritance.turn_timeout,
            trace_sink: self.trace.trace_sink.clone(),
            accounting_sink: self.trace.accounting_sink.clone(),
            // P3 Stage I — per-agent MCP scope; provisioned when an agent_def
            // declares `mcp_servers` and a registry is wired (B2).
            plugin_registry: self.background.plugin_registry.clone(),
            // A2 — subagent concurrency cap.
            subagent_semaphore: self.background.subagent_semaphore.clone(),
            // VESR v1.1 (b) — threaded from the gateway so subagents capture.
            routing_store: self.routing_experience.routing_store.clone(),
            // B15 — the parent's iteration cap, so a capless child role does
            // not run its loop unbounded until the spawn timeout kills it.
            default_max_iterations: self.budget_inheritance.default_max_iterations,
            // The parent's Act-phase parallel cap, so a child honours the
            // operator's `[tool_service] parallel_tool_concurrency` (0/1 =
            // disabled) instead of the hardcoded config default.
            parallel_tool_concurrency: self.budget_inheritance.parallel_tool_concurrency,
            // The parent's `[context_budget]` config, so the child is context-
            // managed on the same terms (the spawner builds its own instances).
            // rust-doctor-disable-next-line excessive-clone
            context_budget_config: self.budget_inheritance.context_budget_config.clone(),
            context_budget_refiner: self.budget_inheritance.context_budget_refiner.clone(),
            primary_context_window: self.budget_inheritance.primary_context_window,
            cheap_summary_provider: self.budget_inheritance.cheap_summary_provider.clone(),
            verifier_chain: self.budget_inheritance.verifier_chain.clone(),
        };
        let req = SpawnRequest {
            agent_def: &config.identity.agent_def,
            task: &config.identity.task,
            context_summary: config.identity.context_summary.as_deref(),
            // A rewritten (de-qualified) id wins; otherwise pass the caller's
            // model through untouched and let the spawner apply its own
            // `model_hint` fallback.
            model: routed_model
                .as_deref()
                .or(config.spawn_override.model.as_deref()),
            timeout_secs: config.lifecycle.timeout_secs,
            cancel: self.cancel_token.clone(),
            spawn_context: config.spawn_override.spawn_context,
            fork_source: config.spawn_override.fork_source.clone(),
            isolation: config.identity.agent_def.isolation.clone(),
            strategy: self.policy_inheritance.strategy.as_deref(),
            session_mode: self.policy_inheritance.session_mode,
            request_id: config.spawn_override.request_id.as_deref(),
        };
        spawn(&base, req).await
    }
}

// =============================================================================
// Helpers
// =============================================================================

/// Resolve which provider a spawn runs on, and the model id that goes on the
/// wire.
///
/// Precedence:
///   1. `agent_def.provider_hint` — an explicit author/operator choice, and the
///      only form that existed before. Wins outright.
///   2. A `provider/model` id whose prefix names the PARENT's own provider: keep
///      the parent provider, stamp the bare model id. Without this a direct
///      single-vendor deployment (the common case) sent `anthropic/claude-…` to
///      Anthropic verbatim and got a 404.
///   3. A `provider/model` id whose prefix names another CONFIGURED provider
///      (`overrides`, keyed by `[providers]` toml name and matched through
///      `canonical_provider_id`, so `kimi` ≡ `moonshot/…` and `vertex-anthropic`
///      ≡ `anthropic/…`): run the child there with the bare model id. This is
///      what makes a cross-vendor MoA fan-out
///      (`proposer_models: ["openai/gpt-5.2", "anthropic/claude-opus-5"]`)
///      actually reach two vendors instead of handing both strings to whichever
///      provider the parent happened to hold.
///   4. Otherwise: the parent's provider, model string untouched. Untouched
///      matters — an OpenAI-compatible aggregator primary (OpenRouter and
///      friends) *wants* `anthropic/claude-…` on the wire, and such a deployment
///      has no separate `[providers] anthropic` entry to match in step 3.
///
/// Returns the provider plus `Some(bare_model)` when the id was rewritten, and
/// `None` when the caller's model string must be passed through as-is.
fn resolve_spawn_route(
    parent: &Arc<dyn AiProvider>,
    overrides: &HashMap<String, Arc<dyn AiProvider>>,
    agent_def: &AgentDef,
    model: Option<&str>,
) -> (Arc<dyn AiProvider>, Option<String>) {
    if let Some(pinned) = agent_def
        .provider_hint
        .as_deref()
        .and_then(|hint| overrides.get(hint))
    {
        return (pinned.clone(), None);
    }
    let Some((prefix, bare)) = model.and_then(split_provider_prefix) else {
        return (parent.clone(), None);
    };
    let want = crate::providers::model_catalog::canonical_provider_id(prefix);
    let parent_vendor = parent
        .serving_provider_hint()
        .and_then(|name| crate::providers::model_catalog::canonical_provider_id(&name));
    if want.is_some() && want == parent_vendor {
        return (parent.clone(), Some(bare.to_string()));
    }
    match override_for_provider(overrides, prefix, want) {
        Some(provider) => (provider, Some(bare.to_string())),
        None => (parent.clone(), None),
    }
}

/// Look up a configured non-primary provider by `[providers]` toml name, falling
/// back to a canonical-vendor match. The fallback resolves ties by the
/// lexicographically smallest key so two entries for one vendor pick
/// deterministically (same rule as `MultiProviderRegistry::default_provider`).
fn override_for_provider(
    overrides: &HashMap<String, Arc<dyn AiProvider>>,
    name: &str,
    canonical: Option<&'static str>,
) -> Option<Arc<dyn AiProvider>> {
    if let Some(provider) = overrides.get(name) {
        return Some(provider.clone());
    }
    let want = canonical?;
    overrides
        .iter()
        .filter(|(key, _)| {
            crate::providers::model_catalog::canonical_provider_id(key) == Some(want)
        })
        .min_by(|(a, _), (b, _)| a.cmp(b))
        .map(|(_, provider)| provider.clone())
}

/// Split a `provider/model` id into `(provider, model)`.
///
/// `None` when there is no prefix, or when either half is blank — those are not
/// qualified ids and must be passed through untouched. Only the FIRST `/` is
/// split on, so a nested aggregator id (`x-ai/openai/…`) keeps its remainder.
fn split_provider_prefix(model: &str) -> Option<(&str, &str)> {
    let (prefix, rest) = model.split_once('/')?;
    let prefix = prefix.trim();
    let rest = rest.trim();
    (!prefix.is_empty() && !rest.is_empty()).then_some((prefix, rest))
}

/// Format a `TranscriptOutcome` for log output.
#[must_use]
const fn format_outcome(outcome: &TranscriptOutcome) -> &str {
    match outcome {
        TranscriptOutcome::Success => "success",
        TranscriptOutcome::Error(_) => "error",
        TranscriptOutcome::Timeout => "timeout",
    }
}

// B1-05 (R10 CUT): persist_transcript and cleanup_old_transcripts deleted —
// they had zero consumers repo-wide (the only `data/transcripts` occurrence
// was the write site; no reader, no RPC, no tool). The durable subagent
// record consumers actually use is the session event log. If observability
// is wanted later, route through TraceSink instead of a second unread store.

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn make_agent_def() -> AgentDef {
        AgentDef::new("test-agent", crate::agents::AgentMode::SubAgent)
    }

    /// Provider stub that reports a configured key through
    /// `serving_provider_hint`, the way `HttpProvider` does at the leaf of the
    /// decorator stack.
    struct NamedProvider(&'static str);

    impl crate::providers::AiProvider for NamedProvider {
        fn process<'a>(
            &'a self,
            _payload: crate::providers::adapter::RequestPayload<'a>,
        ) -> std::pin::Pin<
            Box<
                dyn std::future::Future<
                        Output = crate::error::Result<crate::providers::adapter::ProviderResponse>,
                    > + Send
                    + 'a,
            >,
        > {
            Box::pin(async {
                Ok(crate::providers::adapter::ProviderResponse::text_only(
                    "stub".to_string(),
                ))
            })
        }
        fn name(&self) -> &str {
            self.0
        }
        fn color(&self) -> &str {
            "#000"
        }
        fn serving_provider_hint(&self) -> Option<std::borrow::Cow<'_, str>> {
            Some(std::borrow::Cow::Borrowed(self.0))
        }
    }

    fn named(name: &'static str) -> Arc<dyn AiProvider> {
        Arc::new(NamedProvider(name))
    }

    fn overrides(entries: &[(&str, &'static str)]) -> HashMap<String, Arc<dyn AiProvider>> {
        entries
            .iter()
            .map(|(key, provider)| ((*key).to_string(), named(provider)))
            .collect()
    }

    /// An explicit `provider_hint` is an author decision and still wins outright
    /// — the model id never redirects it.
    #[test]
    fn spawn_route_provider_hint_wins() {
        let parent = named("anthropic");
        let ovr = overrides(&[("openai", "openai")]);
        let def = make_agent_def().with_provider_hint("openai");
        let (provider, model) = resolve_spawn_route(&parent, &ovr, &def, Some("openai/gpt-5"));
        assert_eq!(provider.name(), "openai");
        assert_eq!(
            model, None,
            "a pinned provider passes the caller's model string through untouched"
        );
    }

    /// A qualified id naming the parent's OWN vendor keeps the parent provider
    /// and drops the prefix — the direct single-vendor deployment used to send
    /// `anthropic/claude-…` to Anthropic verbatim.
    #[test]
    fn spawn_route_strips_prefix_for_parent_vendor() {
        let parent = named("anthropic");
        let ovr = overrides(&[("openai", "openai")]);
        let (provider, model) = resolve_spawn_route(
            &parent,
            &ovr,
            &make_agent_def(),
            Some("anthropic/claude-opus-5"),
        );
        assert_eq!(provider.name(), "anthropic");
        assert_eq!(model.as_deref(), Some("claude-opus-5"));
    }

    /// A qualified id naming a different configured provider routes there — the
    /// case that makes a cross-vendor MoA fan-out actually reach two vendors.
    #[test]
    fn spawn_route_crosses_to_configured_provider() {
        let parent = named("anthropic");
        let ovr = overrides(&[("openai", "openai-chain")]);
        let (provider, model) =
            resolve_spawn_route(&parent, &ovr, &make_agent_def(), Some("openai/gpt-5.2"));
        assert_eq!(provider.name(), "openai-chain");
        assert_eq!(model.as_deref(), Some("gpt-5.2"));
    }

    /// Provider keys are operator-chosen, so the match falls back to canonical
    /// vendor slugs: a `[providers] kimi` entry serves `moonshot/…`.
    #[test]
    fn spawn_route_matches_provider_alias() {
        let parent = named("anthropic");
        let ovr = overrides(&[("kimi", "kimi-chain")]);
        let (provider, model) =
            resolve_spawn_route(&parent, &ovr, &make_agent_def(), Some("moonshot/kimi-k2.7"));
        assert_eq!(provider.name(), "kimi-chain");
        assert_eq!(model.as_deref(), Some("kimi-k2.7"));
    }

    /// An unmatched prefix must pass through untouched: an aggregator primary
    /// (OpenRouter and friends) wants the qualified id on the wire, and a
    /// deployment with no matching `[providers]` entry has nothing to route to.
    #[test]
    fn spawn_route_leaves_unmatched_prefix_untouched() {
        let parent = named("openrouter");
        let (provider, model) = resolve_spawn_route(
            &parent,
            &HashMap::new(),
            &make_agent_def(),
            Some("anthropic/claude-opus-5"),
        );
        assert_eq!(provider.name(), "openrouter");
        assert_eq!(model, None);
    }

    /// A bare model id keeps the pre-existing behaviour exactly: parent
    /// provider, model stamped by the spawner as given.
    #[test]
    fn spawn_route_bare_model_is_unchanged() {
        let parent = named("anthropic");
        let ovr = overrides(&[("openai", "openai")]);
        for model in [None, Some("gpt-5"), Some("claude-opus-5")] {
            let (provider, routed) = resolve_spawn_route(&parent, &ovr, &make_agent_def(), model);
            assert_eq!(provider.name(), "anthropic");
            assert_eq!(routed, None, "bare id {model:?} must not be rewritten");
        }
    }

    /// Two entries for one vendor resolve deterministically (smallest key), so
    /// the route never depends on HashMap iteration order.
    #[test]
    fn spawn_route_alias_tie_break_is_deterministic() {
        let parent = named("anthropic");
        let ovr = overrides(&[("zeta-gpt", "zeta"), ("alpha-gpt", "alpha")]);
        for _ in 0..8 {
            let (provider, _) =
                resolve_spawn_route(&parent, &ovr, &make_agent_def(), Some("openai/gpt-5"));
            assert_eq!(provider.name(), "alpha");
        }
    }

    /// A blank half is not a qualified id.
    #[test]
    fn split_provider_prefix_rejects_blank_halves() {
        assert_eq!(
            split_provider_prefix("openai/gpt-5"),
            Some(("openai", "gpt-5"))
        );
        assert_eq!(split_provider_prefix("/gpt-5"), None);
        assert_eq!(split_provider_prefix("openai/"), None);
        assert_eq!(split_provider_prefix("gpt-5"), None);
        // Only the first slash is split, so nested aggregator ids keep the rest.
        assert_eq!(
            split_provider_prefix("x-ai/openai/gpt-5"),
            Some(("x-ai", "openai/gpt-5"))
        );
    }

    #[test]
    fn agent_runtime_config_construction() {
        #[allow(clippy::needless_update)]
        let config = AgentRuntimeConfig {
            identity: AgentIdentity {
                agent_def: make_agent_def(),
                task: "Do something".to_string(),
                context_summary: Some("Parent context".to_string()),
            },
            spawn_override: SpawnOverride {
                spawn_context: None,
                fork_source: None,
                model: Some("claude-sonnet".to_string()),
                request_id: None,
            },
            lifecycle: Lifecycle { timeout_secs: 60 },
        };

        assert_eq!(config.identity.task, "Do something");
        assert_eq!(config.lifecycle.timeout_secs, 60);
        assert!(config.identity.context_summary.is_some());
        assert!(config.spawn_override.model.is_some());
    }

    #[test]
    fn transcript_outcome_variants() {
        let success = TranscriptOutcome::Success;
        assert_eq!(format_outcome(&success), "success");

        let error = TranscriptOutcome::Error("something broke".to_string());
        assert_eq!(format_outcome(&error), "error");

        let timeout = TranscriptOutcome::Timeout;
        assert_eq!(format_outcome(&timeout), "timeout");
    }

    #[test]
    fn subagent_transcript_field_access() {
        let transcript = SubagentTranscript {
            agent_id: "test-agent-123".to_string(),
            agent_type: "test-agent".to_string(),
            task_summary: "test task".to_string(),
            outcome: TranscriptOutcome::Success,
            iterations: 5,
            duration_ms: 1200,
            tokens_used: 500,
            key_findings: "some findings".to_string(),
        };

        assert_eq!(transcript.agent_id, "test-agent-123");
        assert_eq!(transcript.agent_type, "test-agent");
        assert_eq!(transcript.task_summary, "test task");
        assert_eq!(transcript.iterations, 5);
        assert_eq!(transcript.duration_ms, 1200);
        assert_eq!(transcript.tokens_used, 500);
    }

    #[test]
    fn transcript_serialization_roundtrip() {
        let transcript = SubagentTranscript {
            agent_id: "test-123".to_string(),
            agent_type: "explorer".to_string(),
            task_summary: "Find all Rust files".to_string(),
            outcome: TranscriptOutcome::Success,
            iterations: 5,
            duration_ms: 1200,
            tokens_used: 3000,
            key_findings: "Found 42 Rust files in src/".to_string(),
        };

        let json = serde_json::to_string(&transcript).unwrap();
        let deserialized: SubagentTranscript = serde_json::from_str(&json).unwrap();

        assert_eq!(deserialized.agent_id, "test-123");
        assert_eq!(deserialized.iterations, 5);
        assert_eq!(deserialized.key_findings, "Found 42 Rust files in src/");
        assert!(matches!(deserialized.outcome, TranscriptOutcome::Success));
    }

    #[test]
    fn transcript_error_outcome_roundtrip() {
        let transcript = SubagentTranscript {
            agent_id: "err-1".to_string(),
            agent_type: "planner".to_string(),
            task_summary: "Plan feature".to_string(),
            outcome: TranscriptOutcome::Error("timeout".to_string()),
            iterations: 0,
            duration_ms: 5000,
            tokens_used: 0,
            key_findings: String::new(),
        };

        let json = serde_json::to_string(&transcript).unwrap();
        assert!(json.contains("\"timeout\""));
        let deserialized: SubagentTranscript = serde_json::from_str(&json).unwrap();
        assert!(matches!(deserialized.outcome, TranscriptOutcome::Error(ref e) if e == "timeout"));
    }
}
