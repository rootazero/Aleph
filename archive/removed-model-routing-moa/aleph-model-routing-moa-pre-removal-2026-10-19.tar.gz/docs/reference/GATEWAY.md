# Gateway System

> WebSocket control plane, JSON-RPC protocol, and multi-channel messaging

---

## Overview

The Gateway is Aleph's control plane, providing:
- WebSocket server for real-time communication
- JSON-RPC 2.0 protocol for structured requests
- Multi-interface message routing (Telegram, Discord, iMessage, CLI)
- Event distribution and streaming
- Session management and persistence

**Location**: `src/gateway/`

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Gateway Server                            │
│                  ws://127.0.0.1:18790/ws                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐    │
│  │   Inbound    │     │   Handler    │     │   Outbound   │    │
│  │   Router     │ ──▶ │   Registry   │ ──▶ │   Emitter    │    │
│  │              │     │              │     │              │    │
│  │ • Parse req  │     │ • Route      │     │ • Stream     │    │
│  │ • Validate   │     │ • Execute    │     │ • Events     │    │
│  └──────────────┘     └──────────────┘     └──────────────┘    │
│                                                                  │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐    │
│  │   Session    │     │    Event     │     │  Interface   │    │
│  │   Manager    │     │     Bus      │     │   Registry   │    │
│  │              │     │              │     │              │    │
│  │ • SQLite     │     │ • Pub/Sub    │     │ • Telegram   │    │
│  │ • Compaction │     │ • Topics     │     │ • Discord    │    │
│  │ • History    │     │ • Subscribe  │     │ • iMessage   │    │
│  └──────────────┘     └──────────────┘     └──────────────┘    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## JSON-RPC Protocol

### Message Format

**Request (Client → Gateway)**:
```json
{
  "jsonrpc": "2.0",
  "id": "uuid-xxx",
  "method": "agent.run",
  "params": {
    "message": "Hello",
    "session_key": "agent:main:main"
  }
}
```

**Response (Gateway → Client)**:
```json
{
  "jsonrpc": "2.0",
  "id": "uuid-xxx",
  "result": {
    "run_id": "run-123",
    "status": "running"
  }
}
```

**Event (Gateway → Client)**:
```json
{
  "jsonrpc": "2.0",
  "method": "event",
  "params": {
    "topic": "stream.chunk",
    "data": {
      "run_id": "run-123",
      "content": "Hello! How can I help you?"
    }
  }
}
```

---

## RPC Methods

### Agent Methods

| Method | Description | Parameters |
|--------|-------------|------------|
| `agent.run` | Start agent execution | `message`, `session_key`, `thinking?`, `model?` |
| `agent.status` | Get run status | `run_id` |
| `agent.cancel` | Cancel running agent | `run_id` |
| `agent.abort` | Force abort | `run_id` |
| `agent.resume` | Re-trigger this session's interrupted run (see [On-demand resume](#on-demand-resume)) | `session_key` |

#### On-demand resume

`ResumeCoordinator` scans for interrupted runs once, at boot. That covers the
case it was built for and nothing else: a run interrupted while the daemon kept
running, or a candidate skipped after a transient store error, had no second
trigger and no way for anyone to ask for one. `agent.resume` and
`POST /v1/admin/resume` (which `aleph-server resume <session-key>` calls) are
that ask.

Both land in `handlers::resume::resume_named_session` →
`ResumeCoordinator::resume_session` → `resume_from_markers`, which the boot
scan also calls. Every judgement — recency filter, crash-loop cap,
crash-boundary repair, concurrency permit — is made once. **Change a resume
criterion in `resume_from_markers` or you have built a second, weaker resume
wearing the same word.**

Four things worth knowing before touching it:

- **`resume_session` deliberately ignores `[resume] enabled`.** That switch
  governs whether the daemon resumes things nobody asked it to. An operator
  naming a session has already made the decision it exists to defer, and
  silently ignoring an explicit request is the kind of no-op that reads as a
  broken feature. Consequently `set_global_resume_coordinator` must be called
  **outside** the `enabled` branch at boot — a handle installed under a
  narrower condition than its consumers fails closed on exactly the
  deployments that need the manual verb most, and its only symptom is a
  rejection.
- **Visibility is `KeyChecked`, and it is worth different amounts per
  transport.** Over JSON-RPC the caller identity is scoped around
  `process_request`, so `visibility::session_visible` compares against a real
  actor and an invisible session gets the byte-identical `not_found` a missing
  one gets. Over `/v1/admin` there is no such scope, `visible_owner_filter()`
  is `None`, and the gate admits everything — which is the trust model working
  (that route is bearer-authenticated with the operator's shared token, and an
  operator sees every session). The check lives in the shared body so this
  reasoning is stated once rather than re-derived per transport.
- **Lane is `Execute`, set explicitly.** `agent.resume` starts agent
  execution; it just takes its input from the session log instead of the
  request. The `.resume` suffix matches no heuristic token, so without the
  `lane.rs::override_for` entry it defaults to `Mutate` and a burst of resumes
  competes on the generic mutation lane instead of the run-concurrency budget.
- **The CLI is IPC-only, with no local fallback.** Resuming means re-entering
  the harness with the session's provider, tools and workspace. A `LockOrIpc`
  local half would either do nothing or stand a second runtime beside the
  singleton, so `aleph-server resume` uses `run_no_lock` + `forward_to_server`
  and says so when no server is running.

- **One resume per session at a time.** `repair_boundary`
  (`src/session/boundary_repair.rs` since round-2; the coordinator keeps only
  the `in_flight` slot) is a read-then-append, so two concurrent resumes of one
  session both compute the same repair set and both append it — leaving one
  `call_id` answered by **two synthetic `ToolError`s**. What that costs is worth
  stating exactly, because this page said the wrong thing about it until
  2026-09-02: since `harness::agent::prompt` learned to downgrade an
  orphaned/duplicate `tool_result` to a plain user note (7929bbda6) it is **no
  longer a provider rejection**. The model reads the same "outcome unknown"
  sentence twice, the second time as prose that no longer references the call it
  answers — duplicated text it must reconcile, not an API error that bricks
  every later turn. The boot scan never
  exposed this on its own: through round-2 it walked sessions in a sequential
  loop, and since round-3 (T15) `launch_resume` spawns one `JoinSet` task per
  candidate under `[resume] max_concurrent` permits
  (`resume_coordinator.rs:1070-1121`, permits from `:997`, default 2 at
  `config/types/resume.rs:46-48`) — but every task claims a **different**
  session, so the fan-out cannot collide with itself. Before T15 the knob
  bounded only `retrigger` and the scan was serial, so the permit pool was never
  contended; now one permit spans a candidate's boundary repair AND re-trigger
  and is shared with the on-demand face (`resume_session` takes the same
  permit). The on-demand face is what can collide with the boot scan, which is
  spawned while the gateway is already serving requests.
  `ResumeCoordinator.in_flight` claims the session before anything reads the
  log; a collision returns `busy` rather than proceeding (line numbers measured
  at `dded43c7f`). `already_resuming` is checked **first** when deriving the status
  word, because a busy report has every other counter at zero and would
  otherwise render as `no_runs` — telling the operator a session has no history
  at the moment it is being resumed.
  What the fan-out still costs is latency, not correctness: each candidate
  task holds its permit across the whole re-triggered run, `launch.settle()`
  joins every task, and boot's late `reinject_survivors` pass (busy-queue
  survivors whose session the scan visits) and the §8.2(b) lost-input notices
  (`adjudicate_orphaned_tasks`, run from `settle`) only start after that join
  — so a survivor for a session the scan merely skipped, or a user whose
  message was lost pre-seed, waits for the **slowest resumed run** to finish
  (`start/mod.rs` argues why the order must hold; FOLLOW-UP F27 is the
  per-session release).

Status vocabulary (same on both surfaces): `resumed` · `already_resuming` ·
`already_finished`
(scanned, newest marker was a `RunFinished`) · `no_runs` (the session has no
run markers at all — an answer, not a failure) · `abandoned` (too old, or the
crash-loop cap tripped) · `not_resumed` (interrupted, but the boundary repair
or the re-trigger failed; the server log has the reason).

**Crash-boundary wording is part of this contract.** A dangling
`ToolCallRequested` is answered by `boundary_repair_text(tool, provenance,
denied, parked, degrade)`, which has **four arms because there are four true
sentences** (the fourth, `parked`, since round-3 — see below), all sharing one closing instruction (`VERIFY_CLOSE`, a constant, so
the sentences cannot drift apart on the one point that tells the model what to
*do*):

- `OUTCOME UNKNOWN — the server restarted after this <tool> call was dispatched
  but before its result was recorded` (`DanglingProvenance::ThisRestart`);
- the same verdict with the other lead, `an earlier run in this session ended
  without recording the result` (`EarlierRun`) — the attribution matters because
  saying "the server restarted" about a dangle left by an interrupted earlier
  run is false about *when*;
- `NOT EXECUTED — this <tool> call was denied by the approval gate and did not
  run` (`denied`), which explicitly lists what has therefore **not** happened;
- `NOT EXECUTED — this <tool> call never ran: … while it was still waiting for
  <reason>` (`parked: Some(ParkReason)`, round-3 §6.1): the gate wrote a
  `ToolCallParked { reason }` intent stamp BEFORE it parked (Normal durability —
  losing it reads as "outcome unknown", the safe direction), and nothing answered
  the gate before the log ends. `Approval` / `PreHook` say "never ran"; the
  `Clarification` body does not, because the question WAS delivered and only
  the answer is missing. `denied` wins over `parked` (the reducer never sets
  both). A parked call is only TOLD to the model — no approval or clarification
  is re-delivered (U4). Full text: FEATURE_LOCATOR §4.13a ㉑.

None of the four says the call *failed*: the rational response to a failed call
is to issue it again. The first two say its side effects may already have
landed; the last two say they cannot exist.

**Why there is a third arm — the two-item enumeration above it was not enough.**
`ToolCallRequested` is persisted immediately before dispatch, and the two things
that can still stop a call after that point (a guardrail `Block`, an approval
denial) each write their own answer event — from which this page used to
conclude that "requested, never answered" *always* means the call reached or
passed the dispatch line. That inference holds only while those answer events
are guaranteed to be on disk. A statically denied call is answered in the same
turn and never dangles, but the window between a denial and its receipt is a
crash window like any other, and a call that crashed inside it **never ran**.
Telling that call "this may have completed and its side effects have already
landed" is a fabrication, and the model's likely reaction is to go hunting for
state that does not exist — which is why `denied` is a field on
`session::reduction::DanglingCall` rather than a detail of the approval path.
Real-machine stage: `qa/resume_boundary/run.sh denied`.

Deliberately **not** a safety-level classifier: `ToolSafetyLevel` exists and
could sort read-only calls from destructive ones, but deciding "is this safe to
redo?" from a tool name and its arguments is the reasoning R7 reserves for the
model. State the fact; let it judge.

### Session Methods

| Method | Description | Parameters |
|--------|-------------|------------|
| `session.get` | Get session info | `session_key` |
| `session.list` | List all sessions | `filter?` |
| `session.history` | Get message history | `session_key`, `limit?` |
| `session.compact` | Summarize older turns and drop them from the live context (`context::compact::manual`; soft-retires the event log, deletes nothing) | `session_key`, `instructions?` |
| `session.delete` | Delete session | `session_key` |

### Config Methods

| Method | Description | Parameters |
|--------|-------------|------------|
| `config.get` | Get current config | - |
| `config.patch` | Partial update | `patch` (JSON Merge Patch) |
| `config.apply` | Full replace | `config` |
| `config.reload` | Reload from file | - |

### Event Methods

| Method | Description | Parameters |
|--------|-------------|------------|
| `events.subscribe` | Subscribe to topics | `topics` (globs, or `{topic, where}` objects), `except?` (`aleph_protocol::TopicCarveOut`) |
| `events.unsubscribe` | Remove the entries of these topics carrying exactly this carve-out | `topics`, `except?` |
| `events.list` | List subscriptions | - |

All three answer with `aleph_protocol::SubscriptionList`: `subscribed` (one pattern per entry) and `entries` (`SubscriptionEntry`: `topic`, `where`, `except`); subscribe / unsubscribe add `changed`.

### Memory Methods

| Method | Description | Parameters |
|--------|-------------|------------|
| `memory.store` | Store fact | `content`, `metadata?` |
| `memory.search` | Search facts | `query`, `limit?` |
| `memory.delete` | Delete fact | `fact_id` |
| `memory.stats` | Get statistics | - |

### Browser Methods (CDP)

| Method | Description | Parameters |
|--------|-------------|------------|
| `browser.navigate` | Go to URL | `url` |
| `browser.click` | Click element | `selector` |
| `browser.type` | Type text | `selector`, `text` |
| `browser.screenshot` | Take screenshot | `selector?` |
| `browser.evaluate` | Run JavaScript | `script` |

### Other Methods

| Domain | Methods |
|--------|---------|
| `connect` | LAN-trust handshake (no auth; always `operator`) |
| `pairing.*` | `list`, `approve`, `reject` — **channel** sender approval (iMessage/Telegram unknown senders), not device auth |
| `interface.*` | `status`, `config` |
| `mcp.*` | `list`, `list_pending_approvals`, `respond_approval`, `cancel_approval` — persistent server CRUD is `mcp_config.*`; the eleven lifecycle / aggregation verbs (`add`…`restart`, `tools`/`resources`/`prompts`) were cut 2026-09-20 (zero clients) |
| `plugins.*` | `install`, `uninstall`, `list`, `enable`, `disable` |
| `skills.*` | `list`, `install`, `activate` |
| `runs.*` | `list`, `status`, `wait`, `queue` |
| `clarification.*` | `pending`, `resolve` — value-free shared question views and optional request/question identity guards; see below |
| `trace.*` | `by_runs`, `tool_output` — recorded loop replay and masked byte-paged tool output |
| `models.*` | `list`, `config` |
| `generation.*` | `image`, `video` |
| `cron.*` | `list`, `add`, `remove`, `run` |
| `projects.*` | rooms: `list`, `get`, `create`, `rename`, `archive`, `member_*`, `bind_workspace`, `room_session`, `workspace.list/read` — plus `channel.bind` / `channel.unbind` / `channel.list`, below |

### Clarification identity and recovery（2026-10-15）

公开形状集中在 `shared/protocol/src/clarification.rs`。注册生成 `request_id`，并原样出现在 `AskUser`、pending 与 `ClarificationEnded`；pending 还携带关联 `run_id`，客户端取消后台请求时必须使用这个 run，不得猜当前屏幕上的 run。旧帧省略新增身份字段仍可解码。

`clarification.resolve` 支持可选 `expected_request_id` 与 `expected_question_id`。Core `ClarificationManager::resolve_many_expected` 在推进问题游标的同一把写锁内检查身份；旧问题的迟到回复不会消费其替代请求。调用方必须读取 `resolved`、`stale` 和 `pending_questions`：`resolved: true` 只说明本次答案已接受，未必代表多题请求结束。传输失败、身份过期或遗漏后继帧时，应保留输入并用 `clarification.pending` 恢复公开状态。选项内部 value 仅留在 Core，不通过 pending/事件发给 TUI。

English: Registration identity is shared across event, pending snapshot and completion. Guarded resolution compares request and cursor under the same lock as mutation. An accepted answer can leave more questions; clients recover through pending snapshots and retain drafts on uncertain transport outcomes.

`trace.tool_output` 返回 `ToolOutputPage { tool_call_id, text, offset, total_bytes, truncated, source }`。offset 是实际 UTF-8 页起点，下一页用 `offset + text.len()`，不能按字符计数。`source: expired` 表示持久化原文已过期，`truncated: true` 不应触发无限加载。正文脱敏归 Gateway，客户端只消费 RPC，不读取服务器路径。

---

## Event Topics

Subscribe to events using glob patterns:

| Pattern | Events |
|---------|--------|
| `stream.*` | All streaming events |
| `stream.chunk` | Text chunks |
| `stream.agent_trace` | Structured loop-originated execution trace; best-effort (a lagging drain drops frames), and since 2026-09-23 `seq`-ordered with the run's other `stream.*` frames → [TRANSCRIPT_RENDERING §7](TRANSCRIPT_RENDERING.md) |
| `stream.tool_start` | Tool execution start |
| `stream.tool_end` | Tool execution end |
| `agent.*` | Agent lifecycle events |
| `agent.started` | Run started |
| `agent.completed` | Run completed |
| `agent.error` | Run error |
| `session.*` | Session events |
| `config.*` | Configuration changes |

---

## Interfaces

**Location**: `src/gateway/interfaces/`

### Interface Trait

```rust
#[async_trait]
pub trait Interface: Send + Sync {
    fn name(&self) -> &str;

    async fn start(&self) -> Result<()>;
    async fn stop(&self) -> Result<()>;

    async fn send_message(
        &self,
        target: &InterfaceTarget,
        message: &str,
    ) -> Result<()>;

    fn is_running(&self) -> bool;
}
```

### Available Interfaces

| Interface | Feature Flag | Description |
|-----------|--------------|-------------|
| CLI | `cli` | Command-line interface |
| Telegram | `telegram` | Telegram Bot API |
| Discord | `discord` | Discord Bot |
| iMessage | always compiled | Apple iMessage — two transports: **Local** (chat.db poll + AppleScript, macOS-only) and **BlueBubbles** (REST + webhook, any OS). See `src/gateway/interfaces/imessage/`. |
| WebChat | `gateway` | Built-in web chat |

### Factory registration is what makes a channel configurable

`handlers::channel::create_channel_from_config` resolves a configured
`[channels.<type>]` entry through the plugin table in
`interfaces/plugin.rs`, and returns `None` for a type that is not in it —
after which `initialize_channels` logs `Failed to create channel` and continues.
**A `ChannelFactory` that is not registered in `interfaces::register_channel_plugins`
is therefore unreachable, however complete it is.**

The table landed 2026-04-05. Channels added after it registered themselves in the
same commit; the ten that predate it (Slack, Discord, Matrix, Mattermost, Signal,
IRC, Nostr, XMPP, Email, Webhook) were never back-filled and were silently
unconfigurable until 2026-07-26. `imessage` and `cli` are deliberately absent —
iMessage is constructed directly in `initialize_channels`, which `continue`s before
consulting the table, and CLI is not a configurable channel type.

New adapters must be added to `register_channel_plugins` by hand.
`every_configurable_channel_type_is_registered` pins the current set against
regression, but it cannot enumerate `impl ChannelFactory`, so it will not catch a
*future* adapter that forgets to register — adding the name to that list is the
same manual step as the registration.

### Self-healing needs intent, not just status

`ChannelHealthMonitor` sweeps for wedged channels and restarts them in place.
Its predicate reads **two** facts, because one is not enough:

- `ChannelRegistry`'s `DesiredChannelState` — `Running` after a successful
  `start_channel` / `restart_channel`, `Stopped` after `stop_channel` or before
  any start. Only the layer that serves start/stop knows this.
- The live `ChannelStatus`, plus staleness.

`ChannelStatus::Disconnected` means three unrelated things — never started,
stopped on purpose, transport died — so a status-only predicate must either
resurrect channels the operator stopped or never rescue a dead socket. The old
predicate chose the latter (`status == Error` alone) and was consequently a
**no-op for exactly the long-lived socket channels the monitor was written
for**: `discord`, `irc` and `xmpp` all write `Disconnected` when their
connection task exits, and Discord assigned `Error` and then unconditionally
overwrote it on the next line. Registered, budgeted, tested, never fired.

The predicate is now "supposed to be running AND down AND stale", where down
covers `Error`, `Disconnected` and a hung `Connecting`. `Connected`-but-silent
is still excluded — a quiet Slack workspace is not a broken one, and Aleph has
no separate transport-liveness signal to tell them apart (openclaw restarts on
`stale-socket` only because it tracks `lastTransportActivityAt`). `Disabled` is
excluded as configuration. Mapped from openclaw's `isManagedAccount` +
`lifecycle` in `gateway/channel-health-policy.ts`.

**Adapter rule**: do not unconditionally overwrite `status` on a connection
task's exit path. That one line erases the failure the line above just
recorded, blinding both `channels.list` and the monitor.

### Addressing: channel vs conversation

Three different things get called "channel". Keep them apart when reading an error:

| Term | Type | Example | Where it comes from |
|------|------|---------|---------------------|
| **channel** — the transport | `ChannelId` | `"slack"` | `[channels.*]` config, registered into `ChannelRegistry` |
| **conversation** — the room | `ConversationId` | `"C0A1B2C3"` | opaque platform handle |
| **capability** — what this transport can do | `ChannelCapabilities` | `reactions: true` | the adapter's own `capabilities()` |

`OutboundMessage` needs a `ConversationId`, and until 2026-07-26 the only source of
one was an *inbound* message — so the agent could only ever reply where it had been
spoken to. `Channel::list_conversations(query, limit) -> ConversationPage` closes
that: it is the trait's only read, and it reads **routing metadata only** (name, id,
`is_member`), never message content. That line is deliberate — content fetched by a
*pull* would arrive with none of the access control that `inbound_router::check_permission`
(dm/group policy, pairing, allowlists) applies to *pushed* messages.

`ConversationPage` is `{ conversations, warnings }` rather than a bare `Vec` because a
roster lookup has a real **partial** outcome: an app granted `channels:read` but not
`users:read` can list every channel and no people. A bare `Vec` can only say "no match",
which would have the model report that a person does not exist when the truth is that it
was never allowed to look. Slack therefore fails the call only when **both** sweeps fail;
one failing degrades and names the reason. The same field carries page-cap truncation, so
"we stopped looking" is never mistaken for "not in the roster".

Model-facing, this is the read-only `channel_directory` tool feeding `channel_message`.
They are two tools on purpose: `ToolFacts::idempotent` is keyed on the tool **name**
(`registry_adapter::READ_ONLY_TOOLS`), so folding a lookup into non-idempotent
`channel_message` would gate it under the `Ask` exec tier — and a tier never widens,
so there would be no way back.

Slack implements it in `interfaces/slack/directory.rs::ConversationDirectory`
(`conversations.list` + `users.list`, cursor-paginated, 15-minute TTL cache, hard page
cap). The cap is not cosmetic: `ChannelRegistry` holds the channel's **read guard**
across the adapter call, so an unbounded sweep would block the write lock that
`stop_channel` / `restart_channel` need.

### A conversation can be bound to a project room

There is a **fourth** thing worth keeping apart from the three above: the
*binding key*. `projects.channel.bind` points a room at one channel
conversation, and the table is keyed on
`(channel_id, peer_kind, peer_id)` — the conversation's own identity — **not**
on a session key. That is the whole reason it survives an `agent_switch`,
which mints a new session key for the same group.

What binding buys: every turn spoken in that group now runs under the room's
scope instead of under `personal:<speaker>`. Memory partition, the
`<room_context>` roster, the speaker label and the room's bound workspace all
follow, and the conversation's existing session rows are moved into the room so
roster members see it in `sessions.list`. Before this, a group's turns
fragmented into one partition per speaker.

Three things a reader would otherwise have to infer:

- **The mechanism does not know which channel it is.** `conversation_of` reads
  the binding key off any `SessionKey::Group`, so a Telegram group, a Feishu
  group and a `webhook` conversation are the same case. Components are
  normalized once, at `bind_conversation`, through
  `binding::normalize_component` — and the comparison side must use the
  normalized `ChannelBinding` rather than the raw request params, which is
  enforced by `rescope_existing_transcript` taking `&ChannelBinding` and never
  seeing `ChannelBindParams` at all. A signature says "this mistake cannot be
  made without changing the signature"; a test only says it was not made.
- **`bind`/`unbind` are admin-gated; `list` is not.** The two writers sit in
  `method_admin::ADMIN_METHODS` because **their exposure runs outward**: after
  binding, a roster member speaking in the group makes the agent answer out of
  the room's shared memory, notes and workspace, and that answer is delivered
  to the whole conversation — including people the roster does not control. No
  per-caller filter can express that, which is why the decision belongs to an
  operator rather than to a room owner who may be an ordinary member. `list`
  stays open and is narrowed to the roster by `gate_project`.
- **A roster gate sits on the upgrade, not on the conversation.** Being in a
  bound conversation is not itself a claim on the room: the *binding* is an
  operator's declaration, being in the group is not. So `room_claiming`'s
  `BoundConversation` arm leaves the producer's stamp alone for a speaker the
  roster does not admit. An unpaired speaker gets no scope at all — the
  fail-closed `stamped?` in `request_scope` reaches that before the room
  question is asked.

**The receipt is three-valued and the third value is load-bearing.** `bind`
answers `Moved` / `NothingToMove` / `Unknown`. An `Err` from the session store
must **not** fold into `NothingToMove`: that would be a confident factual claim
about a conversation whose store just failed. The bind has already committed by
the time the scan runs, so the error must not fail the RPC either — hence
`Unknown` plus a named `warn!`. An `Err` after some rows already moved is also
`Unknown`, not `Moved`, because `Moved` asserts the whole transcript is in the
room. How the scan can come back short in each backend is enumerated in
`rescope_existing_transcript`'s doc and recorded as known gap #6 in
[SECURITY.md](SECURITY.md).

The gateway-owned mapping must win over producer metadata on **every** reader's
path, not just the one you are looking at — `src/gateway/CLAUDE.md` 地雷 Q is
the full account, and it exists because the fourth of five readers re-derived
the answer from raw metadata and dropped the room at the harness spawn.
Real-machine coverage: `qa/rooms_channel_bind/run.sh`.

### Capability flags are promises

Each `ChannelCapabilities` bool claims the matching optional `Channel` method works.
An adapter that sets one **must** override that method: the default bodies now return
`ChannelError::UnsupportedFeature` naming the adapter, where they used to return
`Ok(())` and let the caller report a success that never happened. Six shipped adapters
were in exactly that state — `msteams.reactions` and `whatsapp.deletion` made
`channel_message` answer `delivered: true` for a no-op. Pinned by
`declared_but_unimplemented_optional_methods_fail_loudly` in `channel.rs`.

### Interface Configuration

```json5
{
  "interfaces": {
    "telegram": {
      "token": "BOT_TOKEN",
      "allowFrom": ["+1234567890"],
      "groups": {
        "*": { "requireMention": true }
      }
    },
    "discord": {
      "token": "BOT_TOKEN",
      "guilds": ["guild-id-1"]
    }
  }
}
```

---

## Durable Outbound Delivery Queue

**Location**: `src/gateway/delivery_queue.rs` (store + drain loop),
`src/gateway/channel_registry.rs` (enqueue-on-failure + accessors),
`src/builtin_tools/channel_outbox.rs` (operator/model surface).
**Config**: `[gateway.delivery_queue]`. **Opt-out**: no store attached ⇒
byte-identical pre-queue behaviour.

`ChannelRegistry::send` retries only `RateLimited`, in memory, for a bounded
window. Every other *definitely-not-delivered* failure — above all
`NotConnected` while a channel reconnects — used to drop the message, and
nothing survived a restart. For an assistant whose core promise is proactive
push (R5), a lost Daemon notification is a silent correctness failure.

### The three-way outcome, not two

Delivery has three endings, and the queue used to model two:

| Ending | Classifier | Action |
|---|---|---|
| Reported, definitely not delivered (`NotConnected` / `RateLimited`) | `should_enqueue` | persist, retry with backoff |
| Reported, may already be on the wire (`SendFailed` / `Internal`) | `terminal_reason` → `Ambiguous` | never retried; dead-lettered for inspection |
| **Not reported at all — the process vanished mid-send** | in-flight stamp | never retried; dead-lettered as `UnknownOutcome` |

The third row is why `mark_inflight` stamps a row *before* the send crosses the
transport boundary and `reconcile_inflight` runs once per process (from
`spawn_drain`, at the moment it wins the drainer slot). Without it, a daemon
that exits between a successful send and `mark_delivered` leaves a pending,
already-due row that the next boot replays — a duplicate. Mapped from
openclaw's `markDeliveryPlatformSendAttemptStarted` /
`needsUnknownSendReconciliation`; Aleph skips its multi-process lease because
the single-drainer invariant (`try_claim_drainer`) makes it unnecessary.

### Ordering is per conversation

`drain_once` groups a claimed batch by `(channel, conversation)`, preserves
claim order, and stops a conversation at its first non-success. Grouping alone
is not enough across ticks: the failed head backs off into the future while its
followers stay due, so the next tick would claim a follower, never see the
head, and deliver it first — permanently reordering the chat. The head's
backoff is therefore carried to the rest of its conversation
(`defer_conversation`, over an indexed `conversation_id` column backfilled at
open). Different conversations never block each other.

That covered only the *queued* half. A live `send` that succeeded while an
older message for the same conversation was still serving out a backoff arrived
first — permanently, and up to `max_backoff` early. `send` now flushes that
conversation's backlog ahead of itself (`flush_conversation`), which keeps the
return contract byte-for-byte: the caller still gets a real `SendResult` or the
exact error it would have got before. The rejected alternative was admitting
live sends into the queue, which changes what every caller observes (a queued
message has no `SendResult`) and converts a reordering bug into head-of-line
*unavailability* — one wedged record would hold up its conversation until it
dead-lettered, roughly 45 minutes at the default curve.

Three constraints make the flush safe:

| Constraint | Why |
|---|---|
| `claim_conversation` ignores `next_attempt_at` | the record a live send overtakes is precisely the one sitting in the future |
| `AttemptMode::Inline` never settles a *transient* failure (`clear_inflight` only, `attempts` / `next_attempt_at` untouched) | an opportunistic probe must not spend the backlog's retry budget — ten user messages would otherwise burn the head's ten attempts and dead-letter it far ahead of the configured curve. Ambiguous *terminal* failures are still settled: handing a possibly-on-the-wire send back for another attempt is how at-most-once dies |
| `drain_gate` serializes flush against the drain loop; `try_lock`, never blocking | both claims are unleased SELECTs — this is exactly the "a second drainer is introduced" case `claim_due` warns about. A process-local mutex suffices because the single-drainer invariant already is process-local. Standing down when the drainer holds it beats blocking a user-facing send behind a whole tick |

Bounded by `inline_flush_max` (default 8, `0` disables; deliberately not floored
at 1). A backlog deeper than the cap is flushed up to the cap and the overtake
is logged, not silently accepted.

### Dead letters carry their own replay-safety

`redrive_dead_letters` used to rest on "every dead letter is duplicate-safe by
construction", which was true only while exhausted transient retries were the
sole producer. With terminal failures and interrupted attempts also landing
there, safety is per record — and it is **two questions, not one**:

- `DeadLetterReason::replay_safe` — "can replaying this double-send?" It is the
  operator-facing duplication flag, and `PayloadTooLarge` is **safe** by it: the
  row is written by `DeliveryStore::enqueue` *before* any transport call, so
  nothing was ever attempted.
- `DeadLetterReason::redrivable` — "will redrive actually move it?" Strictly
  narrower, and projected into SQL by `redrivable_tokens()`. `PayloadTooLarge`
  is **not** redrivable: a redrive re-inserts the row without re-running the cap
  check, so it would land a record the limit rejects.

The two were one boolean until 2026-08-29, and the cost was a message that
provably never left the process being reported to the user as "the outcome of
the last attempt is unknown" — the one refusal whose remedy (raise
`max_payload_bytes`) has nothing to do with duplicates.

⚠️ `redrivable` is spelled as its **own** exhaustive `matches!`, not as
`replay_safe() && !PayloadTooLarge`. The derived form made
`every_dead_letter_reason_answers_both_questions_consistently` — whose stated job
is to check `redrivable ⇒ replay_safe` for every variant including future ones —
true by construction, so it could not go red for any input.

Redrive therefore reports **three** counters, because the operator's next action
differs for each: `moved`, `skipped_capacity` (live queue full — retry later),
`skipped_unsafe` (may already have been delivered — ask the user), and
`skipped_over_cap` (raise the cap). The `channel_outbox` tool renders all of
them; when it read only `skipped_unsafe`, `moved + skipped_capacity +
skipped_unsafe` silently stopped adding up to the number of dead letters.

Redrive also respects the live-queue bound by **moving fewer records**, never
by evicting live ones. The previous implementation moved everything then
trimmed by oldest `created_at` — and since redriven rows carry `created_at =
now`, the rows evicted were the genuinely-older *pending* deliveries.

### Bounds

- `max_queue_len` — row count, oldest-first eviction, both tables.
- `max_payload_bytes` — serialized size. `OutboundMessage` carries
  `Attachment`s that may hold inline `data: Vec<u8>`, so a row-count cap alone
  lets a few media pushes to a wedged channel grow `delivery.db` without bound.
  Over-cap payloads are dead-lettered (`PayloadTooLarge`), not silently dropped.

### A durable row must not outlive its media

Every local `Attachment.path` Aleph produces points **inside the OS temp
directory** — `media::cache` refuses to attach a local path from anywhere else
(arbitrary-file exfiltration guard) and TTS writes there too. So the one thing
this queue exists to promise, "it survives a restart", was false for any row
carrying media: a path attachment serializes to a couple of hundred bytes,
sails past `max_payload_bytes`, and replays as a message whose media is gone.
The byte cap cannot see this — it is measuring the reference, not the file.

`take_media_custody` (called from `maybe_enqueue`, the single admission
chokepoint, and only on the failure path) inlines the bytes into
`Attachment.data` — the branch every adapter already prefers over `path`.
Custody lives **in the row**, not in a spool directory: the row stays
self-contained, so eviction, dead-lettering, redrive and the byte cap keep
working unchanged and there is no second lifecycle to garbage-collect. openclaw
needs its `delivery-queue-media-spool.ts` (stage table, `.part` publishes, 24h
orphan grace, prune sweep) because it is queue-first — every message goes
through the queue, so the copy must be cheap and out of band. Aleph queues only
on failure, so it can afford the simplest shape. Do not port the spool.

Both refusals leave the attachment exactly as the caller wrote it, so a queued
row is never *less* deliverable than before: an unreadable file (already gone,
permissions) has nothing to inline, and bytes that would push the payload over
`max_payload_bytes` are better queued as a path that *might* still be there
than dead-lettered on the spot. Both are logged. The path's file name moves
into `filename` on the way in, because inline bytes carry no name of their own.

### Surfaces

- `channels.list` → `delivery_queue`: counts only (depth, due, oldest age,
  per-channel, dead-lettered, dead-lettered-replayable). Panel reads this.
- `channel_outbox` tool → `status` / `dead_letters` / `redrive`. This is the
  **only** production consumer of `recent_dead_letters` / `redrive_dead_letters`;
  the `channels.dead_letters` / `channels.redrive_dead_letters` RPCs were
  removed as orphans and must not be revived — no client ever called them, and
  the consumer that exists is the model (R8).

---

## Busy Input & Wait Lane

**Location**: `src/gateway/busy_queue/` (lane + delivery loop + config)

Exactly one run may be in flight per session (`execution_engine::SessionRunRegistry`).
A message that arrives while its session is busy is routed by the originating
channel's declared `BusyInputMode`:

| Mode | Behaviour |
|---|---|
| `Steer` (default) | Injected into the live event log; the running loop consumes it at its next turn boundary. |
| `Interrupt` | Cancels the session's run **and its delegated child runs**, then the message restarts as a fresh run via the lane. |
| `Queue` | Leaves the running task alone; the message waits in the lane. |

Anything that cannot be delivered inline joins its session's **FIFO wait lane**.
All three surfaces share the one lane — the inbound router (channels) and both
`aleph-server` RPC handlers (`agent.run`, `chat.send`, via
`busy_queue::spawn_queued_run`) call `busy_queue::register` on the arrival path
and `busy_queue::deliver_with_ticket` inside the spawned delivery task.

Invariants worth preserving:

- **Ticket is taken synchronously on the arrival path**, before the delivery task
  is spawned. Registering inside the task makes lane order follow task
  scheduling instead of arrival order.
- **The lane is a waiting room, not a run registry.** `deliver_with_ticket`
  holds its ticket across the whole `attempt()`, and `attempt()` *is* the agent
  run — so `SessionRunRegistry::try_claim` calls `busy_queue::mark_admitted` to
  withdraw the ticket the moment the run is admitted (the exact mirror of
  `release` → `notify_slot_free`). Without it the running message sits at the
  head of its own lane for the run's entire lifetime, every follow-up parks
  behind the very run it wants to change, and `Steer` / `Interrupt` — which only
  mean anything *while* a sibling runs — silently degrade to `Queue`. The same
  root cause made `/stop` count the message it was stopping among the "queued
  messages dropped" and inflated `busy_queue.total_waiting` by one per busy
  session. FIFO constrains only the messages that are still waiting.
- **Waiters do not poll.** They park on a per-session `Notify` fired by
  `SessionRunRegistry::release` (the authoritative slot-free edge),
  `mark_admitted` (the symmetric "the lane just got shorter" edge), and ticket
  departures. `busy_queue_wake_fallback_secs` is a missed-signal safety net, not
  the delivery latency.
- **`TicketGuard` is the only way in or out.** Its `Drop` is load-bearing: a
  panic while holding the front ticket would otherwise wedge the lane until
  daemon restart.
- **A stale or unknown ticket fails open** — the engine's gate is the real
  authority, so the worst case is one redundant delivery attempt.
- **Report a failure once.** `DeliveryOutcome::Executed(_)` means the run's own
  emitter already sent a `RunError`; only the never-ran outcomes are the
  caller's to report.

**The wire representation of waiting.** Before this was wired, a queued run
emitted nothing at all between `chat.send` returning its id and `RunAccepted`
— every client painted "thinking" over a run the engine had never heard of,
for as long as `busy_queue_max_wait_secs`. Waiting now has two halves, split
the same way `agent_trace` (lossy live mirror) and `RunSummary` (authority)
already are: the live half is the best-effort `StreamEvent::RunQueued{run_id,
session_key, ahead}`; the authoritative half is `chat.history`'s `pending[]`
array (`aleph_protocol::queue::PendingRun`), which carries the lane
truthfully — but **no client renders it today**. `active_run` and `pending[]`
are disjoint by construction: `try_claim` calls `busy_queue::mark_admitted`
in the same step that populates `active_run`, which withdraws the ticket
from the lane, so a run that is `active_run` has already left `pending[]`,
and a run still in `pending[]` is never `active_run`. A returning client has
no way to identify which queued entry (if any) is its own from `pending[]`
alone, either — the entries carry neither an author nor the message payload
(deliberate non-goals, see the design doc's §7). The live
`StreamEvent::RunQueued` frame is currently the only representation of a
user's own wait that any client renders; wiring an attach-time renderer for
`pending[]` is a decision recorded separately, not yet made. `ahead` comes
from `TicketGuard::ahead()`, which counts the same way `snapshot()`'s
`total_waiting` contract does — a cancelled ticket ahead of you is not a wait
— and fails **open** to `0` once the ticket has left the lane (withdrawn by
`mark_admitted`, dropped, or garbage-collected). `0` renders as "about to
start", and whichever terminal frame arrives next (`RunAccepted` or
`RunError`) overwrites it, so a stale open answer costs one frame, never a
stuck UI.

**Why position is self-reported by the waiter, not broadcast or polled.** The
production point is the wait loop itself: `report(ahead)` is called from
`deliver_with_ticket`, immediately before it parks — not from inside the
"not front" branch. That distinction is deliberate: a front ticket refused
for steering backpressure (`attempt()` returning `AgentBusy` at
`max_pending_steering`) is waiting too, and it is the one wait that otherwise
has no representation anywhere; reporting only from the not-front branch would
miss it. Two alternatives were rejected. The lane broadcasting positions to
every waiter would require the process-global lane table
(`static LANES: OnceLock<Mutex<HashMap<..>>>`) to hold emitters — a
responsibility that table does not have today and should not gain. The client
polling `chat.pending` would reintroduce a poll this gateway already removed
once, when Round-5 of the busy-input work converted queue visibility from
polling to event-driven delivery; bringing it back would undo that round.
`report` is `async` and awaited inline rather than a callback that spawns:
`ahead` only decreases, and spawning would abandon that ordering, letting two
rapid updates land inverted and flicker the number a user is reading.
Reporting is deduplicated — `report` fires only when `ahead` actually changes
— so an idle session that is never made to wait sees none of this: it takes
the front of its lane on the first attempt and the function returns before the
report point is ever reached.

Stopping has two granularities: `/stop` purges the whole session lane
(`busy_queue::purge`, wired only in `command_handler::handle_stop` — the
`Interrupt` mode depends on the lane to restart its own message, so
`cancel_session` must not purge), while `chat.abort` reaches a single queued
message by `run_id` (`busy_queue::cancel_queued_run`, wired in
`AgentRunManager::cancel_run` — a queued run has no `active_runs` entry, so the
engine's own cancel cannot see it).

Knobs live in `[execution]`: `busy_queue_max_per_session` (32),
`busy_queue_max_wait_secs` (1800), `busy_queue_wake_fallback_secs` (30),
`max_pending_steering` (16). Backlog is observable via
`gateway.metrics.run_concurrency` → `busy_queue`.

### A side question gets its own lane, and the arrival layers must agree

`/btw <question>` runs as an ordinary turn on a session **derived** from the
conversation it was typed in, so that it can be answered while the main run
keeps going. That promise is entirely a routing property, and routing it is not
one chokepoint — it is **one writer plus one query**, because the lane is
claimed before the engine is ever entered.

**The writer** is `execution_engine::stamp_btw`
(`execution_engine/slash_command.rs:67`) — parser-free, idempotent, and the only
thing that ever sets `btw::BTW_METADATA_KEY`. It runs at three places, all of
them *before* the busy lane: the inbound router's execute path
(`inbound_router/executor.rs:451`), inside `stamp_slash_mode`
(`slash_command.rs:98`, whose first statement it is) which the `agent.run` and
`chat.send` run-start handlers call before `busy_queue::spawn_queued_run`
(`src/bin/aleph-server/server_init.rs:272,466`; the guard
`every_run_start_handler_stamps_the_slash_mode_before_the_busy_lane` is phrased
over that file's handlers and inherits nothing outside it), and as the first
statement of `ExecutionEngine::execute` (`execution_engine/execute.rs:375`).

*Stamped after the lane gate, every `/btw` sent during a run is folded into that
run as steering text* — `steering::carries_more_than_text` reads the same key to
decide that a message must be redelivered as its own run rather than injected
into a running sibling.

**The query** is `btw::execution_session(addressed_to, metadata)`
(`gateway/btw/mod.rs:142`), deliberately a query and not a mutation, because two
layers that are not adjacent both need the answer:

- `busy_queue::register_run` (`busy_queue/mod.rs:238`) keys the lane on it, so a
  side question waits in its own lane rather than behind the very run it is
  asking about;
- `ExecutionEngine::execute`'s `redirect_to_side_session`
  (`execute.rs:98`, called at `:381`) moves the request onto the derived key
  **before `admit_run`** (`:458`), so the engine's per-session slot claim and the
  busy-input policy both see the side session.

Asking twice is free; *writing* twice would derive the side key of the side key
and land the run where neither layer named. The idempotence is
`btw::is_side_key` (`btw/mod.rs:203`), and it is load-bearing beyond the two
arrival layers: `steering::build_steering_rescue_request` re-enters `execute()`
with the metadata *and* the already-derived key cloned, so a completed side
question with an unanswered steering burst is a third ask.

Channels reach that path through an explicit claim at
`inbound_router/mod.rs:872`, placed **above** the unified slash interception and
keeping both things the turn needs — the `/btw` prefix (so `stamp_btw` fires) and
the conversation's own session key (so `execution_session` has something to
derive from). It has to be a claim rather than a fall-through because both paths
below it are wrong in their own way: the unified interception routes anything the
shared `CommandParser` resolves into the engine's slash fast path, which
dispatches on the raw `ToolRegistry` and never builds the `ScopedToolService` the
read-only ceiling lives in; and anything it does *not* resolve reaches
`try_send_unknown_command_help`, which answers "did you mean …?" and returns
without running the agent — `suggest_commands("btw", 3)` returns
`["session_new"]` today (alias `new`, edit distance 2), so the fall-through is
broken now, not latently.

`/stop` in the main conversation reaches the side question too:
`ExecutionEngine::cancel_session` (`execution_engine/engine.rs:549`) walks
`btw::side_session_of` (`:557`), which returns `None` for an already-derived key
so the walk is one level deep by construction. Full account, including the
read-only ceiling and the retirement surfaces, in
[FEATURE_LOCATOR §4.14](FEATURE_LOCATOR.md#414-btw-侧问派生的只读侧会话-side-questions--2026-08-20).

## Many clients, one thread

A session key names a **conversation**, not a viewer. Any number of clients can
be watching the same one — two Panel tabs, a Panel and the TUI, every member of
a project room, plus whatever channel or cron job started the turn. There is no
`attach` verb and deliberately none: delivery is `topic + per-connection
visibility projection`, and an attachment table would be a second source of
truth for a question `event_visibility` already answers. What that model owes
its clients instead is two things, both of which were missing until 2026-08-10
(full account in [FEATURE_LOCATOR §6.9](FEATURE_LOCATOR.md#69-多端共享一条线程--重连与崩溃后的状态重建-multi-client-thread-sharing--post-reconnect-state-rebuild)):

- **Every frame must carry enough identity to be routed by a client that did
  not start the run.** `RunAccepted` has always carried `session_key`; what was
  missing was a client using it instead of guessing "the conversation in front
  of the user". A frame that names a session no local view is showing must be
  **dropped**, never redirected.
- **A cache of that projection needs a verb that invalidates it, and that verb
  needs a caller.** `session_admits` caches the `(owner_user_id, scope_id)`
  pair per session key — fill-on-miss, process-lifetime, bounded FIFO, no TTL,
  one `Arc` shared by every connection. Caching the **pair of facts** rather
  than a per-caller verdict is deliberate (a cached verdict has nothing to
  invalidate, and P2's "removing a member takes effect immediately" would
  quietly become a lie). But exactly one verb rewrites that pair —
  `SessionStore::rescope_attribution`, the single exception to spec §10's
  scope immutability, used by `projects.channel.bind` — and until 2026-09-03
  `EventVisibilityIndex::forget_session` had **zero callers**, so after a bind
  the live frames of the newly-shared conversation were refused to every other
  member of the roster, permanently, while both halves looked implemented. The
  invalidation now runs inside the bind's rescope loop, **after** each write and
  for **every** key moved; three mutations (drop it, move it above the write,
  apply it to the first key only) each redden exactly one test, so the ordering
  and the "every key" are falsified rather than argued. Its twin `forget_team`
  was CUT rather than wired — a zero-consumer channel is cheaper to delete than
  to connect. ⚠️ Still open: nothing in source forces a future second writer of
  that pair to call it.
- **A client joining mid-turn needs a pointer to the turn in flight.**
  `chat.history` answers it: the response carries `active_run` — the run id
  currently claiming this session's slot in the `SessionRunRegistry`, or `null`.
  It rides on that response rather than a method of its own so the transcript
  and the live pointer are one snapshot, and so it inherits the visibility gate
  `handle_history` has already passed instead of opening a second one. Sourced
  through `ExecutionAdapter::active_run_for_session` (default `None`), because
  the registry is the only table that sees runs from *every* interface —
  `AgentRunManager::active_runs` holds Panel-started runs only.

**Turn-end announcements go out on both terminal arms.** `SessionUpdated` is
what every other surface re-hydrates on, and a run that failed, timed out or
was cancelled still moved the transcript (the harness appends the user message
*before* dispatch). `ExecutionEngine::announce_turn_end` is the single
derivation both arms of `execute()` call; a source-level guard pins that the
failure path is one of them.

## Session Routing

**Location**: `src/routing/session_key.rs`

### Session Key Variants

| Variant | Format | Use Case |
|---------|--------|----------|
| **Main** | `agent:main:main` | Cross-channel shared session |
| **DirectMessage** | `agent:main:telegram:dm:user123` | Per-user DM |
| **Group** | `agent:main:discord:group:guild-id` | Group/channel chat |
| **Task** | `agent:main:cron:daily-summary` | Cron jobs, webhooks |
| **Subagent** | `subagent:agent:main:translator` | Sub-agent delegation |
| **Ephemeral** | `agent:main:ephemeral:uuid` | Temporary, no persistence |

### DM Scope Strategies

```rust
pub enum DmScope {
    Main,           // All DMs share main session
    PerPeer,        // Isolated per user (default)
    PerChannelPeer, // Isolated per channel + user
}
```

---

## Session Manager

**Location**: `src/gateway/session_manager/` (a directory, not the single
`session_manager.rs` this line used to name).

### Storage Schema

Abridged from `session_manager/mod.rs`; that file is the source, this is the
shape. There is no `messages TEXT` JSON column and no `session_metadata`
table — both were in this document long after they stopped existing.

```sql
CREATE TABLE sessions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    key            TEXT UNIQUE NOT NULL,
    agent_id       TEXT NOT NULL,
    session_type   TEXT NOT NULL,
    created_at     INTEGER NOT NULL,
    last_active_at INTEGER NOT NULL,
    message_count  INTEGER DEFAULT 0,
    total_tokens   INTEGER DEFAULT 0,
    state          TEXT DEFAULT 'created',
    metadata       TEXT,      -- JSON: identity_meta, knobs, owner/scope
    label          TEXT,
    model          TEXT,
    model_provider TEXT
    -- plus auto_reset_at, input_tokens, output_tokens
);

CREATE TABLE messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_key TEXT NOT NULL,
    role        TEXT NOT NULL,
    content     TEXT NOT NULL,
    timestamp   INTEGER NOT NULL,
    metadata    TEXT,
    source_seq  INTEGER,      -- the `session_events.seq` this row came from
    FOREIGN KEY (session_key) REFERENCES sessions(key) ON DELETE CASCADE
);
```

### `messages` is a projection, not a source

The SSOT is `session_events` ([SESSION_SERVICE.md](SESSION_SERVICE.md)).
`MessageProjector` (`src/gateway/session_projector.rs`) is, since 2026-09-13,
the table's **only production writer** — pinned by
`session_projector::tests::the_projector_is_the_only_production_writer_of_the_messages_table`
— and it is asynchronous: an append lands in the log first and reaches the
transcript on a per-session drain. The two direct writers that used to bypass
the log (`AgentInstance::add_message`, the boot orphan notice) are gone (T17,
T16); rows they left carry a NULL `source_seq`, which `map_message_row`
(`src/gateway/session_manager/ops/crud.rs`) reads back as "not event-sourced,
leave it alone", keeping them out of the projection's seq-set arithmetic.

The projection is **self-healing, never lossy**. Back-pressure or a stopped
drain records the event's `seq` in `missed` (the payload is already durable in
the SSOT) and a later heal re-reads it; a heal is a **seq-set difference**
against the rows the transcript already has, so a hole *below* the newest row
is filled too — before 2026-09-02 a watermark suppressed everything at or
under `max(seq)` and those holes were permanent. `missed` is process memory,
so a crash between an append and its drain is repaired at the NEXT boot:
`ProjectionReconciler` repairs every session in the activity window
(`[resume] max_age_secs`) plus every session whose markers read as
interrupted, and the `core/projection-holes` doctor check does the unbounded
sweep for anything older. `RunMeta` is stamped onto the last assistant row
**in the run's seq range** (not by position) and bills usage once, so a replay
cannot charge a run twice.

⚠️ One consequence is recorded and unfixed: a healed row is a fresh INSERT, so
its `AUTOINCREMENT id` sorts it at the **tail** of the transcript rather than
at its `seq` position — and `id` is the authoritative transcript order
([FEATURE_LOCATOR](FEATURE_LOCATOR.md) §6.9 round-8 · 附录 D.4.38).

### Compaction

When session exceeds token threshold:

1. Extract key facts from old messages
2. Store facts in memory system
3. Replace old messages with summary
4. Update token count

---

## Security

**Network boundary + Gateway token**: the trust boundary is the network
boundary, gated by a Gateway-token login wall. The default bind is
`127.0.0.1` (loopback only); loopback is the zero-config operator and needs
no token. Set `[gateway] host = "0.0.0.0"` to open the LAN — a remote device
can then reach the socket but is **walled until it presents a valid
credential** at `connect`. Authorization is resolved by
`connect::resolve_connect_auth` in priority order: (1) loopback ⇒ operator;
(2) a valid **device token** (`aleph-dt-*`, long-lived, bound to a paired
device, SHA-256-hashed at rest); (3) a valid **bootstrap ticket**
(`aleph-bt-*`, 5-min single-use, exchanged for a fresh device token during
onboarding); (4) the legacy shared **Gateway token** (`aleph-<uuid>`,
`SharedTokenManager`, HMAC-hashed, constant-time verified). A valid
credential = full operator authority (identical to local); a missing/invalid
one is walled — the WS dispatch refuses every method but `connect`.
Revocation has three granularities, all effective immediately rather than at
the next handshake: token rotation (`gateway.token.rotate`, which also
force-closes live remote sockets), per-device revoke (`gateway.devices.revoke`,
which drops that device's live sessions to the login wall and then closes their
sockets with WS 4001 `device_revoked`), and — since 2026-09-03 —
`gateway.ticket.revoke` for a still-redeemable **bootstrap ticket**, listed by
`gateway.ticket.list` and addressed by a non-secret `ticket_id` the listing
returns instead of the code. That third one exists because rotation does not
reach it: an unredeemed ticket is not a remote yet, so "revoke all remotes"
left it fully redeemable, and minting had two faces while cancelling had none.
Client: `aleph-server pair --list` / `--revoke` (no Panel face yet). The WS
Origin check (`src/gateway/origin_policy.rs`) additionally blocks public web
pages from cross-origin-driving the local daemon. See
[SECURITY.md#auth-ux](SECURITY.md#auth-ux) for the full model.

### Connect handshake

The first frame on a `/ws` connection must be `connect`. Loopback carries no
credential (zero-config operator). A remote connection presents one of
`device_token`, `bootstrap_ticket`, or `token` (the legacy shared Gateway
token) in `connect` params; `resolve_connect_auth`
(`src/gateway/handlers/connect.rs`) stamps the resolved role (`operator` when
authorized, else `guest`) onto the connection state, and the response echoes
`role` / `authorized` / `needs_token`. A bootstrap-ticket exchange also
returns a freshly minted `device_token` the client persists for subsequent
reconnects. A rejected remote `connect` is recorded in the security audit log
(`AuditEventType::AuthFailure`, bounded by the `Auth`-scope rate limiter).

```json
{
  "method": "connect",
  "params": {
    "minProtocol": 1,
    "maxProtocol": 1,
    "client": {
      "id": "macos-app",
      "version": "1.0.0",
      "platform": "macos"
    },
    "device_token": "aleph-dt-…",
    "bootstrap_ticket": "aleph-bt-…"
  }
}
```

> Loopback clients omit the credential fields entirely. A remote client sends
> `bootstrap_ticket` on first pairing (receiving a `device_token` back), then
> `device_token` on every reconnect. `token` (the legacy shared Gateway token)
> is accepted as a fallback.
>
> `device_id` is **client-asserted** and the `devices` table is one namespace
> shared with cluster nodes, so the exchange refuses a `device_id` that already
> names a non-Panel device (and `cluster::admit_node` refuses the mirror case).
> Without that guard one ticket buys an operator token the Panel roster cannot
> see and no revoke path can reach.

---

## Hot Reload

**Location**: `src/gateway/hot_reload.rs`

Configuration changes are detected via file watcher:

```
~/.aleph/config.json modified
    │
    ▼
┌─────────────────────────────────┐
│ Debounce (500ms)                │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ Parse new config                │
│ Validate against schema         │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ Apply changes                   │
│ • Restart affected interfaces    │
│ • Update routing rules          │
│ • Emit config.changed event     │
└─────────────────────────────────┘
```

---

## HTTP Server

**Location**: `src/gateway/http_server.rs`

Alongside WebSocket, Gateway serves:
- Static files (WebChat UI)
- Liveness probe (`/health`) and readiness probe (`/ready`)
- Metrics endpoint (`/metrics`) — Prometheus text exposition (v0.0.4) of
  request-lifecycle counters, connection gauges, rate-limiter pressure, and a
  request-duration histogram (`aleph_gateway_request_duration_ms`, fed by the
  per-request `elapsed_ms` the metrics middleware already measures); exports
  only aggregate counts (no payloads/secrets), unauthenticated like the probes.
  Implemented in `src/gateway/server/metrics_endpoint.rs` +
  `src/gateway/middleware/latency.rs`.
- MCP server face (`POST/GET/DELETE /mcp`, Streamable HTTP) — Aleph as an MCP
  *server* for dsh / pi-mcp-adapter / Claude Code: `tools/list` + `tools/call`
  over the same scoped dispatch a chat turn uses, whitelist from
  `[mcp_server].expose`, loopback free / remote bearer (device or gateway
  token), `notifications/tools/list_changed` on plugin transitions. Implemented
  in `src/gateway/mcp_face/`; real-machine `qa/mcp_face/run.sh`.

Abuse protection at WS upgrade: besides the global `max_connections` cap, a
per-IP concurrent-connection cap (`gateway.max_connections_per_ip`, default 64,
`0` disables, loopback exempt) bounds slot-exhaustion — a remote peer
opening many idle sockets.

### `[gateway.rate_limit]` — the per-principal ceilings, from the operator's side

The rate limiter has keyed off the **principal** rather than the socket since
2026-08-21 (`rate_limit_identity()`: loopback ⇒ `127.0.0.1`, authenticated ⇒
`user:<id>`), and until 2026-09-03 every production construction site still
passed `RateLimitConfig::default()` — no config section, no setter, so an
operator could neither read the ceilings nor change them, while the defaults'
own comment recorded that those numbers had already needed changing once.

`[gateway.rate_limit]` now carries a window (`max_requests` +
`window_secs`) per scope plus `lockout_secs`. Three properties are load-bearing:

- **The numbers live in exactly one place.** The TOML schema's fields are all
  optional and its `Default` does **not** replay the table — an omitted key
  falls through to `RateLimitConfig::default()`, which stays the only statement
  of what the defaults are. Replaying them in the schema would be a second
  spelling that drifts silently.
- **`lockout_secs = 0` disables the lockout.** The runtime carries
  `Option<u64>` and TOML has no null, so without this spelling an operator could
  only lengthen auth's five-minute lockout, never remove it.
- **Restart-only, and it says so in its own doc.** The section is not
  `ConfigPatcher`-reachable. Placing it under `[policies]` would make it
  live-appliable and is the recorded alternative — a design change, not an
  extension.

Two limits carried deliberately. There is **no read face**: an operator can set
the ceilings but still cannot ask a running server what they are. And `Auth` and
`WebhookAuth` share one window (`RateLimitConfig::config_for` fans both into
`auth`), so writing `[gateway.rate_limit.auth]` retunes webhook auth too and
nothing says so — unchanged behaviour, but the section makes it visible for the
first time.

### Reverse proxies (opt-in `X-Forwarded-For` resolution)

The IP-keyed abuse protections (per-IP connection cap, rate limiter, `Auth`-scope
lockout) key off the **raw socket peer address** by default. `X-Forwarded-For`
honoring is opt-in via `[gateway.trusted_proxy] enabled = true` and the
companion `trusted_ips` allowlist in `src/gateway/trusted_proxy.rs`.

**Operators must NEVER include `127.0.0.1` / `::1` in `trusted_ips`.** The
loopback check is the zero-config-operator grant, and an XFF forwarded from
a loopback peer must not be allowed to satisfy it — a malicious client on
the loopback interface would otherwise be indistinguishable from the
operator. When `enabled = false` (the default) the resolver is a no-op and
every per-IP check sees the raw peer.

**Two identities, and they answer different questions.** `ResolvedClient`
carries `ip` *and* `local`:

- `ip` is the **bucketing / audit** identity: which per-IP bucket a connection
  belongs to for the connection cap, the rate limiter and the security audit
  log.
- `local` is the **authority** bit — `peer.is_loopback() && !via a trusted proxy
  hop` — and it is what every privilege decision reads: the insecure-transport
  gate, the per-IP exemption, `ChannelClass`, `SurfaceKind`, the three
  connect-auth call sites, the rotation kick, and `ConnectionState::new`'s
  initial `caller_role`.

⚠️ Until 2026-08-29 there was only `ip`, and `resolve_client` fell back to the
peer address when `X-Forwarded-For` was **absent**. In the deployment this
section documents — Aleph on `127.0.0.1`, a same-host proxy, `trusted_ips`
defaulting to loopback — that fallback address *is* loopback. A reverse-proxy
config that simply omits `proxy_set_header X-Forwarded-For` (nginx does not add
it unless told to) therefore handed **every internet client, presenting no
credential at all**, the zero-config operator grant. `local` is a parameter
everywhere it is consumed rather than a predicate each site re-derives, so a
consumer that forgets it is a compile error; the tenth consumer,
`ConnectionState::new`, was missed by the first pass precisely because it
re-derived instead of reading.

The trade-off: when the gateway is fronted by a reverse proxy, every client
collapses to the proxy's socket address, so the per-IP protections bound the
*proxy* rather than individual clients. Terminate client-identity trust
upstream (the proxy) if you need per-client limits, and treat the Gateway
token as the transport auth.

### Method-level authorization

The connection-level barrier is the **login wall**: a remote connection that has
not presented a valid Gateway credential is `guest` and may only issue `connect`
(§Connect handshake). Once authorized it is `operator`, identical to local —
there is no finer per-RPC operator-vs-guest tier on the Panel surface. A separate
classifier survives at the *channel* tool-dispatch tier
(`src/gateway/method_authz.rs`, consumed by `ScopedToolService`): the
`inbound_router` caps a chat-tier channel (Telegram/Slack, default `guest`) so it
cannot run Aleph's self-config tools. Limiting *what an agent may do* (vs *who may
connect*) is the job of the per-channel tool-permission layer, orthogonal to
connection trust.

### Distributed-trace correlation

Each JSON-RPC request resolves a [W3C `traceparent`](https://www.w3.org/TR/trace-context/):
an inbound `params.traceparent` is honoured (its trace id adopted), otherwise a
fresh 128-bit root trace is minted. The dispatch chokepoint opens a `tracing`
span carrying `trace_id`/`span_id`, and the response echoes a `traceparent`
naming the server's span as the parent so a multi-hop call graph stitches
together. This is a lightweight propagation layer (`src/gateway/trace_context.rs`),
**not** an OpenTelemetry integration — the OTel SDK would violate core
minimalism (R3) for what is, given Aleph's own trace persistence and `tracing`
logging, a correlation feature.

> Note: the JSON-RPC middleware chain is built once at server construction and
> cloned per connection. Building it per-connection previously reinstalled the
> global request-state registry on every connect, zeroing the `/metrics`
> request-lifecycle counters and undercounting in-flight requests.

### Channel webhook ingestion

Channels that receive over HTTP POST (`generic webhook`, and future ones)
return a handler from `Channel::webhook_handler()`. `build_router()` registers
**one constant route** — `POST /webhook/{*rest}` — whose state is the shared
`WebhookMountTable`. `ChannelRegistry` owns that table and is its only writer.

- **Mounting follows the registry, not boot.** `start_channel` /
  `restart_channel` mount; `stop_channel` / `unregister` / `register` /
  `create_channel` unmount. So `channel.stop` and `channel.delete` really do
  remove the endpoint (404, not 503), and a channel created at runtime is
  reachable without restarting the daemon. The earlier version built the route
  table once at boot: `stop` returned `"stopped"` while the endpoint kept
  answering 200 and driving agent runs, because the route held its own
  `Arc<Handler>` clone. The forwarder never exiting has a separate,
  mount-independent cause: the forwarder task captures a `channel_arc` clone
  by move and holds it for its entire — infinite — lifetime
  (`channel_registry.rs` `start_message_forwarder`). That keeps the channel
  instance alive, which keeps `ChannelState`'s original `Sender` alive, so
  `RecvError::Closed` is structurally unreachable for any started channel,
  whether or not a mount exists.
- **⚠️ `restart_channel` does not go through `stop_channel`/`start_channel`.**
  It calls `channel.stop()` + `channel.start()` directly, so it carries its own
  mount refresh. A hook set that only covers start/stop leaves the pre-restart
  handler clone in the table forever.
- **`path` must be under `/webhook/`**, enforced by
  `WebhookChannelConfig::validate()` and again by `WebhookMountTable::mount()`
  (one predicate, `is_mountable_path`). Because operator-writable paths never
  enter axum's route table, a bad path can no longer panic `Router::merge` at
  boot, and can no longer shadow a Panel SPA path (`path = "/settings"` used to
  turn `GET /settings` into 405). `RESERVED_ROUTE_PREFIXES` existed only to
  guard that boot panic and was withdrawn with it.
- **⚠️ matchit does not panic on `/webhook/foo` next to `/webhook/{*rest}`** —
  the more specific static route just wins. A future gateway route under this
  prefix would therefore *silently* steal a channel's webhook path. The guard
  is a source scan in `server/mod.rs`'s own tests
  (`build_router_registers_no_second_route_under_the_webhook_prefix`); axum
  cannot be asked what is in its route table.
- **Two channels, one path** → the lower `channel_id` keeps the route, warned
  with both ids. Deterministic on purpose: `start_all` iterates a HashMap, so
  arrival order would make route ownership a per-boot coin flip. The loser is
  only warned — it still reports `Connected` in `channels.list` while being
  deaf, and the `channel.start` RPC still answers `{"status":"started"}`:
  `mount()`'s refusal `bool` is discarded at both call sites, so the operator
  sees the `warn!` naming both ids but the RPC caller is told nothing. For
  that one case this is a small step backwards from the deleted
  `"restart_required"` receipt. Recorded limit, not a fix — threading the
  refusal into the receipt changes an RPC response shape and needs its own
  round.
- **One port.** Webhook traffic rides the gateway's own listener, so it
  inherits `[gateway] host`, TLS, and `SecurityHeadersLayer`. `WebhookReceiver`
  deliberately owns no listener — the version that bound `0.0.0.0` itself would
  have opened a LAN surface regardless of the configured host.
- **Auth is per-handler HMAC**, not the login wall — an external platform
  cannot present a device token. Same posture as `/health`, `/metrics`, `/a2a`:
  no transport-level auth, no rate limiter (that lives in `MiddlewareChain`,
  on the JSON-RPC/WS path only). The signature also binds no timestamp or
  nonce (unlike Stripe/GitHub's `t=…,v1=…`), so replay protection is
  incidental — it comes only from inbound dedup at
  `src/gateway/inbound_router/dedup.rs`, whose window is **5 minutes**; a
  captured signed request replayed after that re-triggers an agent run. This
  is posture, not a known gap requiring action.
- **Check order is deliberate**: lookup → 404, signature → 403, channel status
  → 503, then parse and forward. Signature comes *before* status so an
  unauthenticated caller learns only whether a mount exists at that path,
  never the mounted channel's status.
  The status check is depth only, for a channel that moved itself to
  `Error`/`Connecting` without any RPC; `try_read` fails **open** on
  contention, because a momentary write-lock holder is not evidence the
  channel is down.
- ⚠️ The sink is the channel's **own** `ChannelState::sender()`, not the
  registry's. Going direct to the registry bypasses
  `start_message_forwarder`, the only place inbound traffic stamps
  `health.record_event()` — the channel would receive while health monitoring
  reported it dead.

---

### MCP 面（`src/gateway/mcp_face/`，2026-09-20）

Aleph 对外**是一个 MCP server**：dsh 一行 `cordis.yml`、pi 一行 `pi-mcp-adapter` 配置、Claude Code 一行
`.mcp.json`（`type: http`）都能挂上，零专属代码。**客户端侧的接法只写一份**：`packages/pi-aleph/README.md`——
一个 JS-free 的 pi 包（`package.json#pi = { skills, mcp }` + `mcp.json` + `skills/aleph/SKILL.md`），README 同时给出
pi（经 pi-mcp-adapter）、Claude Code `.mcp.json`（`type: http`）与 dsh `cordis.yml` 的三行配置；本节不抄那三行。设计母本：spec
`docs/superpowers/specs/2026-09-20-plugin-scope-and-cc-compat-design.md` §3.7。它是一张**接口脸**（R4：
纯 I/O），把 `tools/call` 翻成 Aleph 自己的工具调用路径；**wire 类型复用 `src/mcp/{jsonrpc,protocol,types}.rs`，
信封复用网关自己的 `protocol::JsonRpc{Request,Response}`（客户端侧的 `mcp/jsonrpc.rs` 的 id 是 `u64`，回不了字符串 id），不复制**（CLAUDE.md 禁用清单 2026-09-20 那一行）。

| 项 | 决定 |
|---|---|
| 传输 | **只做 Streamable HTTP**，挂网关已有 HTTP 监听的 `/mcp`：`POST /mcp`（JSON-RPC，一请求一响应；通知 → `202`）+ `GET /mcp`（SSE 通知流）+ `DELETE /mcp`（结束 session）+ `Mcp-Session-Id` 头。**stdio 刻意不做**——宿主 spawn 第二个 `aleph-server` 会撞单例 flock（PROCESS_MANAGEMENT.md）；legacy SSE 传输 dsh 不支持 |
| 协议版本 | 协商：客户端提出的版本在支持集内则接受，否则回**最新**（`2025-11-25`）由客户端决定。支持集 `SUPPORTED_PROTOCOL_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26"]`（最老的一个就是客户端栈自己的 `MCP_LEGACY_PROTOCOL_VERSION`；pi-mcp-adapter 默认 `2025-03-26`）。`src/mcp/modern/` 的 `2026-07-28` 是**无握手、无 session** 的方言（`server/discover` + 每请求 `_meta`），这一面**不说它**——`server/discover` 答 `-32601`，adapter 的 `auto` 探测会退回 `initialize` |
| 能力 | 只宣告 `tools: { listChanged: true }` + 短 `instructions`；prompts / resources / sampling / elicitation / roots / tasks **不做**（YAGNI） |
| 认证与护栏 | **复用 `connect` 那一份**（上文「Connect handshake」），逐请求判：loopback 免凭据；远程须 `Authorization: Bearer <token>`（device token / 共享 token），dsh 与 adapter 都是静态 `headers`——无凭据或坏凭据 → **401**（`WWW-Authenticate: Bearer realm="aleph"`）。`/ws` 的三道护栏原样复用：明文远程且未放行 → **426**；Origin 不允许 → **403**；`local` 位来自 `trusted_proxy::resolve_client`，**不是** `ip.is_loopback()`。远程 `POST /mcp` 另有一个私有限流桶：`MCP_REMOTE_POSTS_PER_MINUTE = 120`，超出 → **429** + `Retry-After`，loopback 免（形状同 artifact 路由的桶） |
| 暴露 | `[mcp_server] enabled = true / expose = ["…"]`（`McpServerConfig`）。`expose` 是白名单，**默认集合＝按谓词从工具目录挑出的无副作用工具，再按名字减去 `DEFAULT_EXPOSE_EXCLUDES`**（`tool_usage` / `config_audit` / `node_list` / `user_profile`，每条带理由）——结果是 **36 个名字**，由 P6.1 的逐名测试钉住（数字带谓词：`3ddc1f2e7` 的工具目录；目录变了先红的是那条测试，不是这句）；`bash` / 文件写 / 浏览器须显式加入。启动时校验 `expose ⊆ 工具目录`（守卫 G5：写一个不存在的工具名 → 红 + boot warn）。**`expose` 改动即时生效**（`mcp_server.expose` 在 `LIVE_SUBSECTIONS` 里，面上一份 `ArcSwap<BTreeSet<String>>`），重跑 G5 校验后向每条活着的 session 广播 `list_changed`；**`enabled` 仍是 `Restart`**——开关这张脸要重启 |
| 会话 / principal | 每个 MCP session ↔ 一个 Aleph 会话；principal `McpClient { client_name }`（来自 `initialize.clientInfo.name`）。调用走**同一条** scoped dispatch（审批门 + spend ledger + hooks）——不是第二条执行路径 |
| 审批 | 「有没有 operator 能答」是**连接表**上的事实：`McpFace` 每次调用问 `OperatorPresence` 探针（`GatewayServer::operator_presence_probe()`），派发时 `unattended = !present`——无 operator 界面时 confirm 门**立刻** fail-closed，结果 `isError: true`，文本末尾附 `MCP_APPROVAL_HINT`（告诉对端模型卡本会去哪、怎么开）。⚠️ 这一步**不是** `OperatorApprovalRequester` 的「零订阅者即拒绝」——boot 给事件总线挂了内部消费者，那条臂在真服务器上**永远不触发**（FL 附录 D.0.199）。**有 operator 在线时**：卡按现有审批流升起，**没有死线**（2026-08-28 裁定），MCP 客户端那边等的是它自己的超时（dsh 60 s / adapter 30 s）；客户端放弃后卡**仍挂在 Panel 上**——用户裁定接受这个形状（U-d），「handler future 掉落时收回卡」记为 follow-up，未建 |
| 错误形状 | 工具执行错误 → `isError: true` 的结果（**不是**协议错误）；不在 `expose` → tool not found；body 不是 JSON-RPC → 400 + JSON-RPC error body；非 `initialize` 请求缺 session 头 → 400；未知 / 过期 session → 404 |
| 通知 | 插件 mount/unmount/reload（`lifecycle.rs::after_transition` 里的 `if let Some(face) = try_mcp_face() { face.notify_tools_list_changed() }`，G3 钉住这个调用点）与 `expose` 变更 → 向每条活着的 MCP session 广播 `notifications/tools/list_changed`。进程级句柄 `try_mcp_face() -> Option<&'static Arc<McpFace>>`（同 spend 的 `install_ledger` 形状，FL §5.25）让 lifecycle 不必穿 7 个构造点 |
| 名字 | Aleph 工具名已是 `[a-z0-9_]`，满足 dsh 的 64 字符规则（dsh 侧展示为 `mcp__<server>__<tool>`）；P6 逐名验证无超长名 |

**有 operator 在线时的审批卡是「挂着的」，这是接受下来的形状（用户裁定 2026-09-20，U-d）。** 一个需要确认的
`tools/call` 在 Panel 上升起一张没有死线的卡（2026-08-28 裁定：审批不超时）；MCP 客户端那边等的是**它自己的**超时
（dsh 60 s、pi-mcp-adapter 30 s），到点后客户端把这次调用当失败，而卡**仍挂在 Panel 上**——operator 点批准时，那个
`tools/call` 的 handler future 早已被丢弃，批准落在一个没有人在等的动作上。两种后果都比它们的替代品便宜：立刻拒绝
会把每一个 attended 调用变成 unattended（那正是 `deny` 阶段要证的另一臂），给卡加死线会推翻 08-28 的裁定。
「handler future 掉落时收回卡」记为 follow-up，未建；在那之前，Panel 上一张来自 `McpClient` 的旧卡读作
「对端已经放弃了」，不是「还在等」。

真机：`qa/mcp_face/run.sh {handshake,tools,auth,list_changed,deny}`——每阶段证明什么见
[`qa/README.md`](../../qa/README.md)。

---
## See Also

- [Architecture](ARCHITECTURE.md) - System overview
- [Agent System](AGENT_SYSTEM.md) - Agent loop
- [Security](SECURITY.md) - Exec approval system
