// API layer for Gateway RPC methods
// Provides type-safe interfaces for interacting with the Gateway

// Existing submodules
pub mod agents;
pub mod chat;
pub mod cron;
pub mod heartbeat;
pub mod tool_permissions;

// Graph visualization
pub mod graph;

// Cluster API
pub mod cluster;

// Split submodules
pub mod acp;
pub mod agent_binding;
pub mod artifacts;
pub mod browser;
pub mod browser_viewer;
pub mod canvas;
pub mod clarification;
pub mod config;
pub mod discord;
pub mod embedding;
pub mod exec_approval;
pub mod exec_grants;
pub mod extensions;
pub mod fetch;
pub mod fs;
pub mod generation_providers;
pub mod kanban;
pub mod logs;
pub mod mcp;
pub mod memory;
pub mod memory_config;
pub mod moa;
pub mod native_credentials;
pub mod projects;
pub mod providers;
pub mod routing;
pub mod runtime_agents;
pub mod runtimes;
pub mod search;
pub mod security;
pub mod sessions;
pub mod settings;
pub mod system;
pub mod team_chat;
pub mod teams;
pub mod telecom_approval;
pub mod trace;
pub mod users;
pub mod workspace;

// Re-export all public types for backward compatibility (crate::api::Foo)
pub use acp::*;
pub use agent_binding::*;
pub use browser::*;
pub use browser_viewer::*;
pub use clarification::*;
pub use config::*;
pub use discord::*;
pub use embedding::*;
pub use exec_approval::*;
pub use exec_grants::*;
pub use extensions::*;
pub use fetch::*;
pub use generation_providers::*;
pub use graph::*;
pub use logs::*;
pub use mcp::*;
pub use memory::*;
pub use memory_config::*;
pub use projects::*;
pub use providers::*;
pub use routing::*;
pub use runtimes::*;
pub use search::*;
pub use security::*;
pub use settings::*;
pub use system::*;
pub use telecom_approval::*;
pub use trace::*;
pub use users::*;
pub use workspace::*;
