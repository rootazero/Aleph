//! Chat reactive state — signals for chat messages, streaming, and UI mode.

use super::plan::{PlanUpdate, PlanView};
use crate::api::sessions::SessionKnobs;
use crate::api::teams::CoordTaskDto;
use crate::i18n::{td_string, Locale};
use aleph_protocol::session_thread::HistoryWindow;
use leptos::prelude::*;
use serde::{Deserialize, Serialize};
use shared_ui_logic::state::{merge_recalled_draft, remember_own_message_id};

mod run_phase;
mod send_error;
pub use run_phase::ChatPhase;
pub use send_error::{ChatSendError, ChatSendErrorCode};

/// File staged for upload as part of the next outbound message.
///
/// Lives on `ChatState` so both the composer's paperclip input AND the
/// chat-surface drop zone (cycle-2 G5) can append to the same list.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PendingAttachment {
    pub name: String,
    pub mime_type: String,
    pub data_base64: String,
    pub size: u64,
}

/// A follow-up prompt the user lined up while a turn was still running.
///
/// Mirrors hermes-agent's `QueuedPromptEntry`. Reuses [`PendingAttachment`]
/// so a queued prompt carries the exact same payload as a live send — the
/// drain path just replays it through the normal composer pipeline.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct QueuedPrompt {
    pub text: String,
    pub attachments: Vec<PendingAttachment>,
}

/// One-line preview for a queued prompt: trimmed text (UTF-8-safe truncation,
/// P7), or an attachment-count fallback when attachments-only. Pure — the
/// ghost bubble renders whatever this returns.
#[must_use]
pub fn queue_preview_label(entry: &QueuedPrompt) -> String {
    const MAX: usize = 64;
    let text = entry.text.trim();
    if !text.is_empty() {
        let truncated: String = text.chars().take(MAX).collect();
        if truncated.chars().count() < text.chars().count() {
            format!("{truncated}…")
        } else {
            truncated
        }
    } else {
        let n = entry.attachments.len();
        format!("📎 {n}")
    }
}

/// Reconciliation key for one queued-ghost row.
///
/// The queue is addressed **by position** — [`ChatState::take_queued_prompt`]
/// and [`ChatState::remove_queued_prompt`] take an index, and a ghost row's
/// click handler closes over the index it was built with. That is only sound
/// because this key moves with the position: every mutation that shifts a row
/// (turn-boundary flush, busy→idle auto-drain, ✕, recall) re-keys it, so
/// Leptos rebuilds the row and its handler closes over the new index.
///
/// Keying on the text alone would keep the stale handlers alive and silently
/// reintroduce the two failures that costs the most: removing the wrong row,
/// and restoring into the composer a prompt that has already been sent (which
/// the user then sends twice). Keying on the index alone would leave a row
/// rendering a prompt that no longer sits at that position.
///
/// Pinned by `queue_tests::{a_shifted_row_never_keeps_its_key,
/// two_identical_prompts_get_distinct_keys,
/// editing_the_text_at_one_position_changes_the_key}` — and, because none of
/// those can see a Leptos view, by
/// `queue_tests::the_ghost_row_view_actually_uses_the_shared_key`.
#[must_use]
pub fn queue_row_key(idx: usize, entry: &QueuedPrompt) -> String {
    format!("{idx}:{}", entry.text)
}

/// Transient provider-retry status for the active run.
///
/// Set by `stream.run_retrying` (provider chain failed transiently, run-loop
/// is retrying), cleared as soon as the provider responds (first chunk) or
/// the run settles. Ephemeral — never part of [`SessionSnapshot`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderRetryNotice {
    /// Provider that just failed (e.g. "kimi-for-coding").
    pub provider: String,
    /// 1-based dispatch attempt about to run.
    pub attempt: u32,
    /// Total attempts before the run gives up.
    pub max_attempts: u32,
}

/// Context-window occupancy snapshot for the composer gauge. All three figures
/// are computed by core and shipped on the `run_complete` summary — the panel
/// is a pure renderer (R4): `used_tokens` = current occupancy
/// (`prompt_tokens_total` + last output), `window_tokens` = the model's
/// authoritative context window, `total_tokens` = the run's cumulative total.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ContextUsage {
    /// Input/context tokens occupying the window after the latest turn.
    pub used_tokens: u32,
    /// Resolved context-window size for the run's model (gauge denominator).
    pub window_tokens: u32,
    /// Running total tokens billed for the run (shown in the tooltip).
    pub total_tokens: u64,
    /// True when these figures are a pre-run estimate (no real LLM turn yet),
    /// so the gauge renders `≈N%` instead of `N%`.
    pub is_estimate: bool,
}

/// Model resolution info (mirrors core `ModelInfo`).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ModelInfo {
    pub model: String,
    pub provider: String,
    #[serde(default)]
    pub is_fallback: bool,
    #[serde(default)]
    pub original_model: Option<String>,
}

/// Why a run stopped, when it stopped for a reason worth saying out loud.
///
/// Projected from `run_complete`'s `summary.terminate_reason` — core decides
/// (`TerminateReason::as_static_str`), the panel renders (R4).
///
/// The clean case is deliberately **absent** rather than
/// `Some("completed")`: a badge on every finished run is noise, and the four
/// surfaces that already read this field
/// (`reply_emitter::streaming::cap_notice_for`, the TUI run footer,
/// `aleph exec`, `aleph watch`) all suppress it the same way. Until this type
/// existed the panel read the field at all — a capped or crashed run rendered
/// here exactly like a clean one.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RunHalt {
    /// Stable token from `TerminateReason::as_static_str()`.
    pub reason: String,
    /// Granular cap label under the `budget_exhausted_partial_result`
    /// umbrella (`summary.terminate_detail`). Preferred over `reason` when
    /// present — the precedence is `aleph_protocol::terminate::effective_token`,
    /// which every terminal surface now reads as well.
    #[serde(default)]
    pub detail: Option<String>,
}

impl RunHalt {
    /// The words on screen.
    ///
    /// Takes a `Locale` rather than the context for the same reason
    /// `cluster::last_seen_label` does: this is a pure function with host unit
    /// tests, and `td_string!` resolves against a locale value, so both
    /// languages are assertable without standing up a reactive owner.
    ///
    /// An unrecognised token falls through **verbatim and untranslated**: a
    /// core newer than this panel must still say something true, and the raw
    /// token is truer than either a guess or silence. That fall-through is the
    /// one place this function cannot localise, by construction — the string is
    /// the server's, and it is the same fall-through the TUI and
    /// `cap_notice_for` apply.
    #[must_use]
    pub fn label(&self, locale: Locale) -> String {
        let raw = self.detail.as_deref().unwrap_or(&self.reason);
        match raw {
            "hit_max_iterations" => td_string!(locale, chat.halt_hit_max_iterations).to_string(),
            "context_budget_exhausted" => {
                td_string!(locale, chat.halt_context_budget_exhausted).to_string()
            }
            "max_output_tokens_exhausted" => {
                td_string!(locale, chat.halt_max_output_tokens_exhausted).to_string()
            }
            "budget_exhausted_partial_result" => {
                td_string!(locale, chat.halt_budget_exhausted_partial_result).to_string()
            }
            "consecutive_failure_cap" => {
                td_string!(locale, chat.halt_consecutive_failure_cap).to_string()
            }
            "empty_response_exhausted" => {
                td_string!(locale, chat.halt_empty_response_exhausted).to_string()
            }
            "reactive_compact_exhausted" => {
                td_string!(locale, chat.halt_reactive_compact_exhausted).to_string()
            }
            "stall_timeout" => td_string!(locale, chat.halt_stall_timeout).to_string(),
            "turn_timeout" => td_string!(locale, chat.halt_turn_timeout).to_string(),
            "verifier_veto" => td_string!(locale, chat.halt_verifier_veto).to_string(),
            "stop_hook_halt" => td_string!(locale, chat.halt_stop_hook_halt).to_string(),
            "cancelled" => td_string!(locale, chat.halt_cancelled).to_string(),
            "failed" => td_string!(locale, chat.halt_failed).to_string(),
            "diminishing_returns" => td_string!(locale, chat.halt_diminishing_returns).to_string(),
            other => other.to_string(),
        }
    }
}

/// What a completed run cost, projected from `run_complete`'s summary. Core
/// computes both the money and the token split (R4 — the panel only renders).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RunCost {
    /// Estimated spend in USD. `None` when core could not price the run at all.
    #[serde(default)]
    pub usd: Option<f64>,
    /// Core's `cost_status`: "complete" | "partial_missing_price" | "unknown".
    /// Anything other than "complete" must be rendered as an approximation —
    /// presenting a partial estimate as exact is a lie about money.
    #[serde(default)]
    pub status: Option<String>,
    /// Run-cumulative token total.
    #[serde(default)]
    pub total_tokens: u64,
    /// Prompt/completion split from `token_breakdown`, for the hover title.
    #[serde(default)]
    pub input_tokens: u64,
    #[serde(default)]
    pub output_tokens: u64,
    /// Prompt tokens served from the provider's prefix cache (~0.1x price).
    #[serde(default)]
    pub cache_read_tokens: u64,
    /// Prompt tokens *written* to the prefix cache (1.25x price) — i.e. the
    /// bytes the provider did not find in its cache. Arrives in the same
    /// `token_breakdown` object as `input`/`output`.
    #[serde(default)]
    pub cache_creation_tokens: u64,
}

/// Share of cacheable prompt bytes the provider actually reused —
/// `read / (read + created)`. `None` when the run touched no cache at all (a
/// provider without prompt caching, or a run that never got that far).
///
/// This answers "did the prefix hold?" and is deliberately NOT core's
/// `AgentUsageTotal::cache_hit_ratio`, which answers the different question
/// "what share of the prompt came from cache" over `input + cache_read`.
/// Creation tokens are the misses here precisely because a stable prefix would
/// have made them reads.
#[must_use]
pub fn prefix_reuse_ratio(cache_read: u64, cache_creation: u64) -> Option<f64> {
    let total = cache_read.saturating_add(cache_creation);
    if total == 0 {
        return None;
    }
    Some(cache_read as f64 / total as f64)
}

impl RunCost {
    /// True when core priced the run in full. Anything else renders with a `≈`.
    #[must_use]
    pub fn is_exact(&self) -> bool {
        self.status.as_deref() == Some("complete")
    }

    /// The meta-line money label, or `None` when the run carries no price.
    /// Sub-cent runs still get a figure (4 decimals) — "$0.00" reads as free.
    #[must_use]
    pub fn cost_label(&self) -> Option<String> {
        let usd = self.usd?;
        let sigil = if self.is_exact() { "" } else { "≈" };
        if usd >= 0.01 {
            Some(format!("{sigil}${usd:.2}"))
        } else {
            Some(format!("{sigil}${usd:.4}"))
        }
    }

    /// This run's prefix reuse — see [`prefix_reuse_ratio`].
    #[must_use]
    pub fn prefix_reuse(&self) -> Option<f64> {
        prefix_reuse_ratio(self.cache_read_tokens, self.cache_creation_tokens)
    }

    /// Compact token label ("12.3k tok"). `None` when core reported no tokens
    /// (a cached/aborted turn) — rendering "0 tok" reads as broken.
    #[must_use]
    pub fn tokens_label(&self) -> Option<String> {
        match self.total_tokens {
            0 => None,
            n if n < 1000 => Some(format!("{n} tok")),
            n => Some(format!("{:.1}k tok", n as f64 / 1000.0)),
        }
    }
}

/// Compact projection of a file the user attached to this turn.
///
/// `PendingAttachment` carries the full base64 payload + size so the
/// composer can ship the file, but a `ChatMessage` only needs to render a
/// chip ("photo.png · image/png") — the payload is gone by the time the
/// bubble is up. `PendingAttachment → AttachmentMeta` is a single field-by-
/// field copy at the composer send boundary, the only place that has both
/// types in scope (see `ChatState::push_user_message_with_attachments`).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AttachmentMeta {
    pub name: String,
    pub mime: String,
}

/// One model-side uncertainty note attached to a run.
///
/// Mirrors `StreamEvent::UncertaintySignal` (T2.13): backend has always
/// emitted this event, but until the panel started consuming it the user
/// never saw it — there was no place for it to land. Stored keyed by
/// `run_id` (mirrors how `run_halts` / `run_costs` are stored) so the
/// trailing assistant bubble can show a small chip explaining why the model
/// flagged itself, without coupling the chip's existence to whichever bubble
/// happened to mount last.
///
/// `serde` derives exist for the (theoretical) session-snapshot path;
/// nothing currently snapshots this field. Cheap insurance for parity with
/// the other per-run maps.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct UncertaintyNote {
    pub uncertainty: String,
    pub action: aleph_protocol::events::UncertaintyAction,
}

/// A rendered chat message (user or assistant).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ChatMessage {
    pub id: String,
    pub role: String,    // "user" | "assistant"
    pub content: String, // final or accumulated text
    /// Files the user attached to this turn, rendered as chips below the
    /// text on the user bubble. `serde(default)` keeps history rows
    /// produced before the field existed loadable — they deserialize to an
    /// empty list and simply render no chips. Empty for every assistant
    /// row by construction.
    #[serde(default)]
    pub attachments: Vec<AttachmentMeta>,
    #[serde(default)]
    pub tool_calls: Vec<ToolCallEntry>,
    #[serde(default)]
    pub is_streaming: bool, // true while response_chunks arrive
    #[serde(default)]
    pub is_intermediate: bool, // true for intermediate progress messages
    #[serde(default)]
    pub error: Option<String>,
    #[serde(default)]
    pub model_info: Option<ModelInfo>,
    /// Wall-clock creation time in epoch milliseconds. Stamped client-side on
    /// the message-creation path and hydrated from `chat.history` rows.
    /// `serde(default)` keeps older session snapshots (no field) loadable —
    /// they deserialize to `None` and simply render without a clock/separator.
    #[serde(default)]
    pub timestamp: Option<i64>,
    /// Think→Act iteration this bubble belongs to, stamped from
    /// `agent_trace.turn_started`. `None` for user messages, the pre-turn
    /// placeholder, and legacy/hydrated history rows. Drives left-chat
    /// segmentation and the `(run_id, iteration)` cross-highlight key.
    #[serde(default)]
    pub iteration: Option<usize>,
    /// The completed run's authoritative final answer (`run_complete`'s
    /// `summary.final_response`). When set this bubble renders as the
    /// conversational answer even if its terminating turn also issued a tool
    /// call — the tool card stays inline. Without it, a run whose last turn
    /// emitted text *and* a tool call (e.g. a closing `web_fetch`) would trap
    /// the answer in the step strip, since `is_final_answer` otherwise requires
    /// no tool calls. Mirrors the reference agents' typed-part model where text
    /// is always the answer and tools are always steps.
    #[serde(default)]
    pub is_final: bool,
    /// Set once `set_step_text` writes this bubble's authoritative per-turn text
    /// (`agent_trace.text_emitted`). Locks out late-arriving streamed
    /// `response_chunk` previews: the two travel independent async pipelines, so
    /// a chunk landing *after* the authoritative text would otherwise
    /// `push_str` a duplicate copy on top of it.
    #[serde(default)]
    pub text_finalized: bool,
    /// Team chat: the agent this bubble is attributed to. `None` = single-agent
    /// legacy path (zero regression; old snapshots without the field deserialize
    /// to None). `Some(..)` → MessageBubble renders attribution (color + name).
    #[serde(default)]
    pub agent_id: Option<String>,
    /// Sunk archive of a finished/superseded scratchpad plan. `Some` ⇒ this
    /// message renders as a compact "completed task" capsule instead of normal
    /// text. Reconstructed identically by live projection and `replay_run`
    /// (both drive the same archive call sites), so it survives a tab swap (via
    /// `messages` in `SessionSnapshot`) and a full reload (via replay).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub plan_archive: Option<super::plan::PlanView>,
    /// The human principal who typed this turn, when it was sent inside a
    /// project room (P2 Task 6/8). `None` for a single-user session, a
    /// pre-P2 core, or an assistant/system row. `MessageBubble` renders it as
    /// a display-name label above a user bubble, but only when it differs
    /// from the viewer's own id — never for the viewer's own messages.
    #[serde(default)]
    pub author_user_id: Option<String>,
}

/// Terminal status for a tool row whose outcome never reached the panel: the
/// run settled while the row was still `running` and the authoritative
/// end-of-run `tool_summaries` did not name it either.
///
/// It exists because live `agent_trace` frames are best-effort — a lagging
/// receiver of the run's bounded broadcast flow channel (or of a WS
/// connection's event stream) drops them. Without a fourth state a dropped
/// `tool_call_completed` left the row pulsing `running` forever (permanent 1s
/// tick subscription, and its `ExploreGroup` stuck on "Exploring…"). Settling
/// to `unknown` is honest: we know the run is over, we do not know how the
/// call ended. See [`ChatState::settle_orphan_tools`].
pub const TOOL_STATUS_UNKNOWN: &str = "unknown";

/// Minimal tool call record for display.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ToolCallEntry {
    pub tool_id: String,
    pub tool_name: String,
    /// `"running" | "completed" | "failed" | "unknown"` — see
    /// [`TOOL_STATUS_UNKNOWN`] for the fourth state's rationale.
    pub status: String,
    #[serde(default)]
    pub duration_ms: Option<u64>,
    /// Epoch-ms when the tool first went "running" — drives the live
    /// elapsed timer on long-running tool rows. Stamped panel-side.
    #[serde(default)]
    pub started_at_ms: Option<i64>,
}

/// A tool row's render-relevant status triple: `(status, duration_ms,
/// started_at_ms)`.
pub type ToolStatusEntry = (String, Option<u64>, Option<i64>);

/// `tool_id → status triple` for every tool row in the transcript.
pub type ToolStatusMap = std::collections::HashMap<String, ToolStatusEntry>;

/// Look one tool row's status up by scanning the transcript. The single
/// implementation behind both [`ToolIndex`] and its no-context fallback.
#[must_use]
pub fn find_tool_status(messages: &[ChatMessage], tool_id: &str) -> Option<ToolStatusEntry> {
    messages
        .iter()
        .flat_map(|m| m.tool_calls.iter())
        .find(|t| t.tool_id == tool_id)
        .map(|t| (t.status.clone(), t.duration_ms, t.started_at_ms))
}

/// Shared, memoized `tool_id → status` index over the foreground transcript.
///
/// Every mounted `ToolCard` (and the right-pane `ToolInspector`) needs one
/// tool's live status. Doing that as a per-card `Memo` that scans
/// `messages × tool_calls` meant a single streamed token — which invalidates
/// `messages` — re-ran an O(transcript) scan **once per mounted card**: a long
/// agentic run with dozens of tool rows paid O(cards × tool_calls) per token,
/// in WASM, at token rate.
///
/// One shared `Memo` collapses that to O(tool_calls) per token, and — because
/// `Memo` only notifies dependents when the computed value actually differs —
/// pure text streaming (the overwhelmingly common case: no tool row changed)
/// recomputes an *equal* map and wakes **no** card at all.
#[derive(Clone, Copy)]
pub struct ToolIndex(pub Memo<ToolStatusMap>);

impl ToolIndex {
    /// Build the index over `chat`'s transcript. Provided once at the app root.
    #[must_use]
    pub fn new(chat: ChatState) -> Self {
        Self(Memo::new(move |_| {
            chat.messages.with(|msgs| {
                msgs.iter()
                    .flat_map(|m| m.tool_calls.iter())
                    .map(|t| {
                        (
                            t.tool_id.clone(),
                            (t.status.clone(), t.duration_ms, t.started_at_ms),
                        )
                    })
                    .collect()
            })
        }))
    }

    /// Reactive lookup of one tool row's status.
    #[must_use]
    pub fn status_of(&self, tool_id: &str) -> Option<ToolStatusEntry> {
        self.0.with(|m| m.get(tool_id).cloned())
    }
}

/// One authoritative tool outcome from `run_complete`'s
/// `summary.tool_summaries[]`, projected onto the transcript by
/// [`ChatState::reconcile_tools`].
///
/// Core builds this from the harness's `tool_timeline` (`build_run_summary` in
/// `gateway/execution_engine/event_drain.rs`), keyed by the same `call.id` the
/// live `tool_call_started` / `tool_call_completed` trace events carry — so a
/// settlement always addresses the row the stream already created, and can
/// safely *create* the row when the `tool_call_started` mirror was the frame
/// that got dropped.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ToolSettlement {
    pub tool_id: String,
    pub tool_name: String,
    pub duration_ms: u64,
    pub success: bool,
}

/// Panel-side team member view (roster rail rendering + attribution coloring).
#[derive(Debug, Clone, PartialEq)]
pub struct TeamMemberView {
    pub agent_id: String,
    pub name: String,
    /// Agent emoji (avatar glyph); `None` falls back to a name monogram.
    pub emoji: Option<String>,
    pub role: String, // backend role, e.g. "leader" | "member" | "researcher"
    pub is_leader: bool,
    pub status: MemberStatus,
}

/// Live execution status of a team member (drives the roster rail status dot).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum MemberStatus {
    #[default]
    Idle,
    Working,
    Done,
    Error,
}

/// Which sink trigger is archiving the active plan.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ArchiveGate {
    /// New `set_plan` / `clear` — archive only a worked-on plan (`has_activity`).
    Activity,
    /// Next-turn start — archive only an already-complete plan.
    Completed,
}

/// Transcript rows the first hydration of a conversation asks for.
///
/// The predecessor was 50, hard-coded at the single call site, with no way to
/// ask for more — so every conversation longer than 50 rows opened missing its
/// beginning, permanently and with nothing on screen saying so. 50 is a handful
/// of turns here because `messages` holds one row per assistant step, not one
/// per turn: a six-turn agentic session on this machine had 88 rows.
pub const DEFAULT_HISTORY_LIMIT: usize = 200;

/// How much one "load earlier" press adds to [`DEFAULT_HISTORY_LIMIT`].
///
/// Re-fetching a larger window (rather than paging backwards with the server's
/// `before` cursor) is deliberate: hydration REPLAYS assistant runs through
/// `replay_run`, which appends to `messages` and expands one row into many
/// narration/tool rows, and it keys untraced rows by their index in the page
/// (`hist-{i}`). Prepending a second page would therefore both mis-order the
/// transcript and mint duplicate keys. Re-hydrating reuses that one tested
/// path and cannot drift from it.
pub const HISTORY_PAGE: usize = 200;

/// What a just-fetched transcript window implies about what sits above it:
/// `(show the control, how many rows are up there)`.
///
/// Two inputs answer the same question with different authority, and the order
/// matters. `total` is the server counting its own rows — when it is present
/// the gap is arithmetic and exact. `received >= limit` is the client guessing
/// from the size of what it got, and it is wrong in one specific place: a
/// transcript that is exactly `limit` rows long comes back full and complete,
/// and the guess calls it truncated. So the guess is the FALLBACK, reached only
/// when the server declined to answer (a core older than the field, or a count
/// that failed) — never a cross-check on an answer that was given.
///
/// The arithmetic half is [`HistoryWindow::above`], shared with the CLI rather
/// than spelled a second time here: "how many rows are above this window" is
/// one question, and two copies of it is how the two surfaces would come to
/// disagree about the same response.
///
/// Its `saturating_sub` is load-bearing because the server takes the two
/// numbers in two reads — and it counts FIRST, deliberately, so the skew falls
/// this way: a message appended in between lands in the window, `received`
/// comes back the larger, and "nothing above" is the honest reading. Counting
/// after the window would over-report instead, which on a conversation shorter
/// than the limit renders a "load earlier" control over a transcript with
/// nothing earlier.
#[must_use]
pub fn history_window_gap(
    received: usize,
    limit: usize,
    total: Option<usize>,
) -> (bool, Option<usize>) {
    let window = HistoryWindow {
        count: received,
        total,
    };
    match window.above() {
        Some(above) => (above > 0, Some(above)),
        None => (received >= limit, None),
    }
}

/// Reactive state container provided via Leptos context.
#[derive(Clone, Copy)]
pub struct ChatState {
    /// All messages in the current session.
    pub messages: RwSignal<Vec<ChatMessage>>,
    /// How many transcript rows the next hydration asks `chat.history` for.
    ///
    /// Lives here rather than as a parameter because all five hydration entry
    /// points (`hydrate_and_follow` and its callers) write into this one
    /// singleton anyway, and a parameter would have to be threaded through
    /// every one of them to be raised from a single button.
    ///
    /// `chat.history` returns the TRAILING `limit` rows (`paginate_before`
    /// keeps the most recent), so a limit smaller than the transcript drops
    /// the OLDEST messages — silently, before this existed. Raising it and
    /// re-hydrating is what "load earlier" does.
    pub history_limit: RwSignal<usize>,
    /// Whether rows exist above the window the last hydration rendered — the
    /// gate on the "load earlier" control.
    pub history_has_more: RwSignal<bool>,
    /// HOW MANY rows are above the window, when the server said so.
    ///
    /// `chat.history` reports `total` (the whole session) alongside the
    /// trailing page it serves, so this is `total - received`. `None` means the
    /// server gave no answer — a core that predates the field, or a count that
    /// failed to read — and it must be read as "unknown", never as zero.
    ///
    /// It is what makes the control an exit rather than a staircase: knowing
    /// the number, one press fetches the entire remainder and the label can say
    /// what that costs before it is paid. Not knowing it, the control degrades
    /// to `HISTORY_PAGE` at a time — the behaviour it had when the length of
    /// the page was the only evidence available.
    ///
    /// That older evidence — "the page came back full" — is still the fallback
    /// for `history_has_more`, and it is wrong in one specific place: a
    /// transcript that is exactly `history_limit` rows long looks truncated to
    /// it. A server that reports `total` has no such blind spot, which is the
    /// point of asking rather than guessing.
    pub history_above: RwSignal<Option<usize>>,
    /// Current phase of the UI.
    pub phase: RwSignal<ChatPhase>,
    /// Active `run_id` (Some while agent is running).
    pub active_run_id: RwSignal<Option<String>>,
    /// Resolved session key from first chat.send response.
    pub session_key: RwSignal<Option<String>>,
    /// Currently selected agent ID for routing.
    pub agent_id: RwSignal<Option<String>>,
    /// Accumulated reasoning text for the current run.
    pub reasoning_text: RwSignal<String>,
    /// Error message (set when `run_error` arrives).
    ///
    /// Kept as a bare string for backward compatibility with sidebar /
    /// boot-gate readers; new UI code should read `send_error` for the
    /// structured form (preserves error code for severity styling and
    /// analytics).
    pub error_message: RwSignal<Option<String>>,
    /// Structured form of the last send / delivery error, kept in lock-step
    /// with `error_message`. Populated by `fail_run`, `set_send_error`,
    /// and cleared together with `error_message` on `clear*`.
    pub send_error: RwSignal<Option<ChatSendError>>,
    /// A non-fatal notice from the spoken layer — currently only "this system
    /// cannot decode the audio the core sent". Separate from [`Self::send_error`]
    /// on purpose: that one carries a `ChatSendErrorCode` and describes a failed
    /// send, and a decoder problem has a different remedy. Cleared by the user
    /// or by the next successful playback.
    pub voice_notice: RwSignal<Option<String>>,
    /// Files staged for the next outbound message. Composer paperclip and
    /// chat-surface drop zone both push into this list.
    pub pending_attachments: RwSignal<Vec<PendingAttachment>>,
    /// True while a drag is hovering the chat surface — drives the drop
    /// overlay highlight.
    pub is_dragging_files: RwSignal<bool>,
    /// What the user has typed but not yet sent. Owned here rather than by the
    /// composer so that (a) it is conversation-scoped like the queue and the
    /// attachment tray it belongs with — a tab swap used to keep the text while
    /// swapping the files out from under it — and (b) anything outside the
    /// composer (starter chips, the queued-ghost tap, keyboard recall) can put
    /// a prompt back in front of the user by writing it, with no prefill
    /// channel that could be produced with nothing draining it.
    /// Both composers bind their textarea straight to this signal.
    pub draft: RwSignal<String>,
    /// One-shot: an explicit Stop must suppress exactly one queue auto-drain,
    /// or cancelling a turn would flip busy → idle and immediately re-fire the
    /// queued prompt (the "Stop button does nothing" trap).
    ///
    /// Lives here rather than in the composer because the queue it gates is
    /// per-conversation while the composer is a single foreground component:
    /// pressing Stop in one conversation used to consume the suppression owed
    /// to whichever conversation the user switched to next.
    pub stop_suppresses_next_drain: RwSignal<bool>,
    /// Latest context-window occupancy, set on each `run_complete` and read by
    /// the composer's [`super::context_gauge::ContextGauge`]. `None` until the
    /// first run reports usage. Ephemeral (excluded from [`SessionSnapshot`]);
    /// it simply repopulates on the next completed turn after a tab swap.
    pub context_usage: RwSignal<Option<ContextUsage>>,
    /// Last-call prompt-cache hit rate as a rounded percentage (0–100), set
    /// live from `agent_trace.provider_usage` events via the canonical
    /// `aleph_protocol::cache_hit_ratio` — the same number the TUI status bar
    /// and the core DB rollup show. `None` until a call reports cache
    /// activity, so providers without prompt caching never show a
    /// misleading 0%. Ephemeral, like `context_usage`.
    pub live_cache_pct: RwSignal<Option<u64>>,
    /// Follow-up prompts queued while a run is active. Drained one-at-a-time
    /// when the turn settles naturally (see
    /// [`shared_ui_logic::state::should_auto_drain_on_settle`]). Session-scoped
    /// content, so it rides along in [`SessionSnapshot`] across tab swaps.
    pub prompt_queue: RwSignal<Vec<QueuedPrompt>>,
    /// Pulse signal that asks the composer to retry the last user message:
    /// each bump increments by 1. Used by `MessageBubble`'s retry button so
    /// the composer (which owns the send pipeline) actually fires the send
    /// without prop drilling a callback through every bubble.
    pub retry_pulse: RwSignal<u32>,
    /// One-shot pulse asking the composer to flush the prompt queue into the
    /// live run at a turn boundary (bumped by `events.rs` on
    /// `agent_trace.turn_started`). Ephemeral, like `retry_pulse` — excluded
    /// from [`SessionSnapshot`], so it neither snapshots nor needs clearing.
    pub flush_pulse: RwSignal<u32>,
    /// Pulse signal that asks the composer to run the doctor + LLM-repair
    /// flow (G1, `f` hotkey): each bump increments by 1. Bumped by the global
    /// keydown listener via `HotkeyState`; the composer seeds a diagnostic
    /// instruction and routes it through the normal send pipeline. Ephemeral,
    /// like `retry_pulse` — excluded from [`SessionSnapshot`].
    pub repair_pulse: RwSignal<u32>,
    /// Active project workspace root (absolute path). When `Some`, the
    /// chat composer attaches it to `chat.send` as `project_root`, and the
    /// daemon swaps the agent's working directory for the duration of the
    /// run. Switching project clears the session per the "switch opens new
    /// session" convention agreed for the desktop App.
    pub active_project_root: RwSignal<Option<String>>,
    /// Human-friendly display name for the active project. Surfaced in the
    /// composer's "enter project workspace ▾" chip so the user always sees which
    /// folder they're operating against.
    pub active_project_name: RwSignal<Option<String>>,
    /// `Some(project_id)` when this conversation is a project room (P2 Task
    /// 8), rather than a plain single-agent chat. Every `ChatApi::send` call
    /// site reads this to attach `project_id` and force `project_root` to
    /// `None` (the two are mutually exclusive — an explicit `project_root`
    /// outranks the room's workspace binding and is refused server-side for
    /// remote chat-tier callers).
    ///
    /// Unlike `team_id` (ephemeral, re-entered via compose — see
    /// `clear_team_context`'s doc), a room's binding must survive a tab swap:
    /// it rides in [`SessionSnapshot`] and is left untouched by
    /// `clear_session()`, mirroring `active_project_root`'s treatment. It is
    /// set exactly once, when the room's conversation is opened
    /// (`components::project_page`), and never mutated afterwards — each
    /// project gets its own `ConvId`, so there is no "switching root within
    /// one conversation" case to handle here.
    pub room_project_id: RwSignal<Option<String>>,
    /// User-selected per-turn model override (chat-window picker).
    ///
    /// `None` means "use the agent's configured default + fallback chain"
    /// — equivalent to openclaw's empty session model row. When `Some`, the
    /// composer attaches it to `chat.send.model_override`; the daemon
    /// short-circuits the resolver and pins the requested model.
    ///
    /// Selection is **session-sticky on the client**: it persists across
    /// turns within the panel session but resets on page reload (the
    /// server-side `preferred_model` persistence is a follow-up). Picker
    /// component owns reads/writes through this signal.
    pub selected_model: RwSignal<Option<crate::api::providers::ModelOverride>>,
    /// A model override requested from OUTSIDE the chat view (e.g. the MoA
    /// settings page's "Use in chat"). Parked here instead of written straight
    /// to `selected_model` because `restore_from` — which runs when the chat
    /// view activates a session on navigation — would immediately overwrite
    /// `selected_model` from the (empty) snapshot and lose it. Ephemeral: NOT in
    /// `SessionSnapshot`; `restore_from` consumes it right after the snapshot
    /// restore so the externally-requested model wins.
    pub pending_model_override: RwSignal<Option<crate::api::providers::ModelOverride>>,
    /// What each completed run cost, keyed by `run_id`. Projected from
    /// `run_complete`'s summary and read by the assistant bubble's meta line.
    /// Keyed on the run rather than stamped on [`ChatMessage`] because the same
    /// run's cost is looked up from whichever bubble ended up carrying its final
    /// answer. Session-scoped → rides along in [`SessionSnapshot`].
    pub run_costs: RwSignal<std::collections::HashMap<String, RunCost>>,
    /// Why each completed run stopped, when it did not stop cleanly. Keyed and
    /// scoped exactly like [`Self::run_costs`] — same producer frame, same
    /// per-conversation lifetime, same snapshot.
    pub run_halts: RwSignal<std::collections::HashMap<String, RunHalt>>,
    /// Latest uncertainty note per run (T2.13). Backend has always emitted
    /// `StreamEvent::UncertaintySignal` for self-flagged uncertainty; the panel
    /// was the only surface that never rendered it. Keyed the same way
    /// `run_halts` is, so the assistant bubble reads it the same way
    /// `MessageBubble::halt_view` reads `run_halts`. Cleared per-run on
    /// `clear_uncertainty` (called by `complete_run` / `fail_run`) so a new
    /// run never inherits the previous turn's note.
    pub uncertainty_signals: RwSignal<std::collections::HashMap<String, UncertaintyNote>>,
    /// Per-session execution tier override (`"ask"` | `"auto"` | `"full"`).
    /// `None` = follow the global tier. Mirrors what core persists under
    /// `SessionIdentityMeta.custom["exec_tier"]`; the composer's tier pill owns
    /// reads/writes. Session-scoped → rides along in [`SessionSnapshot`].
    pub session_exec_tier: RwSignal<Option<String>>,
    /// Per-session usage-mode override (`"chat"` | `"work"` | `"code"`).
    /// `None` = follow the global `[policies] mode`. Mirrors what core
    /// persists under `SessionIdentityMeta.custom["session_mode"]`; the
    /// composer's mode pill owns reads/writes. Session-scoped → rides along
    /// in [`SessionSnapshot`].
    pub session_mode: RwSignal<Option<String>>,
    /// Per-session reasoning depth (`"off"` … `"xhigh"`). `None` = send no
    /// thinking directive at all, which is NOT the same as `"off"`: core's
    /// precedence is request > session > *nothing*, so clearing this leaves the
    /// provider on its own default rather than disabling reasoning. Mirrors
    /// `SessionIdentityMeta.custom["think_level"]`. Session-scoped → rides
    /// along in [`SessionSnapshot`].
    pub session_think_level: RwSignal<Option<String>>,
    /// Per-session memory mode (`"on"` | `"off"`). `None` = follow the
    /// install-wide `[memory] enabled`. Mirrors
    /// `SessionIdentityMeta.custom["memory_mode"]`. Session-scoped → rides
    /// along in [`SessionSnapshot`].
    pub session_memory_mode: RwSignal<Option<String>>,
    /// The model this conversation is PINNED to (`select_model`), if any.
    ///
    /// Read-only here — the tool is the authoritative writer. Distinct from
    /// [`Self::selected_model`], which is this turn's override and outranks the
    /// pin, and from the model that last *served*: a pin applies from the next
    /// run, so a surface showing only the latter names the model the user just
    /// switched away from. Session-scoped → rides along in [`SessionSnapshot`].
    pub session_model_pin: RwSignal<Option<String>>,
    /// The global `[policies] mode` default, mirrored from
    /// `config.get_tool_permissions` by the mode pill's fetch. Lets the
    /// right-rail mode dispatch (`events.rs`) resolve the EFFECTIVE mode for
    /// sessions that follow the global default — not just session-explicit
    /// overrides. Global, not session-scoped: survives `clear_session()` and
    /// stays out of [`SessionSnapshot`]. `None` = not yet fetched (older core
    /// or pre-connect) → dispatch falls back to pre-mode behavior.
    pub global_mode: RwSignal<Option<String>>,
    /// Run IDs whose final assistant reply should be spoken aloud — the
    /// voice-loop turns started from the composer mic button. `events.rs` pops
    /// each on `run_complete` and plays its TTS audio. Ephemeral, like
    /// `is_dragging_files` / `retry_pulse` (excluded from session snapshots).
    pub voice_run_ids: RwSignal<Vec<String>>,
    /// Provider-retry status shown under the thinking indicator while the
    /// run-loop retries a transiently failing provider chain. Ephemeral.
    pub provider_retry: RwSignal<Option<ProviderRetryNotice>>,
    /// Monotonic counter for generating unique user message IDs.
    next_msg_id: RwSignal<u64>,
    /// How many messages **this viewer** has sent in this conversation.
    ///
    /// Bumped by [`Self::push_user_message`] and nothing else, which is the
    /// whole point: it is the only signal in this struct that answers "did the
    /// person at this keyboard just send something", and the transcript cannot
    /// answer it. A room peer's row is `role == "user"` too
    /// ([`Self::push_peer_user_message`]), a replayed history row is, and a
    /// conversation swap replaces the vector wholesale — so every proxy built
    /// out of the message list mistakes at least one of those for a send. See
    /// `shared_ui_logic::state::chat_scroll` for the consumer and the bugs that
    /// cost.
    ///
    /// Deliberately not folded into `Self::next_msg_id`, which is an id
    /// allocator shared with `archive_active_plan`: a plan capsule retiring
    /// into the transcript is not a send.
    pub sends: RwSignal<u64>,
    /// Team chat mode marker. `Some(team_id)` → render 3-pane team view; composer
    /// routes to teams.chat.send. `None` = single-agent chat (zero regression).
    /// NOTE (MVP): not persisted in SessionSnapshot — team mode is ephemeral and
    /// does not survive a session-tab swap; re-enter via the team compose button.
    pub team_id: RwSignal<Option<String>>,
    /// Team roster + live status (left roster rail data source). Empty = non-team.
    pub team_members: RwSignal<Vec<TeamMemberView>>,
    /// Team chat: coordination tasks for the active team (drives the bottom
    /// task strip + drawer). Empty when not in team mode. Fetched from
    /// `teams.list_tasks` and upserted by `team.<id>.task.<verb>` events.
    pub team_tasks: RwSignal<Vec<CoordTaskDto>>,
    /// Bounded FIFO of this viewer's own recently-sent `teams.chat.send`
    /// `message_id`s (spec §6.2 P3). `teams.chat.send`'s response and the
    /// live `team.<id>.message` event it triggers carry the SAME id — this
    /// lets `team_events`'s Message arm recognize and skip the live echo of
    /// a bubble the composer already pushed optimistically, without falsely
    /// suppressing a second browser tab's own copy of the same human's
    /// message (dedup is keyed by id, not by "am I the author"). See
    /// `shared_ui_logic::state::team_chat::remember_own_message_id`.
    pub own_team_msg_ids: RwSignal<std::collections::VecDeque<String>>,
    /// Per explore-group expand override, keyed by group key. Absent = use the
    /// default (running groups open, completed collapsed); present = the
    /// user's explicit toggle. Lives here — not as a group-local signal —
    /// because `timeline::row_key` folds in content length, so the group row
    /// remounts on every streamed token and a component-local `open` would
    /// reset each time (re-opening a group the user just collapsed mid-run).
    /// Ephemeral, like `retry_pulse` — excluded from [`SessionSnapshot`].
    pub strip_open: RwSignal<std::collections::HashMap<String, bool>>,
    /// Active single-chat task plan (scratchpad-driven Todo widget). `None`
    /// hides the panel. Projected by `events.rs` via `scratchpad_plan_update`.
    pub plan: RwSignal<Option<PlanView>>,
    /// `true` after `reattach_after_connect` gave up retrying
    /// `gateway.metrics.run_concurrency` and the probe never landed. The
    /// app-root Effect re-reads this on every `connection_epoch` bump and
    /// re-fires `reattach_after_connect` while it is set, clearing it on
    /// success — the "transient RPC failure, socket is fine" recovery path
    /// (T2.6). Cleared by a successful reattach. Ephemeral, like `retry_pulse`
    /// — excluded from [`SessionSnapshot`].
    pub pending_reattach: RwSignal<bool>,
}

impl Default for ChatState {
    fn default() -> Self {
        Self::new()
    }
}

impl ChatState {
    #[must_use]
    pub fn new() -> Self {
        Self {
            messages: RwSignal::new(Vec::new()),
            history_limit: RwSignal::new(DEFAULT_HISTORY_LIMIT),
            history_has_more: RwSignal::new(false),
            history_above: RwSignal::new(None),
            phase: RwSignal::new(ChatPhase::Idle),
            active_run_id: RwSignal::new(None),
            session_key: RwSignal::new(None),
            agent_id: RwSignal::new(None),
            reasoning_text: RwSignal::new(String::new()),
            error_message: RwSignal::new(None),
            send_error: RwSignal::new(None),
            voice_notice: RwSignal::new(None),
            pending_attachments: RwSignal::new(Vec::new()),
            is_dragging_files: RwSignal::new(false),
            draft: RwSignal::new(String::new()),
            stop_suppresses_next_drain: RwSignal::new(false),
            context_usage: RwSignal::new(None),
            live_cache_pct: RwSignal::new(None),
            prompt_queue: RwSignal::new(Vec::new()),
            retry_pulse: RwSignal::new(0),
            flush_pulse: RwSignal::new(0),
            repair_pulse: RwSignal::new(0),
            active_project_root: RwSignal::new(None),
            active_project_name: RwSignal::new(None),
            room_project_id: RwSignal::new(None),
            selected_model: RwSignal::new(None),
            pending_model_override: RwSignal::new(None),
            run_costs: RwSignal::new(std::collections::HashMap::new()),
            run_halts: RwSignal::new(std::collections::HashMap::new()),
            uncertainty_signals: RwSignal::new(std::collections::HashMap::new()),
            session_exec_tier: RwSignal::new(None),
            session_mode: RwSignal::new(None),
            session_think_level: RwSignal::new(None),
            session_memory_mode: RwSignal::new(None),
            session_model_pin: RwSignal::new(None),
            global_mode: RwSignal::new(None),
            voice_run_ids: RwSignal::new(Vec::new()),
            provider_retry: RwSignal::new(None),
            pending_reattach: RwSignal::new(false),
            next_msg_id: RwSignal::new(0),
            sends: RwSignal::new(0),
            team_id: RwSignal::new(None),
            team_members: RwSignal::new(Vec::new()),
            team_tasks: RwSignal::new(Vec::new()),
            own_team_msg_ids: RwSignal::new(std::collections::VecDeque::new()),
            strip_open: RwSignal::new(std::collections::HashMap::new()),
            plan: RwSignal::new(None),
        }
    }

    /// Whether explore group `key` is expanded. `default_open` is the state
    /// to use when the user hasn't toggled it (running groups default open,
    /// completed groups default collapsed).
    #[must_use]
    pub fn strip_is_open(&self, key: &str, default_open: bool) -> bool {
        self.strip_open
            .with(|m| m.get(key).copied())
            .unwrap_or(default_open)
    }

    /// Toggle explore group `key`'s expand state, seeding from
    /// `default_open` when the user hasn't toggled it before. The stored
    /// override survives the group row's per-token remount.
    pub fn toggle_strip(&self, key: &str, default_open: bool) {
        let next = !self.strip_is_open(key, default_open);
        self.strip_open.update(|m| {
            m.insert(key.to_string(), next);
        });
    }

    /// Apply a projected plan update to the Todo-panel signal.
    pub fn apply_plan_update(&self, update: PlanUpdate) {
        match update {
            PlanUpdate::Show(v) => self.plan.set(Some(v)),
            PlanUpdate::Hide => self.plan.set(None),
            PlanUpdate::NoChange => {}
        }
    }

    /// Settle the Todo strip at run end — the plan-shaped twin of
    /// [`Self::reconcile_tools`] + [`Self::settle_orphan_tools`].
    ///
    /// Two jobs, in order:
    /// 1. **Reconcile** against `summary.plan`, the authoritative terminal
    ///    snapshot the core latches in its own (unbounded, in-process) event
    ///    drain. The live projection rides the deliberately lossy `agent_trace`
    ///    mirror, so without this a single dropped `complete_item` frame left
    ///    the strip stuck at e.g. 2/5 forever with no repair path.
    /// 2. **Sink a finished plan immediately**, instead of waiting for the next
    ///    run to start. A completed list has nothing left to steer, and leaving
    ///    it mounted kept a pulsing "current step" row on screen across the
    ///    user's next message.
    ///
    /// An unfinished plan deliberately stays mounted: the objective is still
    /// open and the user should keep seeing what is left.
    pub fn settle_plan(&self, summary_plan: Option<&PlanView>) {
        self.apply_plan_update(super::plan::plan_settlement(summary_plan));
        self.archive_active_plan(ArchiveGate::Completed);
    }

    /// Which sink trigger is calling — decides the archive gate.
    pub fn archive_active_plan(&self, gate: ArchiveGate) {
        let Some(p) = self.plan.get_untracked() else {
            return;
        };
        let should = match gate {
            ArchiveGate::Activity => p.has_activity(),
            ArchiveGate::Completed => p.complete,
        };
        if !should {
            return; // leave the slot for the caller to overwrite/hide
        }
        let seq = self.next_msg_id.get_untracked();
        self.next_msg_id.set(seq + 1);
        self.messages.update(|msgs| {
            msgs.push(ChatMessage {
                id: format!("plan-archive-{seq}"),
                role: "assistant".into(),
                content: String::new(),
                attachments: Vec::new(),
                tool_calls: vec![],
                is_streaming: false,
                is_intermediate: false,
                error: None,
                model_info: None,
                is_final: false,
                text_finalized: false,
                timestamp: Some(super::timeline::now_millis()),
                iteration: None,
                agent_id: None,
                plan_archive: Some(p),
                author_user_id: None,
            });
        });
        self.plan.set(None);
    }

    /// Record a provider-retry status (`stream.run_retrying`).
    pub fn set_provider_retry(&self, notice: ProviderRetryNotice) {
        self.provider_retry.set(Some(notice));
    }

    /// Clear the retry notice once the provider responds or the run settles.
    /// Cheap no-op when nothing is set (called from the per-chunk hot path).
    pub fn clear_provider_retry(&self) {
        if self
            .provider_retry
            .with_untracked(std::option::Option::is_some)
        {
            self.provider_retry.set(None);
        }
    }

    /// Append a follow-up prompt to the tail of the queue.
    pub fn enqueue_prompt(&self, entry: QueuedPrompt) {
        self.prompt_queue.update(|q| q.push(entry));
    }

    /// Remove the queued prompt at `index` (no-op if out of range). Used by
    /// the per-row ✕ in the queue preview bar.
    pub fn remove_queued_prompt(&self, index: usize) {
        self.prompt_queue.update(|q| {
            if index < q.len() {
                q.remove(index);
            }
        });
    }

    /// Take the queued prompt at `index` back out of the queue, if it exists.
    /// The caller is expected to hand it to [`Self::seed_draft`] — dropping the
    /// return value silently destroys a message the user queued.
    #[must_use]
    pub fn take_queued_prompt(&self, index: usize) -> Option<QueuedPrompt> {
        let mut taken = None;
        self.prompt_queue.update(|q| {
            if index < q.len() {
                taken = Some(q.remove(index));
            }
        });
        taken
    }

    /// Take the **newest** queued prompt back out of the queue — the keyboard
    /// recall (`ArrowUp` / `Alt+ArrowUp`) and its pointer equivalent.
    ///
    /// Recall pops from the tail so that repeated recalls, each prepended to
    /// the draft by [`Self::seed_draft`], rebuild the queue's original order in
    /// the composer.
    #[must_use]
    pub fn recall_latest_queued(&self) -> Option<QueuedPrompt> {
        let mut popped = None;
        self.prompt_queue.update(|q| popped = q.pop());
        popped
    }

    /// Put a prompt back in front of the user, **ahead of** whatever they are
    /// already typing.
    ///
    /// The single entry point for "restore this into the composer": starter
    /// chips, the queued-ghost tap, and keyboard recall all call it. It writes
    /// [`Self::draft`] directly — there is no prefill channel that could be
    /// written with nothing draining it — and merges rather than overwrites, so
    /// neither an in-progress draft nor a second recall arriving in the same
    /// frame can be lost.
    pub fn seed_draft(&self, text: String, attachments: Vec<PendingAttachment>) {
        if !text.trim().is_empty() {
            self.draft
                .update(|draft| *draft = merge_recalled_draft(&text, draft));
        }
        if !attachments.is_empty() {
            self.pending_attachments.update(|staged| {
                let mut merged = attachments;
                merged.append(staged);
                *staged = merged;
            });
        }
    }

    /// Remove and return every queued prompt (FIFO order preserved), leaving
    /// the queue empty. Flushes the whole batch in one shot — at a turn
    /// boundary (Steer) or on the busy→idle settle.
    ///
    /// The caller now owns those prompts: a flush that fails part-way must put
    /// the remainder back with [`Self::requeue_front`] rather than drop them.
    #[must_use]
    pub fn drain_all_queued(&self) -> Vec<QueuedPrompt> {
        let mut out = Vec::new();
        self.prompt_queue.update(|q| out = std::mem::take(q));
        out
    }

    /// Put drained prompts back at the head of the queue, ahead of anything
    /// enqueued while the flush was in flight, so their arrival order is
    /// preserved. Used when a send never left the client.
    pub fn requeue_front(&self, prompts: Vec<QueuedPrompt>) {
        if prompts.is_empty() {
            return;
        }
        self.prompt_queue.update(|q| {
            let mut restored = prompts;
            restored.append(q);
            *q = restored;
        });
    }

    /// Register a run whose final assistant reply should be spoken aloud.
    /// Called by the composer mic button after it sends a voice-loop turn.
    pub fn mark_speak_run(&self, run_id: &str) {
        let id = run_id.to_string();
        self.voice_run_ids.update(|ids| {
            if !ids.contains(&id) {
                ids.push(id);
            }
        });
    }

    /// Pop a run from the speak set; returns `true` if it was registered.
    #[must_use]
    pub fn take_speak_run(&self, run_id: &str) -> bool {
        let mut found = false;
        self.voice_run_ids.update(|ids| {
            if let Some(pos) = ids.iter().position(|r| r == run_id) {
                ids.remove(pos);
                found = true;
            }
        });
        found
    }

    /// Final accumulated text of the assistant message for `run_id`, if present.
    #[must_use]
    pub fn assistant_text_for_run(&self, run_id: &str) -> String {
        let target_id = format!("assistant-{run_id}");
        self.messages.with(|msgs| {
            msgs.iter()
                .rev()
                .find(|m| m.id == target_id)
                .map(|m| m.content.clone())
                .unwrap_or_default()
        })
    }

    /// Set the active project and reset the session (1:1 project↔session
    /// binding per the agreed UX model). Passing `None` exits project mode
    /// and the chat reverts to running inside `~/.aleph/workspaces/{agent_id}`.
    ///
    /// A no-op inside a project room. The room's conversation belongs to every
    /// member, and `clear_session()` deliberately does not clear
    /// `room_project_id` — so without this guard, picking a folder here wiped
    /// `session_key` while leaving the room flag set, and the next message
    /// silently forked a SECOND room session that nobody else was in. The
    /// room's working directory is its owner's `bind_workspace` choice, which
    /// this picker is not.
    pub fn set_active_project(&self, root: Option<String>, name: Option<String>) {
        if self.room_project_id.get_untracked().is_some() {
            return;
        }
        let switching = self.active_project_root.get_untracked() != root;
        self.active_project_root.set(root);
        self.active_project_name.set(name);
        if switching {
            self.clear_session();
        }
    }

    /// Append a user message and reset error state.
    ///
    /// The single writer of [`Self::sends`] — every surface that lets this
    /// viewer send (composer, queued-prompt flush, retry, voice, slash command)
    /// funnels through here, so the counter is covered by construction rather
    /// than by remembering to bump it per call site.
    pub fn push_user_message(&self, text: &str) {
        self.push_user_message_with_attachments(text, &[]);
    }

    /// Append a user message with optional attachments, and reset error state.
    ///
    /// The single writer of [`Self::sends`] — every surface that lets this
    /// viewer send (composer, queued-prompt flush, retry, voice, slash command)
    /// funnels through here, so the counter is covered by construction rather
    /// than by remembering to bump it per call site.
    ///
    /// `attachments` is `&[PendingAttachment]` rather than `Vec<AttachmentMeta>`
    /// so callers (only the composer send path has any) can hand over the
    /// payload-bearing list they already have. The conversion to chip-only
    /// `AttachmentMeta` happens here so the rest of the projection stays
    /// unaware of base64 blobs. Voice, retry, slash-command sends and the
    /// queued-prompt drain all pass `&[]` — they have nothing to chip.
    pub fn push_user_message_with_attachments(
        &self,
        text: &str,
        attachments: &[PendingAttachment],
    ) {
        let seq = self.next_msg_id.get_untracked();
        self.next_msg_id.set(seq + 1);
        self.sends.update(|n| *n += 1);
        let id = format!("user-{seq}");
        let meta: Vec<AttachmentMeta> = attachments
            .iter()
            .map(|a| AttachmentMeta {
                name: a.name.clone(),
                mime: a.mime_type.clone(),
            })
            .collect();
        self.messages.update(|msgs| {
            msgs.push(ChatMessage {
                id,
                role: "user".into(),
                content: text.to_string(),
                attachments: meta,
                tool_calls: vec![],
                is_streaming: false,
                is_intermediate: false,
                error: None,
                model_info: None,
                is_final: false,
                text_finalized: false,
                timestamp: Some(super::timeline::now_millis()),
                iteration: None,
                agent_id: None,
                plan_archive: None,
                author_user_id: None,
            });
        });
        self.error_message.set(None);
        // The banner describes the LAST send attempt, so a new one retires it.
        // Without this a corrective send (remove the attachment, drop the
        // flagged phrasing) left the old red banner pinned above the transcript
        // until the session was cleared, reading as if the fix had failed.
        self.send_error.set(None);
    }

    /// Append another human's message, live, from
    /// `run.session_user_message`.
    ///
    /// # Why this is not `push_user_message`
    ///
    /// That one models *this viewer having just sent something*: it stamps
    /// `now_millis()` and clears both error banners, because a fresh send
    /// retires the complaint about the previous one. Neither is true of a room
    /// peer's message — it carries the server's own timestamp (so it sorts
    /// against reloaded rows instead of against this tab's clock), and a
    /// message somebody else typed must not wipe an error banner describing
    /// *my* last failed send.
    ///
    /// **Idempotent per source seq.** The id is the row's identity, so a frame
    /// delivered twice, or one racing the re-hydrate that will replay the same
    /// row, appends once.
    ///
    /// # Why it inserts rather than pushes
    ///
    /// This frame always arrives AFTER `run_accepted` for the same turn — the
    /// server cannot announce a row it has not written yet, and the row is
    /// written well inside the run. So by the time it lands, the empty
    /// `assistant-{run_id}` placeholder is already the last bubble, and a plain
    /// push would file the question BELOW the answer to it. It therefore lands
    /// ahead of any trailing placeholder that has produced nothing yet.
    ///
    /// The same rule is what makes mid-run steering come out right, in the
    /// other direction: by then the bubble carries text or tool calls, so it is
    /// no longer "nothing yet" and the interjection appends after it — which is
    /// exactly where `chat.history` will replay it from the event log.
    pub fn push_peer_user_message(
        &self,
        seq: u64,
        text: &str,
        author_user_id: &str,
        timestamp: Option<i64>,
    ) {
        /// A bubble opened for a run that has not emitted anything yet. It
        /// stands for a *future* answer, so a message that arrives now belongs
        /// in front of it.
        fn awaits_its_first_output(m: &ChatMessage) -> bool {
            m.role == "assistant"
                && m.is_streaming
                && m.content.is_empty()
                && m.tool_calls.is_empty()
        }

        let id = format!("peer-{seq}");
        self.messages.update(|msgs| {
            if msgs.iter().any(|m| m.id == id) {
                return;
            }
            let at = msgs
                .iter()
                .rposition(|m| !awaits_its_first_output(m))
                .map_or(0, |i| i + 1);
            msgs.insert(
                at,
                ChatMessage {
                    id,
                    role: "user".into(),
                    content: text.to_string(),
                    attachments: Vec::new(),
                    tool_calls: vec![],
                    is_streaming: false,
                    is_intermediate: false,
                    error: None,
                    model_info: None,
                    is_final: false,
                    text_finalized: false,
                    timestamp,
                    iteration: None,
                    agent_id: None,
                    plan_archive: None,
                    author_user_id: Some(author_user_id.to_string()),
                },
            );
        });
    }

    /// How many of this viewer's own recently-sent team-chat `message_id`s
    /// to remember for self-echo dedup (see [`Self::own_team_msg_ids`]).
    const OWN_TEAM_MSG_ID_CAP: usize = 32;

    /// Record `message_id` as one of this viewer's own team-chat sends, so
    /// the live `team.<id>.message` echo of it (`team_events`'s Message arm)
    /// is recognized and skipped rather than rendered as a second bubble.
    /// Bounded FIFO — see [`Self::own_team_msg_ids`].
    pub fn remember_own_team_message(&self, message_id: String) {
        self.own_team_msg_ids.update(|ids| {
            remember_own_message_id(ids, message_id, Self::OWN_TEAM_MSG_ID_CAP);
        });
    }

    /// Whether `message_id` is one of this viewer's own remembered
    /// team-chat sends (see [`Self::remember_own_team_message`]).
    #[must_use]
    pub fn is_own_team_message(&self, message_id: &str) -> bool {
        self.own_team_msg_ids
            .with_untracked(|ids| ids.iter().any(|id| id == message_id))
    }

    /// Start a new assistant message placeholder (streaming).
    ///
    /// **Idempotent per run id.** A run has exactly one `assistant-{run_id}`
    /// bubble, and two independent paths can now try to open it: the live
    /// `run_accepted` frame, and `hydrate_and_follow` joining a turn already in
    /// flight. Their order is genuinely undecidable — the `chat.history`
    /// response and the `RunAccepted` event travel the same socket but are
    /// written by different arms of the dispatch `select!` — so whichever
    /// arrives second must be a no-op rather than a second empty bubble. The
    /// same guard covers a transcript in which two persisted rows carry one run
    /// id, which `replay_run` would otherwise render twice.
    ///
    /// The early return deliberately skips `archive_active_plan` too: a
    /// duplicate open is not a new turn, so nothing should retire into the
    /// conversation flow.
    pub fn start_assistant_message(&self, run_id: &str) {
        let id = format!("assistant-{run_id}");
        if self
            .messages
            .with_untracked(|msgs| msgs.iter().any(|m| m.id == id))
        {
            return;
        }
        // Next-turn sink: a finished plan retires into the conversation flow
        // when the next run begins. Both live (`run_accepted`) and replay
        // (`replay_run`) call this, so the capsule reconstructs identically.
        self.archive_active_plan(ArchiveGate::Completed);
        self.messages.update(|msgs| {
            msgs.push(ChatMessage {
                id,
                role: "assistant".into(),
                content: String::new(),
                attachments: Vec::new(),
                tool_calls: vec![],
                is_streaming: true,
                is_intermediate: false,
                error: None,
                model_info: None,
                is_final: false,
                text_finalized: false,
                timestamp: Some(super::timeline::now_millis()),
                // Stamp the placeholder as step 1 immediately so the timeline
                // folds it into the step strip from the first frame, instead of
                // briefly rendering it as a bare reply bubble before the first
                // `turn_started` arrives.
                iteration: Some(1),
                agent_id: None,
                plan_archive: None,
                author_user_id: None,
            });
        });
        self.active_run_id.set(Some(run_id.to_string()));
        self.phase.set(ChatPhase::Thinking);
        self.reasoning_text.set(String::new());
    }

    /// The run joined its session's wait lane. Idempotent — the lane reports
    /// only when `ahead` changes, but a re-attach can replay the same value.
    ///
    /// Scoped to the run this conversation is actually following: a lane frame
    /// for a sibling run (another tab, a channel, cron) must not repaint this
    /// conversation's phase.
    ///
    /// Out-of-order guard (T2.10): a stale `run_queued` arriving AFTER the run
    /// has already been admitted (and therefore reads `Thinking` / `Streaming`
    /// / `Error`) must NOT flip the phase back to "waiting" — the wait is
    /// over, the phase it ended into is the source of truth for what is
    /// happening NOW. Mirror image of `mark_admitted`'s "only ever flips
    /// `Queued` → `Thinking`" guard.
    pub fn mark_queued(&self, run_id: &str, ahead: u16) {
        if self.active_run_id.get_untracked().as_deref() != Some(run_id) {
            return;
        }
        if matches!(
            self.phase.get_untracked(),
            ChatPhase::Thinking | ChatPhase::Streaming | ChatPhase::Error
        ) {
            return;
        }
        self.phase.set(ChatPhase::Queued { ahead });
    }

    /// The run was admitted to the engine — the wait is over.
    ///
    /// Only ever moves `Queued` to `Thinking`; every other phase is left
    /// exactly as it was, because admission answers "the wait ended", never
    /// "what is happening now" (a later frame may already have moved this
    /// conversation to `Streaming`).
    ///
    /// This cannot ride on `start_assistant_message`, which is what
    /// `run_accepted` already calls: that early-returns once the run's bubble
    /// exists, and by admission time the queued frame has created it. Without
    /// this method the phase would read "queued" until the first
    /// `turn_started` or token — i.e. for the whole of model latency, exactly
    /// while the model is in fact thinking.
    pub fn mark_admitted(&self, run_id: &str) {
        if self.active_run_id.get_untracked().as_deref() != Some(run_id) {
            return;
        }
        if matches!(self.phase.get_untracked(), ChatPhase::Queued { .. }) {
            self.phase.set(ChatPhase::Thinking);
        }
    }

    /// Begin a new agent step (Think→Act iteration) for `run_id`.
    ///
    /// Driven by `agent_trace.turn_started`. If the current
    /// `assistant-{run_id}` bubble already carries text or tool calls and
    /// belongs to a different iteration, it is finalized as a standalone
    /// intermediate step and a fresh streaming bubble tagged with `iteration`
    /// is started. Otherwise the trailing placeholder is reused — its iteration
    /// is simply updated to the incoming one. This covers the first turn (the
    /// placeholder is pre-stamped as step 1 in `start_assistant_message`) and
    /// the order where `response_chunk` preview text lands before
    /// `turn_started`: the preview then belongs to THIS step and must not be
    /// orphaned into a duplicate intermediate bubble. The server no longer
    /// produces that order (both frames share the run's one flow channel and
    /// `seq`), but reusing the same-step placeholder is correct either way.
    pub fn begin_step(&self, run_id: &str, iteration: usize) {
        let target_id = format!("assistant-{run_id}");
        self.messages.update(|msgs| {
            let len = msgs.len();
            if let Some(idx) = msgs.iter().rposition(|m| m.id == target_id) {
                let has_payload = !msgs[idx].content.is_empty() || !msgs[idx].tool_calls.is_empty();
                // Only finalize the bubble as a completed intermediate step when
                // it already belongs to a *different, already-stamped* iteration.
                // When the iteration matches (first turn or a raced preview), the
                // placeholder is reused so the content stays in the step strip.
                let prior_step = msgs[idx].iteration.is_some_and(|prev| prev != iteration);
                if has_payload && prior_step {
                    msgs[idx].is_streaming = false;
                    msgs[idx].is_intermediate = true;
                    msgs[idx].id = format!("intermediate-{run_id}-{len}");
                    msgs.push(ChatMessage {
                        id: target_id,
                        role: "assistant".into(),
                        content: String::new(),
                        attachments: Vec::new(),
                        tool_calls: vec![],
                        is_streaming: true,
                        is_intermediate: false,
                        error: None,
                        model_info: None,
                        iteration: Some(iteration),
                        timestamp: Some(super::timeline::now_millis()),
                        is_final: false,
                        text_finalized: false,
                        agent_id: None,
                        plan_archive: None,
                        author_user_id: None,
                    });
                } else {
                    msgs[idx].iteration = Some(iteration);
                }
            }
        });
        self.phase.set(ChatPhase::Thinking);
    }

    /// Set the authoritative text for the bubble of `run_id` at `iteration`,
    /// overwriting any streamed typewriter preview. Targets the bubble
    /// carrying the matching iteration tag — the live `assistant-{run_id}`
    /// bubble or an already-finalized `intermediate-{run_id}-{n}` bubble for
    /// this run — so late `text_emitted` events still land correctly.
    pub fn set_step_text(&self, run_id: &str, iteration: usize, text: &str) {
        let assistant_id = format!("assistant-{run_id}");
        let intermediate_prefix = format!("intermediate-{run_id}-");
        self.messages.update(|msgs| {
            if let Some(m) = msgs.iter_mut().rev().find(|m| {
                m.iteration == Some(iteration)
                    && (m.id == assistant_id || m.id.starts_with(&intermediate_prefix))
            }) {
                m.content = text.to_string();
                // Authoritative per-turn text has landed: lock this bubble so a
                // late streamed `response_chunk` preview can't `push_str` a
                // duplicate copy on top of it (the two arrive on independent
                // async pipelines and can race).
                m.text_finalized = true;
            }
        });
    }

    /// Set model info on the current assistant message for the given run.
    pub fn set_model_info(&self, run_id: &str, info: ModelInfo) {
        let target_id = format!("assistant-{run_id}");
        self.messages.update(|msgs| {
            if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                msg.model_info = Some(info);
            }
        });
    }

    /// Append a response text chunk to the current assistant message.
    pub fn append_chunk(&self, run_id: &str, content: &str) {
        // Provider produced output — any pending retry notice is stale.
        self.clear_provider_retry();
        let target_id = format!("assistant-{run_id}");
        self.messages.update(|msgs| {
            if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                // Skip once `set_step_text` has written the authoritative text
                // for this bubble — a late preview chunk would otherwise double
                // the content (see `text_finalized`).
                if !msg.text_finalized {
                    msg.content.push_str(content);
                }
            }
        });
        self.phase.set(ChatPhase::Streaming);
    }

    /// Record a tool call event.
    ///
    /// The update half searches **every bubble of the run** (the trailing
    /// `assistant-{run}` one *and* the already-finalized
    /// `intermediate-{run}-{n}` ones), mirroring what `set_step_text` and
    /// `finalize_answer` already do. Searching only the trailing bubble made a
    /// late `tool_call_completed` — one that lands after the next
    /// `turn_started` renamed its bubble — miss its own row and *append a
    /// phantom duplicate* to the fresh step, leaving the original row pinned
    /// on `running` forever.
    ///
    /// A first sighting still appends to the trailing bubble, so a tool call
    /// always joins the step it was issued from.
    pub fn update_tool(
        &self,
        run_id: &str,
        tool_id: &str,
        tool_name: &str,
        status: &str,
        duration_ms: Option<u64>,
    ) {
        let target_id = format!("assistant-{run_id}");
        let intermediate_prefix = format!("intermediate-{run_id}-");
        self.messages.update(|msgs| {
            let existing = msgs
                .iter_mut()
                .rev()
                .filter(|m| m.id == target_id || m.id.starts_with(&intermediate_prefix))
                .find_map(|m| m.tool_calls.iter_mut().find(|t| t.tool_id == tool_id));
            if let Some(tc) = existing {
                tc.status = status.to_string();
                tc.duration_ms = duration_ms;
                return;
            }
            if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                msg.tool_calls.push(ToolCallEntry {
                    tool_id: tool_id.to_string(),
                    tool_name: tool_name.to_string(),
                    status: status.to_string(),
                    duration_ms,
                    started_at_ms: (status == "running").then(super::timeline::now_millis),
                });
            }
        });
    }

    /// Project the run's authoritative end-of-run tool outcomes
    /// (`run_complete` → `summary.tool_summaries[]`) onto its rows.
    ///
    /// This is the repair pass for the deliberately lossy `agent_trace` mirror
    /// (see [`TOOL_STATUS_UNKNOWN`]): whichever `tool_call_started` /
    /// `tool_call_completed` frames were dropped, the terminal truth for every
    /// call of the run rides along in the very same `run_complete` frame the
    /// panel already parses for cost and occupancy. Core is authoritative and
    /// the panel is a pure renderer (R4), so a settlement always wins over the
    /// streamed status.
    ///
    /// A settlement whose row does not exist creates it on the trailing bubble
    /// — the case where the *start* frame was the one that got dropped, so the
    /// call was never visible at all.
    pub fn reconcile_tools(&self, run_id: &str, settlements: &[ToolSettlement]) {
        if settlements.is_empty() {
            return;
        }
        let target_id = format!("assistant-{run_id}");
        let intermediate_prefix = format!("intermediate-{run_id}-");
        self.messages.update(|msgs| {
            for s in settlements {
                let status = if s.success { "completed" } else { "failed" };
                let existing = msgs
                    .iter_mut()
                    .rev()
                    .filter(|m| m.id == target_id || m.id.starts_with(&intermediate_prefix))
                    .find_map(|m| m.tool_calls.iter_mut().find(|t| t.tool_id == s.tool_id));
                if let Some(tc) = existing {
                    tc.status = status.to_string();
                    tc.duration_ms = Some(s.duration_ms);
                    if tc.tool_name.is_empty() {
                        tc.tool_name.clone_from(&s.tool_name);
                    }
                } else if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                    msg.tool_calls.push(ToolCallEntry {
                        tool_id: s.tool_id.clone(),
                        tool_name: s.tool_name.clone(),
                        status: status.to_string(),
                        duration_ms: Some(s.duration_ms),
                        started_at_ms: None,
                    });
                }
            }
        });
    }

    /// Settle every row of `run_id` still marked `running` to
    /// [`TOOL_STATUS_UNKNOWN`].
    ///
    /// Runs after [`Self::reconcile_tools`] on `run_complete`, and alone on
    /// `run_error` (whose frame carries no summary at all). Without it a row
    /// whose completion frame was dropped keeps a pulsing dot and an
    /// ever-growing elapsed timer — a permanent 1s-tick subscription — and its
    /// `ExploreGroup` never reaches `completed`, so the block stays expanded
    /// under an "Exploring…" header for the rest of the session.
    pub fn settle_orphan_tools(&self, run_id: &str) {
        let target_id = format!("assistant-{run_id}");
        let intermediate_prefix = format!("intermediate-{run_id}-");
        self.messages.update(|msgs| {
            for m in msgs
                .iter_mut()
                .filter(|m| m.id == target_id || m.id.starts_with(&intermediate_prefix))
            {
                for tc in m.tool_calls.iter_mut().filter(|t| t.status == "running") {
                    tc.status = TOOL_STATUS_UNKNOWN.to_string();
                }
            }
        });
    }

    /// Stop treating `run_id` as in flight **without claiming an outcome**.
    ///
    /// For a run the server can no longer confirm: the core restarted (its
    /// per-session run registry is in-memory), or the socket was down long
    /// enough that the run's terminal frame is simply gone. Neither
    /// [`Self::complete_run`] nor [`Self::fail_run`] is honest here — the turn
    /// may have finished, may have been resumed under a new run id, may have
    /// died. So the bubble stops streaming and its unfinished tool rows go to
    /// `unknown` (the same word `replay_run` uses for a trace that ends
    /// mid-tool, and the same posture the core's own crash-boundary repair
    /// takes), and nothing is written into the message as an error.
    ///
    /// The composer release is **guarded**, unlike `complete_run`'s: a
    /// conversation can have a second run outstanding — one this Panel queued
    /// that the gateway is still holding in its wait lane — and unlocking the
    /// composer for a run that is no longer the active one would say "idle"
    /// while work is still going. Same reasoning as [`Self::fail_run`]'s.
    pub fn settle_abandoned_run(&self, run_id: &str) {
        let target_id = format!("assistant-{run_id}");
        self.messages.update(|msgs| {
            if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                msg.is_streaming = false;
            }
        });
        self.settle_orphan_tools(run_id);
        if self.active_run_id.get_untracked().as_deref() == Some(run_id) {
            self.active_run_id.set(None);
            self.phase.set(ChatPhase::Idle);
            self.clear_provider_retry();
        }
    }

    /// Record what a completed run cost (projected from `run_complete`).
    pub fn set_run_cost(&self, run_id: &str, cost: RunCost) {
        self.run_costs.update(|m| {
            m.insert(run_id.to_string(), cost);
        });
    }

    /// Record why a run stopped. `None` (a clean `completed`, or a core that
    /// predates the field) *removes* any prior entry rather than leaving it:
    /// run ids are reused on nothing, but a replay of the same run must not be
    /// able to leave a stale badge behind.
    pub fn set_run_halt(&self, run_id: &str, halt: Option<RunHalt>) {
        self.run_halts.update(|m| match halt {
            Some(h) => {
                m.insert(run_id.to_string(), h);
            }
            None => {
                m.remove(run_id);
            }
        });
    }

    /// Record (or refresh) the latest uncertainty note for a run (T2.13).
    /// Driven by `StreamEvent::UncertaintySignal`; the chip on the trailing
    /// assistant bubble reads it the same way `halt_view` reads `run_halts`.
    /// Latest-wins: a second signal within one run overwrites the first — the
    /// chip is a "this answer had doubts" indicator, not a stack of them
    /// (mirrors the TUI's `add_system_message` decision to keep the most
    /// recent, not accumulate). Drops the call when `uncertainty` is blank,
    /// because an empty signal would render as a chip with no explanation.
    pub fn set_uncertainty(&self, run_id: &str, note: UncertaintyNote) {
        if note.uncertainty.trim().is_empty() {
            return;
        }
        self.uncertainty_signals.update(
            |m: &mut std::collections::HashMap<String, UncertaintyNote>| {
                m.insert(run_id.to_string(), note);
            },
        );
    }

    /// Drop a run's uncertainty note. Called by `complete_run` / `fail_run`
    /// for the run that just settled, so the chip never outlives its run.
    /// (`run_id`s are not reused; clearing an unrelated id is harmless.)
    pub fn clear_uncertainty(&self, run_id: &str) {
        self.uncertainty_signals.update(
            |m: &mut std::collections::HashMap<String, UncertaintyNote>| {
                m.remove(run_id);
            },
        );
    }

    /// Prefix reuse across every priced run of *this* conversation.
    ///
    /// A single run's figure is noisy — the first run of a session writes the
    /// cache and reads nothing, so it always reads 0%. The question worth
    /// answering ("is this session re-billing its history?") is cumulative, and
    /// `run_costs` already holds the per-run split and is cleared on every
    /// session switch, so no extra bookkeeping is needed.
    #[must_use]
    pub fn session_prefix_reuse(&self) -> Option<f64> {
        let (read, created) = self.run_costs.with(|m| {
            m.values().fold((0u64, 0u64), |(r, c), cost| {
                (
                    r.saturating_add(cost.cache_read_tokens),
                    c.saturating_add(cost.cache_creation_tokens),
                )
            })
        });
        prefix_reuse_ratio(read, created)
    }

    /// Finalize current run (mark message as not streaming).
    pub fn complete_run(&self, run_id: &str) {
        let target_id = format!("assistant-{run_id}");
        self.messages.update(|msgs| {
            if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                msg.is_streaming = false;
            }
        });
        self.active_run_id.set(None);
        self.phase.set(ChatPhase::Idle);
        self.clear_provider_retry();
        // T2.13: uncertainty note belongs to the run that produced it; once
        // the run settles the chip must not bleed into the next turn.
        self.clear_uncertainty(run_id);
    }

    /// Promote a completed run's authoritative final answer into its trailing
    /// assistant bubble. Driven by `run_complete` from `summary.final_response`
    /// (and mirrored on the `replay_run` history path). Overwrites the trailing
    /// bubble with the authoritative text and flags it `is_final`, so the answer
    /// renders as a conversational bubble even when its terminating turn also
    /// issued a tool call — without this, such an answer stays trapped in the
    /// step strip. No-op for an empty answer or a run with no assistant bubble.
    pub fn finalize_answer(&self, run_id: &str, final_text: &str) {
        if final_text.trim().is_empty() {
            return;
        }
        let assistant_id = format!("assistant-{run_id}");
        let intermediate_prefix = format!("intermediate-{run_id}-");
        self.messages.update(|msgs| {
            if let Some(m) = msgs.iter_mut().rev().find(|m| {
                m.role == "assistant"
                    && (m.id == assistant_id || m.id.starts_with(&intermediate_prefix))
            }) {
                m.content = final_text.to_string();
                m.is_final = true;
                m.is_intermediate = false;
                m.is_streaming = false;
                m.text_finalized = true;
            }
        });
    }

    /// Mark current run as errored.
    ///
    /// `error_code` is the server's own classification of the failure
    /// (`aleph_protocol::receipt::ReceiptCode`, carried on the wire as
    /// `run_error.error_code`) — prefer it over re-deriving a bucket from the
    /// rendered message, which is what left Stop, a rejected queued message,
    /// and an expired key all rendering as an UNKNOWN banner. `None` is only
    /// for a core that predates the field or a transport-layer failure raised
    /// before any run exists.
    pub fn fail_run(&self, run_id: &str, error: &str, error_code: Option<&str>) {
        let target_id = format!("assistant-{run_id}");
        self.messages.update(|msgs| {
            if let Some(msg) = msgs.iter_mut().rev().find(|m| m.id == target_id) {
                msg.is_streaming = false;
                msg.error = Some(error.to_string());
            }
        });
        // Only the run that failed gets torn down. A conversation can have a
        // second run_id outstanding — one the Panel queued and the gateway is
        // still holding in its wait lane — and a `RunError` for *that* one used
        // to clear `active_run_id` and flip the phase to Error while the live
        // run was still streaming: the transcript kept filling in but the
        // composer showed Stop gone, an error banner up, and the queue's settle
        // edge already spent.
        if self
            .active_run_id
            .with_untracked(|live| live.as_deref() == Some(run_id))
        {
            self.active_run_id.set(None);
            self.phase.set(ChatPhase::Error);
            self.clear_provider_retry();
        }
        let structured = ChatSendError::from_wire_code(error_code, error);
        self.error_message.set(Some(structured.message.clone()));
        self.send_error.set(Some(structured));
        // T2.13: see `complete_run` — same lifetime rule.
        self.clear_uncertainty(run_id);
    }

    /// Record a structured chat send error from the composer / outbound
    /// path (e.g. `ChatApi::send` rejection, prompt-injection gate). Keeps
    /// the legacy `error_message` field in sync.
    pub fn set_send_error(&self, err: ChatSendError) {
        self.error_message.set(Some(err.message.clone()));
        // NOT routed through `admin_refusal`: `send_error` holds a typed
        // `ChatSendError`, not the server's `error.message`. There is no
        // protocol string here to recognise a refusal in.
        self.send_error.set(Some(err));
        self.phase.set(ChatPhase::Error);
    }

    /// Ask the composer to retry the last user message. Bumps the pulse so
    /// downstream Effects see a change even when content is identical.
    pub fn request_retry(&self) {
        self.retry_pulse.update(|n| *n = n.wrapping_add(1));
    }

    /// Ask the composer to run the doctor + LLM-repair flow (G1 `f` hotkey).
    /// Bumps the pulse so the composer's Effect seeds the diagnostic prompt
    /// and fires it through the normal send pipeline.
    pub fn request_repair(&self) {
        self.repair_pulse.update(|n| *n = n.wrapping_add(1));
    }

    /// Return the content of the most recent user message, if any. Used by
    /// the retry path to repopulate the composer.
    #[must_use]
    pub fn last_user_text(&self) -> Option<String> {
        self.messages.with(|msgs| {
            msgs.iter()
                .rev()
                .find(|m| m.role == "user")
                .map(|m| m.content.clone())
        })
    }

    /// Clear all messages and reset state.
    pub fn clear(&self) {
        self.messages.set(Vec::new());
        self.phase.set(ChatPhase::Idle);
        self.active_run_id.set(None);
        self.session_key.set(None);
        self.agent_id.set(None);
        self.reasoning_text.set(String::new());
        self.error_message.set(None);
        self.send_error.set(None);
        self.prompt_queue.set(Vec::new());
        self.draft.set(String::new());
        self.stop_suppresses_next_drain.set(false);
        self.strip_open.set(std::collections::HashMap::new());
        self.plan.set(None);
        self.context_usage.set(None);
        self.live_cache_pct.set(None);
        self.run_costs.set(std::collections::HashMap::new());
        self.run_halts.set(std::collections::HashMap::new());
        // A fresh conversation carries no dials of its own — every one of them
        // follows the install default until the user picks otherwise.
        self.apply_session_knobs(SessionKnobs::default());
    }

    /// Reset only the per-session state that [`SessionSnapshot`] does *not*
    /// carry.
    ///
    /// Opening another session in the same tab goes through
    /// `SessionMap::activate` first, which snapshots the outgoing conversation
    /// and restores the incoming one — every signal listed in
    /// `SessionSnapshot` is already correct by then. Calling the full
    /// [`Self::clear_session`] afterwards threw all of it away again: the
    /// draft and the prompt queue vanished (so a recalled or queued message
    /// was lost for good on one sidebar click), and `active_run_id` was
    /// nulled, which is the signal that tells the composer the conversation is
    /// still running — the Stop button disappeared, new input stopped queueing,
    /// and the next Enter started a second concurrent run on the same session.
    ///
    /// Team state is the part no snapshot holds, so it is the part that still
    /// has to be reset by hand — otherwise leaving group A for group B shows
    /// A's roster and tasks under B's name.
    pub fn clear_team_context(&self) {
        self.team_id.set(None);
        self.team_members.set(Vec::new());
        self.team_tasks.set(Vec::new());
        self.strip_open.set(std::collections::HashMap::new());
    }

    /// Clear session state but keep `agent_id` (for new chat within same agent).
    pub fn clear_session(&self) {
        self.messages.set(Vec::new());
        // Back to one page. Without this a session opened after a long one
        // inherits its raised limit, which is merely wasteful — but it also
        // inherits a stale `history_has_more`, which is a visible lie (a "load
        // earlier" control over a three-message conversation).
        self.history_limit.set(DEFAULT_HISTORY_LIMIT);
        self.history_has_more.set(false);
        self.history_above.set(None);
        self.phase.set(ChatPhase::Idle);
        self.active_run_id.set(None);
        self.session_key.set(None);
        self.reasoning_text.set(String::new());
        self.error_message.set(None);
        self.send_error.set(None);
        self.prompt_queue.set(Vec::new());
        self.draft.set(String::new());
        self.stop_suppresses_next_drain.set(false);
        self.team_id.set(None);
        self.team_members.set(Vec::new());
        // Clear the task strip too. Leaving it behind meant switching from
        // group A to group B showed A's tasks under B's name until the new
        // team's `teams.list_tasks` came back — and, worse, leaving a group for
        // a single chat kept a phantom strip pinned above the composer.
        self.team_tasks.set(Vec::new());
        self.strip_open.set(std::collections::HashMap::new());
        self.plan.set(None);
        self.context_usage.set(None);
        self.live_cache_pct.set(None);
        self.run_costs.set(std::collections::HashMap::new());
        self.run_halts.set(std::collections::HashMap::new());
        self.apply_session_knobs(SessionKnobs::default());
        // agent_id is intentionally preserved
    }

    /// This conversation's dials, as one value.
    ///
    /// Built with an exhaustive struct literal on purpose — see
    /// [`SessionKnobs`]. Never `..Default::default()`: that turns "I forgot the
    /// sixth dial" from a compile error back into a silently-dropped setting.
    ///
    /// Reads are `try_get_untracked().flatten()` because one caller — the voice
    /// send — deliberately runs after its composer may have been unmounted, and
    /// swallowing a finished utterance because the user navigated away is worse
    /// than sending it with the dials at their defaults. For a live state this
    /// is byte-identical to `get_untracked`.
    #[must_use]
    pub fn session_knobs(&self) -> SessionKnobs {
        SessionKnobs {
            exec_tier: self.session_exec_tier.try_get_untracked().flatten(),
            mode: self.session_mode.try_get_untracked().flatten(),
            think_level: self.session_think_level.try_get_untracked().flatten(),
            memory_mode: self.session_memory_mode.try_get_untracked().flatten(),
            model_pin: self.session_model_pin.try_get_untracked().flatten(),
        }
    }

    /// Adopt a conversation's dials wholesale — on select, on restore, and on
    /// clear (with [`SessionKnobs::default`]).
    ///
    /// Every dial is written, including the ones that are `None`. Writing only
    /// the present ones is how the outgoing conversation's tier leaks into the
    /// incoming one, and the leak reads as a setting the user thought they had
    /// made.
    pub fn apply_session_knobs(&self, knobs: SessionKnobs) {
        let SessionKnobs {
            exec_tier,
            mode,
            think_level,
            memory_mode,
            model_pin,
        } = knobs;
        self.session_exec_tier.set(exec_tier);
        self.session_mode.set(mode);
        self.session_think_level.set(think_level);
        self.session_memory_mode.set(memory_mode);
        self.session_model_pin.set(model_pin);
    }

    /// Capture a serializable, owned copy of all per-session signals.
    /// Used by `SessionMap` to swap tabs without remounting the chat tree:
    /// the outgoing tab's state is snapshotted here, the incoming tab's
    /// snapshot is then restored via [`Self::restore_from`].
    ///
    /// `is_dragging_files` and `retry_pulse` are intentionally excluded —
    /// the former is ephemeral DOM-hover state, the latter a one-shot
    /// pulse that shouldn't replay on restore.
    #[must_use]
    pub fn capture_snapshot(&self) -> SessionSnapshot {
        SessionSnapshot {
            messages: self.messages.get_untracked(),
            phase: self.phase.get_untracked(),
            active_run_id: self.active_run_id.get_untracked(),
            session_key: self.session_key.get_untracked(),
            agent_id: self.agent_id.get_untracked(),
            reasoning_text: self.reasoning_text.get_untracked(),
            error_message: self.error_message.get_untracked(),
            send_error: self.send_error.get_untracked(),
            pending_attachments: self.pending_attachments.get_untracked(),
            prompt_queue: self.prompt_queue.get_untracked(),
            draft: self.draft.get_untracked(),
            stop_suppresses_next_drain: self.stop_suppresses_next_drain.get_untracked(),
            active_project_root: self.active_project_root.get_untracked(),
            active_project_name: self.active_project_name.get_untracked(),
            room_project_id: self.room_project_id.get_untracked(),
            selected_model: self.selected_model.get_untracked(),
            next_msg_id: self.next_msg_id.get_untracked(),
            sends: self.sends.get_untracked(),
            context_usage: self.context_usage.get_untracked(),
            run_costs: self.run_costs.get_untracked(),
            run_halts: self.run_halts.get_untracked(),
            uncertainty_signals: self.uncertainty_signals.get_untracked(),
            knobs: self.session_knobs(),
            plan: self.plan.get_untracked(),
        }
    }

    /// Restore a previously captured snapshot. Always sets every field so
    /// stale values from the outgoing tab never leak across.
    pub fn restore_from(&self, snap: SessionSnapshot) {
        self.messages.set(snap.messages);
        self.phase.set(snap.phase);
        self.active_run_id.set(snap.active_run_id);
        self.session_key.set(snap.session_key);
        self.agent_id.set(snap.agent_id);
        self.reasoning_text.set(snap.reasoning_text);
        self.error_message.set(snap.error_message);
        self.send_error.set(snap.send_error);
        self.pending_attachments.set(snap.pending_attachments);
        self.prompt_queue.set(snap.prompt_queue);
        self.draft.set(snap.draft);
        self.stop_suppresses_next_drain
            .set(snap.stop_suppresses_next_drain);
        self.active_project_root.set(snap.active_project_root);
        self.active_project_name.set(snap.active_project_name);
        self.room_project_id.set(snap.room_project_id);
        self.selected_model.set(snap.selected_model);
        // A model requested from outside the chat view (MoA "Use in chat")
        // survives this restore: apply it over the snapshot value, then consume.
        if let Some(mo) = self.pending_model_override.get_untracked() {
            self.selected_model.set(Some(mo));
            self.pending_model_override.set(None);
        }
        self.run_costs.set(snap.run_costs);
        self.run_halts.set(snap.run_halts);
        self.uncertainty_signals.set(snap.uncertainty_signals);
        self.apply_session_knobs(snap.knobs);
        self.next_msg_id.set(snap.next_msg_id);
        self.sends.set(snap.sends);
        // Carried in the snapshot so the occupancy gauge survives a tab swap
        // (None for a fresh/empty tab, which correctly hides the gauge).
        self.context_usage.set(snap.context_usage);
        // The execution list belongs to the conversation, so it rides the
        // snapshot: it used to be blanked here, which meant switching tabs and
        // back — even mid-run — silently destroyed the Todo strip until the
        // model happened to touch the scratchpad again.
        self.plan.set(snap.plan);
        // Collapse choices stay ephemeral: they are view state about rows that
        // may not even exist in the restored transcript.
        self.strip_open.set(std::collections::HashMap::new());
        // Team mode is ephemeral (not in the snapshot, re-entered via compose) —
        // reset so the outgoing tab's team view/routing never leaks into the
        // restored single-agent session across a tab swap or close.
        self.team_id.set(None);
        self.team_members.set(Vec::new());
        self.team_tasks.set(Vec::new());
    }
}

/// Owned snapshot of every per-session signal in [`ChatState`]. Cheap to
/// stash in a `HashMap` (every field is `Clone`).
#[derive(Debug, Clone, Default)]
pub struct SessionSnapshot {
    pub messages: Vec<ChatMessage>,
    pub phase: ChatPhase,
    pub active_run_id: Option<String>,
    pub session_key: Option<String>,
    pub agent_id: Option<String>,
    pub reasoning_text: String,
    pub error_message: Option<String>,
    pub send_error: Option<ChatSendError>,
    pub pending_attachments: Vec<PendingAttachment>,
    pub prompt_queue: Vec<QueuedPrompt>,
    /// The unsent composer text, so a tab swap carries it with the queue and
    /// the attachment tray instead of stranding it on the wrong conversation.
    pub draft: String,
    /// Whether an explicit Stop is still owed one suppressed auto-drain.
    pub stop_suppresses_next_drain: bool,
    pub active_project_root: Option<String>,
    pub active_project_name: Option<String>,
    /// See [`ChatState::room_project_id`] — persisted (unlike `team_id`) so a
    /// room conversation stays a room across a tab swap.
    pub room_project_id: Option<String>,
    pub selected_model: Option<crate::api::providers::ModelOverride>,
    pub next_msg_id: u64,
    /// See [`ChatState::sends`] — carried so a tab swap back into a
    /// conversation does not read its own restored count as a fresh send.
    pub sends: u64,
    /// Last completed turn's context-window occupancy, so the gauge survives a
    /// tab swap instead of blanking until the next turn finishes.
    pub context_usage: Option<ContextUsage>,
    /// Per-run cost, so the meta line survives a tab swap.
    pub run_costs: std::collections::HashMap<String, RunCost>,
    /// Per-run halt reason, for the same reason and by the same route.
    pub run_halts: std::collections::HashMap<String, RunHalt>,
    /// Per-run uncertainty note (T2.13). Same lifetime and rationale as
    /// `run_costs` / `run_halts`: the chip survives a tab swap because the
    /// note belongs to the conversation, not to whichever bubble happens to
    /// be on screen.
    pub uncertainty_signals: std::collections::HashMap<String, UncertaintyNote>,
    /// This conversation's dials, so a tab swap restores the tier / mode /
    /// depth / memory setting the server is actually enforcing rather than the
    /// install defaults. One field, so a new dial cannot be captured on the way
    /// out and dropped on the way back.
    pub knobs: SessionKnobs,
    /// The session's live execution list, so the Todo strip survives a tab
    /// swap the same way the context gauge and per-run costs do.
    pub plan: Option<PlanView>,
}

#[cfg(test)]
mod step_tests {
    use super::*;

    fn assistant_ids(chat: &ChatState) -> Vec<(String, Option<usize>, bool, bool)> {
        chat.messages.with(|m| {
            m.iter()
                .map(|x| (x.id.clone(), x.iteration, x.is_streaming, x.is_intermediate))
                .collect()
        })
    }

    fn ids(chat: &ChatState) -> Vec<String> {
        chat.messages
            .with(|m| m.iter().map(|x| x.id.clone()).collect())
    }

    /// Only this viewer's own send moves [`ChatState::sends`], and the count
    /// travels with the conversation.
    ///
    /// It is the input `shared_ui_logic::state::chat_scroll` uses to decide
    /// whether to yank the viewport to the bottom, so every writer that is
    /// *not* a send is a viewport hijack: a project-room peer's message and a
    /// retiring plan capsule both append a row, and the plan capsule shares the
    /// id allocator this counter was nearly folded into.
    #[test]
    fn only_my_own_send_counts_as_a_send() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        assert_eq!(chat.sends.get_untracked(), 0);

        chat.push_user_message("mine");
        assert_eq!(chat.sends.get_untracked(), 1);

        // A room peer typing is a `role == "user"` row and must not read as
        // mine.
        chat.push_peer_user_message(7, "theirs", "u-someone-else", None);
        assert_eq!(
            chat.sends.get_untracked(),
            1,
            "a peer's message was counted as this viewer's send"
        );

        // A plan capsule retiring into the transcript bumps `next_msg_id` —
        // the allocator this counter deliberately does not share.
        chat.apply_plan_update(PlanUpdate::Show(crate::views::chat::plan::PlanView {
            objective: Some("Obj".into()),
            items: vec![crate::views::chat::plan::PlanItemView {
                text: "step".into(),
                status: crate::views::chat::plan::PlanItemStatusView::Completed,
            }],
            complete: true,
        }));
        chat.archive_active_plan(ArchiveGate::Activity);
        assert_eq!(
            chat.sends.get_untracked(),
            1,
            "an archived plan was counted as a send"
        );

        // And the count is part of the conversation, not of the tab.
        let snap = chat.capture_snapshot();
        chat.clear_session();
        chat.restore_from(snap);
        assert_eq!(
            chat.sends.get_untracked(),
            1,
            "the send count did not travel"
        );
    }

    /// Every dial survives a tab swap, and none of them leaks into the next
    /// conversation.
    ///
    /// The failure this pins is the one that already happened twice on other
    /// surfaces: a dial captured on the way out and forgotten on the way back
    /// reads as "this conversation follows the global default", which is
    /// indistinguishable from the truth — while the run loop keeps resolving
    /// the stored value every turn. Asserting on the whole [`SessionKnobs`]
    /// rather than field by field is what makes a sixth dial join this test by
    /// construction.
    #[test]
    fn every_dial_survives_a_snapshot_round_trip_and_none_leaks() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();

        let armed = SessionKnobs {
            exec_tier: Some("ask".into()),
            mode: Some("code".into()),
            think_level: Some("high".into()),
            memory_mode: Some("off".into()),
            model_pin: Some("claude-opus-5".into()),
        };
        chat.apply_session_knobs(armed.clone());
        let snap = chat.capture_snapshot();
        assert_eq!(snap.knobs, armed, "the outgoing tab must carry its dials");

        // Switching to a conversation with no dials of its own must show the
        // defaults, not the last tab's.
        chat.clear_session();
        assert_eq!(
            chat.session_knobs(),
            SessionKnobs::default(),
            "a dial leaked across a conversation switch"
        );

        chat.restore_from(snap);
        assert_eq!(
            chat.session_knobs(),
            armed,
            "a dial was captured on the way out and dropped on the way back"
        );
    }

    /// The production order for a room peer's turn: `run_accepted` opens the
    /// assistant placeholder first (the server cannot announce a row it has not
    /// written yet), so a plain push would file the question under the answer.
    #[test]
    fn a_peer_message_lands_above_the_answer_it_started() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.push_peer_user_message(7, "how did the migration go?", "u-alice", Some(1));

        assert_eq!(ids(&chat), vec!["peer-7", "assistant-r1"]);
    }

    /// Mid-run steering is the same rule read the other way: the bubble has
    /// produced output, so the interjection belongs after it — where the event
    /// log will replay it from.
    #[test]
    fn a_peer_message_lands_below_an_answer_already_in_progress() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.append_chunk("r1", "working on it");
        chat.push_peer_user_message(9, "actually, hold off", "u-alice", Some(2));

        assert_eq!(ids(&chat), vec!["assistant-r1", "peer-9"]);
    }

    /// Keyed by the row's own seq, so a duplicate delivery — or one racing the
    /// re-hydrate that replays the same row — cannot double the bubble.
    #[test]
    fn a_peer_message_is_idempotent_per_source_seq() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.push_peer_user_message(7, "hi", "u-alice", Some(1));
        chat.push_peer_user_message(7, "hi", "u-alice", Some(1));

        assert_eq!(ids(&chat), vec!["peer-7"]);
    }

    /// Somebody else's message must not retire the banner describing MY last
    /// failed send — the one behavioural difference from `push_user_message`
    /// that is easy to lose by copying it.
    #[test]
    fn a_peer_message_leaves_my_own_send_error_alone() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.error_message.set(Some("my send failed".into()));
        chat.push_peer_user_message(7, "hi", "u-alice", Some(1));

        assert_eq!(
            chat.error_message.get_untracked().as_deref(),
            Some("my send failed")
        );
    }

    #[test]
    fn begin_step_reuses_empty_placeholder() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);

        let rows = assistant_ids(&chat);
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].0, "assistant-r1");
        assert_eq!(rows[0].1, Some(1));
        assert!(rows[0].2, "reused placeholder still streaming");
    }

    #[test]
    fn assistant_placeholder_is_pre_stamped_as_step_one() {
        // The placeholder must fold into the step strip from the first frame,
        // so the UI never renders a bare reply bubble before the first turn
        // starts.
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");

        let rows = assistant_ids(&chat);
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].0, "assistant-r1");
        assert_eq!(rows[0].1, Some(1), "placeholder pre-stamped as step 1");
        assert!(rows[0].2, "placeholder streaming");
        assert!(!rows[0].3, "placeholder not intermediate");
    }

    #[test]
    fn begin_step_finalizes_nonempty_and_opens_new() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.append_chunk("r1", "step one");
        chat.begin_step("r1", 2);

        let rows = assistant_ids(&chat);
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].0, "intermediate-r1-1");
        assert_eq!(rows[0].1, Some(1));
        assert!(!rows[0].2 && rows[0].3, "finalized + intermediate");
        assert_eq!(rows[1].0, "assistant-r1");
        assert_eq!(rows[1].1, Some(2));
        assert!(rows[1].2 && !rows[1].3);
    }

    #[test]
    fn begin_step_reuses_placeholder_with_raced_preview() {
        // Regression (double-render): streamed preview text lands in the
        // placeholder bubble BEFORE the first `turn_started`. The server now
        // sequences both frames on one flow channel, so it no longer produces
        // this order; the client must still handle it. The
        // late `begin_step` must REUSE the pre-stamped placeholder — its
        // content is THIS step's preview — not orphan it into a duplicate
        // `intermediate-` bubble that `set_step_text` then mirrors.
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.append_chunk("r1", "你好"); // deltas win the cross-pipeline race
        chat.begin_step("r1", 1); // turn_started arrives late
        chat.set_step_text("r1", 1, "你好"); // authoritative text

        let rows = assistant_ids(&chat);
        assert_eq!(rows.len(), 1, "no duplicate intermediate bubble");
        assert_eq!(rows[0].0, "assistant-r1");
        assert_eq!(rows[0].1, Some(1));
        let content = chat.messages.with(|m| m[0].content.clone());
        assert_eq!(content, "你好");
    }

    #[test]
    fn set_step_text_overwrites_streamed_preview() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.append_chunk("r1", "par");
        chat.append_chunk("r1", "tial");
        chat.set_step_text("r1", 1, "authoritative");

        let content = chat.messages.with(|m| m[0].content.clone());
        assert_eq!(content, "authoritative");
    }

    #[test]
    fn set_step_text_targets_finalized_step_by_iteration() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.append_chunk("r1", "x");
        chat.begin_step("r1", 2); // finalizes step 1 as intermediate
        chat.set_step_text("r1", 1, "late fix");

        let content = chat.messages.with(|m| m[0].content.clone());
        assert_eq!(content, "late fix");
    }

    #[test]
    fn late_chunk_after_finalize_does_not_duplicate() {
        // Symptom B: `text_emitted` (set_step_text) and the streamed
        // `response_chunk` (append_chunk) ride independent async pipelines. When
        // the authoritative text lands first and a preview chunk arrives after,
        // the late chunk must be dropped — not appended on top — or the text
        // shows doubled ("ok…report. ok…report.").
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.set_step_text("r1", 1, "好的，我来继续制作HTML报告。");
        // Late streamed preview for the same turn races in after the
        // authoritative text — must be ignored.
        chat.append_chunk("r1", "好的，我来继续制作HTML报告。");

        let content = chat.messages.with(|m| m[0].content.clone());
        assert_eq!(content, "好的，我来继续制作HTML报告。");
    }

    #[test]
    fn finalize_answer_promotes_trailing_tool_turn() {
        // Symptom A: the run's last turn emitted the answer text *and* a tool
        // call, then ended. `finalize_answer` (driven by run_complete's
        // authoritative summary.final_response) must flag the trailing bubble
        // `is_final` and overwrite its text, so the timeline lifts it out of the
        // step strip — while its tool call is preserved (rendered inline).
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.append_chunk("r1", "report draft");
        chat.update_tool("r1", "t1", "web_fetch", "completed", Some(3));
        chat.complete_run("r1");
        chat.finalize_answer("r1", "AUTHORITATIVE REPORT");

        chat.messages.with(|m| {
            let bubble = m
                .iter()
                .find(|b| b.id == "assistant-r1")
                .expect("trailing bubble");
            assert!(bubble.is_final, "promoted to final answer");
            assert!(!bubble.is_intermediate);
            assert!(!bubble.is_streaming);
            assert_eq!(bubble.content, "AUTHORITATIVE REPORT");
            assert!(
                !bubble.tool_calls.is_empty(),
                "tool call preserved for inline render"
            );
        });
    }

    #[test]
    fn provider_retry_notice_cleared_on_first_chunk() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.set_provider_retry(ProviderRetryNotice {
            provider: "kimi-for-coding".into(),
            attempt: 2,
            max_attempts: 3,
        });
        assert!(chat.provider_retry.with_untracked(|n| n.is_some()));

        chat.append_chunk("r1", "hello");
        assert!(
            chat.provider_retry.with_untracked(|n| n.is_none()),
            "provider responded — retry notice must clear"
        );
    }

    #[test]
    fn provider_retry_notice_cleared_when_run_settles() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.set_provider_retry(ProviderRetryNotice {
            provider: "302ai".into(),
            attempt: 3,
            max_attempts: 3,
        });
        chat.fail_run("r1", "provider 302ai transient: Request timed out", None);
        assert!(
            chat.provider_retry.with_untracked(|n| n.is_none()),
            "run settled — retry notice must clear"
        );
    }

    #[test]
    fn classify_provider_timeout_is_cloud_send_failed() {
        // Real message from a provider-chain network outage (2026-06-10 log).
        // Must NOT be labelled SafetyTimeout — the harness never timed out;
        // the upstream was unreachable.
        let e = ChatSendError::classify(
            "Execution failed: provider failover transient: llm error: Request timed out",
        );
        assert_eq!(e.code, ChatSendErrorCode::CloudSendFailed);
    }

    #[test]
    fn classify_harness_turn_timeout_is_safety_timeout() {
        // Actual humanized TerminateReason::TurnTimeout text from
        // orchestrator::summary_format — the case SafetyTimeout exists for.
        let e = ChatSendError::classify("Turn timeout in think (5m 0s)");
        assert_eq!(e.code, ChatSendErrorCode::SafetyTimeout);
    }

    #[test]
    fn classify_harness_stall_is_safety_timeout() {
        // Humanized TerminateReason::StallTimeout text.
        let e = ChatSendError::classify("Stalled after 3m 0s");
        assert_eq!(e.code, ChatSendErrorCode::SafetyTimeout);
    }

    #[test]
    fn finalize_answer_ignores_empty_final_text() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.append_chunk("r1", "kept");
        chat.finalize_answer("r1", "   ");

        chat.messages.with(|m| {
            let bubble = m.iter().find(|b| b.id == "assistant-r1").unwrap();
            assert!(!bubble.is_final, "empty final text is a no-op");
            assert_eq!(bubble.content, "kept");
        });
    }

    #[test]
    fn chat_message_agent_id_defaults_none_for_legacy_json() {
        let legacy = serde_json::json!({ "id": "a", "role": "assistant", "content": "hi" });
        let msg: ChatMessage = serde_json::from_value(legacy).unwrap();
        assert_eq!(msg.agent_id, None);
    }

    #[test]
    fn chat_message_roundtrips_agent_id() {
        let msg: ChatMessage = serde_json::from_value(serde_json::json!({
            "id": "m", "role": "assistant", "content": "x", "agent_id": "alice"
        }))
        .unwrap();
        assert_eq!(msg.agent_id.as_deref(), Some("alice"));
        let v = serde_json::to_value(&msg).unwrap();
        assert_eq!(v.get("agent_id").and_then(|a| a.as_str()), Some("alice"));
    }

    use super::super::plan::{PlanItemStatusView, PlanItemView, PlanView};

    fn plan(items: &[(&str, PlanItemStatusView)], complete: bool) -> PlanView {
        PlanView {
            objective: Some("Obj".into()),
            items: items
                .iter()
                .map(|(t, s)| PlanItemView {
                    text: (*t).into(),
                    status: *s,
                })
                .collect(),
            complete,
        }
    }

    fn archive_count(chat: &ChatState) -> usize {
        chat.messages
            .with(|m| m.iter().filter(|x| x.plan_archive.is_some()).count())
    }

    #[test]
    fn archive_activity_sinks_worked_plan_and_clears_slot() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.plan
            .set(Some(plan(&[("a", PlanItemStatusView::Completed)], false)));
        chat.archive_active_plan(ArchiveGate::Activity);
        assert_eq!(archive_count(&chat), 1, "worked plan sinks one capsule");
        assert!(
            chat.plan.get_untracked().is_none(),
            "slot cleared after archive"
        );
    }

    #[test]
    fn archive_activity_skips_pristine_plan() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.plan
            .set(Some(plan(&[("a", PlanItemStatusView::Pending)], false)));
        chat.archive_active_plan(ArchiveGate::Activity);
        assert_eq!(archive_count(&chat), 0, "pristine plan is not archived");
        assert!(
            chat.plan.get_untracked().is_some(),
            "slot left for overwrite"
        );
    }

    #[test]
    fn archive_completed_gate_ignores_incomplete() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.plan
            .set(Some(plan(&[("a", PlanItemStatusView::InProgress)], false)));
        chat.archive_active_plan(ArchiveGate::Completed);
        assert_eq!(
            archive_count(&chat),
            0,
            "in-progress plan not sunk on Completed gate"
        );
        assert!(chat.plan.get_untracked().is_some());
    }

    #[test]
    fn start_assistant_message_sinks_completed_plan() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.plan
            .set(Some(plan(&[("a", PlanItemStatusView::Completed)], true)));
        chat.start_assistant_message("r2");
        assert_eq!(
            archive_count(&chat),
            1,
            "completed plan sinks at next run start"
        );
        assert!(chat.plan.get_untracked().is_none());
    }

    #[test]
    fn start_assistant_message_keeps_incomplete_plan() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.plan
            .set(Some(plan(&[("a", PlanItemStatusView::InProgress)], false)));
        chat.start_assistant_message("r2");
        assert_eq!(
            archive_count(&chat),
            0,
            "in-progress plan stays in the sticky slot"
        );
        assert!(chat.plan.get_untracked().is_some());
    }

    #[test]
    fn context_usage_clears_on_reset_but_survives_tab_swap() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        let seed = || {
            chat.context_usage.set(Some(ContextUsage {
                used_tokens: 10_000,
                window_tokens: 200_000,
                total_tokens: 12_000,
                is_estimate: false,
            }))
        };

        seed();
        chat.clear();
        assert!(
            chat.context_usage.get_untracked().is_none(),
            "clear() must reset the context gauge"
        );

        seed();
        chat.clear_session();
        assert!(
            chat.context_usage.get_untracked().is_none(),
            "clear_session() must reset the context gauge"
        );

        // Tab swap = capture outgoing tab → restore incoming tab. The gauge now
        // rides in SessionSnapshot, so a tab that already ran a turn keeps its
        // occupancy across the swap instead of blanking out (the user-visible
        // "switching tabs hides the gauge" complaint).
        seed();
        let snap = chat.capture_snapshot();
        chat.context_usage.set(None);
        chat.restore_from(snap);
        assert_eq!(
            chat.context_usage.get_untracked(),
            Some(ContextUsage {
                used_tokens: 10_000,
                window_tokens: 200_000,
                total_tokens: 12_000,
                is_estimate: false,
            }),
            "restore_from() must rehydrate the captured gauge so it survives tab swaps"
        );

        // A fresh/empty tab (default snapshot) still shows no gauge.
        chat.restore_from(SessionSnapshot::default());
        assert!(
            chat.context_usage.get_untracked().is_none(),
            "restoring an empty snapshot must leave the gauge hidden"
        );
    }

    fn plan_of(
        items: &[(&str, super::super::plan::PlanItemStatusView)],
        complete: bool,
    ) -> PlanView {
        PlanView {
            objective: Some("Ship".into()),
            items: items
                .iter()
                .map(|(t, s)| PlanItemView {
                    text: (*t).into(),
                    status: *s,
                })
                .collect(),
            complete,
        }
    }

    /// The halt reason rides the snapshot for the same reason the cost does:
    /// switching tabs and switching back must not turn a capped run into one
    /// that looks like it finished cleanly.
    #[test]
    fn a_halt_reason_survives_a_tab_swap_and_can_be_taken_back() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.set_run_halt(
            "r1",
            Some(RunHalt {
                reason: "hit_max_iterations".into(),
                detail: None,
            }),
        );

        let snap = chat.capture_snapshot();
        chat.run_halts.set(std::collections::HashMap::new());
        chat.restore_from(snap);
        assert_eq!(
            chat.run_halts
                .get_untracked()
                .get("r1")
                .map(|h| h.label(Locale::en))
                .as_deref(),
            Some("hit max iterations")
        );

        // `None` removes rather than leaves: a replay of the same run that now
        // reports a clean finish must not keep the old badge on screen.
        chat.set_run_halt("r1", None);
        assert!(chat.run_halts.get_untracked().is_empty());

        // A fresh tab shows nothing.
        chat.set_run_halt(
            "r2",
            Some(RunHalt {
                reason: "failed".into(),
                detail: None,
            }),
        );
        chat.restore_from(SessionSnapshot::default());
        assert!(chat.run_halts.get_untracked().is_empty());
    }

    #[test]
    fn plan_survives_a_tab_swap() {
        use super::super::plan::PlanItemStatusView::{InProgress, Pending};
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.apply_plan_update(PlanUpdate::Show(plan_of(
            &[("a", InProgress), ("b", Pending)],
            false,
        )));

        // Tab swap = capture outgoing → restore incoming.
        let snap = chat.capture_snapshot();
        chat.plan.set(None);
        chat.restore_from(snap);

        let restored = chat.plan.get_untracked().expect("plan rides the snapshot");
        assert_eq!(restored.current_step(), Some("a"));

        // A fresh tab still shows nothing.
        chat.restore_from(SessionSnapshot::default());
        assert!(chat.plan.get_untracked().is_none());
    }

    #[test]
    fn settle_plan_reconciles_a_stale_live_checklist() {
        use super::super::plan::PlanItemStatusView::{Completed, InProgress, Pending};
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        // Live projection lost the last two ticks (dropped agent_trace frames).
        chat.apply_plan_update(PlanUpdate::Show(plan_of(
            &[("a", Completed), ("b", InProgress), ("c", Pending)],
            false,
        )));

        let authoritative = plan_of(
            &[("a", Completed), ("b", Completed), ("c", Completed)],
            true,
        );
        chat.settle_plan(Some(&authoritative));

        // Complete → sunk into the transcript, strip cleared.
        assert!(
            chat.plan.get_untracked().is_none(),
            "a finished plan sinks at run end instead of staying mounted"
        );
        let archived = chat.messages.with_untracked(|m| {
            m.iter()
                .filter_map(|x| x.plan_archive.clone())
                .next_back()
                .expect("an archive capsule")
        });
        assert_eq!(
            archived.done_count(),
            3,
            "the sunk capsule shows 3/3, not 1/3"
        );
    }

    #[test]
    fn settle_plan_keeps_an_unfinished_list_mounted() {
        use super::super::plan::PlanItemStatusView::{Completed, Pending};
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.apply_plan_update(PlanUpdate::Show(plan_of(
            &[("a", Completed), ("b", Pending)],
            false,
        )));
        chat.settle_plan(Some(&plan_of(&[("a", Completed), ("b", Pending)], false)));
        assert!(
            chat.plan.get_untracked().is_some(),
            "the objective is still open — the user must keep seeing what is left"
        );
    }

    #[test]
    fn settle_plan_without_a_summary_leaves_the_live_plan_alone() {
        use super::super::plan::PlanItemStatusView::{Completed, Pending};
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.apply_plan_update(PlanUpdate::Show(plan_of(
            &[("a", Completed), ("b", Pending)],
            false,
        )));
        chat.settle_plan(None);
        assert_eq!(
            chat.plan.get_untracked().map(|p| p.done_count()),
            Some(1),
            "an older core with no summary.plan must not blank the strip"
        );
    }

    /// Every tool row of `run`, flattened across its step bubbles.
    fn rows(chat: &ChatState) -> Vec<(String, String, Option<u64>)> {
        chat.messages.with_untracked(|msgs| {
            msgs.iter()
                .flat_map(|m| m.tool_calls.iter())
                .map(|t| (t.tool_id.clone(), t.status.clone(), t.duration_ms))
                .collect()
        })
    }

    /// Regression: a `tool_call_completed` that lands *after* the next
    /// `turn_started` renamed its bubble used to miss its own row (the search
    /// covered only the trailing `assistant-{run}` bubble) and append a phantom
    /// duplicate to the fresh step, leaving the original pinned on `running`.
    #[test]
    fn update_tool_reaches_a_row_in_an_earlier_step_bubble() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.begin_step("r1", 1);
        chat.update_tool("r1", "t1", "bash", "running", None);
        // Next turn opens: the step-1 bubble is renamed, a fresh
        // `assistant-r1` is pushed. Only then does t1's completion arrive.
        chat.begin_step("r1", 2);
        chat.update_tool("r1", "t1", "bash", "completed", Some(90));

        assert_eq!(
            rows(&chat),
            vec![("t1".to_string(), "completed".to_string(), Some(90))],
            "one row, settled in place — not a stuck row plus a phantom copy"
        );
    }

    #[test]
    fn reconcile_tools_is_authoritative_over_the_streamed_status() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.update_tool("r1", "t1", "bash", "running", None);

        chat.reconcile_tools(
            "r1",
            &[ToolSettlement {
                tool_id: "t1".into(),
                tool_name: "bash".into(),
                duration_ms: 33,
                success: false,
            }],
        );
        assert_eq!(
            rows(&chat),
            vec![("t1".to_string(), "failed".to_string(), Some(33))]
        );
        // Empty settlement list is a no-op, not a wipe.
        chat.reconcile_tools("r1", &[]);
        assert_eq!(rows(&chat).len(), 1);
    }

    #[test]
    fn settle_orphan_tools_touches_only_running_rows_of_that_run() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1");
        chat.update_tool("r1", "done", "bash", "completed", Some(5));
        chat.update_tool("r1", "stuck", "bash", "running", None);
        chat.start_assistant_message("r2");
        chat.update_tool("r2", "other", "bash", "running", None);

        chat.settle_orphan_tools("r1");

        let by_id: std::collections::HashMap<_, _> = rows(&chat)
            .into_iter()
            .map(|(id, status, _)| (id, status))
            .collect();
        assert_eq!(by_id["done"], "completed", "terminal rows are left alone");
        assert_eq!(by_id["stuck"], TOOL_STATUS_UNKNOWN);
        assert_eq!(
            by_id["other"], "running",
            "another run's live tool must keep running"
        );
    }

    /// Asserting the effect arrives, not that the call happened. `mark_queued`
    /// is guarded on `active_run_id`, and the canonical first-frame path is
    /// `apply_run_queued` setting `active_run_id` for a conversation that has
    /// not seen the run yet — this is the only path the whole queued phase
    /// depends on (T2.10 out-of-order guard means a Thinking/Streaming/Error
    /// phase is left alone, so the test must start from `Idle`).
    #[test]
    fn marking_a_run_queued_moves_the_phase() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        // `apply_run_queued`'s first half: adopt when nothing else is in flight.
        chat.active_run_id.set(Some("run-a".into()));
        chat.mark_queued("run-a", 2);
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Queued { ahead: 2 });
    }

    /// A lane frame for a sibling run — another tab, a channel, cron — must not
    /// repaint this conversation.
    #[test]
    fn a_sibling_runs_lane_frame_repaints_nothing() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("run-a");
        chat.mark_queued("run-b", 5);
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Thinking);
    }

    /// Admission is the edge that ends the wait. It cannot ride on
    /// `start_assistant_message`: that early-returns once the bubble exists,
    /// and by admission time the queued frame has already created it — so
    /// without this the phase reads "queued" for the whole of model latency.
    #[test]
    fn admission_clears_the_queued_phase_and_touches_nothing_else() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("run-a");
        chat.mark_queued("run-a", 1);
        chat.mark_admitted("run-a");
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Thinking);

        // Every other phase is left exactly as it was: admission answers only
        // "the wait is over", never "what is happening now".
        chat.phase.set(ChatPhase::Streaming);
        chat.mark_admitted("run-a");
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Streaming);

        // And a sibling run's admission is not this conversation's news:
        // the phase was Queued, a sibling admit must not flip it to Thinking.
        chat.phase.set(ChatPhase::Queued { ahead: 1 });
        chat.mark_admitted("run-b");
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Queued { ahead: 1 });
    }

    /// Out-of-order `run_queued` after `run_admitted` must NOT flip the
    /// phase back to `Queued` (T2.10).
    ///
    /// The mirror image of `mark_admitted`'s "only ever flips Queued →
    /// Thinking" guard. Once the run is admitted (or further along), a
    /// stale lane frame arriving later — the server may have queued it
    /// while we were reconnecting, or a re-attach replayed a snapshot —
    /// must not regress the UI from "the model is thinking/streaming" to
    /// "queued: 1 ahead". Without this guard the user sees the busy
    /// indicator swap to "waiting" for an already-running turn.
    #[test]
    fn mark_queued_after_admitted_does_not_flip_back_to_queued() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();

        // The exact brief sequence: admitted first, stale queued frame second.
        chat.start_assistant_message("run-1");
        chat.mark_admitted("run-1");
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Thinking);
        chat.mark_queued("run-1", 1);
        assert_eq!(
            chat.phase.get_untracked(),
            ChatPhase::Thinking,
            "a queued frame arriving after admission must be ignored"
        );

        // The same guard fires further along the timeline.
        chat.phase.set(ChatPhase::Streaming);
        chat.mark_queued("run-1", 1);
        assert_eq!(
            chat.phase.get_untracked(),
            ChatPhase::Streaming,
            "a queued frame mid-stream must not regress the UI"
        );

        chat.phase.set(ChatPhase::Error);
        chat.mark_queued("run-1", 1);
        assert_eq!(
            chat.phase.get_untracked(),
            ChatPhase::Error,
            "even after an error the wait indicator is not the truth"
        );

        // And the guard must NOT prevent the legitimate transition: from
        // `Idle`, a fresh queued frame still drives the phase to Queued.
        // Mirror `apply_run_queued`'s adoption half: set active_run_id
        // directly so phase stays Idle (start_assistant_message would set
        // it to Thinking and the guard would (correctly) fire).
        let chat2 = ChatState::new();
        chat2.active_run_id.set(Some("run-2".into()));
        chat2.mark_queued("run-2", 2);
        assert_eq!(
            chat2.phase.get_untracked(),
            ChatPhase::Queued { ahead: 2 },
            "guard only protects non-queued phases; the happy path still works"
        );

        // And within Queued itself, a smaller `ahead` still updates — the
        // lane is moving, this is not the out-of-order frame the guard
        // exists to catch.
        chat2.mark_queued("run-2", 0);
        assert_eq!(
            chat2.phase.get_untracked(),
            ChatPhase::Queued { ahead: 0 },
            "legitimate forward-progress lane updates must still apply"
        );
    }

    /// Pins the fact `platform::phone::chat::composer`'s `running` predicate
    /// depends on: unlike `fail_run`, `set_send_error` is NOT scoped to a run
    /// id — it flips `phase` to `Error` unconditionally and leaves
    /// `active_run_id` exactly as it was. That is why the phone composer's
    /// busy check cannot rely on `phase.is_busy()` alone (`Error` reads
    /// `false`) and must also check `active_run_id.get().is_some()` — a
    /// `flush_queue` steer-send failing on a transient error while the real
    /// run is still streaming must not read as idle. If this test ever goes
    /// red, `set_send_error` became run-scoped and the second arm in
    /// `composer.rs` can be reconsidered — by a person reading this failure,
    /// not by someone "simplifying" a line they assume is dead weight.
    #[test]
    fn set_send_error_flips_phase_without_touching_the_active_run() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("run-a");
        assert_eq!(chat.phase.get_untracked(), ChatPhase::Thinking);

        chat.set_send_error(ChatSendError::new(
            ChatSendErrorCode::CloudSendFailed,
            "boom",
        ));

        assert_eq!(chat.phase.get_untracked(), ChatPhase::Error);
        assert_eq!(
            chat.active_run_id.get_untracked().as_deref(),
            Some("run-a"),
            "set_send_error must not clear active_run_id — the run it \
             failed to steer into is still in flight server-side"
        );
    }
}

#[cfg(test)]
mod queue_tests {
    use super::*;

    fn prompt(text: &str, attachments: usize) -> QueuedPrompt {
        QueuedPrompt {
            text: text.to_string(),
            attachments: (0..attachments)
                .map(|i| PendingAttachment {
                    name: format!("f{i}"),
                    mime_type: "text/plain".into(),
                    data_base64: String::new(),
                    size: 0,
                })
                .collect(),
        }
    }

    #[test]
    fn label_uses_trimmed_text() {
        assert_eq!(queue_preview_label(&prompt("  hello  ", 0)), "hello");
    }

    #[test]
    fn label_truncates_on_codepoint_boundary() {
        let long = "a".repeat(100);
        let out = queue_preview_label(&prompt(&long, 0));
        assert!(out.ends_with('…'));
        assert_eq!(out.chars().count(), 65); // 64 chars + ellipsis
    }

    #[test]
    fn label_falls_back_to_attachment_count() {
        assert_eq!(queue_preview_label(&prompt("   ", 2)), "📎 2");
    }

    #[test]
    fn drain_all_queued_empties_and_preserves_order() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.enqueue_prompt(prompt("a", 0));
        chat.enqueue_prompt(prompt("b", 0));
        let drained = chat.drain_all_queued();
        let texts: Vec<_> = drained.iter().map(|p| p.text.clone()).collect();
        assert_eq!(texts, vec!["a", "b"]);
        assert!(chat.prompt_queue.get_untracked().is_empty());
    }

    #[test]
    fn a_queued_runs_failure_does_not_tear_down_the_live_run() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("live");

        // A second run id the Panel is holding — queued in the gateway's wait
        // lane — fails (purged by a Stop, rejected by a full lane, timed out).
        chat.fail_run("queued", "queue full", None);

        assert_eq!(
            chat.active_run_id.get_untracked().as_deref(),
            Some("live"),
            "the live run must survive another run's failure"
        );
        assert!(
            chat.send_error.get_untracked().is_some(),
            "the failure is still reported — it just does not end the live run"
        );

        // The live run's own failure does tear it down.
        chat.fail_run("live", "provider unreachable", None);
        assert!(chat.active_run_id.get_untracked().is_none());
    }

    #[test]
    fn a_stop_suppression_swaps_with_the_conversation_that_earned_it() {
        // Pressing Stop in one conversation must not spend the suppression owed
        // to whichever conversation the user opens next — the queue it gates is
        // per-conversation, so the flag has to travel with it.
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.enqueue_prompt(prompt("stopped conversation's queue", 0));
        chat.stop_suppresses_next_drain.set(true);
        let stopped = chat.capture_snapshot();

        // Open a different conversation: it owes no suppression.
        chat.restore_from(SessionSnapshot::default());
        assert!(
            !chat.stop_suppresses_next_drain.get_untracked(),
            "a fresh conversation must not inherit another one's Stop"
        );

        // Back to the one that was stopped: its suppression is still armed.
        chat.restore_from(stopped);
        assert!(chat.stop_suppresses_next_drain.get_untracked());
    }

    #[test]
    fn a_failed_flush_gives_the_unsent_prompts_back_ahead_of_newer_ones() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.enqueue_prompt(prompt("a", 0));
        chat.enqueue_prompt(prompt("b", 0));

        // Flush drains the batch; the first send fails, so nothing was sent.
        let batch = chat.drain_all_queued();
        // Meanwhile the user queues another one.
        chat.enqueue_prompt(prompt("typed during the flush", 0));
        chat.requeue_front(batch);

        let texts: Vec<_> = chat
            .prompt_queue
            .get_untracked()
            .into_iter()
            .map(|p| p.text)
            .collect();
        assert_eq!(
            texts,
            vec!["a", "b", "typed during the flush"],
            "prompts that never left the client keep their place in the arrival order"
        );
    }

    #[test]
    fn recall_takes_the_newest_and_shortens_the_queue() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.enqueue_prompt(prompt("a", 0));
        chat.enqueue_prompt(prompt("b", 0));

        assert_eq!(
            chat.recall_latest_queued().map(|p| p.text).as_deref(),
            Some("b")
        );
        assert_eq!(
            chat.prompt_queue.get_untracked().len(),
            1,
            "the recalled prompt must leave the queue, not be copied out of it"
        );
        assert_eq!(
            chat.recall_latest_queued().map(|p| p.text).as_deref(),
            Some("a")
        );
        assert!(
            chat.recall_latest_queued().is_none(),
            "an empty queue recalls nothing"
        );
    }

    #[test]
    fn two_recalls_before_the_composer_drains_keep_both_and_their_order() {
        // The composer's drain runs in an Effect, i.e. after the keystroke.
        // Two fast presses must not let the second seed overwrite the first —
        // that would silently destroy a queued message.
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.enqueue_prompt(prompt("first", 0));
        chat.enqueue_prompt(prompt("second", 0));

        for _ in 0..2 {
            let entry = chat.recall_latest_queued().expect("queued prompt");
            chat.seed_draft(entry.text, entry.attachments);
        }

        assert_eq!(
            chat.draft.get_untracked(),
            "first\n\nsecond",
            "recalling from the tail and prepending rebuilds the queue's order"
        );
        assert!(chat.prompt_queue.get_untracked().is_empty());
    }

    #[test]
    fn recall_joins_an_in_progress_draft_instead_of_replacing_it() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.draft.set("half a thought".into());
        chat.enqueue_prompt(prompt("queued", 0));

        let entry = chat.recall_latest_queued().expect("queued prompt");
        chat.seed_draft(entry.text, entry.attachments);

        assert_eq!(chat.draft.get_untracked(), "queued\n\nhalf a thought");
    }

    #[test]
    fn a_tab_swap_carries_the_draft_with_the_queue_and_the_tray() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.draft.set("conversation A's unsent line".into());
        chat.enqueue_prompt(prompt("A queued", 0));
        let snap = chat.capture_snapshot();

        // Project conversation B over the same signals, then come back to A.
        chat.draft.set("conversation B's line".into());
        chat.prompt_queue.set(Vec::new());
        chat.restore_from(snap);

        assert_eq!(
            chat.draft.get_untracked(),
            "conversation A's unsent line",
            "the draft must swap with the conversation, not linger on the next one"
        );
        assert_eq!(chat.prompt_queue.get_untracked().len(), 1);
    }

    #[test]
    fn seeding_a_prompt_with_files_stages_them_ahead_of_what_is_already_attached() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.pending_attachments.set(prompt("", 1).attachments);

        chat.seed_draft("recalled".into(), prompt("", 2).attachments);

        assert_eq!(
            chat.pending_attachments.get_untracked().len(),
            3,
            "a recalled prompt's files must join the staged ones, not replace them"
        );
    }

    #[test]
    fn taking_a_queued_prompt_by_index_returns_it_and_removes_it_once() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.enqueue_prompt(prompt("a", 0));
        chat.enqueue_prompt(prompt("b", 0));

        assert_eq!(
            chat.take_queued_prompt(0).map(|p| p.text).as_deref(),
            Some("a")
        );
        let left: Vec<_> = chat
            .prompt_queue
            .get_untracked()
            .into_iter()
            .map(|p| p.text)
            .collect();
        assert_eq!(left, vec!["b"]);
        assert!(
            chat.take_queued_prompt(7).is_none(),
            "an out-of-range index must not disturb the queue"
        );
        assert_eq!(chat.prompt_queue.get_untracked().len(), 1);
    }

    // --- The four guards behind index-addressed ghost rows -----------------
    //
    // `take_queued_prompt(idx)` / `remove_queued_prompt(idx)` trust an index a
    // row's click handler captured when it was built. Nothing in `ChatState`
    // enforces that the index is still current — the property lives entirely in
    // the `<For>` key over in `messages.rs`, which is what these pin.

    #[test]
    fn a_shifted_row_never_keeps_its_key() {
        // Draining the head (turn-boundary flush / busy→idle auto-drain) shifts
        // every survivor down by one. Each must get a key it did not hold
        // before, or Leptos keeps the old row — and with it a handler pointing
        // one slot past the prompt the user is looking at.
        let before: Vec<String> = ["a", "b", "c"]
            .iter()
            .enumerate()
            .map(|(i, t)| queue_row_key(i, &prompt(t, 0)))
            .collect();
        let after: Vec<String> = ["b", "c"]
            .iter()
            .enumerate()
            .map(|(i, t)| queue_row_key(i, &prompt(t, 0)))
            .collect();

        for key in &after {
            assert!(
                !before.contains(key),
                "row key {key} survived a head drain unchanged — its handler \
                 would keep the stale index and address the wrong prompt"
            );
        }
    }

    #[test]
    fn two_identical_prompts_get_distinct_keys() {
        // Two identical follow-ups are ordinary ("go on" twice). Keyed on the
        // text alone they collapse into one row: the second is never built, and
        // the survivor answers for whichever index reconciled first.
        assert_ne!(
            queue_row_key(0, &prompt("same", 0)),
            queue_row_key(1, &prompt("same", 0)),
            "the row key must depend on the position, not only on the text"
        );
    }

    #[test]
    fn editing_the_text_at_one_position_changes_the_key() {
        // The mirror failure: keyed on the index alone, removing row 0 leaves
        // row 0 rendering the prompt that was just taken away.
        assert_ne!(
            queue_row_key(0, &prompt("before", 0)),
            queue_row_key(0, &prompt("after", 0)),
            "the row key must depend on the text, not only on the position"
        );
    }

    #[test]
    fn the_ghost_row_view_actually_uses_the_shared_key() {
        // The three above pin what `queue_row_key` returns; this one pins that
        // the view asks for it. Without it, inlining a different key expression
        // back into `messages.rs` leaves all of them green while the property
        // they describe stops holding in the browser — this repo's recurring
        // shape, where the guard asserted the call and not the effect. A source
        // assertion is the only handle a host test has on a Leptos view.
        let src = include_str!("../messages.rs");
        let body = src
            .split("fn QueuedGhosts()")
            .nth(1)
            .expect("messages.rs must still define QueuedGhosts");
        let body = body.split("#[component]").next().unwrap_or(body);
        let compact: String = body.chars().filter(|c| !c.is_whitespace()).collect();

        assert!(
            compact.contains("key=|(idx,e)|queue_row_key(*idx,e)"),
            "QueuedGhosts must key its <For> with `queue_row_key` — see that \
             function's doc for why the captured index depends on it"
        );
    }
}

#[cfg(test)]
mod tool_timestamp_tests {
    use super::*;

    #[test]
    fn update_tool_stamps_started_at_on_first_running() {
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.start_assistant_message("r1"); // 建 assistant-r1 容器
        chat.update_tool("r1", "t1", "bash", "running", None);
        let started = chat.messages.with_untracked(|m| {
            m.iter()
                .flat_map(|m| m.tool_calls.iter())
                .find(|t| t.tool_id == "t1")
                .and_then(|t| t.started_at_ms)
        });
        assert!(started.is_some(), "first running must stamp started_at_ms");

        // don't overwrite timestamp on completion
        chat.update_tool("r1", "t1", "bash", "completed", Some(30));
        let after = chat.messages.with_untracked(|m| {
            m.iter()
                .flat_map(|m| m.tool_calls.iter())
                .find(|t| t.tool_id == "t1")
                .map(|t| (t.started_at_ms, t.status.clone()))
        });
        assert_eq!(after.map(|(s, _)| s), Some(started));
    }
}

#[cfg(test)]
mod run_cost_tests {
    use super::*;

    fn cost(usd: Option<f64>, status: &str, total: u64) -> RunCost {
        RunCost {
            usd,
            status: Some(status.to_string()),
            total_tokens: total,
            input_tokens: 0,
            output_tokens: 0,
            cache_read_tokens: 0,
            cache_creation_tokens: 0,
        }
    }

    fn cached(read: u64, created: u64) -> RunCost {
        RunCost {
            cache_read_tokens: read,
            cache_creation_tokens: created,
            ..cost(None, "complete", 0)
        }
    }

    #[test]
    fn prefix_reuse_is_read_over_read_plus_created() {
        // A run that found everything in cache; a run that found nothing.
        assert_eq!(cached(900, 100).prefix_reuse(), Some(0.9));
        assert_eq!(cached(0, 5_000).prefix_reuse(), Some(0.0));
        // No cache activity at all is not "0% reuse" — it is no answer. A
        // provider without prompt caching must not render as a broken cache.
        assert_eq!(cached(0, 0).prefix_reuse(), None);
    }

    #[test]
    fn session_prefix_reuse_sums_every_priced_run() {
        // The first run of a session writes the prefix and reads nothing, so
        // per-run it reads 0% — only the cumulative figure is meaningful.
        let owner = Owner::new();
        owner.set();
        let chat = ChatState::new();
        chat.set_run_cost("r1", cached(0, 1_000));
        assert_eq!(chat.session_prefix_reuse(), Some(0.0));

        chat.set_run_cost("r2", cached(3_000, 0));
        assert_eq!(chat.session_prefix_reuse(), Some(0.75));
    }

    #[test]
    fn a_fully_priced_run_renders_an_exact_figure() {
        let c = cost(Some(0.1234), "complete", 12_345);
        assert!(c.is_exact());
        assert_eq!(c.cost_label().as_deref(), Some("$0.12"));
        assert_eq!(c.tokens_label().as_deref(), Some("12.3k tok"));
    }

    #[test]
    fn a_partially_priced_run_is_never_passed_off_as_exact() {
        // THE contract: core could not price every model in the run, so the
        // figure must read as an approximation.
        let c = cost(Some(0.5), "partial_missing_price", 900);
        assert!(!c.is_exact());
        assert_eq!(c.cost_label().as_deref(), Some("≈$0.50"));
        assert_eq!(c.tokens_label().as_deref(), Some("900 tok"));
        assert!(!cost(Some(0.5), "unknown", 1).is_exact());
    }

    #[test]
    fn sub_cent_runs_keep_four_decimals() {
        // "$0.00" reads as free; a cheap run is not a free one.
        assert_eq!(
            cost(Some(0.0034), "complete", 10).cost_label().as_deref(),
            Some("$0.0034")
        );
    }

    #[test]
    fn absent_price_or_zero_tokens_render_nothing() {
        // Rendering "$0.00" / "0 tok" for an unpriced or cached turn reads as
        // broken, so both labels stay absent.
        let c = cost(None, "unknown", 0);
        assert!(c.cost_label().is_none());
        assert!(c.tokens_label().is_none());
    }
}

/// `history_window_gap` decides whether the transcript is missing a beginning,
/// and how much of one.
///
/// The interesting cases are all about which of its two inputs wins. The
/// server's `total` is a count; the page length is a guess; and the guess is
/// wrong in a way that is invisible unless it is named — hence a test for the
/// exact shape where they disagree.
#[cfg(test)]
mod history_window_gap_tests {
    use super::history_window_gap;

    #[test]
    fn a_reported_total_larger_than_the_page_is_the_gap() {
        assert_eq!(history_window_gap(200, 200, Some(1_047)), (true, Some(847)));
    }

    /// The one shape where the two inputs disagree, and the whole reason the
    /// server was asked at all: 200 rows fetched with a limit of 200, and the
    /// session holds exactly 200. The page is full AND complete. The guess
    /// (`received >= limit`) calls that truncated and offers a press that can
    /// only find nothing; the count calls it finished.
    #[test]
    fn a_full_page_that_is_also_the_whole_transcript_is_finished_not_truncated() {
        assert_eq!(history_window_gap(200, 200, Some(200)), (false, Some(0)));
        // Byte-for-byte the same window, no answer from the server: now the
        // guess is all there is, and it says the opposite.
        assert_eq!(history_window_gap(200, 200, None), (true, None));
    }

    #[test]
    fn without_a_total_the_depth_stays_unknown_so_the_control_steps_one_page() {
        // `None` for the gap is not zero — it is what makes the press add
        // `HISTORY_PAGE` and the label stay unquantified.
        assert_eq!(history_window_gap(200, 200, None), (true, None));
        // A short page is complete under either rule.
        assert_eq!(history_window_gap(37, 200, None), (false, None));
    }

    #[test]
    fn a_message_appended_between_the_two_server_reads_reads_as_nothing_above() {
        // `total` and the window are two reads; the window can come back
        // longer. Saturating, not wrapping: the honest answer is "nothing
        // above", not `usize::MAX`.
        assert_eq!(history_window_gap(5, 200, Some(4)), (false, Some(0)));
    }

    #[test]
    fn an_empty_session_offers_nothing_to_load() {
        assert_eq!(history_window_gap(0, 200, Some(0)), (false, Some(0)));
        assert_eq!(history_window_gap(0, 200, None), (false, None));
    }
}

/// The two copies of the halt vocabulary, held against each other.
///
/// `RunHalt::label` and `aleph_protocol::terminate::label` answer the same
/// question for different readers — a browser whose language is a UI setting,
/// and a terminal whose language is `LC_MESSAGES`. Both copies are deliberate
/// (see the protocol module's doc for why this crate does not simply call it),
/// and "deliberate" is exactly the condition under which two tables drift
/// without anyone noticing: each has its own tests, each stays green, and the
/// only place the disagreement shows is a screenshot next to a terminal.
#[cfg(test)]
mod halt_vocabulary_is_shared_tests {
    use super::RunHalt;
    use crate::i18n::Locale;
    use aleph_protocol::terminate::{self, UiLocale};

    fn halt(token: &str) -> RunHalt {
        RunHalt {
            reason: token.to_string(),
            detail: None,
        }
    }

    /// Every token the shared table has words for renders the same bytes here.
    ///
    /// Walks [`terminate::labelled_tokens`] rather than restating it, so a
    /// fourteenth row reddens this on the commit that adds it — which is the
    /// whole point: the panel is the copy that has to be edited by hand.
    ///
    /// One row is skipped, and only one: `CLEAN_TOKEN`. The panel never prints
    /// a word for a clean run (`parse_run_halt` returns `None` for it), so a
    /// `chat.halt_completed` key would be a key with no reader — the other half
    /// of the very defect this crate's English sweep was about.
    #[test]
    fn the_panel_says_the_same_words_as_the_terminal_clients() {
        let mut checked = 0usize;
        for token in terminate::labelled_tokens() {
            if token == terminate::CLEAN_TOKEN {
                continue;
            }
            for (panel, shared) in [(Locale::en, UiLocale::En), (Locale::zh, UiLocale::Zh)] {
                assert_eq!(
                    halt(token).label(panel),
                    terminate::label(token, shared),
                    "the panel and aleph_protocol::terminate disagree about {token:?} \
                     in {panel:?}; both are hand-written and this is where they drift",
                );
            }
            checked += 1;
        }
        assert!(
            checked >= 13,
            "only {checked} tokens compared — the shared table shrank, or \
             `labelled_tokens` stopped yielding",
        );
    }

    /// Neither table has a row the other lacks.
    ///
    /// Read off `locales/en.json` rather than off the `match` above, because the
    /// two failure modes are different and only this one sees both: a `match`
    /// arm with no key does not compile, but a **key with no arm** compiles
    /// fine and is dead weight in both locale files, and a **token with no key**
    /// falls through to the raw wire string on screen while every test here
    /// stays green.
    ///
    /// The `halt_` prefix plus the exact token is what makes this decidable at
    /// all; the keys were renamed to that shape (`halt_budget_partial` ->
    /// `halt_budget_exhausted_partial_result`) in the same change that wrote
    /// this guard, because a key whose name only resembles its token can be
    /// compared by a human and by nothing else.
    #[test]
    fn every_halt_key_has_a_token_and_every_token_has_a_key() {
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
        let mut keyed: Vec<String> = Vec::new();
        for locale_file in ["en.json", "zh.json"] {
            let path = root.join("locales").join(locale_file);
            let src = std::fs::read_to_string(&path)
                .unwrap_or_else(|e| panic!("{}: {e}", path.display()));
            let mut here: Vec<String> = src
                .lines()
                .filter_map(|l| l.trim().strip_prefix("\"halt_"))
                .filter_map(|l| l.split('"').next())
                .map(str::to_string)
                .collect();
            here.sort();
            if keyed.is_empty() {
                keyed = here;
            } else {
                assert_eq!(
                    keyed, here,
                    "the two locale files carry different halt keys"
                );
            }
        }
        assert!(
            !keyed.is_empty(),
            "no halt keys found — did the scan break?"
        );

        let mut expected: Vec<String> = terminate::labelled_tokens()
            .filter(|t| *t != terminate::CLEAN_TOKEN)
            .map(str::to_string)
            .collect();
        expected.sort();
        assert_eq!(
            keyed, expected,
            "left = chat.halt_* keys in locales/, right = tokens the shared \
             table has words for. A key on the left only is dead weight; a \
             token on the right only renders as a raw wire string on screen.",
        );
    }
}
