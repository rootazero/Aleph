//! Chat composer — textarea, attachments, slash-command palette,
//! send / abort. The orchestrator only; render plane lives in the
//! `palette` and `attachments` submodules so this file owns only the
//! glue (signals, closures, top-level view layout).
//!
//! Originally a single 815 LOC `composer.rs`. Split per CLAUDE.md P2
//! (high cohesion, low coupling) — each submodule is independently
//! testable and the orchestrator now fits inside the 400 LOC ceiling.

// `pub(crate)`: the phone composer reuses the same file reader and preview bar
// rather than growing a second attachment pipeline (`PendingAttachment` and the
// tray on `ChatState` are already shared, so a second reader would only be a
// second place for the base64 dance to drift).
pub(crate) mod appearance_command;
pub(crate) mod attachments;
mod palette;
mod voice;

use super::mention_palette::{update_mention_palette, MentionPaletteView};
use super::project_menu::ProjectMenu;
use super::state::{
    ChatPhase, ChatSendError, ChatSendErrorCode, ChatState, QueuedPrompt, TeamMemberView,
};
use super::TodoPanel;
use crate::api::chat::{ChatApi, ChatAttachment};
use crate::components::team_task_strip::TeamTaskStrip;
use crate::context::DashboardState;
use crate::i18n::{t_string, use_i18n};
use crate::state::sessions::{ConvId, SessionMap};
use attachments::{read_file_list_into, AttachmentPreviewBar};
use leptos::prelude::*;
use leptos::task::spawn_local;
use palette::{
    build_palette_entries, doctor_command_info, is_doctor_command, parse_command_info, CommandInfo,
    PaletteEntry, PaletteLabels, SlashPaletteView,
};
use shared_ui_logic::safety::{
    check_prompt_injection, prompt_guard_message, PromptInjectionVerdict,
};
use shared_ui_logic::state::{
    session_dials_for_send, should_auto_drain_on_settle, should_flush_on_turn_boundary,
    should_recall_on_bare_arrow_up, was_busy_across_switch,
};
use wasm_bindgen::closure::Closure;
use wasm_bindgen::JsCast;

// The instruction seeded by the `f` hotkey (G1) lives in
// `chat.doctor_repair_prompt` — a locale key, not a Rust item, hence `//`. The
// doctor tool only diagnoses and applies safe mechanical repairs; the
// *reasoning* repair lives entirely in that prompt (R7/R9), not in any
// deterministic branch. It tells the LLM to read the structured findings and
// route each one: mechanical issues via `doctor(fix=true)`, everything else
// through the tool named in the finding's `fix_hint` (`self_config` /
// `vault_store` / …), then re-verify. It is copy, not config: it is the
// *user's* message in the transcript, so a reader who picked English must not
// be made to send Chinese.

/// Textarea + side buttons + palette popup + injection-guard banner.
/// Mounted by [`super::view::ChatView`] at the viewport bottom, and (P2 Task
/// 8) directly by `components::project_page::RoomChat` — a project room's
/// chat tab reuses this and [`super::messages::MessageList`] rather than
/// re-mounting `ChatView` itself, which would double-subscribe the
/// `stream.*`/`team.*` Gateway topics `ChatView` owns (see that component's
/// doc). `pub(crate)` for that second caller.
#[component]
#[must_use]
pub(crate) fn InputArea() -> impl IntoView {
    let dashboard = expect_context::<DashboardState>();
    let chat = expect_context::<ChatState>();
    let sessions = expect_context::<SessionMap>();
    let i18n = use_i18n();

    // The unsent draft lives on ChatState next to the attachment tray and the
    // prompt queue it belongs with, so a tab swap carries all three together
    // instead of keeping the text on the wrong conversation. It is also how
    // anything outside the composer (starter chips, the queued-ghost tap,
    // keyboard recall) puts a prompt back in front of the user.
    let input_text = chat.draft;
    let is_sending = RwSignal::new(false);
    // One-shot flag: set when the user presses Stop, consumed by the queue
    // drain Effect so an explicit interrupt suppresses exactly one auto-drain
    // (mirrors hermes-agent's `shouldAutoDrainOnSettle`). Kept on ChatState —
    // the queue it gates is per-conversation, and while this was a composer
    // signal a Stop in one conversation consumed the suppression owed to
    // whichever one the user opened next.
    let user_interrupted = chat.stop_suppresses_next_drain;
    // Attachments live on ChatState so the chat-surface drop zone (G5)
    // can share the same list as the paperclip input.
    let attachments = chat.pending_attachments;

    // IME composition gate (T1.2) — Chinese IMEs (pinyin / wubi) fire a
    // trailing `keydown(Enter)` after `compositionend` with `isComposing`
    // already cleared, which would otherwise dispatch `send_message`. The
    // gate swallows Enter while a composition is active and for a short
    // "recently settled" window afterwards. Logic lives in the pure
    // `ImeGate` struct (unit-tested at the bottom of this file) so the
    // gate is not coupled to leptos signals or the keyboard-event closure
    // (which is structurally untestable in this crate's `csr` build — see
    // the A1 report's parked render-test blocker).
    let ime_gate = RwSignal::new(ImeGate::new());

    // Palette state — populated lazily on first `/`.
    let all_commands: RwSignal<Vec<CommandInfo>> =
        RwSignal::new(vec![appearance_command::theme_command_info(
            t_string!(i18n, appearance.popover_title).to_string(),
        )]);
    let show_palette = RwSignal::new(false);
    let theme_command_open = RwSignal::new(false);
    let theme_command_invalid = RwSignal::new(false);
    let theme_command_selected = RwSignal::new(0usize);
    let palette_entries: RwSignal<Vec<PaletteEntry>> = RwSignal::new(Vec::new());
    let selected_index = RwSignal::new(0usize);
    let commands_loaded = RwSignal::new(false);
    let current_namespace: RwSignal<Option<String>> = RwSignal::new(None);

    // @-mention palette state — team mode only.
    let show_mention = RwSignal::new(false);
    let mention_members: RwSignal<Vec<TeamMemberView>> = RwSignal::new(Vec::new());
    let mention_selected = RwSignal::new(0usize);
    // Byte offset of the active `@` in `input_text` (None when palette hidden).
    let mention_at: RwSignal<Option<usize>> = RwSignal::new(None);

    let file_input_ref = NodeRef::<leptos::html::Input>::new();
    let stack_ref = NodeRef::<leptos::html::Div>::new();
    let textarea_ref = NodeRef::<leptos::html::Textarea>::new();

    // Composer height → `--composer-clearance` on <html>, so the scroll
    // content + jump pill always clear the floating bar (queue bar /
    // attachments / multiline growth included). Mirrors the ResizeObserver
    // pattern in the galaxy canvas gl engine.
    //
    // The observer and its closure are kept alive in a LocalStorage slot so
    // they can be disconnected on cleanup instead of leaking via `cb.forget()`.
    let resize_handle: StoredValue<
        Option<(web_sys::ResizeObserver, Closure<dyn FnMut(js_sys::Array)>)>,
        LocalStorage,
    > = StoredValue::new_local(None);

    Effect::new(move |_| {
        let Some(el) = stack_ref.get() else { return };
        // Disconnect any previous observer before installing a new one.
        if let Some((old, _)) = resize_handle.try_update_value(|opt| opt.take()).flatten() {
            old.disconnect();
        }
        let cb: Closure<dyn FnMut(js_sys::Array)> = Closure::new(move |entries: js_sys::Array| {
            if let Ok(entry) = entries.get(0).dyn_into::<web_sys::ResizeObserverEntry>() {
                let h = entry.content_rect().height();
                if let Some(root) = web_sys::window()
                    .and_then(|w| w.document())
                    .and_then(|d| d.document_element())
                    .and_then(|e| e.dyn_into::<web_sys::HtmlElement>().ok())
                {
                    let _ = root
                        .style()
                        .set_property("--composer-clearance", &format!("{}px", h + 40.0));
                }
            }
        });
        if let Ok(observer) = web_sys::ResizeObserver::new(cb.as_ref().unchecked_ref()) {
            observer.observe(&el);
            resize_handle.set_value(Some((observer, cb)));
        }
    });

    on_cleanup(move || {
        if let Some((obs, _cb)) = resize_handle.try_update_value(|opt| opt.take()).flatten() {
            obs.disconnect();
        }
    });

    // Auto-grow the composer textarea to fit its content. We track the
    // `input_text` signal (not just the DOM `input` event) so every
    // programmatic rewrite — send-clear, retry refill, draft seed, slash/@
    // completion, clear button, queue replay — resizes too. Set height to
    // `auto` first so the box can shrink, then to `scroll_height`; CSS
    // `max-h-[140px]` caps it and `overflow-y-auto` scrolls beyond the cap.
    Effect::new(move |_| {
        let text = input_text.get();
        if let Some(ta) = textarea_ref.get() {
            // Ordering, and why this needs an explicit write. Typing updates
            // the DOM *first* (the browser does it) and the signal second, so
            // `scroll_height` already measures the new text. A programmatic
            // rewrite is the mirror image: the signal changes first and Leptos
            // flushes `prop:value` into the element *after* this effect runs,
            // so the node still holds the previous text and we would size the
            // box to it. That is why none of the rewrites this comment claims
            // to cover actually resized — an emptied composer stayed tall, and
            // a multi-line recall was clipped to its first line. Write the
            // value ourselves, but only when it differs: on the typing path it
            // already matches, and assigning `value` would drop the caret to
            // the end mid-word.
            if ta.value() != text {
                ta.set_value(&text);
            }
            // Cast to HtmlElement so `.style()` resolves to the web-sys
            // inherent method, not Leptos's `ElementExt::style` (which is in
            // scope and would otherwise shadow it on HtmlTextAreaElement).
            let el: web_sys::HtmlElement = ta.unchecked_into();
            let _ = el.style().set_property("height", "auto");
            let _ = el
                .style()
                .set_property("height", &format!("{}px", el.scroll_height()));
        }
    });

    // i18n labels threaded into the pure palette builder so palette.rs
    // stays free of i18n macros (and unit-testable).
    let palette_labels = move || PaletteLabels {
        back: t_string!(i18n, chat.back).to_string(),
        back_desc: t_string!(i18n, chat.back_desc).to_string(),
    };

    let intercept_theme = move |raw: &str| -> bool {
        use appearance_command::{parse_theme_request, ThemeRequest};
        let Some(request) = parse_theme_request(raw) else {
            return false;
        };
        if let ThemeRequest::Apply(mode) = request {
            crate::appearance::apply_mode(mode);
        }
        theme_command_invalid.set(request == ThemeRequest::Invalid);
        theme_command_open.set(true);
        theme_command_selected.set(
            crate::appearance::ThemeMode::ALL
                .iter()
                .position(|mode| *mode == crate::appearance::read_mode())
                .unwrap_or(0),
        );
        input_text.set(String::new());
        show_palette.set(false);
        current_namespace.set(None);
        true
    };

    let send_message = move || {
        if intercept_theme(&input_text.get_untracked()) {
            return;
        }
        if is_sending.get_untracked() {
            return;
        }
        let raw = input_text.get_untracked().trim().to_string();
        // `/doctor` → seed the read-only detection prompt and route it through
        // the normal LLM pipeline, mirroring the `f`-hotkey repair flow. Done
        // before send so the literal slash command never reaches the gateway
        // fast path (which would run the tool deterministically, no LLM).
        let text = if is_doctor_command(&raw) {
            t_string!(i18n, chat.doctor_detect_prompt).to_string()
        } else {
            raw
        };
        let files = attachments.get_untracked();
        if text.is_empty() && files.is_empty() {
            return;
        }

        // `teams.chat.send` carries `{team_id, message}` only — there is no
        // attachment leg on the group transcript. The team branch below used to
        // run AFTER the tray was cleared, so a user who attached a spec and hit
        // Enter watched it vanish with no reply and no error. Refuse the send
        // instead, and leave the tray intact so nothing is lost.
        if chat.team_id.get_untracked().is_some() && !files.is_empty() {
            chat.set_send_error(ChatSendError::new(
                ChatSendErrorCode::Unsupported,
                t_string!(i18n, chat.team_attachments_unsupported).to_string(),
            ));
            return;
        }

        // G1 client-side prompt-injection guard — hard-blocks save a
        // wasted round-trip; reviews are surfaced live by the banner
        // below but still permitted through (server is final authority).
        if !text.is_empty() {
            let check = check_prompt_injection(&text);
            if check.verdict == PromptInjectionVerdict::Block {
                chat.set_send_error(ChatSendError::new(
                    ChatSendErrorCode::PromptBlocked,
                    prompt_guard_message(&check),
                ));
                return;
            }
        }

        is_sending.set(true);
        input_text.set(String::new());
        attachments.set(Vec::new());
        chat.push_user_message_with_attachments(&text, &files);

        // Team chat mode: route the requirement to the leader orchestration RPC
        // instead of the single-agent ChatApi::send. Early return skips the
        // single-agent path below.
        if let Some(team_id) = chat.team_id.get_untracked() {
            let dash = dashboard;
            let team_text = text.clone();
            // Optimistic busy state: the authoritative signal is the
            // `team.<id>.fanout` `started` event, but that is a round-trip away
            // and the first member reply can be a minute out. Without this the
            // group chat sits visually idle right after Enter, exactly the
            // stretch where the user most needs to see something happening.
            chat.phase.set(ChatPhase::Thinking);
            spawn_local(async move {
                match crate::api::team_chat::TeamChatApi::send(&dash, &team_id, &team_text).await {
                    Ok(resp) => {
                        // Both send outcomes (activated or observed) fire the
                        // SAME live `team.<id>.message` echo of this bubble —
                        // remember the id so `team_events` recognizes and
                        // skips it rather than rendering a duplicate.
                        if let Some(mid) = resp.message_id {
                            chat.remember_own_team_message(mid);
                        }
                        if resp.observed {
                            // Multi-human mention gate (spec §6.2): no roster
                            // member was addressed, so no run was minted — no
                            // `team.<id>.fanout` event is ever coming to flip
                            // this back to idle. The bubble is already up
                            // (pushed optimistically above); observe mode
                            // just never becomes a Stop button.
                            chat.phase.set(ChatPhase::Idle);
                        }
                    }
                    Err(e) => {
                        // The fan-out never started, so no `settled` event is
                        // coming — drop back to idle or the composer hangs on
                        // "thinking".
                        chat.phase.set(ChatPhase::Idle);
                        chat.set_send_error(ChatSendError::classify(e));
                    }
                }
                is_sending.set(false);
            });
            return;
        }

        // `iter().cloned()`, not `into_iter()`: `files` has to survive the send
        // so a failure can hand it back (see the `Err` arm below).
        let api_attachments: Vec<ChatAttachment> = files
            .iter()
            .cloned()
            .map(|f| ChatAttachment {
                name: f.name,
                mime_type: f.mime_type,
                data_base64: f.data_base64,
                size: f.size,
            })
            .collect();

        let session_key = chat.session_key.get();
        let agent_id = chat.agent_id.get();
        // A project-room conversation (`room_project_id` set) sends
        // `project_id` and forces `project_root` to `None` — an explicit
        // `project_root` outranks the room's workspace binding and is
        // refused server-side for remote chat-tier callers. Kept
        // unconditional even though `ProjectMenu` is now hidden in a room and
        // `ChatState::set_active_project` early-returns there: this is the
        // last of the three, and it is the one that holds if a future surface
        // writes `active_project_root` by some other route.
        let room_project_id = chat.room_project_id.get();
        let project_root = if room_project_id.is_some() {
            None
        } else {
            chat.active_project_root.get()
        };
        // Per-turn model override stamped on ChatState → daemon's run
        // loop short-circuits its provider-fallback chain.
        let model_override = chat.selected_model.get();
        // The per-session dials. The rule (tier every send, the store-owned
        // three only on the first) is `session_dials_for_send` — shared with
        // the phone composer, which has to agree with this one exactly.
        let dials = session_dials_for_send(session_key.is_some(), &chat.session_knobs());
        // Capture the conversation active at *send* time. Binding the run to
        // this (rather than to whichever tab is focused when `run_accepted`
        // arrives) is what lets the user send in A, switch to B, and still have
        // A's reply stream into A (I1).
        let send_conv = sessions.active_conv();
        let dash = dashboard;
        spawn_local(async move {
            let sk = session_key.as_deref();
            let aid = agent_id.as_deref();
            let pr = project_root.as_deref();
            let pid = room_project_id.as_deref();
            let mo = model_override.as_ref();
            match ChatApi::send(
                &dash,
                &text,
                sk,
                api_attachments,
                aid,
                pr,
                pid,
                mo,
                &dials,
                false,
            )
            .await
            {
                Ok(resp) => {
                    if let Some(conv) = send_conv {
                        sessions.bind_run(&resp.run_id, conv, Some(&resp.session_key));
                    }
                    chat.session_key.set(Some(resp.session_key));
                }
                Err(e) => {
                    // Structured error → banner colour-codes (warn vs
                    // error); analytics can branch on the code.
                    chat.set_send_error(ChatSendError::classify(e));
                    // Nothing reached the server, so the payload comes back.
                    // The *text* already survives — the optimistic bubble is in
                    // the transcript and Retry re-sends it from
                    // `last_user_text()` — but that path is text-only, so the
                    // files were gone for good: the user was shown a Retry
                    // button that silently dropped the attachment they came
                    // for. `seed_draft` is the single restore entry point and
                    // merges rather than overwrites, so files staged while this
                    // send was in flight survive too.
                    //
                    // The queue flush below has always done this (via
                    // `requeue_front`, which hands back the whole entry). Only
                    // the typed path was asymmetric.
                    chat.seed_draft(String::new(), files);
                }
            }
            is_sending.set(false);
        });
    };

    // The question this conversation is parked on, if any.
    let pending_ask = Memo::new(move |_| {
        crate::state::notifications::pending_ask_for_session(
            &dashboard.pending_clarifications.get(),
            chat.session_key.get().as_deref(),
        )
        .cloned()
    });

    // Queue a follow-up while a run is active instead of sending it now.
    // Runs the same client-side injection guard as `send_message` so a
    // blocked prompt never enters the queue, then stashes the draft on
    // `ChatState` and clears the composer for the next line of input.
    let enqueue_message = move || {
        if intercept_theme(&input_text.get_untracked()) {
            return;
        }
        let raw = input_text.get_untracked().trim().to_string();
        let text = if is_doctor_command(&raw) {
            t_string!(i18n, chat.doctor_detect_prompt).to_string()
        } else {
            raw
        };
        let files = attachments.get_untracked();
        if text.is_empty() && files.is_empty() {
            return;
        }
        if !text.is_empty() {
            let check = check_prompt_injection(&text);
            if check.verdict == PromptInjectionVerdict::Block {
                chat.set_send_error(ChatSendError::new(
                    ChatSendErrorCode::PromptBlocked,
                    prompt_guard_message(&check),
                ));
                return;
            }
        }
        chat.enqueue_prompt(QueuedPrompt {
            text,
            attachments: files,
        });
        input_text.set(String::new());
        attachments.set(Vec::new());
        show_palette.set(false);
        current_namespace.set(None);
    };

    // Answer a pending `ask_user` with the current draft. Returns `true` when a
    // question was pending — the caller must then NOT fall through to the send /
    // queue path.
    //
    // This is the composer's half of the rule every channel already enforces in
    // `inbound_router::try_intercept_hitl`: while a clarification is pending,
    // whatever the user sends IS the answer. Without it the draft would be
    // queued behind a turn that can never reach its next boundary — the parked
    // tool would sit there until it timed out, and the user would have no way to
    // reach it except aborting the run.
    //
    // A stale question is the trap: core answers `resolved: false` when nobody
    // was unblocked (expired / superseded / run cancelled). The reply is then
    // still an unsent chat message — restore the draft and route it through the
    // normal path instead of swallowing it.
    let answer_pending_ask = move || -> bool {
        if intercept_theme(&input_text.get_untracked()) {
            return true;
        }
        let Some(ask) = pending_ask.get_untracked() else {
            return false;
        };
        let reply = input_text.get_untracked().trim().to_string();
        // A question IS pending, so consume the keystroke either way — an empty
        // draft simply isn't an answer.
        if reply.is_empty() {
            return true;
        }
        input_text.set(String::new());
        let dash = dashboard;
        spawn_local(async move {
            match crate::api::ClarificationApi::resolve(&dash, &ask.session_key, &reply)
                .await
                .map(|o| (o.accepted, o.is_finished()))
            {
                Ok((true, finished)) => {
                    chat.push_user_message(&reply);
                    // Only drop the card when the whole request is over. A
                    // multi-question request keeps the card (re-rendered at the
                    // new cursor by the advance frame) so the next question can
                    // still own Enter — dropping it here would strand the rest
                    // of the walk behind a card the user can no longer see.
                    if finished {
                        dash.pending_clarifications
                            .update(|l| l.retain(|p| p.session_key != ask.session_key));
                    }
                }
                Ok((false, _)) => {
                    // The question is dead: drop it so it stops owning Enter,
                    // put the draft back, and send it as the ordinary message it
                    // turned out to be.
                    dash.pending_clarifications
                        .update(|l| l.retain(|p| p.session_key != ask.session_key));
                    input_text.set(reply);
                    // Probe a *component-owned* signal, not `chat`: both calls
                    // below read several of these, and `chat` (like `input_text`
                    // = `chat.draft`) is root-owned, so it would answer "alive"
                    // long after this composer was disposed. Same fix as the
                    // phone composer's arm (see `crate::disposed_reads`).
                    if is_sending.try_get_untracked().is_none() {
                        return;
                    }
                    if chat.active_run_id.try_get_untracked().flatten().is_some() {
                        enqueue_message();
                    } else {
                        send_message();
                    }
                }
                Err(e) => {
                    // The answer never left the client — keep the draft.
                    input_text.set(reply);
                    chat.set_send_error(ChatSendError::classify(e));
                }
            }
        });
        true
    };

    // Flush the entire prompt queue into the live run in one batch. Each prompt
    // rides the normal send path: while a run is active the gateway
    // Steer-injects it into the live session (picked up at the next turn
    // boundary); when idle the first send starts a fresh run and the rest steer
    // into it. Sends are awaited sequentially so the backend coalesces them in
    // order.
    let flush_queue = move || {
        let batch = chat.drain_all_queued();
        if batch.is_empty() {
            return;
        }
        // Team chat. `active_run_id` IS set here — `team_events` writes it on
        // the fan-out `started` event, which is what puts a Stop button under a
        // group run — so Enter queues in group chat exactly as it does in a
        // single chat, and this flush is reached. Sending the batch down the
        // single-agent `ChatApi::send` below would have started a *separate*
        // one-agent run instead of talking to the group. The group takes one
        // requirement per turn, so the queued follow-ups go as one message
        // rather than N fan-outs.
        if let Some(team_id) = chat.team_id.get_untracked() {
            let joined = batch
                .iter()
                .map(|e| e.text.as_str())
                .collect::<Vec<_>>()
                .join("\n\n");
            let dash = dashboard;
            spawn_local(async move {
                match crate::api::team_chat::TeamChatApi::send(&dash, &team_id, &joined).await {
                    // The bubble goes up only once the group has the message —
                    // same contract as the single-agent loop below. Remember
                    // the id (both send outcomes fire the same live
                    // `team.<id>.message` echo) so `team_events` skips it
                    // rather than rendering a duplicate. `observed` needs no
                    // extra handling here — unlike the typed-send branch
                    // above, this path never sets a `Thinking` phase to
                    // revert, so there is nothing else to settle.
                    Ok(resp) => {
                        if let Some(mid) = resp.message_id {
                            chat.remember_own_team_message(mid);
                        }
                        chat.push_user_message(&joined);
                    }
                    Err(e) => {
                        chat.set_send_error(ChatSendError::classify(e));
                        chat.requeue_front(batch);
                    }
                }
            });
            return;
        }
        let session_key = chat.session_key.get_untracked();
        let agent_id = chat.agent_id.get_untracked();
        // Same room-vs-picker exclusivity as the typed send above.
        let room_project_id = chat.room_project_id.get_untracked();
        let project_root = if room_project_id.is_some() {
            None
        } else {
            chat.active_project_root.get_untracked()
        };
        let model_override = chat.selected_model.get_untracked();
        // Same rule as the typed send above. A queue flush all but always has
        // a live session, so everything but the tier is None in practice.
        let dials = session_dials_for_send(session_key.is_some(), &chat.session_knobs());
        // Bind the run to the conversation that is active *now*, exactly as the
        // typed path does: a flush on the busy->idle settle starts a fresh run,
        // and if the user has switched tabs by the time `run_accepted` arrives,
        // the event router would otherwise fall back to whichever conversation
        // is in the foreground and stream the reply into it.
        //
        // Only the *first* send of an idle flush is a run, though. A flush while
        // a run is live (the turn-boundary steer) is folded into that run by the
        // gateway, and so are the follow-ups behind the first idle send: those
        // return a run_id the client already has, but no run ever exists under
        // it, so no `run_complete` will ever arrive to settle it. Binding one
        // would leave `SessionMap::running` incremented forever — a red dot on a
        // conversation that finished. That is why the original code ignored the
        // returned id outright; the bug was that it also ignored the one case
        // where the id is real.
        let mut binds_a_real_run = chat.active_run_id.get_untracked().is_none();
        let send_conv = sessions.active_conv();
        let dash = dashboard;
        spawn_local(async move {
            let mut pending = batch.into_iter();
            while let Some(entry) = pending.next() {
                let api_attachments: Vec<ChatAttachment> = entry
                    .attachments
                    .iter()
                    .cloned()
                    .map(|f| ChatAttachment {
                        name: f.name,
                        mime_type: f.mime_type,
                        data_base64: f.data_base64,
                        size: f.size,
                    })
                    .collect();
                match ChatApi::send(
                    &dash,
                    &entry.text,
                    session_key.as_deref(),
                    api_attachments,
                    agent_id.as_deref(),
                    project_root.as_deref(),
                    room_project_id.as_deref(),
                    model_override.as_ref(),
                    &dials,
                    false,
                )
                .await
                {
                    Ok(resp) => {
                        if binds_a_real_run {
                            if let Some(conv) = send_conv {
                                sessions.bind_run(&resp.run_id, conv, Some(&resp.session_key));
                            }
                            // Everything after this one steers into it.
                            binds_a_real_run = false;
                        }
                        // Only now is it a message that was actually sent. The
                        // bubble used to go up first, so a failed send left the
                        // transcript claiming a prompt had been delivered that
                        // the queue had already thrown away.
                        chat.push_user_message(&entry.text);
                        chat.session_key.set(Some(resp.session_key));
                    }
                    Err(e) => {
                        chat.set_send_error(ChatSendError::classify(e));
                        // The prompt never left the client. Give it — and every
                        // prompt behind it — back to the queue instead of
                        // dropping the batch on the floor, and stop: the rest
                        // would almost certainly fail the same way.
                        let mut unsent = vec![entry];
                        unsent.extend(pending);
                        chat.requeue_front(unsent);
                        break;
                    }
                }
            }
        });
    };

    // Force-insert (B7): the user won't wait for the next turn boundary. Fold
    // the current draft into the queue, then interrupt the running task WITHOUT
    // setting `user_interrupted` — so the resulting busy→idle settle runs the
    // normal auto-drain (Task 3), flushing the whole queue as a fresh run. With
    // no active run it degrades to a normal send (B10).
    let force_insert = move || {
        if intercept_theme(&input_text.get_untracked()) {
            return;
        }
        if chat.active_run_id.get_untracked().is_none() {
            send_message();
            return;
        }
        enqueue_message(); // no-op when the draft is empty
        user_interrupted.set(false); // ensure the upcoming settle is NOT suppressed
        if let Some(run_id) = chat.active_run_id.get_untracked() {
            // Same split as the Stop button: in team chat the id is a fan-out
            // TREE, not an engine run, so `chat.abort` misses `active_runs` and
            // the group keeps talking. Force-insert used to abort unconditionally
            // — in a group that made Esc/⚡ a silent no-op that also stranded the
            // queue, because the settle it was waiting for never came.
            let is_team = chat.team_id.get_untracked().is_some();
            let dash = dashboard;
            spawn_local(async move {
                if is_team {
                    let _ = crate::api::team_chat::TeamChatApi::cancel(&dash, &run_id).await;
                    // No `settled` event follows a poisoned tree, so release the
                    // slot here — and that busy->idle edge is what drains the
                    // queue we just folded the draft into.
                    chat.active_run_id.set(None);
                    chat.phase.set(ChatPhase::Idle);
                } else {
                    // Force-insert deliberately does NOT scope the abort to the
                    // session: it is "run this now", not "drop this work", and
                    // purging the lane would throw away the very prompts it just
                    // folded the draft into.
                    let _ = ChatApi::abort(&dash, &run_id, None).await;
                }
            });
        }
    };

    // G4 retry plumbing — MessageBubble's Retry button bumps
    // `chat.retry_pulse`; we re-take the most recent user message and
    // route it through the normal send pipeline so prompt-guard +
    // idempotency + error classification apply identically.
    {
        Effect::new(move |prev_pulse: Option<u32>| {
            let pulse = chat.retry_pulse.get();
            if prev_pulse.is_some() && Some(pulse) != prev_pulse {
                if let Some(last) = chat.last_user_text() {
                    input_text.set(last);
                    send_message();
                }
            }
            pulse
        });
    }

    // G1 `f`-hotkey repair flow — the global keydown listener bumps
    // `repair_pulse` (it can't reach the send pipeline directly). We seed the
    // doctor-and-fix instruction and route it through the same send pipeline as
    // a typed message, so prompt-guard + error classification apply identically.
    // While a run is active we queue it instead, matching the Enter-key
    // semantics. Mirrors the retry plumbing above.
    {
        Effect::new(move |prev_pulse: Option<u32>| {
            let pulse = chat.repair_pulse.get();
            if prev_pulse.is_some() && Some(pulse) != prev_pulse {
                input_text.set(t_string!(i18n, chat.doctor_repair_prompt).to_string());
                if chat.active_run_id.get_untracked().is_some() {
                    enqueue_message();
                } else {
                    send_message();
                }
            }
            pulse
        });
    }

    // NOTE: there is deliberately no "drain the prefill channel" Effect here.
    // Empty-state suggestion chips, the queued-ghost "click to edit", and the
    // composer's own ↑ retraction all call `ChatState::seed_draft`, which writes
    // `chat.draft` — and `input_text` above *is* `chat.draft`. A separate
    // `draft_seed` signal drained here would need a second consumer on every
    // platform shell (phone never had one, so a ghost tap silently dropped the
    // message it pulled out of the queue). One home for the state, one entry
    // point that merges instead of overwriting.

    // Queue auto-drain — when a run settles naturally (busy → idle), replay
    // the head of the queue through the normal send pipeline. An explicit
    // Stop sets `user_interrupted`, which suppresses exactly one drain so
    // cancelling a turn doesn't immediately re-fire the queued prompt. The
    // decision itself is the pure `should_auto_drain_on_settle` (host-tested
    // in `shared_ui_logic::state`); this Effect only owns the side effects.
    //
    // The edge is tracked per conversation. The composer reads the *foreground*
    // ChatState, which a tab swap re-projects onto a different conversation, so
    // a plain `prev_busy` turned "left a busy conversation, opened an idle one"
    // into a fabricated busy->idle edge and fired the newly-opened
    // conversation's queue on arrival. Remembering which conversation the
    // previous observation belonged to removes the fabricated edge — and makes
    // switching back the moment a conversation whose run settled while
    // backgrounded finally drains, which nothing else does: both drain triggers
    // live in this one foreground component.
    {
        Effect::new(move |prev: Option<(Option<ConvId>, bool)>| {
            let conv = sessions.active_conv();
            let is_busy = chat.active_run_id.get().is_some();
            let queue_len = chat.prompt_queue.get_untracked().len();
            let switched = prev.is_some_and(|(prev_conv, _)| prev_conv != conv);
            let was_busy =
                was_busy_across_switch(prev.map(|(_, busy)| busy), prev.is_some() && !switched);
            if should_auto_drain_on_settle(
                was_busy,
                is_busy,
                queue_len,
                user_interrupted.get_untracked(),
            ) {
                flush_queue();
            }
            // Reset the one-shot interrupt flag once we've crossed the edge.
            if was_busy && !is_busy && !switched {
                user_interrupted.set(false);
            }
            (conv, is_busy)
        });
    }

    // Turn-boundary flush — `events.rs` bumps `flush_pulse` when the agent
    // crosses into a new Think iteration with prompts still queued. Steer the
    // whole batch into the live run now (the pure decision is host-tested in
    // `shared_ui_logic::state::should_flush_on_turn_boundary`).
    {
        Effect::new(move |prev: Option<u32>| {
            let pulse = chat.flush_pulse.get();
            if prev.is_some() && Some(pulse) != prev {
                let is_busy = chat.active_run_id.get_untracked().is_some();
                let queue_len = chat.prompt_queue.get_untracked().len();
                if should_flush_on_turn_boundary(queue_len, is_busy) {
                    flush_queue();
                }
            }
            pulse
        });
    }

    // Fetch the catalogue once, then refresh whatever the user already
    // typed. Idempotent — guarded by `commands_loaded`.
    let fetch_commands = move || {
        if commands_loaded.get_untracked() {
            return;
        }
        let dash = dashboard;
        let labels = palette_labels();
        // Resolved before the `.await` — reading a locale key on the far side
        // of one is the disposed-read hazard `crate::disposed_reads` guards.
        let doctor_desc = t_string!(i18n, chat.doctor_command_desc).to_string();
        spawn_local(async move {
            // `rpc_call` waits for the handshake itself, so the 50×100 ms poll
            // that used to stand here is gone — see `DashboardState::rpc_call`.
            match dash.rpc_call("commands.list", serde_json::json!({})).await {
                Ok(result) => {
                    let mut cmds = Vec::new();
                    if let Some(arr) = result.get("commands").and_then(|v| v.as_array()) {
                        for item in arr {
                            if let Some(cmd) = parse_command_info(item) {
                                cmds.push(cmd);
                            }
                        }
                    }
                    if !cmds.iter().any(|c| c.key == "doctor") {
                        cmds.push(doctor_command_info(doctor_desc.clone()));
                    }
                    cmds.retain(|command| command.key != "theme");
                    cmds.push(appearance_command::theme_command_info(
                        t_string!(i18n, appearance.popover_title).to_string(),
                    ));
                    all_commands.set(cmds.clone());
                    commands_loaded.set(true);
                    // Refresh palette in case the user already typed `/`
                    // while we were waiting for the catalogue.
                    // Post-`.await`: `commands.list` can outlive this composer.
                    // `current_namespace` is component-owned, so it is the
                    // honest probe — `input_text` is `chat.draft` and root-owned
                    // (see `crate::disposed_reads`).
                    let Some(ns) = current_namespace.try_get_untracked() else {
                        return;
                    };
                    let text = input_text.try_get_untracked().unwrap_or_default();
                    if let Some(query) = text.strip_prefix('/') {
                        let entries = build_palette_entries(&cmds, &ns, query, &labels);
                        palette_entries.set(entries);
                        selected_index.set(0);
                    }
                }
                Err(e) => {
                    web_sys::console::error_1(&format!("Failed to fetch commands: {e}").into());
                }
            }
        });
    };
    fetch_commands();

    // Recompute palette entries from the current draft text. Handles
    // guided drilldown ("/session ...") and auto-exit when the user
    // breaks the prefix.
    let update_palette = move |text: &str| {
        let labels = palette_labels();
        if let Some(after_slash) = text.strip_prefix('/') {
            let cmds = all_commands.get_untracked();
            let ns = current_namespace.get_untracked();

            // Auto-enter "/namespace " when seen for the first time.
            if ns.is_none() && !after_slash.is_empty() {
                let parts: Vec<&str> = after_slash.splitn(2, ' ').collect();
                if parts.len() == 2 {
                    let maybe_ns = parts[0];
                    let sub_query = parts[1];
                    if let Some(parent) = cmds.iter().find(|c| c.key == maybe_ns && c.is_namespace)
                    {
                        current_namespace.set(Some(parent.key.clone()));
                        let entries = build_palette_entries(
                            &cmds,
                            &Some(parent.key.clone()),
                            sub_query,
                            &labels,
                        );
                        palette_entries.set(entries);
                        selected_index.set(0);
                        show_palette.set(true);
                        return;
                    }
                }
            }

            let query = if let Some(ref ns_key) = ns {
                let prefix = format!("{ns_key} ");
                if after_slash.starts_with(&prefix) {
                    &after_slash[prefix.len()..]
                } else if after_slash == ns_key.as_str() {
                    ""
                } else {
                    // User text diverged from "/namespace " — exit.
                    current_namespace.set(None);
                    after_slash
                }
            } else {
                after_slash
            };

            let ns = current_namespace.get_untracked();
            let entries = build_palette_entries(&cmds, &ns, query, &labels);
            palette_entries.set(entries);
            selected_index.set(0);
            show_palette.set(true);
            // Lazy first-use trigger for the catalogue fetch.
            fetch_commands();
        } else {
            show_palette.set(false);
            current_namespace.set(None);
        }
    };

    // Palette row selected (mousedown or Tab/Enter).
    let select_palette_entry = move |entry: PaletteEntry| {
        let labels = palette_labels();
        if entry.is_back {
            current_namespace.set(None);
            input_text.set("/".to_string());
            let cmds = all_commands.get_untracked();
            let entries = build_palette_entries(&cmds, &None, "", &labels);
            palette_entries.set(entries);
            selected_index.set(0);
        } else if entry.is_namespace {
            current_namespace.set(Some(entry.label.clone()));
            input_text.set(format!("/{} ", entry.label));
            let cmds = all_commands.get_untracked();
            let ns = Some(entry.label);
            let entries = build_palette_entries(&cmds, &ns, "", &labels);
            palette_entries.set(entries);
            selected_index.set(0);
        } else {
            if intercept_theme(&entry.full_command) {
                return;
            }
            input_text.set(entry.full_command);
            show_palette.set(false);
            current_namespace.set(None);
        }
    };

    // Commit a mention selection: splice the `@<query>` span with `token`.
    // Captures signals by copy — safe to call from multiple closures.
    let do_commit_mention = move |token: String| {
        let text = input_text.get_untracked();
        if let Some(at) = mention_at.get_untracked() {
            let before = text.get(..at).unwrap_or("");
            let query_start = at + 1;
            let query_end = text[query_start..]
                .find(|c: char| c.is_whitespace())
                .map(|rel| query_start + rel)
                .unwrap_or(text.len());
            let after = text.get(query_end..).unwrap_or("");
            input_text.set(format!("{before}{token}{after}"));
        } else {
            input_text.set(format!("{text}{token}"));
        }
        show_mention.set(false);
        mention_at.set(None);
        mention_members.set(Vec::new());
        mention_selected.set(0);
    };

    let on_keydown = {
        move |ev: web_sys::KeyboardEvent| {
            // IME composition gate (T1.2). Chinese / Japanese / Korean IMEs
            // emit a trailing `keydown(Enter)` *after* `compositionend` to
            // commit a candidate; the Enter arrives with `isComposing` already
            // cleared, so it would otherwise dispatch `send_message`. We
            // swallow Enter when:
            //   1. a composition is still active (Enter should pick a
            //      partial candidate, not send);
            //   2. we are inside the 100ms "recently settled" window after
            //      `compositionend` (covers the trailing-Enter race).
            // All other keys are unaffected, so palette navigation, Esc
            // force-insert, ArrowUp recall, and shift-Enter newlines all
            // behave exactly as before.
            if ev.key() == "Enter"
                && ime_gate.with_untracked(|g| g.should_suppress_enter(js_sys::Date::now() as u64))
            {
                ev.prevent_default();
                return;
            }
            if appearance_command::handle_picker_key(
                &ev.key(),
                theme_command_open,
                theme_command_selected,
            ) {
                ev.prevent_default();
                return;
            }
            // @-mention palette takes priority over slash palette.
            if show_mention.get_untracked() {
                let count = mention_members.get_untracked().len() + 1; // +1 for "@all"
                match ev.key().as_str() {
                    "ArrowDown" => {
                        ev.prevent_default();
                        if count > 0 {
                            mention_selected.set((mention_selected.get_untracked() + 1) % count);
                        }
                    }
                    "ArrowUp" => {
                        ev.prevent_default();
                        if count > 0 {
                            let cur = mention_selected.get_untracked();
                            mention_selected.set(if cur == 0 { count - 1 } else { cur - 1 });
                        }
                    }
                    "Tab" | "Enter" => {
                        ev.prevent_default();
                        let idx = mention_selected.get_untracked();
                        let token = if idx == 0 {
                            "@all ".to_string()
                        } else {
                            mention_members
                                .get_untracked()
                                .get(idx - 1)
                                .map(|m| format!("@{} ", m.agent_id))
                                .unwrap_or_default()
                        };
                        do_commit_mention(token);
                    }
                    "Escape" => {
                        ev.prevent_default();
                        show_mention.set(false);
                        mention_at.set(None);
                    }
                    _ => {}
                }
                return;
            }

            if show_palette.get_untracked() {
                // A complete local theme command must bypass palette filtering.
                // `/theme dark` and `/theme list` have no matching catalogue
                // entry, but Enter still belongs to the appearance picker.
                // Shift+Enter deliberately falls through so the textarea keeps
                // its normal newline behavior.
                if ev.key() == "Enter"
                    && !ev.shift_key()
                    && intercept_theme(&input_text.get_untracked())
                {
                    ev.prevent_default();
                    return;
                }

                let entries = palette_entries.get_untracked();
                let count = entries.len();
                match ev.key().as_str() {
                    "ArrowDown" => {
                        ev.prevent_default();
                        if count > 0 {
                            selected_index.set((selected_index.get_untracked() + 1) % count);
                        }
                    }
                    "ArrowUp" => {
                        ev.prevent_default();
                        if count > 0 {
                            let cur = selected_index.get_untracked();
                            selected_index.set(if cur == 0 { count - 1 } else { cur - 1 });
                        }
                    }
                    "Tab" => {
                        ev.prevent_default();
                        let idx = selected_index.get_untracked();
                        if idx < count {
                            select_palette_entry(entries[idx].clone());
                        }
                    }
                    "Enter" if !ev.shift_key() => {
                        ev.prevent_default();
                        let idx = selected_index.get_untracked();
                        if idx < count {
                            select_palette_entry(entries[idx].clone());
                        }
                    }
                    "Escape" => {
                        ev.prevent_default();
                        if current_namespace.get_untracked().is_some() {
                            current_namespace.set(None);
                            input_text.set("/".to_string());
                            let labels = palette_labels();
                            let cmds = all_commands.get_untracked();
                            let new_entries = build_palette_entries(&cmds, &None, "", &labels);
                            palette_entries.set(new_entries);
                            selected_index.set(0);
                        } else {
                            show_palette.set(false);
                        }
                    }
                    _ => {}
                }
                return;
            }
            // Recall the newest queued prompt back into the composer — the
            // keyboard twin of tapping a ghost bubble. Two bindings, one
            // action:
            //   * `Alt`/`Option` + `ArrowUp` always, matching codex
            //     (`edit_queued_message`) and pi (`app.message.dequeue`);
            //   * a bare `ArrowUp` only when the textarea is empty, where the
            //     key has no caret work to do and "up = my last message" is
            //     what a terminal-shaped habit expects.
            // Both palettes claim `ArrowUp` for list navigation and return
            // early above, so neither is reachable from here. Repeated presses
            // walk further back: each recall prepends, so the queue's order is
            // rebuilt in the draft rather than reversed.
            if ev.key() == "ArrowUp" {
                let queue_len = chat.prompt_queue.get_untracked().len();
                // Trimmed, like every other draft-emptiness test in this file
                // (`can_send`, `has_draft`, `enqueue_message`): a textarea
                // holding only spaces has no line for the caret to move to
                // either, so `ArrowUp` is just as free there.
                let bare_recall = should_recall_on_bare_arrow_up(
                    queue_len,
                    input_text.get_untracked().trim().is_empty(),
                );
                if (ev.alt_key() && queue_len > 0) || (!ev.alt_key() && bare_recall) {
                    ev.prevent_default();
                    if let Some(entry) = chat.recall_latest_queued() {
                        chat.seed_draft(entry.text, entry.attachments);
                    }
                    return;
                }
            }
            // Esc while a run is active = force-insert: interrupt now and flush
            // the queue (+ the current draft) as a fresh run (B7). Palette/
            // mention Esc is handled in the branch above (it returns early), so
            // this only fires in the normal composing context.
            if ev.key() == "Escape" && chat.active_run_id.get_untracked().is_some() {
                ev.prevent_default();
                force_insert();
                return;
            }
            // Guided mode — "/namespace" + Enter → drill into the children
            // instead of sending.
            if ev.key() == "Enter" && !ev.shift_key() {
                let text = input_text.get_untracked();
                let trimmed = text.trim();
                if trimmed.starts_with('/') && !trimmed.contains(' ') {
                    let maybe_ns = &trimmed[1..];
                    let cmds = all_commands.get_untracked();
                    if let Some(parent) = cmds.iter().find(|c| c.key == maybe_ns && c.is_namespace)
                    {
                        ev.prevent_default();
                        current_namespace.set(Some(parent.key.clone()));
                        input_text.set(format!("/{} ", parent.key));
                        let labels = palette_labels();
                        let ns = Some(parent.key.clone());
                        let entries = build_palette_entries(&cmds, &ns, "", &labels);
                        palette_entries.set(entries);
                        selected_index.set(0);
                        show_palette.set(true);
                        return;
                    }
                }
                ev.prevent_default();
                // A pending question owns the send key — the turn is blocked on
                // the answer, so queueing the draft would strand it.
                if answer_pending_ask() {
                    return;
                }
                // While a run is active, Enter queues the follow-up instead
                // of sending (there is no live send slot until it settles).
                if chat.active_run_id.get_untracked().is_some() {
                    enqueue_message();
                } else {
                    send_message();
                }
            }
        }
    };

    let can_send = Memo::new(move |_| {
        (!input_text.get().trim().is_empty() || !attachments.get().is_empty()) && !is_sending.get()
    });

    // Draft is non-empty (text or attachments) — gates the queue button while
    // a run is active. Independent of `is_sending` (that's the brief outbound
    // HTTP window, not the whole run).
    let has_draft =
        Memo::new(move |_| !input_text.get().trim().is_empty() || !attachments.get().is_empty());

    // Force-insert is available while a run is active and there's *something*
    // to insert — queued ghosts or the current draft.
    let can_force = Memo::new(move |_| {
        chat.active_run_id.get().is_some()
            && (!chat.prompt_queue.get().is_empty()
                || !input_text.get().trim().is_empty()
                || !attachments.get().is_empty())
    });

    let on_attach_click = move |_: web_sys::MouseEvent| {
        if let Some(input) = file_input_ref.get() {
            let el: &web_sys::HtmlInputElement = &input;
            el.click();
        }
    };
    let on_file_change = move |_ev: web_sys::Event| {
        let Some(input) = file_input_ref.get() else {
            return;
        };
        let el: &web_sys::HtmlInputElement = &input;
        if let Some(file_list) = el.files() {
            read_file_list_into(&file_list, attachments);
        }
        el.set_value("");
    };

    let on_abort = move |_: web_sys::MouseEvent| {
        // Suppress exactly one auto-drain: an explicit Stop must not let the
        // queue immediately re-fire its head (the "Stop does nothing" trap).
        user_interrupted.set(true);
        let Some(run_id) = chat.active_run_id.get() else {
            return;
        };
        // In team chat the id is a fan-out TREE, not an engine run: `chat.abort`
        // looks it up in `active_runs`, misses, and the group keeps talking.
        // `teams.chat.cancel` poisons the tree and walks its member runs.
        let is_team = chat.team_id.get_untracked().is_some();
        let session_key = chat.session_key.get_untracked();
        let dash = dashboard;
        spawn_local(async move {
            if is_team {
                let _ = crate::api::team_chat::TeamChatApi::cancel(&dash, &run_id).await;
                // The tree is gone, so no `settled` event will arrive to clear
                // the slot — release it here or the composer stays stuck on Stop.
                chat.active_run_id.set(None);
                chat.phase.set(ChatPhase::Idle);
            } else {
                // Stop is "I do not want this work", so it must reach the
                // session's server-side backlog too — cancelling alone frees the
                // slot and lets the lane fire the queued messages one full run
                // at a time, which is exactly what the user just refused.
                let _ = ChatApi::abort(&dash, &run_id, session_key.as_deref()).await;
            }
        });
    };

    let select_for_callback = select_palette_entry;
    let on_palette_select: Callback<PaletteEntry> =
        Callback::new(move |entry: PaletteEntry| select_for_callback(entry));

    // @-mention selection callback — splices the token into `input_text`.
    // A second independent closure capturing the same Copy signals.
    let on_mention_select: Callback<String> = Callback::new(move |token: String| {
        let text = input_text.get_untracked();
        if let Some(at) = mention_at.get_untracked() {
            let before = text.get(..at).unwrap_or("");
            let query_start = at + 1;
            let query_end = text[query_start..]
                .find(|c: char| c.is_whitespace())
                .map(|rel| query_start + rel)
                .unwrap_or(text.len());
            let after = text.get(query_end..).unwrap_or("");
            input_text.set(format!("{before}{token}{after}"));
        } else {
            input_text.set(format!("{text}{token}"));
        }
        show_mention.set(false);
        mention_at.set(None);
        mention_members.set(Vec::new());
        mention_selected.set(0);
    });

    view! {
        <div class="absolute inset-x-0 bottom-0 z-10 px-4 pb-4 pt-2 pointer-events-none">
            <div class="w-full min-w-0 max-w-5xl mx-auto pointer-events-auto" node_ref=stack_ref>
                // Single-chat sticky Todo panel — top of the bottom input
                // stack (below the message flow, above the input box).
                // Hidden when no active plan. Living inside `stack_ref` lets
                // the existing ResizeObserver reserve `--composer-clearance`
                // for its height, so messages never hide behind it.
                <TodoPanel />
                <AttachmentPreviewBar attachments=attachments />

                // Team chat: most-salient task pill, above the input box.
                <TeamTaskStrip />

                // Floating-overlay anchor. The palettes below are positioned
                // `absolute bottom-full` against this `relative` wrapper, so
                // they float above the input cluster instead of sitting in
                // flow. Critical: an in-flow palette would grow the
                // ResizeObserver-tracked `stack_ref`, inflate
                // `--composer-clearance`, and push chat content up.
                <div class="relative">
                <appearance_command::ThemeCommandPicker open=theme_command_open invalid=theme_command_invalid selected=theme_command_selected />
                <SlashPaletteView
                    show=show_palette
                    palette_entries=palette_entries
                    selected_index=selected_index
                    current_namespace=current_namespace
                    on_select=on_palette_select
                />

                // @-mention palette — visible only in team mode when the user
                // types `@` followed by a valid mention token prefix.
                <Show when=move || chat.team_id.get().is_some()>
                    <MentionPaletteView
                        show=show_mention
                        members=mention_members
                        selected_index=mention_selected
                        on_select=on_mention_select
                    />
                </Show>

                // Send-error banner (G2) — the last outbound send failed or was
                // refused before it left. It lives in the composer stack, not in
                // the transcript: every writer of `send_error` is a composer
                // path, and a banner parked above the scrollback is invisible in
                // any conversation long enough to scroll (the team-attachment
                // refusal landed ~700px off-screen).
                <SendErrorBanner />

                // Voice-notice banner — a non-fatal notice from the spoken
                // layer (currently only "this system cannot decode the audio").
                // Same reasoning as SendErrorBanner above for living here
                // rather than in the transcript.
                <VoiceNoticeBanner />

                // Live prompt-injection guard banner (G1). Server-side
                // remains the final authority; this is just a hint so
                // the user can rephrase before wasting a model call.
                {move || {
                    let text = input_text.get();
                    if text.trim().is_empty() {
                        return None;
                    }
                    let check = check_prompt_injection(&text);
                    if check.verdict == PromptInjectionVerdict::Allow {
                        return None;
                    }
                    let is_block = check.verdict == PromptInjectionVerdict::Block;
                    let cls = if is_block {
                        "mx-1 mb-1 px-2.5 py-1.5 rounded-md text-xs border bg-danger-subtle border-danger/30 text-danger"
                    } else {
                        "mx-1 mb-1 px-2.5 py-1.5 rounded-md text-xs border bg-warning-subtle border-warning/30 text-warning"
                    };
                    Some(view! {
                        <div class=cls role="status">
                            {prompt_guard_message(&check)}
                        </div>
                    })
                }}

                // Composer card — two zones: full-width auto-grow textarea
                // on top, a toolbar row below (attach + voice on the left,
                // clear / queue / abort / send on the right). The textarea
                // grows up to 140px then scrolls internally.
                <div class="aleph-composer flex flex-col gap-1.5 px-3 py-2">
                    // Hidden file input. `accept` is a *hint* — the OS
                    // picker defaults to images, common video, plain
                    // text / markdown / pdf / json. Users can still
                    // switch to "All files" for niche types.
                    <input
                        type="file"
                        multiple=true
                        class="hidden"
                        accept="image/*,video/mp4,video/webm,video/quicktime,text/*,application/pdf,application/json,.md,.csv"
                        node_ref=file_input_ref
                        on:change=on_file_change
                    />

                    <textarea
                        class="w-full resize-none overflow-y-auto bg-transparent px-1 py-[6px] text-sm leading-snug
                               text-text-primary placeholder:text-text-tertiary
                               focus:outline-none min-h-[32px] max-h-[140px]"
                        placeholder=move || t_string!(i18n, chat.send_placeholder).to_string()
                        rows=1
                        node_ref=textarea_ref
                        prop:value=move || input_text.get()
                        on:input=move |ev| {
                            let val = event_target_value(&ev);
                            input_text.set(val.clone());
                            update_palette(&val);
                            // Read the caret from the underlying textarea DOM node.
                            // `selection_start` is a UTF-16 code-unit index; convert it
                            // to a UTF-8 byte offset so it lands on a char boundary (a
                            // direct cast would slice mid-codepoint after multibyte text).
                            let sel = ev
                                .target()
                                .and_then(|t| t.dyn_into::<web_sys::HtmlTextAreaElement>().ok())
                                .and_then(|ta| ta.selection_start().ok().flatten());
                            let caret = match sel {
                                Some(u16_off) => {
                                    let mut units = 0u32;
                                    val.char_indices()
                                        .find_map(|(b, c)| {
                                            if units >= u16_off {
                                                Some(b)
                                            } else {
                                                units += c.len_utf16() as u32;
                                                None
                                            }
                                        })
                                        .unwrap_or(val.len())
                                }
                                None => val.len(),
                            };
                            let at = update_mention_palette(
                                &val,
                                caret,
                                chat.team_id.get_untracked(),
                                &chat.team_members.get_untracked(),
                                show_mention,
                                mention_members,
                                mention_selected,
                            );
                            mention_at.set(at);
                        }
                        on:paste=move |event: web_sys::ClipboardEvent| {
                            if let Some(files) = event.clipboard_data().and_then(|data| data.files()) {
                                if files.length() > 0 {
                                    event.prevent_default();
                                    read_file_list_into(&files, attachments);
                                }
                            }
                        }
                        on:keydown=on_keydown
                        // IME composition listeners (T1.2) — same pattern as
                        // every browser that ships a textarea. We use the
                        // typed `CompositionEvent` because the gate only
                        // needs the boundary timestamps, not the payload;
                        // the `web-sys` `CompositionEvent` feature is
                        // enabled in Cargo.toml to back this listener type.
                        on:compositionstart=move |_ev: web_sys::CompositionEvent| {
                            ime_gate.update(|g| g.on_composition_start());
                        }
                        on:compositionend=move |_ev: web_sys::CompositionEvent| {
                            let now_ms = js_sys::Date::now() as u64;
                            ime_gate.update(|g| g.on_composition_end(now_ms));
                        }
                    />

                    // Toolbar row — left: attach + voice + project/model/gauge;
                    // right cluster: export + conditional clear / queue / abort / send.
                    // (The old standalone project-row was folded into this
                    // row so its controls sit level with the attach paperclip.)
                    <div class="flex items-center gap-2 flex-wrap min-w-0">
                        <button
                            class="p-1.5 rounded-lg text-text-tertiary hover:text-text-primary
                                   hover:bg-surface-sunken transition-colors flex-shrink-0"
                            title=move || t_string!(i18n, chat.attach).to_string()
                            on:click=on_attach_click
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5"
                                 viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd"
                                      d="M15.621 4.379a3 3 0 0 0-4.242 0l-7 7a3 3 0 0 0 4.241 4.243h.001l.497-.5a.75.75 0 0 1 1.064 1.057l-.498.501-.002.002a4.5 4.5 0 0 1-6.364-6.364l7-7a4.5 4.5 0 0 1 6.368 6.36l-3.455 3.553A2.625 2.625 0 1 1 9.52 9.52l3.45-3.451a.75.75 0 1 1 1.061 1.06l-3.45 3.451a1.125 1.125 0 0 0 1.587 1.595l3.454-3.553a3 3 0 0 0 0-4.242Z"
                                      clip-rule="evenodd" />
                            </svg>
                        </button>

                        // Voice loop — record → STT → send → spoken reply.
                        <voice::VoiceInputButton
                            disabled=Signal::derive(move || is_sending.get())
                        />

                        // Migrated from the old project row — now level
                        // with the attach paperclip. Dropdowns still flip upward.
                        // Hidden in a project room: the room's working
                        // directory is the owner's `bind_workspace` choice and
                        // a member picking a folder here would be choosing
                        // nothing (`build_run_request` forces `project_root`
                        // to `None` for a room turn).
                        <Show when=move || chat.room_project_id.get().is_none()>
                            <ProjectMenu />
                        </Show>
                        <crate::components::model_picker::ModelPicker />
                        // Per-session usage mode (chat / work / code) + tool
                        // execution tier (Ask / Auto / Full). Hidden in team
                        // chat: the team send path (`TeamChatApi::send`) carries
                        // neither, and with `session_key` cleared a pick could
                        // not persist either — an override dot that does
                        // nothing would just mislead.
                        <Show when=move || chat.team_id.get().is_none()>
                            <crate::views::chat::mode_picker::ModePicker />
                            <crate::views::chat::exec_tier_picker::ExecTierPicker />
                            // Reasoning depth and memory injection — the two
                            // dials the server has always enforced and no
                            // client reported. Both self-hide against a core
                            // that does not enumerate them.
                            <crate::views::chat::dial_picker::DialPicker
                                dial=crate::views::chat::dial_picker::Dial::Think />
                            <crate::views::chat::dial_picker::DialPicker
                                dial=crate::views::chat::dial_picker::Dial::Memory />
                        </Show>
                        // Live context-window gauge (self-hides until first usage).
                        <super::context_gauge::ContextGauge />
                        // Live last-call cache hit rate (self-hides until a
                        // call reports cache activity).
                        <super::context_gauge::CacheStat />

                        <div class="ml-auto flex items-center gap-2 flex-wrap min-w-0">
                            // Export conversation → Markdown (far right of the
                            // cluster). Only once the thread has content.
                            <Show when=move || !chat.messages.get().is_empty()>
                                <button
                                    class="p-1.5 rounded-lg text-text-tertiary hover:text-text-primary
                                           hover:bg-surface-sunken transition-colors flex-shrink-0"
                                    title=move || t_string!(i18n, chat.export_markdown).to_string()
                                    on:click=move |_| {
                                        let msgs = chat.messages.get_untracked();
                                        super::transcript::download_transcript(
                                            &msgs,
                                            t_string!(i18n, chat.transcript_heading),
                                        );
                                    }
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                        <polyline points="7 10 12 15 17 10" />
                                        <line x1="12" y1="15" x2="12" y2="3" />
                                    </svg>
                                </button>
                            </Show>
                            // Clear-draft ✕ — visible only when text exists.
                            // Wipes text + closes palette + exits namespace in
                            // one click. Attachments are left alone (own ✕).
                            <Show when=move || !input_text.get().trim().is_empty()>
                                <button
                                    class="w-8 h-8 rounded-full text-text-tertiary hover:text-text-primary
                                           hover:bg-surface-sunken flex items-center justify-center
                                           transition-colors flex-shrink-0"
                                    title=move || t_string!(i18n, chat.clear).to_string()
                                    on:click=move |_| {
                                        input_text.set(String::new());
                                        show_palette.set(false);
                                        current_namespace.set(None);
                                        show_mention.set(false);
                                        mention_at.set(None);
                                    }
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
                                    </svg>
                                </button>
                            </Show>

                            // Queue button — only while a run is active. Lets the user
                            // line up a follow-up that auto-sends when the turn settles.
                            // Withdrawn while a question is pending: the turn cannot
                            // reach another boundary until it is answered, so a queued
                            // draft would just sit there behind the parked tool.
                            <Show when=move || chat.active_run_id.get().is_some()
                                               && pending_ask.get().is_none()>
                                <button
                                    class="w-8 h-8 rounded-full bg-surface-sunken text-text-secondary
                                           flex items-center justify-center hover:bg-surface-raised
                                           hover:text-text-primary disabled:opacity-35
                                           disabled:cursor-not-allowed transition-colors flex-shrink-0"
                                    title=move || t_string!(i18n, chat.queue).to_string()
                                    disabled=move || !has_draft.get()
                                    on:click=move |_| enqueue_message()
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                              d="M10 3a.75.75 0 0 1 .75.75v5.5h5.5a.75.75 0 0 1 0 1.5h-5.5v5.5a.75.75 0 0 1-1.5 0v-5.5h-5.5a.75.75 0 0 1 0-1.5h5.5v-5.5A.75.75 0 0 1 10 3Z"
                                              clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </Show>

                            // Force-insert ⚡ — interrupt now and flush the queue
                            // (+ draft) immediately instead of waiting for the
                            // next turn boundary. Mirrors Esc.
                            <Show when=move || can_force.get()>
                                <button
                                    class="w-8 h-8 rounded-full bg-primary/15 text-primary flex items-center
                                           justify-center hover:bg-primary/25 transition-colors flex-shrink-0"
                                    title=move || t_string!(i18n, chat.force_insert).to_string()
                                    on:click=move |_| force_insert()
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M11 3 4 11h4l-1 6 7-8h-4l1-6Z" />
                                    </svg>
                                </button>
                            </Show>

                            <Show when=move || chat.active_run_id.get().is_some()>
                                <button
                                    class="w-8 h-8 rounded-full bg-danger/15 text-danger flex items-center
                                           justify-center hover:bg-danger/25 transition-colors flex-shrink-0"
                                    title=move || t_string!(i18n, chat.stop).to_string()
                                    on:click=on_abort
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <rect x="4" y="4" width="12" height="12" rx="2" />
                                    </svg>
                                </button>
                            </Show>

                            <Show when=move || chat.active_run_id.get().is_none()>
                                <button
                                    class="w-8 h-8 rounded-full bg-primary text-white flex items-center
                                           justify-center shadow-sm hover:bg-primary-hover
                                           disabled:opacity-35 disabled:cursor-not-allowed
                                           disabled:shadow-none transition-all flex-shrink-0"
                                    disabled=move || !can_send.get()
                                    on:click=move |_| send_message()
                                >
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
                                         class="w-4 h-4">
                                        <path d="M12 19V5" />
                                        <path d="M5 12l7-7 7 7" />
                                    </svg>
                                </button>
                            </Show>
                        </div>
                    </div>
                </div>
                </div>  // /relative floating-overlay anchor
            </div>
        </div>
    }
}

/// Non-fatal notice from the spoken layer. Deliberately separate from
/// [`SendErrorBanner`]: that one reports a failed send with a
/// `ChatSendErrorCode`, this one reports that playback could not decode. Same
/// shape, different condition, different remedy — including the dismiss
/// button, since the next successful playback that would otherwise clear it
/// never happens on a machine that cannot decode.
#[component]
fn VoiceNoticeBanner() -> impl IntoView {
    let i18n = use_i18n();
    let chat = expect_context::<ChatState>();
    view! {
        <Show when=move || chat.voice_notice.get().is_some()>
            {move || {
                chat.voice_notice
                    .get()
                    .map(|msg| {
                        view! {
                            <div
                                class="mx-1 mb-1 px-3 py-2 rounded-lg border text-sm bg-warning-subtle border-warning/30 text-warning"
                                role="status"
                            >
                                <div class="flex items-start gap-2">
                                    <span class="flex-1">{msg}</span>
                                    <button
                                        class="opacity-60 hover:opacity-100 shrink-0"
                                        title=move || t_string!(i18n, chat.dismiss).to_string()
                                        on:click=move |_| chat.voice_notice.set(None)
                                    >
                                        "\u{2715}"
                                    </button>
                                </div>
                            </div>
                        }
                    })
            }}
        </Show>
    }
}

/// Inline banner for the most recent `ChatSendError`. Empty when none.
#[component]
fn SendErrorBanner() -> impl IntoView {
    let i18n = use_i18n();
    let chat = expect_context::<ChatState>();
    view! {
        <Show when=move || chat.send_error.get().is_some()>
            {move || {
                let err = chat.send_error.get();
                err.map(|e| {
                    // Severity is per-code, not just PromptReview — see
                    // `ChatSendErrorCode::is_warning`'s doc for why `Cancelled`
                    // (the user's own Stop) joins it: painting it danger-red
                    // here contradicted that variant's own doc on every Stop.
                    let is_warning = e.code.is_warning();
                    let class_str = if is_warning {
                        "mx-1 mb-1 px-3 py-2 rounded-lg border text-sm bg-warning-subtle border-warning/30 text-warning"
                    } else {
                        "mx-1 mb-1 px-3 py-2 rounded-lg border text-sm bg-danger-subtle border-danger/30 text-danger"
                    };
                    // `alert` (assertive live region) fits an actual failure;
                    // a warning is informational, so it gets the same `status`
                    // (polite) role the voice-notice banner above already uses.
                    let role_str = if is_warning { "status" } else { "alert" };
                    view! {
                        <div class=class_str role=role_str>
                            <div class="flex items-start gap-2">
                                <span class="font-mono text-[10px] uppercase tracking-wider opacity-70 shrink-0 pt-0.5">
                                    {format!("{:?}", e.code).to_lowercase()}
                                </span>
                                <span class="flex-1">{e.message}</span>
                                <button
                                    class="opacity-60 hover:opacity-100 shrink-0"
                                    title=move || t_string!(i18n, chat.dismiss).to_string()
                                    on:click=move |_| {
                                        chat.send_error.set(None);
                                        chat.error_message.set(None);
                                    }
                                >
                                    "\u{2715}"
                                </button>
                            </div>
                        </div>
                    }
                })
            }}
        </Show>
    }
}

#[cfg(test)]
mod tests {
    /// Only the production half of this file — an unscoped `include_str!` would
    /// count the RED-proof fixtures below as real send sites.
    fn production_half(src: &str) -> &str {
        src.split("#[cfg").next().unwrap_or(src)
    }

    fn typed_send_body(src: &str) -> Option<&str> {
        let src = production_half(src);
        let (_, after) = src.split_once("let send_message = move || {")?;
        let (body, _) = after.split_once("\n    // The question this conversation")?;
        Some(body)
    }

    /// A send that fails must hand the attachment tray back.
    ///
    /// The tray is drained before the request goes out, and the Retry button
    /// rebuilds only the text (`ChatState::last_user_text`). So a failed send
    /// used to destroy the attachment while leaving on screen a button that
    /// claims it will re-send the message — total loss, no error about it, and
    /// disguised as a recovery affordance. The queue flush never had this bug
    /// (`requeue_front` hands back the whole entry); only this typed path did.
    ///
    /// Guarded on both surfaces separately, because the bug was on both and the
    /// fix has to stay on both: the phone twin is
    /// `platform::phone::chat::composer`'s `failed_send_restores_the_tray`.
    fn failed_send_restores_the_tray(src: &str) -> bool {
        let Some(body) = typed_send_body(src) else {
            return false;
        };
        body.contains("set_send_error") && body.contains("seed_draft(")
    }

    #[test]
    fn a_failed_send_gives_the_attachments_back() {
        assert!(
            failed_send_restores_the_tray(include_str!("mod.rs")),
            "a failed desktop send no longer restores the tray — the files are \
             destroyed behind a Retry button that only rebuilds the text"
        );
    }

    /// RED proof: the shape this file had, where the error arm only reported.
    #[test]
    fn restore_check_rejects_an_error_arm_that_only_reports() {
        let before = r"
            let send_message = move || {
                let files = attachments.get_untracked();
                attachments.set(Vec::new());
                spawn_local(async move {
                    match ChatApi::send(&dash).await {
                        Ok(resp) => chat.session_key.set(Some(resp.session_key)),
                        Err(e) => {
                            chat.set_send_error(ChatSendError::classify(e));
                        }
                    }
                });
            };
    // The question this conversation";
        assert!(!failed_send_restores_the_tray(before));
    }

    /// …and the region scrape must actually find the send. Without this the
    /// check above passes vacuously the day `send_message` is renamed.
    #[test]
    fn the_region_scrape_finds_the_typed_send() {
        let body = typed_send_body(include_str!("mod.rs"))
            .expect("could not locate the typed send — the guard is not looking at it");
        assert!(
            body.contains("ChatApi::send("),
            "the scraped region is not the send path"
        );
    }

    // --- Team chat attachment rejection preserves the tray (T1.7) -----
    //
    // `teams.chat.send` carries only `{team_id, message}` — there is no
    // attachment leg on the group transcript. When the user typed a
    // message, attached a file, and hit Enter in a group conversation, the
    // tray used to be cleared *before* the team branch ran, so the file
    // vanished with no reply and no error. The fix refuses the send and
    // returns early so the tray survives — mirroring the single-chat
    // `failed_send_restores_the_tray` pattern. This guard pins the wiring
    // so a future reorder can't silently regress it.
    //
    // The path is on the wasm-only `csr` build and is structurally
    // untestable via render-to-HTML (see the A1 report's parked blocker),
    // so the check is textual — same L1-bound style as the guards above.

    /// Locate the team-attachment rejection block. Returns the text
    /// between the opening `if chat.team_id...` line and the matching
    /// closing brace `}`. The block must surface `set_send_error` and
    /// must NOT touch `attachments` — those are the two halves of T1.7.
    fn team_rejection_block(src: &str) -> Option<&str> {
        let body = typed_send_body(src)?;
        // Open at the team-attachment guard's `if` and find the matching
        // close. Walk braces because the call body contains a multi-line
        // `set_send_error(...)` invocation.
        let open_idx =
            body.find("if chat.team_id.get_untracked().is_some() && !files.is_empty()")?;
        let after_if = &body[open_idx..];
        let after_open_brace = after_if.find('{')?;
        let bytes = after_if.as_bytes();
        let mut depth: i32 = 0;
        let mut close_offset = None;
        for (i, &b) in bytes[after_open_brace..].iter().enumerate() {
            match b {
                b'{' => depth += 1,
                b'}' => {
                    depth -= 1;
                    if depth == 0 {
                        close_offset = Some(i);
                        break;
                    }
                }
                _ => {}
            }
        }
        let close = close_offset?;
        // The block we care about is between the `{` and the matching `}`.
        let block_start = after_open_brace + 1;
        let block_end = after_open_brace + close;
        Some(&after_if[block_start..block_end])
    }

    /// The team-attachment rejection path must (a) recognise the
    /// `team_id.is_some() && !files.is_empty()` shape, (b) surface a user-
    /// visible error via `set_send_error`, and (c) NOT clear attachments
    /// before returning. The check on (c) is the whole point of T1.7.
    fn team_attachment_rejection_preserves_tray(src: &str) -> bool {
        let Some(block) = team_rejection_block(src) else {
            return false;
        };
        // (b) — user-visible error is reported.
        if !block.contains("set_send_error(") {
            return false;
        }
        // (c) — the tray must NOT be cleared inside the rejection block.
        // Any `attachments.set(...)` call before the early `return` would
        // drop the user's file before they see the banner.
        !block.contains("attachments.set(")
    }

    #[test]
    fn team_chat_attachment_rejection_preserves_the_tray() {
        assert!(
            team_attachment_rejection_preserves_tray(include_str!("mod.rs")),
            "team-attachment rejection in the typed-send path no longer \
             preserves the tray — a file attached to a group message will \
             vanish on Enter with only a refusal banner left behind"
        );
    }

    /// RED proof: the bug shape. The team guard reports the error but
    /// also clears the tray before the early `return`, so the file is
    /// dropped before the user sees anything.
    #[test]
    fn team_rejection_check_rejects_tray_clear_before_early_return() {
        let before = r"
            let send_message = move || {
                let files = attachments.get_untracked();
                if chat.team_id.get_untracked().is_some() && !files.is_empty() {
                    chat.set_send_error(ChatSendError::new(
                        ChatSendErrorCode::Unsupported,
                        t_string!(i18n, chat.team_attachments_unsupported).to_string(),
                    ));
                    attachments.set(Vec::new());
                    return;
                }
                is_sending.set(true);
                input_text.set(String::new());
                attachments.set(Vec::new());
                chat.push_user_message(&text);
    // The question this conversation";
        assert!(!team_attachment_rejection_preserves_tray(before));
    }

    /// …and the brace-matcher must actually find the team guard. Without
    /// this, the green test above passes vacuously the day the helper
    /// stops locating the rejection block.
    #[test]
    fn the_team_rejection_block_scrape_finds_the_guard() {
        let block = team_rejection_block(include_str!("mod.rs"))
            .expect("could not locate the team-attachment guard block");
        assert!(
            block.contains("set_send_error("),
            "scraped block is not the team-attachment rejection"
        );
        assert!(
            block.contains("return;"),
            "scraped block is not the team-attachment rejection"
        );
    }

    // --- IME composition gate (T1.2) production wiring guard ----------
    //
    // The unit tests in `ime_tests` cover the pure-logic seam; this guard
    // pins the production wiring (composition listeners + Enter gate) so
    // the seam cannot pass without it. Mirrors the source-pattern style of
    // `failed_send_restores_the_tray`: the wiring is on the wasm-only
    // `csr` path and is structurally untestable via render-to-HTML
    // (see A1's parked blocker), so a textual check is the best L1-bound
    // guarantee we can give.
    fn production_half_ime(src: &str) -> &str {
        src.split("#[cfg").next().unwrap_or(src)
    }

    fn has_composition_listener(src: &str, event: &str) -> bool {
        let needle = format!("on:composition{event}=");
        production_half_ime(src).contains(&needle)
    }

    fn enter_branch_is_gated(src: &str) -> bool {
        // The Enter branch must consult `should_suppress_enter` *before*
        // touching `send_message` / `enqueue_message`. The gate sits at
        // the top of `on_keydown` and returns early, so the source must
        // reference both `should_suppress_enter` and the conditional Enter
        // dispatch.
        let body = production_half_ime(src);
        body.contains("should_suppress_enter(") && body.contains("ev.key() == \"Enter\"")
    }

    #[test]
    fn the_composer_wires_compositionstart_listener() {
        assert!(
            has_composition_listener(include_str!("mod.rs"), "start"),
            "composer lost its compositionstart listener — Chinese IME \
             composition will never be marked active"
        );
    }

    #[test]
    fn the_composer_wires_compositionend_listener() {
        assert!(
            has_composition_listener(include_str!("mod.rs"), "end"),
            "composer lost its compositionend listener — trailing \
             keydown(Enter) from a Chinese IME candidate commit will \
             dispatch send_message (regression of T1.2)"
        );
    }

    #[test]
    fn the_composer_gates_enter_through_should_suppress_enter() {
        assert!(
            enter_branch_is_gated(include_str!("mod.rs")),
            "composer Enter branch no longer consults should_suppress_enter \
             — IME trailing Enter will dispatch send_message (regression \
             of T1.2)"
        );
    }

    // --- Theme command bypasses empty palette results ------------------
    //
    // `/theme dark` and `/theme list` are complete local commands, but the
    // filtered slash catalogue has no row for their full argument text. Pin
    // the production keyboard path, not just `parse_theme_request`, so a
    // future palette edit cannot swallow Enter before `intercept_theme`.
    fn palette_enter_intercepts_theme_before_selection(src: &str) -> bool {
        let body = production_half(src);
        let Some(palette) = body
            .split_once("if show_palette.get_untracked() {")
            .map(|(_, r)| r)
        else {
            return false;
        };
        let Some(enter) = palette
            .split_once("if ev.key() == \"Enter\"")
            .map(|(_, r)| r)
        else {
            return false;
        };
        let Some(selection) = enter.find("select_palette_entry(") else {
            return false;
        };
        let Some(intercept) = enter.find("intercept_theme(") else {
            return false;
        };
        intercept < selection
            && enter[..intercept].contains("!ev.shift_key()")
            && enter[..selection].contains("ev.prevent_default()")
    }

    #[test]
    fn palette_enter_routes_complete_theme_commands_to_picker_first() {
        assert!(
            palette_enter_intercepts_theme_before_selection(include_str!("mod.rs")),
            "palette Enter no longer routes complete /theme commands through \
             intercept_theme before selecting an empty filtered entry list"
        );
    }

    #[test]
    fn palette_theme_guard_keeps_shift_enter_as_newline() {
        let src = production_half(include_str!("mod.rs"));
        let palette = src
            .split_once("if show_palette.get_untracked() {")
            .map(|(_, rest)| rest)
            .expect("could not locate slash palette branch");
        let guard = palette
            .split_once("if ev.key() == \"Enter\"")
            .and_then(|(_, rest)| rest.split_once("let entries = palette_entries"))
            .map(|(guard, _)| guard)
            .expect("could not locate palette theme Enter guard");
        assert!(guard.contains("!ev.shift_key()"));
    }
}

// --- IME composition gate (T1.2) -----------------------------------------
//
// Chinese IME (pinyin, wubi, …) keeps a `compositionstart`/`compositionend`
// session around its candidate window. When the user picks a candidate with
// Enter, browsers fire `compositionend` *and then* a `keydown(Enter)` with
// `isComposing` already cleared on the same tick — Enter reaches the
// composer with `isComposing == false`, and any send-on-Enter handler fires.
// The desktop composer previously had no composition listeners at all and
// would dispatch `send_message` on that trailing Enter.
//
// `ImeGate` is the pure-logic seam: it tracks composition lifecycle and
// answers `should_suppress_enter(now_ms)`. The production handler wires
// DOM `compositionstart`/`compositionend` into `on_composition_start` /
// `on_composition_end`, and gates `Enter` on `should_suppress_enter`. The
// unit tests below exercise the seam without rendering Leptos (the panel is
// `csr`-only; render-to-HTML is structurally unavailable — see the A1
// report's parked blocker).
//
// The 100ms "recently settled" window covers the trailing keydown that
// browsers emit *after* `compositionend`. Without it, the seam would still
// fire send on the same keypress the IME just emitted.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
struct ImeGate {
    composition_active: bool,
    last_composition_end_ms: Option<u64>,
}

impl ImeGate {
    /// Length of the "recently settled" window after `compositionend`. The
    /// value is calibrated to the trailing-Enter pattern (browser fires
    /// `compositionend` then `keydown(Enter)` on the same tick) with margin
    /// for the IME's own intra-window delay before bubbling Enter.
    const SETTLED_WINDOW_MS: u64 = 100;

    fn new() -> Self {
        Self::default()
    }

    fn on_composition_start(&mut self) {
        self.composition_active = true;
    }

    fn on_composition_end(&mut self, now_ms: u64) {
        self.composition_active = false;
        self.last_composition_end_ms = Some(now_ms);
    }

    /// Returns `true` when the trailing Enter from an IME candidate commit
    /// should *not* trigger send. Three reasons to suppress:
    /// 1. Composition is still active (Enter confirms a partial candidate).
    /// 2. Composition just ended and we are inside the 100ms "recently
    ///    settled" window — the browser's trailing `keydown(Enter)` falls
    ///    here.
    /// 3. (covered by 2) The Enter that closed the composition is the very
    ///    event the gate is screening; with the window we swallow it.
    fn should_suppress_enter(&self, now_ms: u64) -> bool {
        if self.composition_active {
            return true;
        }
        match self.last_composition_end_ms {
            Some(t) => now_ms.saturating_sub(t) < Self::SETTLED_WINDOW_MS,
            None => false,
        }
    }
}

#[cfg(test)]
mod ime_tests {
    use super::ImeGate;

    /// Enter pressed while the IME candidate window is still open (user
    /// confirming a partial pinyin like "zhong" → should commit the partial
    /// candidate to the textarea, not send).
    #[test]
    fn enter_during_active_composition_does_not_send() {
        let mut g = ImeGate::new();
        g.on_composition_start();
        assert!(g.should_suppress_enter(0));
        assert!(g.should_suppress_enter(50));
        assert!(g.should_suppress_enter(99));
    }

    /// The browser's trailing keydown(Enter) after compositionend arrives on
    /// the same tick. Suppressing Enter inside the 100ms "recently settled"
    /// window fixes T1.2.
    #[test]
    fn enter_within_100ms_of_composition_end_does_not_send() {
        let mut g = ImeGate::new();
        g.on_composition_start();
        g.on_composition_end(1_000);
        assert!(g.should_suppress_enter(1_000)); // same tick
        assert!(g.should_suppress_enter(1_050)); // 50ms after end
        assert!(g.should_suppress_enter(1_099)); // 99ms after end (boundary)
    }

    /// Past the 100ms window the trailing-Enter pattern no longer applies —
    /// the next Enter is a real send.
    #[test]
    fn enter_after_100ms_of_composition_end_sends() {
        let mut g = ImeGate::new();
        g.on_composition_start();
        g.on_composition_end(1_000);
        // 100ms exactly: <, not <= — the window is "strictly less than 100ms".
        assert!(!g.should_suppress_enter(1_100));
        assert!(!g.should_suppress_enter(1_150));
        assert!(!g.should_suppress_enter(2_000));
    }

    /// Boundary: equal-to-window is *outside* (suppress at t=99, allow at
    /// t=100). Pins the strict-less-than semantics so a future "use `<=`"
    /// drive-by doesn't silently widen the swallow.
    #[test]
    fn settled_window_is_strict_less_than_100ms() {
        let mut g = ImeGate::new();
        g.on_composition_start();
        g.on_composition_end(500);
        assert!(g.should_suppress_enter(599)); // 99ms — still inside
        assert!(!g.should_suppress_enter(600)); // 100ms — outside
    }

    /// Plain (non-IME) Enter: no compositionstart ever fired → gate is
    /// transparent. Pinned so the gate cannot accidentally swallow a normal
    /// send on a fresh page load.
    #[test]
    fn enter_without_any_composition_sends() {
        let g = ImeGate::new();
        assert!(!g.should_suppress_enter(0));
        assert!(!g.should_suppress_enter(1_000_000));
    }

    /// After a settled window expires, a *new* composition cycle still works:
    /// the trailing-Enter suppression re-arms for the next IME session.
    #[test]
    fn second_composition_cycle_suppresses_again() {
        let mut g = ImeGate::new();
        g.on_composition_start();
        g.on_composition_end(1_000);
        // 200ms later — first window expired, Enter sends.
        assert!(!g.should_suppress_enter(1_200));
        // New IME session: compositionstart + compositionend at t=2000.
        g.on_composition_start();
        assert!(g.should_suppress_enter(2_050)); // active
        g.on_composition_end(2_000);
        assert!(g.should_suppress_enter(2_050)); // 50ms after end — inside
        assert!(!g.should_suppress_enter(2_200)); // 200ms after — outside
    }
}
